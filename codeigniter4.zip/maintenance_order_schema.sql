-- ============================================
-- MAINTENANCE ORDER MODULE - GRADE A+ SYSTEM
-- ============================================

-- Main Maintenance Orders Table
CREATE TABLE IF NOT EXISTS `maintenance_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `order_type` enum('preventive','corrective','breakdown','inspection','modification','calibration') NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `asset_id` int(11) DEFAULT NULL,
  `asset_type` enum('machine','part','assembly','facility') DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `priority` enum('low','medium','high','critical','emergency') DEFAULT 'medium',
  `status` enum('draft','pending','approved','assigned','in_progress','on_hold','completed','cancelled','closed') DEFAULT 'pending',
  `failure_type` varchar(100) DEFAULT NULL,
  `failure_code` varchar(50) DEFAULT NULL,
  `downtime_impact` enum('none','low','medium','high','critical') DEFAULT 'none',
  `safety_risk` tinyint(1) DEFAULT 0,
  `requested_by` int(11) DEFAULT NULL,
  `requested_date` datetime DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_date` datetime DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `assigned_team` varchar(100) DEFAULT NULL,
  `assigned_date` datetime DEFAULT NULL,
  `scheduled_start` datetime DEFAULT NULL,
  `scheduled_end` datetime DEFAULT NULL,
  `actual_start` datetime DEFAULT NULL,
  `actual_end` datetime DEFAULT NULL,
  `estimated_hours` decimal(10,2) DEFAULT NULL,
  `actual_hours` decimal(10,2) DEFAULT NULL,
  `estimated_cost` decimal(12,2) DEFAULT NULL,
  `actual_cost` decimal(12,2) DEFAULT NULL,
  `labor_cost` decimal(12,2) DEFAULT 0.00,
  `parts_cost` decimal(12,2) DEFAULT 0.00,
  `external_cost` decimal(12,2) DEFAULT 0.00,
  `completion_notes` text,
  `root_cause` text,
  `corrective_action` text,
  `preventive_action` text,
  `attachments` text,
  `parent_order_id` int(11) DEFAULT NULL,
  `pm_task_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `order_type` (`order_type`),
  KEY `asset_id` (`asset_id`),
  KEY `assigned_to` (`assigned_to`),
  KEY `scheduled_start` (`scheduled_start`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Labor/Technician Time Tracking
CREATE TABLE IF NOT EXISTS `maintenance_order_labor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_order_id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL,
  `technician_name` varchar(255) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `hours_worked` decimal(10,2) DEFAULT NULL,
  `hourly_rate` decimal(10,2) DEFAULT NULL,
  `labor_cost` decimal(12,2) DEFAULT NULL,
  `work_description` text,
  `break_time_minutes` int(11) DEFAULT 0,
  `overtime_hours` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `maintenance_order_id` (`maintenance_order_id`),
  KEY `technician_id` (`technician_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Spare Parts Usage
CREATE TABLE IF NOT EXISTS `maintenance_order_parts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_order_id` int(11) NOT NULL,
  `part_id` int(11) NOT NULL,
  `part_name` varchar(255) DEFAULT NULL,
  `part_number` varchar(100) DEFAULT NULL,
  `quantity_required` decimal(10,2) NOT NULL,
  `quantity_used` decimal(10,2) DEFAULT NULL,
  `unit_cost` decimal(12,2) DEFAULT NULL,
  `total_cost` decimal(12,2) DEFAULT NULL,
  `warehouse_location` varchar(100) DEFAULT NULL,
  `issued_by` int(11) DEFAULT NULL,
  `issued_date` datetime DEFAULT NULL,
  `return_quantity` decimal(10,2) DEFAULT 0.00,
  `status` enum('requested','reserved','issued','returned','cancelled') DEFAULT 'requested',
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `maintenance_order_id` (`maintenance_order_id`),
  KEY `part_id` (`part_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Maintenance Checklist
CREATE TABLE IF NOT EXISTS `maintenance_order_checklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_order_id` int(11) NOT NULL,
  `item_description` varchar(500) NOT NULL,
  `item_order` int(11) DEFAULT 1,
  `category` varchar(100) DEFAULT NULL,
  `is_mandatory` tinyint(1) DEFAULT 0,
  `is_completed` tinyint(1) DEFAULT 0,
  `completed_by` int(11) DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `result` enum('pass','fail','na') DEFAULT NULL,
  `measurement_value` varchar(100) DEFAULT NULL,
  `expected_value` varchar(100) DEFAULT NULL,
  `notes` text,
  `photo_url` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `maintenance_order_id` (`maintenance_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Work Log/Activity History
CREATE TABLE IF NOT EXISTS `maintenance_order_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_order_id` int(11) NOT NULL,
  `log_type` enum('status_change','assignment','comment','attachment','measurement','issue') DEFAULT 'comment',
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `old_value` varchar(500) DEFAULT NULL,
  `new_value` varchar(500) DEFAULT NULL,
  `comment` text,
  `is_internal` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `maintenance_order_id` (`maintenance_order_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- External Services/Contractors
CREATE TABLE IF NOT EXISTS `maintenance_order_external_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_order_id` int(11) NOT NULL,
  `vendor_name` varchar(255) NOT NULL,
  `vendor_contact` varchar(255) DEFAULT NULL,
  `service_type` varchar(100) DEFAULT NULL,
  `service_description` text,
  `po_number` varchar(100) DEFAULT NULL,
  `estimated_cost` decimal(12,2) DEFAULT NULL,
  `actual_cost` decimal(12,2) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `status` enum('requested','approved','in_progress','completed','cancelled') DEFAULT 'requested',
  `invoice_number` varchar(100) DEFAULT NULL,
  `payment_status` enum('pending','paid','overdue') DEFAULT 'pending',
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `maintenance_order_id` (`maintenance_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Downtime Tracking
CREATE TABLE IF NOT EXISTS `maintenance_order_downtime` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maintenance_order_id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `downtime_start` datetime NOT NULL,
  `downtime_end` datetime DEFAULT NULL,
  `duration_minutes` int(11) DEFAULT NULL,
  `downtime_type` enum('planned','unplanned') DEFAULT 'unplanned',
  `production_loss_units` decimal(10,2) DEFAULT NULL,
  `production_loss_value` decimal(12,2) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `maintenance_order_id` (`maintenance_order_id`),
  KEY `asset_id` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Failure Codes Library
CREATE TABLE IF NOT EXISTS `failure_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `severity` enum('minor','moderate','major','critical') DEFAULT 'moderate',
  `typical_resolution_time` int(11) DEFAULT NULL COMMENT 'in minutes',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Maintenance Order Templates
CREATE TABLE IF NOT EXISTS `maintenance_order_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(255) NOT NULL,
  `order_type` enum('preventive','corrective','breakdown','inspection','modification','calibration') NOT NULL,
  `description` text,
  `estimated_hours` decimal(10,2) DEFAULT NULL,
  `checklist_items` text COMMENT 'JSON array',
  `required_skills` text COMMENT 'JSON array',
  `required_parts` text COMMENT 'JSON array',
  `safety_requirements` text,
  `is_active` tinyint(1) DEFAULT 1,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample Failure Codes
INSERT INTO `failure_codes` (`code`, `description`, `category`, `severity`, `typical_resolution_time`) VALUES
('MECH-001', 'Bearing Failure', 'Mechanical', 'major', 240),
('MECH-002', 'Belt Breakage', 'Mechanical', 'moderate', 120),
('MECH-003', 'Shaft Misalignment', 'Mechanical', 'major', 180),
('MECH-004', 'Gear Wear', 'Mechanical', 'moderate', 300),
('ELEC-001', 'Motor Failure', 'Electrical', 'critical', 360),
('ELEC-002', 'Wiring Issue', 'Electrical', 'moderate', 90),
('ELEC-003', 'Sensor Malfunction', 'Electrical', 'minor', 60),
('ELEC-004', 'Control Panel Fault', 'Electrical', 'major', 240),
('HYDR-001', 'Hydraulic Leak', 'Hydraulic', 'major', 180),
('HYDR-002', 'Pump Failure', 'Hydraulic', 'critical', 300),
('HYDR-003', 'Valve Stuck', 'Hydraulic', 'moderate', 120),
('PNEU-001', 'Air Leak', 'Pneumatic', 'minor', 60),
('PNEU-002', 'Compressor Failure', 'Pneumatic', 'critical', 480),
('LUBR-001', 'Oil Contamination', 'Lubrication', 'moderate', 90),
('LUBR-002', 'Insufficient Lubrication', 'Lubrication', 'minor', 45),
('COOL-001', 'Coolant Leak', 'Cooling', 'moderate', 120),
('COOL-002', 'Overheating', 'Cooling', 'major', 180),
('SAFE-001', 'Safety Guard Damaged', 'Safety', 'critical', 60),
('SAFE-002', 'Emergency Stop Failure', 'Safety', 'critical', 30),
('SOFT-001', 'PLC Programming Error', 'Software', 'major', 240);cal_resolution_time`) VALUES
('MECH-001', 'Bearing Failure', 'Mechanical', 'major', 240),
('ELEC-001', 'Motor Overheating', 'Electrical', 'major', 180),
('HYDR-001', 'Hydraulic Leak', 'Hydraulic', 'moderate', 120),
('PNEU-001', 'Air Pressure Loss', 'Pneumatic', 'moderate', 90),
('LUBR-001', 'Lubrication System Failure', 'Lubrication', 'major', 150),
('SENS-001', 'Sensor Malfunction', 'Instrumentation', 'minor', 60),
('BELT-001', 'Belt Wear/Breakage', 'Mechanical', 'moderate', 90),
('SEAL-001', 'Seal Deterioration', 'Mechanical', 'minor', 120),
('WIRE-001', 'Wiring Damage', 'Electrical', 'moderate', 120),
('CTRL-001', 'Control System Error', 'Control', 'major', 180);
