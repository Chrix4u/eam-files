# EAM API Testing Guide

## Quick Start

### 1. Run Migrations
```bash
php spark migrate
```

### 2. Seed Test Data
```bash
php spark db:seed EamTestDataSeeder
```

### 3. Test Credentials
- **Admin**: username: `admin`, password: `admin123`
- **Technician**: username: `technician1`, password: `tech123`
- **Planner**: username: `planner1`, password: `plan123`

## API Base URL
```
http://localhost/factorymanager/api/v1/eam
```

## Testing Workflow

### Step 1: Authentication

**Login**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/auth/login \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"admin\",\"password\":\"admin123\"}"
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "user": {
      "id": 1,
      "username": "admin",
      "email": "admin@factory.com"
    }
  }
}
```

**Save the token** - Use it in all subsequent requests as:
```
Authorization: Bearer {token}
```

### Step 2: Test Asset Hierarchy

**List Facilities**
```bash
curl -X GET http://localhost/factorymanager/api/v1/eam/facilities \
  -H "Authorization: Bearer {token}"
```

**Create New Facility**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/facilities \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"facility_code\":\"FAC003\",\"facility_name\":\"Warehouse\",\"location\":\"Building C\"}"
```

**Get Systems in Facility**
```bash
curl -X GET "http://localhost/factorymanager/api/v1/eam/systems?facility_id=1" \
  -H "Authorization: Bearer {token}"
```

**Get Equipment in System**
```bash
curl -X GET "http://localhost/factorymanager/api/v1/eam/equipment?system_id=1" \
  -H "Authorization: Bearer {token}"
```

### Step 3: Test Preventive Maintenance

**List PM Rules**
```bash
curl -X GET http://localhost/factorymanager/api/v1/eam/pm-rules \
  -H "Authorization: Bearer {token}"
```

**Create PM Rule**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/pm-rules \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"rule_name\":\"Quarterly Equipment Check\",\"asset_type\":\"equipment\",\"asset_id\":1,\"frequency_type\":\"monthly\",\"frequency_value\":3,\"estimated_duration\":180,\"priority\":\"high\"}"
```

**Generate PM Schedules**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/pm-schedules/generate \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"rule_id\":1,\"start_date\":\"2025-01-01\",\"end_date\":\"2025-12-31\"}"
```

**Get Asset PM Schedules**
```bash
curl -X GET "http://localhost/factorymanager/api/v1/eam/pm-schedules/1?asset_type=equipment" \
  -H "Authorization: Bearer {token}"
```

### Step 4: Test Work Orders

**List Work Orders**
```bash
curl -X GET http://localhost/factorymanager/api/v1/eam/work-orders \
  -H "Authorization: Bearer {token}"
```

**Create Work Order**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/work-orders \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"title\":\"Emergency Repair\",\"description\":\"Motor overheating\",\"asset_type\":\"equipment\",\"asset_id\":1,\"priority\":\"high\",\"scheduled_date\":\"2025-01-15\"}"
```

**Assign Work Order**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/work-orders/1/assign \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"assigned_to\":2}"
```

**Complete Work Order**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/work-orders/1/complete \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"completion_notes\":\"Replaced motor bearings\",\"actual_duration\":90}"
```

### Step 5: Test Inventory

**List Inventory**
```bash
curl -X GET http://localhost/factorymanager/api/v1/eam/inventory \
  -H "Authorization: Bearer {token}"
```

**Create Inventory Item**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/inventory \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"part_number\":\"PART003\",\"part_name\":\"Bearing\",\"category\":\"Mechanical\",\"unit_of_measure\":\"EA\",\"unit_price\":45.00,\"quantity_on_hand\":20,\"reorder_point\":5}"
```

**Stock In**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/inventory/stock-in \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"inventory_id\":1,\"quantity\":10,\"reference_number\":\"PO-2025-001\",\"notes\":\"Received from supplier\"}"
```

**Stock Out**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/inventory/stock-out \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"inventory_id\":1,\"quantity\":2,\"reference_number\":\"WO-2025-001\",\"notes\":\"Used for CNC maintenance\"}"
```

**Reserve for Work Order**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/inventory/reserve \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"inventory_id\":2,\"quantity\":1,\"work_order_id\":1}"
```

### Step 6: Test User Management

**List Users**
```bash
curl -X GET http://localhost/factorymanager/api/v1/eam/users \
  -H "Authorization: Bearer {token}"
```

**Create User**
```bash
curl -X POST http://localhost/factorymanager/api/v1/eam/users \
  -H "Authorization: Bearer {token}" \
  -H "Content-Type: application/json" \
  -d "{\"username\":\"supervisor1\",\"email\":\"supervisor@factory.com\",\"password\":\"super123\",\"full_name\":\"Bob Supervisor\"}"
```

## Postman Collection

### Import Steps:
1. Open Postman
2. Click "Import"
3. Create new collection "EAM API"
4. Add environment variables:
   - `base_url`: `http://localhost/factorymanager/api/v1/eam`
   - `token`: (will be set after login)

### Collection Structure:
```
EAM API/
├── Auth/
│   ├── Login
│   ├── Logout
│   └── Refresh Token
├── Facilities/
│   ├── List Facilities
│   ├── Get Facility
│   ├── Create Facility
│   ├── Update Facility
│   └── Delete Facility
├── Systems/
│   └── (same CRUD operations)
├── Equipment/
│   └── (same CRUD operations)
├── PM/
│   ├── List PM Rules
│   ├── Create PM Rule
│   ├── Generate Schedules
│   └── Get Asset Schedules
├── Work Orders/
│   ├── List Work Orders
│   ├── Create Work Order
│   ├── Assign Work Order
│   └── Complete Work Order
└── Inventory/
    ├── List Inventory
    ├── Stock In
    ├── Stock Out
    └── Reserve
```

## Common Query Parameters

### Pagination
```
?page=1&limit=20
```

### Search
```
?search=CNC
```

### Filtering
```
?facility_id=1
?status=open
?priority=high
```

### Sorting
```
?sort=created_at&order=desc
```

## Response Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `500` - Server Error

## Testing Checklist

### Authentication
- [ ] Login with valid credentials
- [ ] Login with invalid credentials
- [ ] Refresh token
- [ ] Logout

### Asset Hierarchy
- [ ] Create facility
- [ ] List facilities with pagination
- [ ] Update facility
- [ ] Create system under facility
- [ ] Create equipment under system
- [ ] Delete asset (check cascade)

### Preventive Maintenance
- [ ] Create PM rule
- [ ] Generate schedules for 1 year
- [ ] View generated schedules
- [ ] Update PM rule
- [ ] Deactivate PM rule

### Work Orders
- [ ] Create work order
- [ ] Assign to technician
- [ ] Update status
- [ ] Complete work order
- [ ] Filter by status/priority
- [ ] Search work orders

### Inventory
- [ ] Create inventory item
- [ ] Stock in transaction
- [ ] Stock out transaction
- [ ] Reserve for work order
- [ ] Check quantity updates
- [ ] View transaction history

### User Management
- [ ] Create user
- [ ] Update user
- [ ] Deactivate user
- [ ] Assign role
- [ ] Test permissions

## Troubleshooting

### Token Issues
- Ensure token is in `Authorization: Bearer {token}` format
- Check token expiration (default 1 hour)
- Use refresh endpoint to get new token

### Database Issues
- Run migrations: `php spark migrate`
- Reset database: `php spark migrate:rollback` then `php spark migrate`
- Check database connection in `.env`

### CORS Issues
- Enable CORS filter in `app/Config/Filters.php`
- Check allowed origins in `app/Config/Cors.php`

### 404 Errors
- Verify routes in `app/Config/RoutesEam.php`
- Check base URL configuration
- Ensure mod_rewrite is enabled

## Next Steps

1. **Frontend Integration**
   - Build dashboard UI
   - Create asset management screens
   - Implement work order interface

2. **Advanced Features**
   - File attachments for work orders
   - Email notifications
   - Mobile app integration
   - Reporting & analytics

3. **Performance Optimization**
   - Add caching layer
   - Optimize database queries
   - Implement rate limiting

4. **Security Enhancements**
   - Add API rate limiting
   - Implement audit logging
   - Add two-factor authentication
