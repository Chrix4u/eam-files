# 🚀 Quick Setup Guide - Inventory & Material Request System

## Step 1: Run Database Migrations

```bash
cd c:\wamp64\www\factorymanager
php spark migrate
```

This creates:
- material_requests
- material_request_items
- stock_transactions
- asset_inventory_links

---

## Step 2: Add API Routes

Edit `app/Config/Routes.php`, add inside the `api/v1/eam` group:

```php
// Material Requests
$routes->get('material-requests', 'MaterialRequestController::index');
$routes->post('material-requests', 'MaterialRequestController::create');
$routes->post('material-requests/(:num)/approve', 'MaterialRequestController::approve/$1');
$routes->post('material-requests/(:num)/reject', 'MaterialRequestController::reject/$1');
$routes->post('material-requests/(:num)/issue', 'MaterialRequestController::issue/$1');
```

---

## Step 3: Test the System

### As Technician:
1. Login as technician
2. Go to `/technician/parts-request`
3. Create a material request
4. Add items using SearchableSelect
5. Submit

### As Stock Manager:
1. Login as admin/shop-attendant
2. Check database: `SELECT * FROM material_requests`
3. See pending request

---

## Step 4: Verify Files

### Backend Files Created:
- ✅ `app/Controllers/Api/V1/MaterialRequestController.php`
- ✅ `app/Models/MaterialRequestModel.php`
- ✅ `app/Models/MaterialRequestItemModel.php`
- ✅ `app/Models/StockTransactionModel.php`
- ✅ `app/Models/AssetInventoryLinkModel.php`
- ✅ `app/Database/Migrations/2025-01-23-000002_CreateMaterialRequestSystem.php`

### Frontend Files Updated:
- ✅ `src/app/technician/parts-request/page.tsx`

---

## Step 5: Next Development

Create stock manager approval page at:
`src/app/admin/inventory/approvals/page.tsx`

Or use the existing inventory page and add approval features.

---

## 🎯 Quick Test

```sql
-- Check if tables exist
SHOW TABLES LIKE 'material_%';
SHOW TABLES LIKE 'stock_transactions';
SHOW TABLES LIKE 'asset_inventory_links';

-- Test data
SELECT * FROM material_requests;
SELECT * FROM material_request_items;
```

---

## 📞 Support

See `INVENTORY_IMPLEMENTATION_SUMMARY.md` for complete documentation.

**Status**: Ready to Deploy ✅
