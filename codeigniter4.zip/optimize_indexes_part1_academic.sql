-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 1: ACADEMIC TABLES
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- MARK TABLE
ALTER TABLE `mark` ADD INDEX IF NOT EXISTS `idx_student_exam` (`student_id`, `exam_id`, `class_id`, `section_id`);
ALTER TABLE `mark` ADD INDEX IF NOT EXISTS `idx_year_term` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `mark` ADD INDEX IF NOT EXISTS `idx_subject_exam` (`subject_id`, `exam_id`, `class_id`);
ALTER TABLE `mark` ADD INDEX IF NOT EXISTS `idx_class_section_exam` (`class_id`, `section_id`, `exam_id`);
ALTER TABLE `mark` ADD INDEX IF NOT EXISTS `idx_status` (`status`);
ALTER TABLE `mark` ADD INDEX IF NOT EXISTS `idx_mute` (`mute`);

-- AGGREGATION TABLE
ALTER TABLE `aggregation` ADD INDEX IF NOT EXISTS `idx_student_exam_agg` (`student_id`, `exam_id`, `class_id`, `section_id`);
ALTER TABLE `aggregation` ADD INDEX IF NOT EXISTS `idx_year_term_agg` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `aggregation` ADD INDEX IF NOT EXISTS `idx_class_section_agg` (`class_id`, `section_id`, `exam_id`);
ALTER TABLE `aggregation` ADD INDEX IF NOT EXISTS `idx_aggregate_mark` (`aggregate_mark`);
ALTER TABLE `aggregation` ADD INDEX IF NOT EXISTS `idx_raw_score` (`raw_score`);

-- ENROLL TABLE
ALTER TABLE `enroll` ADD INDEX IF NOT EXISTS `idx_student_class_enroll` (`student_id`, `class_id`, `section_id`);
ALTER TABLE `enroll` ADD INDEX IF NOT EXISTS `idx_year_term_enroll` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `enroll` ADD INDEX IF NOT EXISTS `idx_status_enroll` (`status`);
ALTER TABLE `enroll` ADD INDEX IF NOT EXISTS `idx_roll` (`roll`);
ALTER TABLE `enroll` ADD INDEX IF NOT EXISTS `idx_mute_enroll` (`mute`);
ALTER TABLE `enroll` ADD INDEX IF NOT EXISTS `idx_class_section_year` (`class_id`, `section_id`, `year`(50), `term`(50));

-- EXAM TABLE
ALTER TABLE `exam` ADD INDEX IF NOT EXISTS `idx_year_term_exam` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `exam` ADD INDEX IF NOT EXISTS `idx_category` (`category_id`);
ALTER TABLE `exam` ADD INDEX IF NOT EXISTS `idx_date` (`date`(50));

-- STUDENT TABLE
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_parent` (`parent_id`);
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_active_status` (`active_status`);
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_student_code` (`student_code`(50));
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_dormitory` (`dormitory_id`);
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_transport` (`transport_id`);
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_mute_student` (`mute`);
ALTER TABLE `student` ADD INDEX IF NOT EXISTS `idx_email_student` (`email`(100));

-- SUBJECT TABLE
ALTER TABLE `subject` ADD INDEX IF NOT EXISTS `idx_class_teacher` (`class_id`, `teacher_id`);
ALTER TABLE `subject` ADD INDEX IF NOT EXISTS `idx_year_term_subject` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `subject` ADD INDEX IF NOT EXISTS `idx_status_subject` (`status`);

-- CLASS TABLE
ALTER TABLE `class` ADD INDEX IF NOT EXISTS `idx_teacher` (`teacher_id`);
ALTER TABLE `class` ADD INDEX IF NOT EXISTS `idx_name_numeric` (`name_numeric`);

-- SECTION TABLE
ALTER TABLE `section` ADD INDEX IF NOT EXISTS `idx_class_section` (`class_id`, `teacher_id`);

-- GRADE TABLE
ALTER TABLE `grade` ADD INDEX IF NOT EXISTS `idx_mark_range` (`mark_from`, `mark_upto`);
ALTER TABLE `grade` ADD INDEX IF NOT EXISTS `idx_grade_point_numeric` (`grade_point_numeric`);

-- TEACHER TABLE
ALTER TABLE `teacher` ADD INDEX IF NOT EXISTS `idx_email` (`email`(100));
ALTER TABLE `teacher` ADD INDEX IF NOT EXISTS `idx_teacher_code` (`teacher_code`(50));
ALTER TABLE `teacher` ADD INDEX IF NOT EXISTS `idx_active_teacher` (`active_status`);
ALTER TABLE `teacher` ADD INDEX IF NOT EXISTS `idx_show_website` (`show_on_website`);

COMMIT;
