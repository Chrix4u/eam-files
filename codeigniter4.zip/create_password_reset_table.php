<?php
require 'vendor/autoload.php';

$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_token (token),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($db, $sql)) {
    echo "Table password_resets created successfully\n";
} else {
    echo "Error: " . mysqli_error($db);
}

// Add email column to users table if not exists
$checkEmail = mysqli_query($db, "SHOW COLUMNS FROM users LIKE 'email'");
if (mysqli_num_rows($checkEmail) == 0) {
    mysqli_query($db, "ALTER TABLE users ADD COLUMN email VARCHAR(255) AFTER username");
    echo "Email column added\n";
}

// Add remember_token column to users table if not exists
$checkToken = mysqli_query($db, "SHOW COLUMNS FROM users LIKE 'remember_token'");
if (mysqli_num_rows($checkToken) == 0) {
    mysqli_query($db, "ALTER TABLE users ADD COLUMN remember_token VARCHAR(255) AFTER password");
    echo "Remember token column added\n";
}

echo "Users table updated\n";

// Update admin user with email
mysqli_query($db, "UPDATE users SET email = 'admin@example.com' WHERE username = 'admin' AND email IS NULL");

mysqli_close($db);
