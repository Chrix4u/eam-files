<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS erp_sync_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entity_type ENUM('assets', 'work_orders', 'inventory') NOT NULL,
    sync_direction ENUM('push', 'pull', 'bidirectional') NOT NULL,
    frequency ENUM('hourly', 'daily', 'weekly') NOT NULL,
    time_of_day TIME NULL,
    day_of_week TINYINT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_run DATETIME NULL,
    next_run DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($db->query($sql)) {
    echo "✓ Table 'erp_sync_schedules' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$schedules = [
    ['assets', 'bidirectional', 'daily', '02:00', null],
    ['work_orders', 'bidirectional', 'hourly', null, null],
    ['inventory', 'pull', 'daily', '03:00', null]
];

foreach ($schedules as $s) {
    $stmt = $db->prepare("INSERT INTO erp_sync_schedules (entity_type, sync_direction, frequency, time_of_day, day_of_week) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $s[0], $s[1], $s[2], $s[3], $s[4]);
    $stmt->execute();
}

echo "✓ Inserted 3 default schedules\n";

$db->close();
?>
