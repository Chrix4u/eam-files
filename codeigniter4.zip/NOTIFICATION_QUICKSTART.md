# Notification System - Quick Start

## ✅ Files Created

### Backend (CodeIgniter 4)
- `app/Database/Migrations/2024-01-15-000001_CreateNotificationsTable.php`
- `app/Database/Migrations/2024-01-15-000002_CreateNotificationJobsTable.php`
- `app/Models/NotificationModel.php`
- `app/Models/NotificationJobModel.php`
- `app/Services/NotificationService.php`
- `app/Commands/NotificationWorker.php` (Queue processor)
- `app/Commands/CheckEscalations.php` (Cron job)
- `app/Controllers/Api/V1/NotificationController.php`
- `app/Config/Email.php`

### SQL Scripts
- `create_notification_jobs.sql` - Manual table creation
- `check_tables.sql` - Verify tables exist

### Test Scripts
- `test_notification_system.php` - Test notification sending

## 🚀 Setup Steps

### 1. Create Database Tables

**Option A: Using phpMyAdmin**
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Select `factorymanager` database
3. Go to SQL tab
4. Copy and paste from `create_notification_jobs.sql`
5. Click "Go"

**Option B: Using MySQL command line**
```bash
mysql -u root -p factorymanager < create_notification_jobs.sql
```

### 2. Configure Email (SMTP)

Edit `app/Config/Email.php`:

```php
public string $SMTPHost = 'smtp.gmail.com';
public string $SMTPUser = 'your-email@gmail.com';
public string $SMTPPass = 'your-app-password';  // Use App Password, not regular password
public int $SMTPPort = 587;
public string $SMTPCrypto = 'tls';
```

**Gmail App Password Setup:**
1. Go to Google Account → Security
2. Enable 2-Step Verification
3. Generate App Password
4. Use that password in SMTPPass

### 3. Test Notification System

```bash
cd C:\wamp64\www\factorymanager
php test_notification_system.php
```

This will:
- Send 2 test notifications
- Queue jobs in `notification_jobs` table
- Show pending jobs count

### 4. Start Notification Worker

```bash
# Start worker (processes queue)
php spark eam:worker

# Or run in background (Windows)
start /B php spark eam:worker
```

The worker will:
- Process pending jobs every 2 seconds
- Send in-app notifications (save to DB)
- Send emails via SMTP
- Send SMS via Twilio (if configured)
- Retry failed jobs up to 3 times

### 5. Setup Escalation Cron Job

**Windows Task Scheduler:**
1. Open Task Scheduler
2. Create Basic Task
3. Name: "EAM Escalations"
4. Trigger: Daily, repeat every 1 hour
5. Action: Start a program
   - Program: `C:\wamp64\bin\php\php8.2.0\php.exe`
   - Arguments: `spark eam:escalations`
   - Start in: `C:\wamp64\www\factorymanager`

**Linux Crontab:**
```bash
0 * * * * cd /path/to/factorymanager && php spark eam:escalations
```

## 📊 API Endpoints

All endpoints require JWT authentication.

### Get User Notifications
```http
GET /api/v1/eam/notifications?user_id=1
Authorization: Bearer {token}
```

Response:
```json
{
  "notifications": [
    {
      "id": 1,
      "user_id": 1,
      "type": "pm_due",
      "title": "PM Schedule Due Soon",
      "body": "PM schedule #123 for asset Pump A-101 is due on 2024-01-20.",
      "data": {...},
      "read_at": null,
      "created_at": "2024-01-15 10:00:00"
    }
  ],
  "unread_count": 5
}
```

### Mark as Read
```http
PUT /api/v1/eam/notifications/1/read
Authorization: Bearer {token}
```

### Mark All as Read
```http
PUT /api/v1/eam/notifications/mark-all-read
Authorization: Bearer {token}
```

### Delete Notification
```http
DELETE /api/v1/eam/notifications/1
Authorization: Bearer {token}
```

## 💻 Usage in Code

### Send Notification

```php
use App\Services\NotificationService;

$notificationService = new NotificationService();

// PM due notification
$notificationService->send(
    userId: 5,
    type: 'pm_due',
    data: [
        'schedule_id' => 123,
        'asset_name' => 'Pump A-101',
        'due_date' => '2024-01-20',
    ],
    channels: ['in_app', 'email']
);

// Work order assigned
$notificationService->send(
    userId: 3,
    type: 'wo_assigned',
    data: [
        'wo_number' => 'WO-2024-0001',
        'priority' => 'high',
    ],
    channels: ['in_app']
);

// PM overdue (escalation)
$notificationService->send(
    userId: 2,
    type: 'pm_overdue',
    data: [
        'schedule_id' => 123,
        'asset_name' => 'Pump A-101',
        'due_date' => '2024-01-15',
        'days_overdue' => 3,
    ],
    channels: ['in_app', 'email', 'sms']
);
```

## 🔔 Notification Types

- `pm_due` - PM schedule due soon
- `pm_overdue` - PM schedule overdue
- `wo_assigned` - Work order assigned to user
- `wo_overdue` - Work order is overdue
- `asset_critical` - Asset in critical condition
- `inventory_low` - Inventory below threshold

## ⚡ Escalation Rules

**24 hours overdue:**
- Target: Department Supervisor
- Channels: in-app + email
- Applies to: PM schedules, Work orders

**72 hours overdue:**
- Target: Manager (role='manager')
- Channels: in-app + email + SMS
- Applies to: PM schedules

## 📱 SMS Configuration (Optional)

Install Twilio SDK:
```bash
composer require twilio/sdk
```

Add to `.env`:
```
TWILIO_SID=your_account_sid
TWILIO_TOKEN=your_auth_token
TWILIO_FROM=+1234567890
```

Add phone field to users table:
```sql
ALTER TABLE users ADD COLUMN phone VARCHAR(20) NULL;
UPDATE users SET phone = '+1234567890' WHERE id = 1;
```

## 🔍 Monitoring

### Check Queue Status
```sql
SELECT status, COUNT(*) as count 
FROM notification_jobs 
GROUP BY status;
```

### View Failed Jobs
```sql
SELECT * FROM notification_jobs 
WHERE status = 'failed' 
ORDER BY created_at DESC 
LIMIT 10;
```

### View Recent Notifications
```sql
SELECT n.*, u.username 
FROM notifications n
JOIN users u ON n.user_id = u.id
ORDER BY n.created_at DESC 
LIMIT 20;
```

## ✅ Verification Checklist

- [ ] `notifications` table exists
- [ ] `notification_jobs` table exists
- [ ] SMTP configured in `app/Config/Email.php`
- [ ] Test script runs successfully
- [ ] Worker processes jobs (`php spark eam:worker`)
- [ ] Escalation cron job scheduled
- [ ] API endpoints return data
- [ ] Email delivery works
- [ ] In-app notifications saved to DB

## 🐛 Troubleshooting

**Worker not processing jobs:**
- Check if worker is running: `tasklist | findstr php`
- Check job status: `SELECT * FROM notification_jobs WHERE status='failed'`
- Check error column for details

**Emails not sending:**
- Verify SMTP credentials
- Check Gmail App Password (not regular password)
- Enable "Less secure app access" or use App Password
- Check firewall allows port 587

**Escalations not running:**
- Verify cron job/task scheduler is active
- Manually run: `php spark eam:escalations`
- Check users have correct roles and department_id

## 📚 Next Steps

1. Integrate notifications into frontend (bell icon, notification panel)
2. Add real-time notifications using WebSockets/SSE
3. Customize email templates in `NotificationWorker.php`
4. Add more notification types as needed
5. Implement notification preferences per user
