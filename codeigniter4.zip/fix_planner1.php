<?php
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "=== FIXING PLANNER1 PASSWORD ===\n\n";

// Check current password
$result = $db->query("SELECT username, password FROM users WHERE username='planner1'");
$user = $result->fetch_assoc();

echo "Current user: {$user['username']}\n";
echo "Current hash: " . substr($user['password'], 0, 60) . "\n";
echo "Verify 'password': " . (password_verify('password', $user['password']) ? 'YES' : 'NO') . "\n\n";

// Update password
$newHash = password_hash('password', PASSWORD_DEFAULT);
$stmt = $db->prepare("UPDATE users SET password = ? WHERE username = 'planner1'");
$stmt->bind_param('s', $newHash);
$stmt->execute();

echo "✓ Password updated\n\n";

// Verify new password
$result = $db->query("SELECT username, password FROM users WHERE username='planner1'");
$user = $result->fetch_assoc();

echo "New hash: " . substr($user['password'], 0, 60) . "\n";
echo "Verify 'password': " . (password_verify('password', $user['password']) ? 'YES' : 'NO') . "\n\n";

// Test login
echo "Testing HTTP login...\n";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://localhost/factorymanager/public/index.php/api/v1/eam/auth/login');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['username' => 'planner1', 'password' => 'password']));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode\n";
if ($httpCode === 200) {
    echo "✓ LOGIN SUCCESS\n";
} else {
    echo "✗ LOGIN FAILED\n";
    echo "Response: $response\n";
}

$db->close();
