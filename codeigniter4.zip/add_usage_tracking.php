<?php

require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "Adding usage tracking fields to production_surveys...\n";

$columns = ['units_produced', 'cycles_completed', 'trigger_pm_check'];
foreach ($columns as $col) {
    $sql = "ALTER TABLE `production_surveys` ADD COLUMN `{$col}` " . 
           ($col === 'trigger_pm_check' ? 'TINYINT(1) DEFAULT 0' : 'INT(11) DEFAULT 0');
    if ($db->query($sql)) {
        echo "✓ Added {$col}\n";
    } else {
        echo "Note: {$col} - " . $db->error . "\n";
    }
}

echo "\nCreating pm_usage_triggers table...\n";

$sql = "CREATE TABLE IF NOT EXISTS `pm_usage_triggers` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `machine_id` INT(11) UNSIGNED NOT NULL,
    `pm_template_id` INT(11) UNSIGNED NOT NULL,
    `trigger_type` ENUM('units', 'cycles', 'hours') DEFAULT 'units',
    `threshold_value` INT(11) NOT NULL,
    `current_value` INT(11) DEFAULT 0,
    `last_pm_date` DATE NULL,
    `next_pm_due` DATE NULL,
    `status` ENUM('active', 'triggered', 'completed') DEFAULT 'active',
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_machine_id` (`machine_id`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

if ($db->query($sql)) {
    echo "✓ pm_usage_triggers table created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

echo "\n✅ Usage tracking setup complete!\n";

$db->close();
