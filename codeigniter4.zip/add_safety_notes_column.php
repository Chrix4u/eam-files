<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();

try {
    $db->query("ALTER TABLE work_orders ADD COLUMN safety_notes TEXT NULL AFTER trade_activity");
    echo "Column 'safety_notes' added successfully!\n";
} catch (\Exception $e) {
    if (strpos($e->getMessage(), "Duplicate column name") !== false) {
        echo "Column 'safety_notes' already exists.\n";
    } else {
        echo "Error: " . $e->getMessage() . "\n";
    }
}
