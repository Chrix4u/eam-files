<?php

define('FCPATH', __DIR__ . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR);
require 'vendor/autoload.php';

$pathsConfig = new Config\Paths();
$bootstrap = \CodeIgniter\Boot::bootWeb($pathsConfig);

$db = \Config\Database::connect();

$sql = "ALTER TABLE company_settings ADD COLUMN logo VARCHAR(255) NULL AFTER website";

try {
    $db->query($sql);
    echo "Logo column added successfully!\n";
} catch (Exception $e) {
    echo "Column may already exist or error: " . $e->getMessage() . "\n";
}
