-- Enterprise-Grade Enhancement for Existing system_modules Table
-- Adds Ghana-specific module structure while preserving existing data

-- Add new columns for enterprise-grade module management
ALTER TABLE system_modules
ADD COLUMN IF NOT EXISTS code VARCHAR(50) UNIQUE AFTER id,
ADD COLUMN IF NOT EXISTS version VARCHAR(20) DEFAULT '1.0.0' AFTER description,
ADD COLUMN IF NOT EXISTS dependencies JSON AFTER version,
ADD COLUMN IF NOT EXISTS ghana_features JSON AFTER dependencies,
ADD COLUMN IF NOT EXISTS route_prefix VARCHAR(100) AFTER ghana_features,
ADD COLUMN IF NOT EXISTS icon VARCHAR(50) AFTER route_prefix,
ADD COLUMN IF NOT EXISTS display_order INT DEFAULT 0 AFTER icon,
ADD INDEX idx_code (code),
ADD INDEX idx_module_name (module_name);

-- Update existing modules with code mappings
UPDATE system_modules SET code = 'maintenance_requests' WHERE module_name = 'maintenance_requests';
UPDATE system_modules SET code = 'work_orders' WHERE module_name = 'work_orders';
UPDATE system_modules SET code = 'preventive_maintenance' WHERE module_name = 'preventive_maintenance';
UPDATE system_modules SET code = 'asset_management' WHERE module_name = 'asset_management';
UPDATE system_modules SET code = 'inventory' WHERE module_name = 'inventory';
UPDATE system_modules SET code = 'analytics' WHERE module_name = 'analytics';
UPDATE system_modules SET code = 'iot_monitoring' WHERE module_name = 'iot_monitoring';
UPDATE system_modules SET code = 'predictive_maintenance' WHERE module_name = 'predictive_maintenance';
UPDATE system_modules SET code = 'mobile_app' WHERE module_name = 'mobile_app';
UPDATE system_modules SET code = 'production_tracking' WHERE module_name = 'production_tracking';

-- Insert/Update RWOP module (Ghana-specific)
INSERT INTO system_modules (
    module_name, display_name, description, is_enabled, subscription_tier,
    code, version, dependencies, ghana_features, route_prefix, icon, display_order
) VALUES (
    'rwop',
    'Repair Work Order Program',
    'Complete work order management with team assignments, shift handover, and Ghana compliance',
    1,
    'enterprise',
    'rwop',
    '2.1.0',
    '["inventory","asset_management"]',
    '{"shift_handover":true,"union_notification":true,"power_outage_tracking":true,"forex_tracking":true,"team_leader_enforcement":true}',
    '/rwop',
    'wrench',
    1
) ON DUPLICATE KEY UPDATE
    display_name = 'Repair Work Order Program',
    description = 'Complete work order management with team assignments, shift handover, and Ghana compliance',
    version = '2.1.0',
    dependencies = '["inventory","asset_management"]',
    ghana_features = '{"shift_handover":true,"union_notification":true,"power_outage_tracking":true,"forex_tracking":true,"team_leader_enforcement":true}',
    route_prefix = '/rwop',
    icon = 'wrench',
    display_order = 1,
    updated_at = NOW();

-- Insert/Update MRMP module
INSERT INTO system_modules (
    module_name, display_name, description, is_enabled, subscription_tier,
    code, version, dependencies, ghana_features, route_prefix, icon, display_order
) VALUES (
    'mrmp',
    'Machine Reliability Maintenance',
    'Preventive maintenance with Ghana seasonal adjustments',
    1,
    'enterprise',
    'mrmp',
    '1.0.0',
    '["asset_management","inventory"]',
    '{"season_adjustment":true,"generator_pm":true,"voltage_monitoring":true}',
    '/mrmp',
    'cog',
    2
) ON DUPLICATE KEY UPDATE
    version = '1.0.0',
    dependencies = '["asset_management","inventory"]',
    ghana_features = '{"season_adjustment":true,"generator_pm":true,"voltage_monitoring":true}',
    updated_at = NOW();

-- Insert/Update MPMP module
INSERT INTO system_modules (
    module_name, display_name, description, is_enabled, subscription_tier,
    code, version, dependencies, ghana_features, route_prefix, icon, display_order
) VALUES (
    'mpmp',
    'Manufacturing Production Management',
    'Production tracking with shift management and union compliance',
    1,
    'enterprise',
    'mpmp',
    '1.0.0',
    '["asset_management"]',
    '{"shift_production":true,"power_outage_downtime":true,"union_break_compliance":true}',
    '/mpmp',
    'factory',
    3
) ON DUPLICATE KEY UPDATE
    version = '1.0.0',
    dependencies = '["asset_management"]',
    ghana_features = '{"shift_production":true,"power_outage_downtime":true,"union_break_compliance":true}',
    updated_at = NOW();

-- Verify enhanced structure
SELECT 
    code,
    module_name,
    display_name,
    is_enabled,
    version,
    subscription_tier,
    JSON_LENGTH(dependencies) as dep_count,
    JSON_LENGTH(ghana_features) as feature_count
FROM system_modules
ORDER BY display_order, module_name;
