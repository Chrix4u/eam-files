<?php

namespace App\Controllers\Api\V1;

use CodeIgniter\RESTful\ResourceController;

/**
 * Example Controller showing CORS is working
 * 
 * Test endpoint: http://localhost/factorymanager/public/api/v1/eam/test
 */
class TestController extends ResourceController
{
    protected $format = 'json';

    public function index()
    {
        // CORS headers are automatically added by the CORS filter
        return $this->respond([
            'status' => 'success',
            'message' => 'CORS is working!',
            'data' => [
                'timestamp' => date('Y-m-d H:i:s'),
                'origin' => $this->request->getHeaderLine('Origin'),
                'method' => $this->request->getMethod()
            ]
        ]);
    }

    public function create()
    {
        $data = $this->request->getJSON(true);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'POST request received',
            'received_data' => $data
        ]);
    }
}
