-- Run this SQL directly in phpMyAdmin or MySQL client

CREATE TABLE IF NOT EXISTS `technician_time_logs` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `technician_id` INT(11) UNSIGNED NOT NULL,
    `clock_in` DATETIME NOT NULL,
    `clock_out` DATETIME NULL,
    `break_duration` INT(11) DEFAULT 0 COMMENT 'minutes',
    `actual_hours` DECIMAL(10,2) NULL,
    `activity_description` TEXT NULL,
    `work_type` ENUM('diagnosis','repair','testing','documentation','other') DEFAULT 'repair',
    `location` VARCHAR(255) NULL,
    `is_overtime` BOOLEAN DEFAULT FALSE,
    `status` ENUM('active','paused','completed') DEFAULT 'active',
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_work_order_tech` (`work_order_id`, `technician_id`),
    KEY `idx_clock_in` (`clock_in`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `work_order_materials_used` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `part_id` INT(11) UNSIGNED NOT NULL,
    `technician_id` INT(11) UNSIGNED NOT NULL,
    `quantity_requested` INT(11) NOT NULL,
    `quantity_used` INT(11) NOT NULL,
    `quantity_returned` INT(11) DEFAULT 0,
    `issued_by` INT(11) UNSIGNED NULL,
    `issued_at` DATETIME NULL,
    `returned_at` DATETIME NULL,
    `unit_cost` DECIMAL(10,2) NULL,
    `total_cost` DECIMAL(10,2) NULL,
    `notes` TEXT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_work_order` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `work_order_completion_reports` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `team_leader_id` INT(11) UNSIGNED NOT NULL,
    `work_performed` TEXT NOT NULL,
    `root_cause` TEXT NULL,
    `corrective_actions` TEXT NOT NULL,
    `observations` TEXT NULL,
    `recommendations` TEXT NULL,
    `quality_check_passed` BOOLEAN DEFAULT TRUE,
    `quality_notes` TEXT NULL,
    `actual_start_time` DATETIME NULL,
    `actual_end_time` DATETIME NULL,
    `total_hours` DECIMAL(10,2) NULL,
    `downtime_hours` DECIMAL(10,2) NULL,
    `report_status` ENUM('draft','submitted','approved','rejected') DEFAULT 'draft',
    `submitted_at` DATETIME NULL,
    `approved_by` INT(11) UNSIGNED NULL,
    `approved_at` DATETIME NULL,
    `rejection_reason` TEXT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_work_order` (`work_order_id`),
    KEY `idx_report_status` (`report_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `work_order_signatures` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `role` ENUM('technician','team_leader','supervisor','planner','manager') NOT NULL,
    `signature_type` ENUM('work_performed','work_approved','work_verified') NOT NULL,
    `signature_data` TEXT NULL,
    `signed_at` DATETIME NOT NULL,
    `comments` TEXT NULL,
    PRIMARY KEY (`id`),
    KEY `idx_work_order` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `work_order_attachments` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `uploaded_by` INT(11) UNSIGNED NOT NULL,
    `file_name` VARCHAR(255) NOT NULL,
    `file_path` VARCHAR(500) NOT NULL,
    `file_type` VARCHAR(50) NOT NULL,
    `file_size` INT(11) NOT NULL,
    `attachment_type` ENUM('before','during','after','document') DEFAULT 'after',
    `description` TEXT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_work_order` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert migration record
INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`) 
VALUES ('2025-01-28-000001', 'App\\Database\\Migrations\\CreateWorkOrderCompletionTables', 'default', 'App', UNIX_TIMESTAMP(), 
    (SELECT COALESCE(MAX(batch), 0) + 1 FROM (SELECT batch FROM migrations) AS temp));
