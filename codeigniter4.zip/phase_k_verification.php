<?php

// Phase K - PM System Verification Checklist
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔍 PHASE K - PM SYSTEM VERIFICATION\n";
    echo "===================================\n\n";

    $results = [];

    // 1. PM Templates CRUD & Persistence
    echo "1. ✅ PM Templates CRUD & Checklists/Triggers...\n";
    $templates = $pdo->query("SELECT COUNT(*) FROM pm_templates")->fetchColumn();
    $checklists = $pdo->query("SELECT COUNT(*) FROM pm_checklists")->fetchColumn();
    $triggers = $pdo->query("SELECT COUNT(*) FROM pm_triggers")->fetchColumn();
    $results['templates'] = $templates > 0 && $checklists > 0 && $triggers > 0;
    echo "   Templates: $templates, Checklists: $checklists, Triggers: $triggers\n";

    // 2. Scheduler Creates PM Schedules
    echo "\n2. ✅ PM Schedules Creation...\n";
    $schedules = $pdo->query("SELECT COUNT(*) FROM pm_schedules")->fetchColumn();
    $results['schedules'] = $schedules > 0;
    echo "   PM Schedules: $schedules\n";

    // 3. Usage-based Triggers & Meter Values
    echo "\n3. ✅ Usage-based Triggers & Meters...\n";
    $meters = $pdo->query("SELECT COUNT(*) FROM meters")->fetchColumn();
    $meterReadings = $pdo->query("SELECT COUNT(*) FROM meter_readings")->fetchColumn();
    $usageTriggers = $pdo->query("SELECT COUNT(*) FROM pm_triggers WHERE trigger_type = 'usage'")->fetchColumn();
    $results['usage_triggers'] = $meters > 0 && $usageTriggers > 0;
    echo "   Meters: $meters, Readings: $meterReadings, Usage Triggers: $usageTriggers\n";

    // 4. Work Order Generation & Parts Reservation
    echo "\n4. ✅ Work Order Generation & Parts...\n";
    $workOrders = $pdo->query("SELECT COUNT(*) FROM work_orders WHERE related_pm_id IS NOT NULL")->fetchColumn();
    $woMaterials = $pdo->query("SELECT COUNT(*) FROM work_order_materials")->fetchColumn();
    $results['work_orders'] = $workOrders > 0;
    echo "   PM Work Orders: $workOrders, Reserved Materials: $woMaterials\n";

    // 5. Audit Logs
    echo "\n5. ✅ Audit Logs...\n";
    $pmHistory = $pdo->query("SELECT COUNT(*) FROM pm_history")->fetchColumn();
    $woLogs = $pdo->query("SELECT COUNT(*) FROM work_order_logs")->fetchColumn();
    $results['audit_logs'] = $pmHistory > 0 && $woLogs > 0;
    echo "   PM History: $pmHistory, WO Logs: $woLogs\n";

    // 6. Checklist Execution
    echo "\n6. ✅ Checklist Execution...\n";
    $checklistItems = $pdo->query("SELECT COUNT(*) FROM work_order_checklist_items")->fetchColumn();
    $results['checklist_execution'] = $checklistItems > 0;
    echo "   Completed Checklist Items: $checklistItems\n";

    // Summary
    echo "\n" . str_repeat("=", 50) . "\n";
    echo "VERIFICATION SUMMARY:\n";
    $passed = 0;
    $total = count($results);
    
    foreach ($results as $test => $result) {
        $status = $result ? "✅ PASS" : "❌ FAIL";
        echo "  $test: $status\n";
        if ($result) $passed++;
    }
    
    echo "\nOverall: $passed/$total tests passed\n";
    
    if ($passed === $total) {
        echo "🎉 ALL PHASE K CRITERIA VERIFIED!\n";
    } else {
        echo "⚠️  Some criteria need attention\n";
    }

} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}