<?php

require __DIR__ . '/vendor/autoload.php';

$db = \Config\Database::connect();

echo "=== HIERARCHICAL DEPARTMENTS MIGRATION ===\n\n";

// Check if columns already exist
$fieldsExist = [
    'parent_id' => $db->fieldExists('parent_id', 'departments'),
    'level' => $db->fieldExists('level', 'departments'),
    'supervisor_id' => $db->fieldExists('supervisor_id', 'departments')
];

echo "Checking existing fields:\n";
foreach ($fieldsExist as $field => $exists) {
    echo "  - $field: " . ($exists ? "EXISTS" : "MISSING") . "\n";
}
echo "\n";

// Add parent_id if not exists
if (!$fieldsExist['parent_id']) {
    echo "Adding parent_id column...\n";
    $db->query("ALTER TABLE departments ADD COLUMN parent_id INT(11) UNSIGNED NULL AFTER id");
    echo "  ✅ parent_id added\n\n";
}

// Add level if not exists
if (!$fieldsExist['level']) {
    echo "Adding level column...\n";
    $db->query("ALTER TABLE departments ADD COLUMN level TINYINT(2) DEFAULT 1 COMMENT '1=Main Department, 2=Sub-Department' AFTER parent_id");
    echo "  ✅ level added\n\n";
}

// Add supervisor_id if not exists
if (!$fieldsExist['supervisor_id']) {
    echo "Adding supervisor_id column...\n";
    $db->query("ALTER TABLE departments ADD COLUMN supervisor_id INT(11) UNSIGNED NULL AFTER description");
    echo "  ✅ supervisor_id added\n\n";
}

// Add indexes
echo "Adding indexes...\n";

$indexes = [
    'idx_parent_id' => "ALTER TABLE departments ADD INDEX idx_parent_id (parent_id)",
    'idx_supervisor_id' => "ALTER TABLE departments ADD INDEX idx_supervisor_id (supervisor_id)",
    'idx_level' => "ALTER TABLE departments ADD INDEX idx_level (level)"
];

foreach ($indexes as $indexName => $sql) {
    $checkIndex = $db->query("
        SELECT INDEX_NAME 
        FROM information_schema.STATISTICS 
        WHERE TABLE_SCHEMA = DATABASE() 
        AND TABLE_NAME = 'departments' 
        AND INDEX_NAME = ?
    ", [$indexName]);
    
    if ($checkIndex->getNumRows() == 0) {
        $db->query($sql);
        echo "  ✅ $indexName created\n";
    } else {
        echo "  ⏭️  $indexName already exists\n";
    }
}

echo "\n";

// Add foreign key
echo "Adding foreign key constraint...\n";

$checkFK = $db->query("
    SELECT CONSTRAINT_NAME 
    FROM information_schema.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'departments' 
    AND CONSTRAINT_NAME = 'fk_departments_parent'
");

if ($checkFK->getNumRows() == 0) {
    $db->query("ALTER TABLE departments ADD CONSTRAINT fk_departments_parent 
        FOREIGN KEY (parent_id) REFERENCES departments(id) ON DELETE SET NULL");
    echo "  ✅ Foreign key constraint added\n\n";
} else {
    echo "  ⏭️  Foreign key constraint already exists\n\n";
}

echo "=== MIGRATION COMPLETED SUCCESSFULLY ===\n";
echo "✅ Hierarchical department structure is ready\n";
echo "✅ Run seeder: php spark db:seed HierarchicalDepartmentsSeeder\n";
