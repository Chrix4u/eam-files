# 🏢 Hierarchical Department System - Implementation Guide

**Date**: 2026-01-22  
**Feature**: Multi-Level Department Structure with Supervisors

---

## 📋 Overview

Refactored department system to support:
- **Main Departments** (Level 1) - e.g., Engineering, Production
- **Sub-Departments** (Level 2) - e.g., Electrical, Mechanical under Engineering
- **Independent Supervisors** - Each department/sub-department can have its own supervisor

---

## 🗄️ Database Schema

### New Fields Added to `departments` Table

| Field | Type | Description |
|-------|------|-------------|
| `parent_id` | INT | References parent department (NULL for main departments) |
| `level` | TINYINT | 1 = Main Department, 2 = Sub-Department |
| `supervisor_id` | INT | Supervisor assigned to this department |

### Indexes
- `idx_parent_id` - Fast parent lookups
- `idx_supervisor_id` - Fast supervisor queries
- `idx_level` - Filter by department level

### Foreign Key
- `fk_departments_parent` - Ensures referential integrity

---

## 🚀 Migration

```bash
cd c:\wamp64\www\factorymanager
php spark migrate
```

**Migration File**: `2026-01-22-000001_RefactorDepartmentsHierarchy.php`

---

## 🌱 Seeding Sample Data

```bash
php spark db:seed HierarchicalDepartmentsSeeder
```

**Creates**:
- 3 Main Departments (Engineering, Production, Quality Control)
- 3 Engineering Sub-Departments (Electrical, Mechanical, Instrumentation)
- 2 Production Sub-Departments (Assembly, Packaging)

---

## 📡 API Endpoints

### 1. Get All Departments (Flat)
```http
GET /api/v1/eam/departments
```

**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "department_code": "ENG",
      "department_name": "Engineering",
      "level": 1,
      "parent_id": null,
      "supervisor_id": 5,
      "supervisor_name": "John Doe",
      "parent_name": null
    },
    {
      "id": 2,
      "department_code": "ENG-ELEC",
      "department_name": "Electrical",
      "level": 2,
      "parent_id": 1,
      "supervisor_id": 8,
      "supervisor_name": "Jane Smith",
      "parent_name": "Engineering"
    }
  ]
}
```

### 2. Get Hierarchical Structure
```http
GET /api/v1/eam/departments?hierarchical=true
```

**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "department_code": "ENG",
      "department_name": "Engineering",
      "level": 1,
      "supervisor_id": 5,
      "supervisor_name": "John Doe",
      "sub_departments": [
        {
          "id": 2,
          "department_code": "ENG-ELEC",
          "department_name": "Electrical",
          "level": 2,
          "supervisor_id": 8,
          "supervisor_name": "Jane Smith"
        },
        {
          "id": 3,
          "department_code": "ENG-MECH",
          "department_name": "Mechanical",
          "level": 2,
          "supervisor_id": 9,
          "supervisor_name": "Bob Wilson"
        }
      ]
    }
  ]
}
```

### 3. Get Main Departments Only
```http
GET /api/v1/eam/departments/main
```

### 4. Get Sub-Departments of a Parent
```http
GET /api/v1/eam/departments/{parent_id}/sub
```

### 5. Get Department with Details
```http
GET /api/v1/eam/departments/{id}
```

**Response includes**:
- Department info
- Supervisor details
- Sub-departments (if main department)
- Department path (breadcrumb)

### 6. Create Main Department
```http
POST /api/v1/eam/departments
Content-Type: application/json

{
  "department_code": "HR",
  "department_name": "Human Resources",
  "description": "HR Department",
  "supervisor_id": 10
}
```

### 7. Create Sub-Department
```http
POST /api/v1/eam/departments
Content-Type: application/json

{
  "department_code": "ENG-HVAC",
  "department_name": "HVAC",
  "description": "Heating, Ventilation, and Air Conditioning",
  "parent_id": 1,
  "supervisor_id": 11
}
```

---

## 💻 Model Methods

### DepartmentModel

```php
// Get all departments with hierarchy info
$departments = $model->getDepartmentsWithSupervisors();

// Get only main departments
$mainDepts = $model->getMainDepartments();

// Get sub-departments of a parent
$subDepts = $model->getSubDepartments($parentId);

// Get full hierarchy (nested)
$hierarchy = $model->getDepartmentHierarchy();

// Get department path (breadcrumb)
$path = $model->getDepartmentPath($deptId);
// Returns: [Engineering, Electrical]
```

---

## 🔄 Workflow Integration

### Maintenance Request Flow

When an operator creates a maintenance request:

1. **User's Department** is captured (could be sub-department)
2. **Supervisor** is auto-assigned from user's department
3. If user is in **Electrical** (sub-dept):
   - Request goes to **Electrical Supervisor**
   - Not to Engineering main supervisor

### Example Scenario

```
User: Mike (Electrician)
Department: Electrical (ENG-ELEC)
Supervisor: Jane Smith (Electrical Supervisor)

Request Flow:
1. Mike creates request
2. Auto-assigned to Jane Smith (Electrical Supervisor)
3. Jane approves/rejects
4. Jane assigns to planner
```

---

## 📊 Use Cases

### 1. Engineering Department Structure
```
Engineering (Main)
├── Electrical (Sub)
│   └── Supervisor: Jane Smith
├── Mechanical (Sub)
│   └── Supervisor: Bob Wilson
└── Instrumentation (Sub)
    └── Supervisor: Alice Brown
```

### 2. Production Department Structure
```
Production (Main)
├── Assembly (Sub)
│   └── Supervisor: Tom Davis
└── Packaging (Sub)
    └── Supervisor: Sarah Johnson
```

---

## 🎯 Benefits

1. **Granular Control** - Each sub-department has its own supervisor
2. **Clear Hierarchy** - Visual organization structure
3. **Flexible Routing** - Requests route to correct sub-department supervisor
4. **Scalable** - Easy to add more sub-departments
5. **Reporting** - Department-level and sub-department-level analytics

---

## 🔍 Validation Rules

### Creating Department

- **Main Department**: `parent_id` = NULL, `level` = 1
- **Sub-Department**: `parent_id` = valid department ID, `level` = 2
- **Supervisor**: Must be a user with role = 'supervisor'
- **Department Code**: Unique across all departments

### Constraints

- Cannot delete department with sub-departments
- Cannot delete department with assigned users
- Sub-departments cannot have sub-departments (max 2 levels)

---

## 📝 Frontend Display Example

```
Departments
├─ 🏢 Engineering (John Doe)
│  ├─ ⚡ Electrical (Jane Smith)
│  ├─ ⚙️ Mechanical (Bob Wilson)
│  └─ 📊 Instrumentation (Alice Brown)
├─ 🏭 Production (Mike Johnson)
│  ├─ 🔧 Assembly (Tom Davis)
│  └─ 📦 Packaging (Sarah Johnson)
└─ ✅ Quality Control (David Lee)
```

---

## 🧪 Testing

### Test Hierarchy Creation
```bash
php spark db:seed HierarchicalDepartmentsSeeder
```

### Verify Structure
```sql
SELECT 
    d.id,
    d.department_code,
    d.department_name,
    d.level,
    p.department_name as parent_name,
    u.username as supervisor_name
FROM departments d
LEFT JOIN departments p ON p.id = d.parent_id
LEFT JOIN users u ON u.id = d.supervisor_id
ORDER BY d.level, d.parent_id, d.department_name;
```

---

## 🚀 Deployment Checklist

- [x] Migration created
- [x] Model updated
- [x] Controller updated
- [x] Seeder created
- [x] API endpoints tested
- [ ] Frontend UI updated
- [ ] User assignment logic updated
- [ ] Reporting updated

---

## 📚 Related Files

- **Migration**: `app/Database/Migrations/2026-01-22-000001_RefactorDepartmentsHierarchy.php`
- **Model**: `app/Models/DepartmentModel.php`
- **Controller**: `app/Controllers/Api/V1/DepartmentsController.php`
- **Seeder**: `app/Database/Seeds/HierarchicalDepartmentsSeeder.php`

---

**Status**: ✅ READY FOR TESTING  
**Version**: 2.1.0  
**Breaking Changes**: None (backward compatible)
