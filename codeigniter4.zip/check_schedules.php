<?php

// Check available PM schedules and their statuses
$baseUrl = 'http://localhost/factorymanager/public/index.php/api/v1/pm';

echo "📋 Checking PM Schedules\n";
echo "========================\n\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $baseUrl . '/schedules');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $result = json_decode($response, true);
    if (isset($result['data'])) {
        foreach ($result['data'] as $schedule) {
            echo "Schedule ID: {$schedule['id']}\n";
            echo "  Title: {$schedule['title']}\n";
            echo "  Status: {$schedule['status']}\n";
            echo "  Due Date: {$schedule['due_date']}\n";
            echo "  Priority: {$schedule['priority']}\n";
            echo "  Maintenance Type: {$schedule['maintenance_type']}\n";
            echo "  ---\n";
        }
        
        // Find schedules in waiting status
        $waitingSchedules = array_filter($result['data'], function($s) {
            return $s['status'] === 'waiting';
        });
        
        if (!empty($waitingSchedules)) {
            echo "\n✅ Schedules in 'waiting' status:\n";
            foreach ($waitingSchedules as $schedule) {
                echo "  - ID {$schedule['id']}: {$schedule['title']}\n";
            }
            
            $firstWaiting = reset($waitingSchedules);
            echo "\n🧪 Testing work order generation for schedule {$firstWaiting['id']}...\n";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $baseUrl . "/schedules/{$firstWaiting['id']}/generate-workorder");
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            echo "HTTP Status: $httpCode\n";
            echo "Response: $response\n";
            
            if ($httpCode === 200) {
                echo "✅ Work order generated successfully!\n";
            }
        } else {
            echo "\n❌ No schedules in 'waiting' status found.\n";
            echo "Available statuses: ";
            $statuses = array_unique(array_column($result['data'], 'status'));
            echo implode(', ', $statuses) . "\n";
        }
    }
} else {
    echo "❌ Failed to fetch schedules (HTTP $httpCode)\n";
    echo "Response: $response\n";
}

echo "\n📋 Your curl command for any waiting schedule:\n";
echo "curl -X POST \"http://localhost/factorymanager/public/index.php/api/v1/pm/schedules/[SCHEDULE_ID]/generate-workorder\" \\\n";
echo "  -H \"Content-Type: application/json\"\n";