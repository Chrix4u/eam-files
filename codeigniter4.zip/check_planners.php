<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();
$planners = $db->query("SELECT id, username, role, full_name, name FROM users WHERE role='planner'")->getResultArray();

if (empty($planners)) {
    echo "No planner users found!\n";
} else {
    echo "Found " . count($planners) . " planner(s):\n";
    foreach ($planners as $p) {
        echo "- ID: {$p['id']}, Username: {$p['username']}, Name: " . ($p['full_name'] ?? $p['name'] ?? 'N/A') . "\n";
    }
}
