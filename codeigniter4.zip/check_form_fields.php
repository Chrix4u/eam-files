<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get current columns
$result = $conn->query("DESCRIBE work_orders");
$existingColumns = [];
while ($row = $result->fetch_assoc()) {
    $existingColumns[] = $row['Field'];
}

// Form fields from the comprehensive request form
$formFields = [
    'work_order_number',      // Order No
    'machine_id',             // Machine
    'location',               // Location (MISSING - needs to be added)
    'is_breakdown',           // Breakdown checkbox
    'title',                  // Problem Description
    'requested_by',           // Requested By (MISSING - but we have requestor_id)
    'date_sent',              // Date Sent
    'time_sent',              // Time Sent
    'work_type',              // Work Order Type (MISSING - we have 'type' and 'work_order_type')
    'delivery_date_required', // Delivery Date Required
    'technical_description',  // Technical Description
    'trade_activity',         // Trade Activity
    'technician_id',          // Assign Technician (MISSING - we have assigned_to, assigned_user_id)
    'scheduled_date',         // Scheduled Date (MISSING - we have planned_start)
    'estimated_hours',        // Estimated Hours
    'notes',                  // Work Order Notes (MISSING)
    'technician_remarks',     // Technician Report
    'technician_brief_report',// Brief Report
    'failure_description',    // Failure Description
    'cause_description',      // Cause Description
    'action_description',     // Action Description
    'general_remarks',        // General Remarks
    'operator_signature',     // Operator Signature
    'line_manager_signature', // Line Manager Signature
    'supervisor_signature',   // Supervisor Signature
];

echo "FORM FIELD ANALYSIS\n";
echo str_repeat("=", 80) . "\n\n";

$missing = [];
$mapped = [];

foreach ($formFields as $field) {
    if (in_array($field, $existingColumns)) {
        echo "✓ $field - EXISTS\n";
    } else {
        echo "✗ $field - MISSING\n";
        $missing[] = $field;
        
        // Check for similar fields
        if ($field === 'location') {
            $mapped[] = "$field -> Could use asset location or add new column";
        } elseif ($field === 'requested_by') {
            $mapped[] = "$field -> Use 'requestor_id'";
        } elseif ($field === 'work_type') {
            $mapped[] = "$field -> Use 'work_order_type' (breakdown/preventive/corrective/other)";
        } elseif ($field === 'technician_id') {
            $mapped[] = "$field -> Use 'assigned_user_id' or 'assigned_to'";
        } elseif ($field === 'scheduled_date') {
            $mapped[] = "$field -> Use 'planned_start'";
        } elseif ($field === 'notes') {
            $mapped[] = "$field -> NEEDS TO BE ADDED";
        }
    }
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "SUMMARY\n";
echo str_repeat("=", 80) . "\n";
echo "Total form fields: " . count($formFields) . "\n";
echo "Missing fields: " . count($missing) . "\n\n";

if (!empty($missing)) {
    echo "Missing fields:\n";
    foreach ($missing as $field) {
        echo "  - $field\n";
    }
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "FIELD MAPPING RECOMMENDATIONS\n";
echo str_repeat("=", 80) . "\n";
foreach ($mapped as $map) {
    echo "  $map\n";
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "SQL TO ADD MISSING COLUMNS\n";
echo str_repeat("=", 80) . "\n";
echo "ALTER TABLE work_orders ADD COLUMN notes TEXT NULL AFTER general_remarks;\n";
echo "ALTER TABLE work_orders ADD COLUMN location VARCHAR(255) NULL AFTER machine_id;\n";

$conn->close();
