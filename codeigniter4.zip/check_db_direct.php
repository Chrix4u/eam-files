<?php
// Direct database check
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "=== FACTORY MANAGER DATABASE TEST ===\n\n";
    
    // 1. Connection
    echo "1. DATABASE CONNECTION\n";
    echo "   ✅ Connected to: $db\n\n";
    
    // 2. List tables
    echo "2. ALL TABLES\n";
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo "   Total tables: " . count($tables) . "\n\n";
    
    // 3. Grade-A tables
    echo "3. GRADE-A TABLES\n";
    $gradeATables = array_filter($tables, function($t) {
        return strpos($t, 'asset_') === 0;
    });
    if (count($gradeATables) > 0) {
        foreach ($gradeATables as $table) {
            $stmt = $pdo->query("SELECT COUNT(*) FROM `$table`");
            $count = $stmt->fetchColumn();
            echo "   ✅ $table ($count records)\n";
        }
    } else {
        echo "   ⚠️ No Grade-A tables found\n";
    }
    echo "\n";
    
    // 4. Key tables
    echo "4. KEY TABLES\n";
    $keyTables = [
        'users' => 'Users',
        'eam_facilities' => 'Facilities',
        'eam_equipment' => 'Equipment',
        'eam_work_orders' => 'Work Orders',
        'eam_pm_schedules' => 'PM Schedules',
        'machines' => 'Machines',
        'assemblies' => 'Assemblies',
        'parts' => 'Parts'
    ];
    
    foreach ($keyTables as $table => $label) {
        if (in_array($table, $tables)) {
            $stmt = $pdo->query("SELECT COUNT(*) FROM `$table`");
            $count = $stmt->fetchColumn();
            echo "   ✅ $label: $count records\n";
        } else {
            echo "   ❌ $label: table missing\n";
        }
    }
    echo "\n";
    
    // 5. Migrations
    echo "5. MIGRATIONS\n";
    if (in_array('migrations', $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM migrations");
        $count = $stmt->fetchColumn();
        echo "   Total migrations run: $count\n";
        
        $stmt = $pdo->query("SELECT MAX(batch) as max_batch FROM migrations");
        $batch = $stmt->fetchColumn();
        echo "   Latest batch: $batch\n";
    } else {
        echo "   ❌ Migrations table missing\n";
    }
    echo "\n";
    
    // 6. Users
    echo "6. USERS\n";
    if (in_array('users', $tables)) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM users");
        $userCount = $stmt->fetchColumn();
        echo "   Total users: $userCount\n";
        
        if ($userCount > 0) {
            $stmt = $pdo->query("SELECT username, role FROM users LIMIT 5");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($users as $user) {
                echo "   - {$user['username']} ({$user['role']})\n";
            }
        }
    }
    echo "\n";
    
    // 7. Work Orders Status
    echo "7. WORK ORDERS STATUS\n";
    if (in_array('eam_work_orders', $tables)) {
        $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM eam_work_orders GROUP BY status");
        $statuses = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if (count($statuses) > 0) {
            foreach ($statuses as $status) {
                echo "   - {$status['status']}: {$status['count']}\n";
            }
        } else {
            echo "   No work orders yet\n";
        }
    }
    echo "\n";
    
    // 8. System Health
    echo "8. SYSTEM HEALTH\n";
    $checks = [
        'Database Connected' => true,
        'Migrations Table' => in_array('migrations', $tables),
        'Users Table' => in_array('users', $tables),
        'Assets Tables' => in_array('eam_equipment', $tables),
        'Work Orders' => in_array('eam_work_orders', $tables),
        'PM System' => in_array('eam_pm_schedules', $tables),
    ];
    
    $passed = count(array_filter($checks));
    $total = count($checks);
    $healthScore = ($passed / $total) * 100;
    
    foreach ($checks as $check => $status) {
        echo "   " . ($status ? "✅" : "❌") . " $check\n";
    }
    echo "\n   Health Score: " . round($healthScore) . "%\n\n";
    
    echo "=== TEST COMPLETE ===\n";
    echo "Status: " . ($healthScore >= 80 ? "✅ SYSTEM HEALTHY" : "⚠️ NEEDS ATTENTION") . "\n";
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
    exit(1);
}
