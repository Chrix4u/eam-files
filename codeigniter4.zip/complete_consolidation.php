<?php
/**
 * COMPLETE MODULAR CONSOLIDATION
 * Moves ALL remaining subfolder controllers into Modules/
 */

$consolidation = [
    // Analytics/ → CORE/
    ['from' => 'app/Controllers/Api/V1/Analytics/AnalyticsController.php', 'to' => 'app/Controllers/Api/V1/Modules/CORE/AnalyticsController.php', 'action' => 'merge'],
    
    // Asset/ → ASSET/
    ['from' => 'app/Controllers/Api/V1/Asset/AssembliesController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/AssembliesController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/BomController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/BomController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/HierarchyController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/HierarchyController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/MachinesController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/EquipmentController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/MetersController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/MetersController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/PartsController.php', 'to' => 'app/Controllers/Api/V1/Modules/IMS/PartsController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/TreeController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/HierarchyController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/RelationshipController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/HierarchyController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Asset/AssetsUnifiedController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/AssetsUnifiedController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Asset/Model3DController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model3DController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Asset/VisualizationController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/VisualizationController.php', 'action' => 'move'],
    
    // Asset/Model/ → ASSET/Model/
    ['from' => 'app/Controllers/Api/V1/Asset/Model/HotspotController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model/HotspotController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Asset/Model/ModelUploadController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model/ModelUploadController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Asset/Model/ModelViewerController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model/ModelViewerController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Asset/Model/PMIntegrationController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model/PMIntegrationController.php', 'action' => 'move'],
    
    // Checklists/ → MRMP/
    ['from' => 'app/Controllers/Api/V1/Checklists/ChecklistController.php', 'to' => 'app/Controllers/Api/V1/Modules/MRMP/ChecklistController.php', 'action' => 'move'],
    
    // Core/ → CORE/
    ['from' => 'app/Controllers/Api/V1/Core/ModuleController.php', 'to' => 'app/Controllers/Api/V1/Modules/CORE/ModuleController.php', 'action' => 'move'],
    
    // Eam/ → Various modules
    ['from' => 'app/Controllers/Api/V1/Eam/DowntimeController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/DowntimeController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Eam/MeterReadingController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/MetersController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Eam/ProductionSurveyController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/ProductionController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Eam/ProductionTargetController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/ProductionController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Eam/ShiftAssignmentController.php', 'to' => 'app/Controllers/Api/V1/Modules/HRMS/ShiftsController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/Eam/WorkCenterController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/WorkCenterController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Eam/ModelAnalyticsController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model/ModelAnalyticsController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/Eam/ModelBatchController.php', 'to' => 'app/Controllers/Api/V1/Modules/ASSET/Model/ModelBatchController.php', 'action' => 'move'],
    
    // PM/ → MRMP/
    ['from' => 'app/Controllers/Api/V1/PM/PMChecklistsController.php', 'to' => 'app/Controllers/Api/V1/Modules/MRMP/PMChecklistsController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/PM/PMRunController.php', 'to' => 'app/Controllers/Api/V1/Modules/MRMP/PMRunController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/PM/PMSchedulesController.php', 'to' => 'app/Controllers/Api/V1/Modules/MRMP/PMSchedulesController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/PM/PMTemplatesController.php', 'to' => 'app/Controllers/Api/V1/Modules/MRMP/PMTemplatesController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/PM/PMTriggersController.php', 'to' => 'app/Controllers/Api/V1/Modules/MRMP/PMTriggersController.php', 'action' => 'move'],
    
    // ProductionSurvey/ → MPMP/
    ['from' => 'app/Controllers/Api/V1/ProductionSurvey/AlertController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/AlertController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/ProductionSurvey/AttachmentController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/AttachmentController.php', 'action' => 'move'],
    ['from' => 'app/Controllers/Api/V1/ProductionSurvey/ProductionSurveyController.php', 'to' => 'app/Controllers/Api/V1/Modules/MPMP/ProductionController.php', 'action' => 'merge'],
    ['from' => 'app/Controllers/Api/V1/ProductionSurvey/ShiftHandoverController.php', 'to' => 'app/Controllers/Api/V1/Modules/RWOP/ShiftHandoverController.php', 'action' => 'merge'],
    
    // Risk/ → TRAC/
    ['from' => 'app/Controllers/Api/V1/Risk/RiskAssessmentController.php', 'to' => 'app/Controllers/Api/V1/Modules/TRAC/RiskAssessmentController.php', 'action' => 'move'],
];

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║  COMPLETE MODULAR CONSOLIDATION                            ║\n";
echo "║  Moving ALL subfolder controllers to Modules/              ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

$moved = 0;
$merged = 0;
$skipped = 0;

foreach ($consolidation as $item) {
    $from = $item['from'];
    $to = $item['to'];
    $action = $item['action'];
    
    if (!file_exists($from)) {
        echo "⊘ Skip: " . basename($from) . " (not found)\n";
        $skipped++;
        continue;
    }
    
    $content = file_get_contents($from);
    
    // Update namespace
    if (strpos($from, 'Asset/Model/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Asset\\\\Model;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\ASSET\\Model;', $content);
    } elseif (strpos($from, 'Asset/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Asset;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\ASSET;', $content);
    } elseif (strpos($from, 'Analytics/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Analytics;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\CORE;', $content);
    } elseif (strpos($from, 'Checklists/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Checklists;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\MRMP;', $content);
    } elseif (strpos($from, 'Core/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Core;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\CORE;', $content);
    } elseif (strpos($from, 'Eam/') !== false) {
        if (strpos($to, 'MPMP') !== false) {
            $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Eam;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\MPMP;', $content);
        } elseif (strpos($to, 'ASSET') !== false) {
            $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Eam;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\ASSET;', $content);
        } elseif (strpos($to, 'HRMS') !== false) {
            $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Eam;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\HRMS;', $content);
        }
    } elseif (strpos($from, 'PM/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\PM;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\MRMP;', $content);
    } elseif (strpos($from, 'ProductionSurvey/') !== false) {
        if (strpos($to, 'MPMP') !== false) {
            $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\ProductionSurvey;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\MPMP;', $content);
        } elseif (strpos($to, 'RWOP') !== false) {
            $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\ProductionSurvey;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\RWOP;', $content);
        }
    } elseif (strpos($from, 'Risk/') !== false) {
        $content = preg_replace('/namespace\s+App\\\\Controllers\\\\Api\\\\V1\\\\Risk;/', 'namespace App\\Controllers\\Api\\V1\\Modules\\TRAC;', $content);
    }
    
    // Create directory if needed
    $dir = dirname($to);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    if ($action === 'merge' && file_exists($to)) {
        echo "⊕ Merge: " . basename($from) . " → " . basename($to) . " (keeping target)\n";
        unlink($from);
        $merged++;
    } else {
        file_put_contents($to, $content);
        unlink($from);
        echo "✓ Moved: " . basename($from) . " → " . basename($to) . "\n";
        $moved++;
    }
}

// Remove empty folders
echo "\n🗑️  Removing empty folders...\n\n";

$foldersToRemove = [
    'app/Controllers/Api/V1/Analytics',
    'app/Controllers/Api/V1/Asset/Model',
    'app/Controllers/Api/V1/Asset',
    'app/Controllers/Api/V1/Checklists',
    'app/Controllers/Api/V1/Core',
    'app/Controllers/Api/V1/Eam',
    'app/Controllers/Api/V1/PM',
    'app/Controllers/Api/V1/ProductionSurvey',
    'app/Controllers/Api/V1/Risk',
];

foreach ($foldersToRemove as $folder) {
    if (is_dir($folder)) {
        $files = scandir($folder);
        $files = array_diff($files, ['.', '..']);
        
        if (count($files) === 0) {
            rmdir($folder);
            echo "✓ Removed: $folder\n";
        } else {
            echo "⊘ Skipped: $folder (" . count($files) . " files remain)\n";
        }
    }
}

echo "\n╔════════════════════════════════════════════════════════════╗\n";
echo "║  CONSOLIDATION COMPLETE                                    ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "  Moved: $moved\n";
echo "  Merged: $merged\n";
echo "  Skipped: $skipped\n\n";
echo "✅ ALL subfolders consolidated into Modules/\n";
echo "📋 Next: Clear cache\n";
