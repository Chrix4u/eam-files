<?php
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "=== MACHINES TABLE COLUMNS ===\n\n";
$result = $conn->query("SHOW COLUMNS FROM machines");
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . " (" . $row['Type'] . ")\n";
}

$conn->close();
