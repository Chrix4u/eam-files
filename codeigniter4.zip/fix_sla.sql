DROP TABLE IF EXISTS sla_definitions;

CREATE TABLE sla_definitions (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL,
    order_type ENUM('preventive','corrective','breakdown','inspection','modification','calibration') NOT NULL,
    response_time_hours INT NOT NULL,
    resolution_time_hours INT NOT NULL,
    escalation_level_1_hours INT NULL,
    escalation_level_2_hours INT NULL,
    escalation_level_3_hours INT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_priority_type (priority, order_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO sla_definitions (name, priority, order_type, response_time_hours, resolution_time_hours, escalation_level_1_hours, escalation_level_2_hours, escalation_level_3_hours) VALUES
('Urgent Corrective', 'urgent', 'corrective', 1, 4, 2, 3, 4),
('High Corrective', 'high', 'corrective', 2, 8, 4, 6, 8),
('Medium Corrective', 'medium', 'corrective', 4, 24, 12, 18, 24),
('Low Corrective', 'low', 'corrective', 8, 48, 24, 36, 48),
('Urgent Breakdown', 'urgent', 'breakdown', 1, 2, 1, 1, 2),
('High Breakdown', 'high', 'breakdown', 1, 4, 2, 3, 4),
('Medium Preventive', 'medium', 'preventive', 24, 72, 48, 60, 72),
('Low Preventive', 'low', 'preventive', 48, 168, 96, 132, 168);

SELECT COUNT(*) AS 'SLA Definitions Created' FROM sla_definitions;
