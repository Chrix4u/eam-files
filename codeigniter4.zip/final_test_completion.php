<?php

// Final test of work order completion
$baseUrl = 'http://localhost/factorymanager/public/index.php/api/v1';

echo "✅ Final Work Order Completion Test\n";
echo "===================================\n\n";

// Get JWT token
$loginData = json_encode(['username' => 'admin', 'password' => 'admin123']);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $baseUrl . '/auth/login');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $loginData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
$response = curl_exec($ch);
curl_close($ch);

$loginResponse = json_decode($response, true);
$token = $loginResponse['data']['tokens']['access_token'];

echo "🔑 JWT Token obtained\n";

// Create a fresh work order for testing
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

$pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
$woNumber = 'WO-FINAL-' . time();
$stmt = $pdo->prepare("INSERT INTO work_orders (wo_number, type, title, description, requestor_id, priority, status, created_at) VALUES (?, 'corrective', 'Final Test WO', 'Testing completion endpoint', 1, 'medium', 'in_progress', NOW())");
$stmt->execute([$woNumber]);
$workOrderId = $pdo->lastInsertId();

echo "📋 Created test work order ID: $workOrderId\n";

// Test completion with your exact curl data
$completionData = json_encode([
    'actual_hours' => 1.5,
    'checklist' => [
        ['item_id' => 1, 'value' => 'yes'],
        ['item_id' => 2, 'value' => 'ok']
    ]
]);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $baseUrl . "/work-orders/{$workOrderId}/complete");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $completionData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $token,
    'Content-Type: application/json'
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "\n🧪 Completion Test Results:\n";
echo "HTTP Status: $httpCode\n";

if ($httpCode === 200) {
    $result = json_decode($response, true);
    if ($result['success']) {
        echo "✅ Work order completed successfully!\n";
        echo "   Status: {$result['data']['status']}\n";
        echo "   Actual Hours: {$result['data']['actual_hours']}\n";
        
        // Check checklist items
        $stmt = $pdo->prepare("SELECT * FROM work_order_checklist_items WHERE work_order_id = ?");
        $stmt->execute([$workOrderId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "   Checklist Items: " . count($items) . " saved\n";
        foreach ($items as $item) {
            echo "     - Item {$item['item_id']}: {$item['value']}\n";
        }
    }
} else {
    echo "❌ Failed: $response\n";
}

echo "\n📋 Your working curl command:\n";
echo "curl -X POST \"http://localhost/factorymanager/public/index.php/api/v1/work-orders/{$workOrderId}/complete\" \\\n";
echo "  -H \"Authorization: Bearer $token\" \\\n";
echo "  -H \"Content-Type: application/json\" \\\n";
echo "  -d '{\"actual_hours\":1.5,\"checklist\":[{\"item_id\":1,\"value\":\"yes\"},{\"item_id\":2,\"value\":\"ok\"}]}'\n";