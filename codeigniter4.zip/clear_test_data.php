<?php
// Clear work orders and maintenance requests for testing

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to database: $database\n\n";
    
    // Count before deletion
    $woCount = $pdo->query("SELECT COUNT(*) FROM work_orders")->fetchColumn();
    $mrCount = $pdo->query("SELECT COUNT(*) FROM maintenance_requests")->fetchColumn();
    
    // Check if optional tables exist
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $hasWorkflow = in_array('maintenance_workflow_history', $tables);
    $hasNotif = in_array('maintenance_notifications', $tables);
    
    $wfCount = $hasWorkflow ? $pdo->query("SELECT COUNT(*) FROM maintenance_workflow_history")->fetchColumn() : 0;
    $notifCount = $hasNotif ? $pdo->query("SELECT COUNT(*) FROM maintenance_notifications")->fetchColumn() : 0;
    
    echo "📊 Current Records:\n";
    echo "  - Work Orders: $woCount\n";
    echo "  - Maintenance Requests: $mrCount\n";
    echo "  - Workflow History: $wfCount\n";
    echo "  - Notifications: $notifCount\n\n";
    
    // Confirm deletion
    echo "⚠️  WARNING: This will delete ALL work orders and maintenance requests!\n";
    echo "Type 'YES' to continue: ";
    $handle = fopen("php://stdin", "r");
    $line = trim(fgets($handle));
    fclose($handle);
    
    if ($line !== 'YES') {
        echo "❌ Cancelled. No data deleted.\n";
        exit(0);
    }
    
    echo "\n🗑️  Deleting data...\n";
    
    // Delete in correct order (respecting foreign keys)
    if ($hasWorkflow) {
        $pdo->exec("DELETE FROM maintenance_workflow_history");
        echo "  ✅ Cleared workflow history\n";
    }
    
    if ($hasNotif) {
        $pdo->exec("DELETE FROM maintenance_notifications");
        echo "  ✅ Cleared notifications\n";
    }
    
    $pdo->exec("DELETE FROM work_orders");
    echo "  ✅ Cleared work orders\n";
    
    $pdo->exec("DELETE FROM maintenance_requests");
    echo "  ✅ Cleared maintenance requests\n";
    
    // Reset auto-increment
    $pdo->exec("ALTER TABLE work_orders AUTO_INCREMENT = 1");
    $pdo->exec("ALTER TABLE maintenance_requests AUTO_INCREMENT = 1");
    if ($hasWorkflow) $pdo->exec("ALTER TABLE maintenance_workflow_history AUTO_INCREMENT = 1");
    if ($hasNotif) $pdo->exec("ALTER TABLE maintenance_notifications AUTO_INCREMENT = 1");
    echo "  ✅ Reset auto-increment counters\n";
    
    echo "\n✅ SUCCESS: All tables cleared!\n\n";
    echo "📊 Final Count:\n";
    echo "  - Work Orders: 0\n";
    echo "  - Maintenance Requests: 0\n";
    echo "  - Workflow History: 0\n";
    echo "  - Notifications: 0\n\n";
    echo "🧪 Ready for testing!\n";
    
} catch (PDOException $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    exit(1);
}
