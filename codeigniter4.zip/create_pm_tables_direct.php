<?php

$host = 'localhost';
$dbname = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to database\n";
    
    // Create PM Templates table
    $sql = "CREATE TABLE IF NOT EXISTS pm_templates (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(50) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        asset_node_type ENUM('machine','assembly','part','subpart') NOT NULL,
        asset_node_id BIGINT UNSIGNED NULL,
        maintenance_type ENUM('inspection','lubrication','replace','clean','calibration','other') NOT NULL,
        priority ENUM('low','medium','high','critical') NOT NULL,
        estimated_hours DECIMAL(5,2) NULL,
        active BOOLEAN DEFAULT TRUE,
        created_by BIGINT UNSIGNED NULL,
        updated_by BIGINT UNSIGNED NULL,
        created_at DATETIME NULL,
        updated_at DATETIME NULL,
        INDEX idx_asset_node (asset_node_type, asset_node_id),
        INDEX idx_active (active)
    )";
    $pdo->exec($sql);
    echo "✅ pm_templates created\n";
    
    // Create PM Triggers table
    $sql = "CREATE TABLE IF NOT EXISTS pm_triggers (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pm_template_id BIGINT UNSIGNED NOT NULL,
        trigger_type ENUM('time','usage','production','event') NOT NULL,
        period_days INT NULL,
        usage_meter_id BIGINT UNSIGNED NULL,
        usage_threshold DECIMAL(15,2) NULL,
        production_metric VARCHAR(100) NULL,
        event_name VARCHAR(100) NULL,
        extra JSON NULL,
        created_at DATETIME NULL,
        updated_at DATETIME NULL,
        INDEX idx_template (pm_template_id),
        INDEX idx_usage_meter (usage_meter_id),
        INDEX idx_trigger_type (trigger_type),
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "✅ pm_triggers created\n";
    
    // Create PM Checklists table
    $sql = "CREATE TABLE IF NOT EXISTS pm_checklists (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pm_template_id BIGINT UNSIGNED NOT NULL,
        title VARCHAR(255) NOT NULL,
        sequence INT DEFAULT 0,
        created_at DATETIME NULL,
        INDEX idx_template (pm_template_id),
        INDEX idx_template_sequence (pm_template_id, sequence),
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "✅ pm_checklists created\n";
    
    // Create PM Checklist Items table
    $sql = "CREATE TABLE IF NOT EXISTS pm_checklist_items (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pm_checklist_id BIGINT UNSIGNED NOT NULL,
        item_text TEXT NOT NULL,
        item_type ENUM('yesno','passfail','numeric','text','photo') NOT NULL,
        required BOOLEAN DEFAULT FALSE,
        sequence INT DEFAULT 0,
        created_at DATETIME NULL,
        INDEX idx_checklist (pm_checklist_id),
        INDEX idx_checklist_sequence (pm_checklist_id, sequence),
        FOREIGN KEY (pm_checklist_id) REFERENCES pm_checklists(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "✅ pm_checklist_items created\n";
    
    // Create PM Schedules table
    $sql = "CREATE TABLE IF NOT EXISTS pm_schedules (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pm_template_id BIGINT UNSIGNED NOT NULL,
        next_due_date DATE NULL,
        next_due_usage DECIMAL(15,2) NULL,
        created_usage_snapshot DECIMAL(15,2) NULL,
        status ENUM('waiting','generated','assigned','in_progress','completed','closed','overdue') DEFAULT 'waiting',
        last_generated_at DATETIME NULL,
        generated_work_order_id BIGINT UNSIGNED NULL,
        created_at DATETIME NULL,
        updated_at DATETIME NULL,
        INDEX idx_template (pm_template_id),
        INDEX idx_template_status (pm_template_id, status),
        INDEX idx_due_date (next_due_date),
        INDEX idx_status (status),
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "✅ pm_schedules created\n";
    
    // Create PM History table
    $sql = "CREATE TABLE IF NOT EXISTS pm_history (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pm_schedule_id BIGINT UNSIGNED NOT NULL,
        action VARCHAR(50) NOT NULL,
        comment TEXT NULL,
        performed_by BIGINT UNSIGNED NULL,
        performed_at DATETIME NOT NULL,
        INDEX idx_schedule (pm_schedule_id),
        INDEX idx_performed_at (performed_at),
        INDEX idx_action (action),
        FOREIGN KEY (pm_schedule_id) REFERENCES pm_schedules(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "✅ pm_history created\n";
    
    echo "\n🎉 All PM tables created successfully!\n";
    
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}