<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
$stmt = $pdo->query("DESCRIBE assets_unified");
$columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
print_r($columns);
