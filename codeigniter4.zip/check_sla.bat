@echo off
c:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager -e "DESCRIBE sla_definitions;"
pause
