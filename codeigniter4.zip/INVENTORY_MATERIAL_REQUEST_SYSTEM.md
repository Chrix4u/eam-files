# 📦 Enterprise Inventory & Material Request System

## Overview

Complete enterprise-grade inventory management system with material request workflow, asset linkage, and stock tracking.

---

## 🏗️ System Architecture

### Database Tables

1. **inventory_items** - Master inventory data
2. **material_requests** - Technician material requests
3. **material_request_items** - Request line items
4. **stock_transactions** - All stock movements
5. **asset_inventory_links** - Spare parts mapping to assets

### Workflow

```
Technician → Request Materials → Stock Manager Approves → Stock Manager Issues → Stock Updated
```

---

## 🔌 API Endpoints

### Inventory Management

```http
GET    /api/v1/eam/inventory/items
POST   /api/v1/eam/inventory/items
PUT    /api/v1/eam/inventory/items/{id}
DELETE /api/v1/eam/inventory/items/{id}
POST   /api/v1/eam/inventory/stock-in
POST   /api/v1/eam/inventory/stock-out
```

### Material Requests

```http
GET    /api/v1/eam/material-requests
POST   /api/v1/eam/material-requests
POST   /api/v1/eam/material-requests/{id}/approve
POST   /api/v1/eam/material-requests/{id}/reject
POST   /api/v1/eam/material-requests/{id}/issue
```

### Asset Linkage

```http
POST   /api/v1/eam/inventory/link-to-asset
GET    /api/v1/eam/inventory/asset-spares/{type}/{id}
```

---

## 📋 Features

### ✅ Inventory Management
- Multi-type items (spare parts, consumables, tools, chemicals, PPE)
- Stock levels with reorder points
- Location and bin tracking
- Barcode/QR code support
- Critical item flagging
- Low stock alerts

### ✅ Material Request Workflow
- Technician request submission
- Work order linkage (optional)
- Priority levels (low, medium, high, urgent)
- Stock manager approval
- Quantity adjustment during approval
- Material issuance tracking
- Rejection with reason

### ✅ Asset Integration
- Link inventory items to machines/assemblies/parts
- PM task code mapping
- Critical spare identification
- Quantity per maintenance tracking

### ✅ Stock Transactions
- Purchase tracking
- Issue tracking
- Returns
- Adjustments
- Transfers
- Complete audit trail

---

## 🎯 User Roles & Permissions

### Technician
- Request materials
- View own requests
- Track request status

### Stock Manager / Shop Attendant
- Approve/reject requests
- Issue materials
- Manage inventory
- Stock adjustments
- View all requests

### Admin
- Full system access
- Configure asset links
- Generate reports

---

## 💻 Frontend Pages

### Technician
- `/technician/parts-request` - Request materials with SearchableSelect

### Admin/Stock Manager
- `/admin/inventory` - Inventory management
- `/admin/inventory/approvals` - Approve/issue requests (to be created)

---

## 🔧 Implementation Guide

### 1. Run Migrations

```bash
cd c:\wamp64\www\factorymanager
php spark migrate
```

### 2. Configure Routes

Add to `app/Config/Routes.php`:

```php
$routes->group('api/v1/eam', ['namespace' => 'App\Controllers\Api\V1'], function($routes) {
    // Material Requests
    $routes->get('material-requests', 'MaterialRequestController::index');
    $routes->post('material-requests', 'MaterialRequestController::create');
    $routes->post('material-requests/(:num)/approve', 'MaterialRequestController::approve/$1');
    $routes->post('material-requests/(:num)/reject', 'MaterialRequestController::reject/$1');
    $routes->post('material-requests/(:num)/issue', 'MaterialRequestController::issue/$1');
    
    // Inventory
    $routes->get('inventory/items', 'EamInventoryController::index');
    $routes->post('inventory/items', 'EamInventoryController::create');
    $routes->put('inventory/items/(:num)', 'EamInventoryController::update/$1');
});
```

### 3. Create Models

Create these models in `app/Models/`:
- MaterialRequestModel.php
- MaterialRequestItemModel.php
- StockTransactionModel.php
- AssetInventoryLinkModel.php

---

## 📊 Database Schema

### inventory_items
- item_code, item_name, item_type
- category, subcategory
- unit_of_measure, unit_cost
- current_stock, reorder_level, min_stock_level
- location, bin_location
- is_critical, is_active

### material_requests
- request_number, work_order_id
- requested_by, department
- request_type, priority, status
- requested_date, required_date
- approved_by, approved_date
- issued_by, issued_date

### material_request_items
- request_id, inventory_item_id
- quantity_requested, quantity_approved, quantity_issued
- unit_cost, total_cost
- purpose, notes

### stock_transactions
- transaction_number, inventory_item_id
- transaction_type (purchase, issue, return, adjustment)
- quantity, unit_cost, total_cost
- reference_type, reference_id
- performed_by, transaction_date

---

## 🎨 UI Components

### SearchableSelect Integration
All dropdowns use SearchableSelect for:
- Inventory item selection (with stock levels)
- Request type selection
- Priority selection
- Asset selection

### Status Badges
- Pending: Yellow
- Approved: Green
- Issued: Blue
- Rejected: Red

### Priority Badges
- Low: Gray
- Medium: Blue
- High: Orange
- Urgent: Red

---

## 🔄 Workflow States

### Material Request States
1. **draft** - Being created
2. **pending** - Awaiting approval
3. **approved** - Approved, ready to issue
4. **partially_issued** - Some items issued
5. **issued** - All items issued
6. **rejected** - Request rejected
7. **cancelled** - Request cancelled

---

## 📈 Reports & Analytics

### Available Metrics
- Total inventory value
- Low stock items count
- Out of stock items
- Pending requests
- Request turnaround time
- Most requested items
- Stock movement trends

---

## 🚀 Next Steps

1. ✅ Database migrations created
2. ✅ Backend controllers created
3. ✅ Technician request page updated
4. ⏳ Create stock manager approval page
5. ⏳ Create inventory dashboard
6. ⏳ Add asset linkage UI
7. ⏳ Implement reports

---

## 🔐 Security

- Role-based access control
- Technicians see only their requests
- Stock managers see all requests
- Transaction audit trail
- User tracking on all operations

---

## 📱 Mobile Support

All pages are responsive and mobile-friendly with:
- Touch-optimized controls
- Simplified layouts for small screens
- Quick actions for common tasks

---

**Status**: Backend Complete | Frontend In Progress
**Grade**: Enterprise-Ready Architecture
