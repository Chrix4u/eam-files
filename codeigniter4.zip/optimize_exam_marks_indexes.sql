-- ============================================================================
-- EXAM MARKS QUERY OPTIMIZATION - INDEX SCRIPT
-- ============================================================================
-- This script adds indexes to optimize exam marks queries
-- Safe to run on live database - uses IF NOT EXISTS checks
-- ============================================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- ============================================================================
-- MARK TABLE INDEXES (Primary exam marks table)
-- ============================================================================

-- Composite index for student exam marks lookup
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_student_exam` (`student_id`, `exam_id`, `class_id`, `section_id`);

-- Index for filtering by year and term
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_year_term` (`year`(50), `term`(50), `sem`(50));

-- Index for subject-based queries
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_subject_exam` (`subject_id`, `exam_id`, `class_id`);

-- Index for class and section filtering
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_class_section_exam` (`class_id`, `section_id`, `exam_id`);

-- Composite index for complete mark retrieval
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_complete_marks` (`student_id`, `class_id`, `section_id`, `exam_id`, `year`(50), `term`(50));

-- Index for status filtering
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_status` (`status`);

-- Index for mute filtering
ALTER TABLE `mark` 
ADD INDEX IF NOT EXISTS `idx_mute` (`mute`);

-- ============================================================================
-- AGGREGATION TABLE INDEXES (Report card aggregation)
-- ============================================================================

-- Primary lookup index
ALTER TABLE `aggregation` 
ADD INDEX IF NOT EXISTS `idx_student_exam_agg` (`student_id`, `exam_id`, `class_id`, `section_id`);

-- Year and term filtering
ALTER TABLE `aggregation` 
ADD INDEX IF NOT EXISTS `idx_year_term_agg` (`year`(50), `term`(50), `sem`(50));

-- Class-based aggregation queries
ALTER TABLE `aggregation` 
ADD INDEX IF NOT EXISTS `idx_class_section_agg` (`class_id`, `section_id`, `exam_id`);

-- Complete aggregation lookup
ALTER TABLE `aggregation` 
ADD INDEX IF NOT EXISTS `idx_complete_agg` (`student_id`, `class_id`, `exam_id`, `year`(50), `term`(50));

-- Index for sorting by aggregate marks
ALTER TABLE `aggregation` 
ADD INDEX IF NOT EXISTS `idx_aggregate_mark` (`aggregate_mark`);

-- Index for raw score sorting
ALTER TABLE `aggregation` 
ADD INDEX IF NOT EXISTS `idx_raw_score` (`raw_score`);

-- ============================================================================
-- ENROLL TABLE INDEXES (Student enrollment data)
-- ============================================================================

-- Primary enrollment lookup
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_student_class_enroll` (`student_id`, `class_id`, `section_id`);

-- Year and term enrollment
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_year_term_enroll` (`year`(50), `term`(50), `sem`(50));

-- Status filtering
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_status_enroll` (`status`);

-- Complete enrollment lookup
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_complete_enroll` (`student_id`, `class_id`, `section_id`, `year`(50), `term`(50));

-- Roll number lookup
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_roll` (`roll`);

-- Mute status filtering
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_mute_enroll` (`mute`);

-- Class and section filtering
ALTER TABLE `enroll` 
ADD INDEX IF NOT EXISTS `idx_class_section_year` (`class_id`, `section_id`, `year`(50), `term`(50));

-- ============================================================================
-- EXAM TABLE INDEXES
-- ============================================================================

-- Year and term filtering
ALTER TABLE `exam` 
ADD INDEX IF NOT EXISTS `idx_year_term_exam` (`year`(50), `term`(50), `sem`(50));

-- Category filtering
ALTER TABLE `exam` 
ADD INDEX IF NOT EXISTS `idx_category` (`category_id`);

-- Date filtering
ALTER TABLE `exam` 
ADD INDEX IF NOT EXISTS `idx_date` (`date`(50));

-- ============================================================================
-- STUDENT TABLE INDEXES (For JOIN operations)
-- ============================================================================

-- Parent lookup for report cards
ALTER TABLE `student` 
ADD INDEX IF NOT EXISTS `idx_parent` (`parent_id`);

-- Active status filtering
ALTER TABLE `student` 
ADD INDEX IF NOT EXISTS `idx_active_status` (`active_status`);

-- Student code lookup
ALTER TABLE `student` 
ADD INDEX IF NOT EXISTS `idx_student_code` (`student_code`(50));

-- ============================================================================
-- SUBJECT TABLE INDEXES
-- ============================================================================

-- Class and teacher lookup
ALTER TABLE `subject` 
ADD INDEX IF NOT EXISTS `idx_class_teacher` (`class_id`, `teacher_id`);

-- Year and term filtering
ALTER TABLE `subject` 
ADD INDEX IF NOT EXISTS `idx_year_term_subject` (`year`(50), `term`(50), `sem`(50));

-- Status filtering
ALTER TABLE `subject` 
ADD INDEX IF NOT EXISTS `idx_status_subject` (`status`);

-- ============================================================================
-- CLASS AND SECTION INDEXES
-- ============================================================================

-- Teacher lookup
ALTER TABLE `class` 
ADD INDEX IF NOT EXISTS `idx_teacher` (`teacher_id`);

-- Section class lookup
ALTER TABLE `section` 
ADD INDEX IF NOT EXISTS `idx_class_section` (`class_id`, `teacher_id`);

-- ============================================================================
-- GRADE TABLE INDEXES (For grade calculation)
-- ============================================================================

-- Mark range lookup for grade assignment
ALTER TABLE `grade` 
ADD INDEX IF NOT EXISTS `idx_mark_range` (`mark_from`, `mark_upto`);

-- Grade point lookup
ALTER TABLE `grade` 
ADD INDEX IF NOT EXISTS `idx_grade_point_numeric` (`grade_point_numeric`);

-- ============================================================================
-- PORTFOLIO ASSESSMENT INDEXES
-- ============================================================================

-- Student exam lookup
ALTER TABLE `portfolio_assessment` 
ADD INDEX IF NOT EXISTS `idx_student_exam_portfolio` (`student_id`, `exam_id`, `class_id`);

-- Subject filtering
ALTER TABLE `portfolio_assessment` 
ADD INDEX IF NOT EXISTS `idx_subject_portfolio` (`subject_id`);

-- Year and term filtering
ALTER TABLE `portfolio_assessment` 
ADD INDEX IF NOT EXISTS `idx_year_term_portfolio` (`year`(50), `term`(50), `sem`(50));

-- Week filtering
ALTER TABLE `portfolio_assessment` 
ADD INDEX IF NOT EXISTS `idx_week` (`week`(50));

-- ============================================================================
-- ONLINE EXAM INDEXES
-- ============================================================================

-- Class and section lookup
ALTER TABLE `online_exam` 
ADD INDEX IF NOT EXISTS `idx_class_section_online` (`class_id`, `section_id`, `subject_id`);

-- Year and term filtering
ALTER TABLE `online_exam` 
ADD INDEX IF NOT EXISTS `idx_year_term_online` (`running_year`(50), `term`(50), `sem`(50));

-- Status filtering
ALTER TABLE `online_exam` 
ADD INDEX IF NOT EXISTS `idx_status_online` (`status`(50));

-- Exam date filtering
ALTER TABLE `online_exam` 
ADD INDEX IF NOT EXISTS `idx_exam_date` (`exam_date`);

-- ============================================================================
-- ONLINE EXAM RESULT INDEXES
-- ============================================================================

-- Student and exam lookup
ALTER TABLE `online_exam_result` 
ADD INDEX IF NOT EXISTS `idx_student_online_exam` (`student_id`, `online_exam_id`);

-- Status filtering
ALTER TABLE `online_exam_result` 
ADD INDEX IF NOT EXISTS `idx_status_result` (`status`(50));

-- Result filtering
ALTER TABLE `online_exam_result` 
ADD INDEX IF NOT EXISTS `idx_result` (`result`(50));

-- ============================================================================
-- INVOICE TABLE INDEXES (For fee-related queries with marks)
-- ============================================================================

-- Student lookup
ALTER TABLE `invoice` 
ADD INDEX IF NOT EXISTS `idx_student_invoice` (`student_id`, `class_id`);

-- Year and term filtering
ALTER TABLE `invoice` 
ADD INDEX IF NOT EXISTS `idx_year_term_invoice` (`year`(50), `term`(50), `sem`(50));

-- Status filtering
ALTER TABLE `invoice` 
ADD INDEX IF NOT EXISTS `idx_status_invoice` (`status`(50));

-- ============================================================================
-- PAYMENT TABLE INDEXES
-- ============================================================================

-- Student payment lookup
ALTER TABLE `payment` 
ADD INDEX IF NOT EXISTS `idx_student_payment` (`student_id`, `class_id`);

-- Year and term filtering
ALTER TABLE `payment` 
ADD INDEX IF NOT EXISTS `idx_year_term_payment` (`year`(50), `term`(50), `sem`(50));

-- Invoice lookup
ALTER TABLE `payment` 
ADD INDEX IF NOT EXISTS `idx_invoice` (`invoice_id`);

-- Timestamp filtering
ALTER TABLE `payment` 
ADD INDEX IF NOT EXISTS `idx_timestamp` (`timestamp`(50));

-- ============================================================================
-- TEACHER TABLE INDEXES
-- ============================================================================

-- Email lookup for authentication
ALTER TABLE `teacher` 
ADD INDEX IF NOT EXISTS `idx_email` (`email`(100));

-- Teacher code lookup
ALTER TABLE `teacher` 
ADD INDEX IF NOT EXISTS `idx_teacher_code` (`teacher_code`(50));

-- Active status
ALTER TABLE `teacher` 
ADD INDEX IF NOT EXISTS `idx_active_teacher` (`active_status`);

COMMIT;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================
-- Run these queries to verify indexes were created successfully

-- Check mark table indexes
SHOW INDEX FROM `mark`;

-- Check aggregation table indexes
SHOW INDEX FROM `aggregation`;

-- Check enroll table indexes
SHOW INDEX FROM `enroll`;

-- Check exam table indexes
SHOW INDEX FROM `exam`;

-- ============================================================================
-- PERFORMANCE TEST QUERIES
-- ============================================================================
-- Use EXPLAIN to test query performance after adding indexes

-- Example 1: Get student marks for specific exam
-- EXPLAIN SELECT * FROM mark 
-- WHERE student_id = 1 AND exam_id = 1 AND class_id = 1 AND section_id = 1;

-- Example 2: Get aggregation for class
-- EXPLAIN SELECT * FROM aggregation 
-- WHERE class_id = 1 AND section_id = 1 AND exam_id = 1 AND year = '2024' AND term = '1';

-- Example 3: Get enrolled students with marks
-- EXPLAIN SELECT e.*, m.* FROM enroll e
-- LEFT JOIN mark m ON e.student_id = m.student_id AND e.class_id = m.class_id
-- WHERE e.year = '2024' AND e.term = '1' AND e.class_id = 1;

-- ============================================================================
-- NOTES
-- ============================================================================
-- 1. All indexes use IF NOT EXISTS to prevent errors on re-run
-- 2. VARCHAR/TEXT columns are indexed with length limits (50-100 chars)
-- 3. Composite indexes are ordered by selectivity (most selective first)
-- 4. Indexes support common query patterns: filtering, joining, sorting
-- 5. No data is modified - only indexes are added
-- 6. Safe to run on production database during low-traffic periods
-- 7. Monitor query performance using EXPLAIN before and after
-- ============================================================================
