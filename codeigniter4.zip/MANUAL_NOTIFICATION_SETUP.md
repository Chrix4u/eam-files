# Manual Notification System Setup

## Step 1: Create notification_jobs Table

Open phpMyAdmin (http://localhost/phpmyadmin) and run this SQL:

```sql
CREATE TABLE IF NOT EXISTS `notification_jobs` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `channel` ENUM('in_app', 'email', 'sms') NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `data` JSON NOT NULL,
    `status` ENUM('pending', 'processing', 'completed', 'failed') NOT NULL DEFAULT 'pending',
    `attempts` INT(3) NOT NULL DEFAULT 0,
    `error` TEXT NULL,
    `created_at` DATETIME NULL,
    `processed_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `status_created_at` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
```

## Step 2: Insert Test Notification Jobs

```sql
-- PM due notification (in-app)
INSERT INTO notification_jobs (user_id, channel, type, data, status, attempts, created_at) VALUES
(1, 'in_app', 'pm_due', JSON_OBJECT(
    'schedule_id', 123,
    'asset_name', 'Pump A-101',
    'due_date', '2024-01-20',
    'title', 'PM Schedule Due Soon',
    'body', 'PM schedule #123 for asset Pump A-101 is due on 2024-01-20.'
), 'pending', 0, NOW());

-- PM due notification (email)
INSERT INTO notification_jobs (user_id, channel, type, data, status, attempts, created_at) VALUES
(1, 'email', 'pm_due', JSON_OBJECT(
    'schedule_id', 123,
    'asset_name', 'Pump A-101',
    'due_date', '2024-01-20',
    'title', 'PM Schedule Due Soon',
    'body', 'PM schedule #123 for asset Pump A-101 is due on 2024-01-20.'
), 'pending', 0, NOW());

-- Work order assigned notification
INSERT INTO notification_jobs (user_id, channel, type, data, status, attempts, created_at) VALUES
(1, 'in_app', 'wo_assigned', JSON_OBJECT(
    'wo_number', 'WO-2024-0001',
    'priority', 'high',
    'title', 'Work Order Assigned',
    'body', 'Work order WO-2024-0001 has been assigned to you. Priority: high.'
), 'pending', 0, NOW());
```

## Step 3: Verify Jobs Created

```sql
SELECT id, user_id, channel, type, status, created_at
FROM notification_jobs
WHERE status = 'pending'
ORDER BY created_at DESC;
```

You should see 3 pending jobs.

## Step 4: Start Notification Worker

Open command prompt in `C:\wamp64\www\factorymanager` and run:

```bash
php spark eam:worker
```

You should see:
```
Notification Worker Started
Press Ctrl+C to stop
Processing job #1 - in_app for user #1
✓ Job #1 completed
Processing job #2 - email for user #1
✓ Job #2 completed (or failed if SMTP not configured)
Processing job #3 - in_app for user #1
✓ Job #3 completed
```

## Step 5: Verify Notifications Created

```sql
SELECT * FROM notifications ORDER BY created_at DESC LIMIT 5;
```

You should see 2 in-app notifications for user #1.

## Step 6: Test API Endpoints

Use Postman or curl to test:

### Get Notifications
```http
GET http://localhost/factorymanager/public/api/v1/eam/notifications?user_id=1
Authorization: Bearer YOUR_JWT_TOKEN
```

### Mark as Read
```http
PUT http://localhost/factorymanager/public/api/v1/eam/notifications/1/read
Authorization: Bearer YOUR_JWT_TOKEN
```

## Step 7: Configure Email (Optional)

Edit `app/Config/Email.php`:

```php
public string $SMTPHost = 'smtp.gmail.com';
public string $SMTPUser = 'your-email@gmail.com';
public string $SMTPPass = 'your-app-password';
public int $SMTPPort = 587;
```

Then restart the worker to process email jobs.

## Step 8: Setup Escalation Cron Job

Windows Task Scheduler:
- Program: `C:\wamp64\bin\php\php8.2.0\php.exe`
- Arguments: `spark eam:escalations`
- Start in: `C:\wamp64\www\factorymanager`
- Trigger: Daily, repeat every 1 hour

## ✅ System Ready!

Your notification system is now operational:
- ✅ In-app notifications saved to database
- ✅ Email notifications queued (configure SMTP to send)
- ✅ Worker processes jobs automatically
- ✅ API endpoints available
- ✅ Escalation rules ready (24h → supervisor, 72h → manager)
