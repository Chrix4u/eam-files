-- Clear work orders and related data
TRUNCATE TABLE work_order_logs;
TRUNCATE TABLE work_order_materials;
TRUNCATE TABLE work_order_attachments;
TRUNCATE TABLE work_orders;

-- Clear maintenance requests and related data
TRUNCATE TABLE maintenance_request_workflow;
TRUNCATE TABLE maintenance_notifications;
TRUNCATE TABLE maintenance_requests;
