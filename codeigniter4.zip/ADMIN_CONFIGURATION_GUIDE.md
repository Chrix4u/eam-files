# Admin Configuration Guide

## 🔧 System Configuration

### 1. Initial Setup

#### Database Configuration
```bash
# Run migrations
mysql -u root -p factory_manager < RUN_ALL_MIGRATIONS.sql

# Verify tables
mysql -u root -p factory_manager -e "SHOW TABLES LIKE '%loto%'"
mysql -u root -p factory_manager -e "SHOW TABLES LIKE '%permit%'"
```

#### API Configuration
Edit `app/Config/Routes.php` - All routes already configured ✅

### 2. User Roles & Permissions

#### Required Roles
- **Admin**: Full system access
- **Safety Officer**: Permit approvals, LOTO oversight
- **Supervisor**: Work order approvals, permit approvals
- **Technician**: Work execution, time tracking
- **Area Manager**: High-risk permit approvals

#### Setting Up Roles
```sql
INSERT INTO roles (name, description) VALUES
('safety_officer', 'Safety Officer - Permit & LOTO Management'),
('area_manager', 'Area Manager - High-Risk Approvals');
```

### 3. Permit Configuration

#### Permit Types
- hot_work
- confined_space
- electrical
- height
- excavation
- cold_work

#### Risk Levels
- low: Supervisor approval only
- medium: Supervisor + Safety Officer
- high: Supervisor + Safety Officer + Area Manager
- critical: All levels + Plant Manager

#### Approval Workflow
```php
// In PermitToWorkController
if ($permit['risk_level'] === 'critical' || $permit['risk_level'] === 'high') {
    // Requires area manager approval
}
```

### 4. LOTO Configuration

#### Lock Inventory Setup
```sql
INSERT INTO loto_locks (lock_number, lock_type, status, current_location) VALUES
('LOCK-001', 'Padlock', 'available', 'Tool Crib A'),
('LOCK-002', 'Padlock', 'available', 'Tool Crib A'),
('LOCK-003', 'Hasp', 'available', 'Tool Crib B');
```

#### Equipment Procedures
Create procedures for each critical equipment:
1. Identify all energy sources
2. Document isolation steps
3. Define verification procedures
4. Specify restoration sequence

### 5. Notification Settings

#### Email Configuration
Edit `.env`:
```
email.fromEmail = noreply@ifactory.com
email.fromName = iFactory EAM
email.SMTPHost = smtp.gmail.com
email.SMTPPort = 587
```

#### Notification Rules
- Permit approval: Email to approver
- LOTO verification: SMS to safety officer
- Work order completion: Email to supervisor

### 6. Time Tracking Settings

#### Break Policies
```php
// Default break duration
'default_break_minutes' => 30,

// Overtime threshold
'overtime_threshold_hours' => 8,
```

#### Rounding Rules
```php
// Round to nearest 15 minutes
'time_rounding_minutes' => 15,
```

### 7. Backup & Maintenance

#### Daily Backups
```bash
# Backup script
mysqldump -u root -p factory_manager > backup_$(date +%Y%m%d).sql
```

#### Log Rotation
```bash
# Clean old logs (90 days)
find /var/log/factorymanager -name "*.log" -mtime +90 -delete
```

### 8. Performance Tuning

#### Database Indexes
```sql
-- Already created in migration ✅
CREATE INDEX idx_work_order_tech ON technician_time_logs(work_order_id, technician_id);
CREATE INDEX idx_permit_status ON permits_to_work(status);
CREATE INDEX idx_loto_equipment ON loto_applications(equipment_id);
```

#### Caching
```php
// Enable query caching
$db->cacheOn();
```

### 9. Security Settings

#### JWT Token Expiry
```php
// In Config/JWT.php
'expiry' => 3600, // 1 hour
'refresh_expiry' => 86400, // 24 hours
```

#### Password Policy
```php
'min_length' => 8,
'require_uppercase' => true,
'require_number' => true,
'require_special' => true,
```

### 10. Monitoring & Alerts

#### System Health Checks
```bash
# Check API status
curl http://localhost/factorymanager/public/index.php/api/v1/eam/system/health

# Check database connections
php spark db:check
```

#### Alert Thresholds
- Permit expiring: 2 hours before
- LOTO active > 24 hours: Alert safety officer
- Time log active > 12 hours: Alert supervisor

---

## 📊 Reports Configuration

### Standard Reports
1. Work Order Completion Summary
2. Permit to Work Statistics
3. LOTO Compliance Report
4. Time Tracking by Technician
5. Material Usage Report

### Custom Reports
Use SQL queries in Reports Builder:
```sql
-- Example: Permits by Risk Level
SELECT risk_level, COUNT(*) as count, 
       AVG(TIMESTAMPDIFF(HOUR, valid_from, valid_until)) as avg_duration
FROM permits_to_work
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY risk_level;
```

---

## 🔍 Troubleshooting

### Common Admin Issues

**Issue**: Permits not routing to approvers
**Solution**: Check user roles and approval workflow configuration

**Issue**: Time logs not calculating correctly
**Solution**: Verify timezone settings in `.env`

**Issue**: LOTO locks showing as unavailable
**Solution**: Check lock status in database, update if needed

---

## 📞 Support Escalation

1. **Level 1**: IT Help Desk
2. **Level 2**: System Administrator
3. **Level 3**: Development Team

---

**Last Updated**: January 2025  
**Version**: 1.0
