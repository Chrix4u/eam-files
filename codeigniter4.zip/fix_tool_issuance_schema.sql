-- Fix Tool Issuance Schema Issues
-- Run this SQL to fix database schema for partial tool issuance feature

USE factory_manager;

-- 1. Update work_order_tool_request_items.condition_on_issue to support all 5 conditions
ALTER TABLE `work_order_tool_request_items` 
MODIFY COLUMN `condition_on_issue` ENUM('GOOD','FAIR','DAMAGED','UNDER_MAINTENANCE','NOT_AVAILABLE') NULL;

-- 2. Update tool_issue_logs.condition_on_issue to support all 5 conditions
ALTER TABLE `tool_issue_logs` 
MODIFY COLUMN `condition_on_issue` ENUM('GOOD','FAIR','DAMAGED','UNDER_MAINTENANCE','NOT_AVAILABLE') NOT NULL DEFAULT 'GOOD';

-- 3. Add missing columns to tool_issue_logs if they don't exist
ALTER TABLE `tool_issue_logs` 
ADD COLUMN IF NOT EXISTS `tool_request_item_id` INT UNSIGNED NULL AFTER `tool_request_id`,
ADD COLUMN IF NOT EXISTS `tool_id` INT UNSIGNED NULL AFTER `tool_request_item_id`,
ADD COLUMN IF NOT EXISTS `quantity` INT NULL DEFAULT 1 AFTER `tool_id`;

-- 4. Verify the changes
SELECT 'Schema updated successfully!' as status;

-- Show updated structure
DESCRIBE work_order_tool_request_items;
DESCRIBE tool_issue_logs;
