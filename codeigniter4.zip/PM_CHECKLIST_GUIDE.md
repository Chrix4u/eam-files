# PM Checklist Generation Guide

## Complete Workflow to Generate and Print PM Checklists

### Prerequisites (Data Setup Required):

1. **Equipment/Machines** - Must exist in `equipment` table
2. **Assemblies** - Must be linked to equipment
3. **Parts** - Must be linked to assemblies
4. **PM Tasks** - Must be created in `pm_tasks` table
5. **PM Task Assignments** - Parts must have PM tasks assigned via `pm_part_tasks` table
6. **PM Schedules** - Must exist in `pm_schedule` table
7. **PM Schedule Tracking** - Must have due schedules in `pm_schedule_tracking` table
8. **Checklist Templates** - Parts should have checklist templates assigned
9. **Inspection Types** - Must exist in `pm_inspection_types` table

---

## Step-by-Step Process:

### Step 1: Navigate to PM Dashboard
- Go to sidebar → **Preventive Maintenance** → **Inspection Scheduler**
- URL: `http://localhost/factorymanager/pmo/dashboard`

### Step 2: View Equipment with Due Parts
- The dashboard shows all equipment that have parts with due PM schedules
- Each equipment card shows:
  - Equipment name and ID
  - List of parts that need inspection
  - Number of tasks due

### Step 3: Select Equipment
- Click the **"Inspect"** button on any equipment card
- This takes you to: `/pmo/select-inspection/{equipment_id}`

### Step 4: Choose Inspection Type
- Select the inspection type (Daily, Weekly, Monthly, etc.)
- Click **"Generate Checklist"** button
- Opens in new tab: `/pmo/generate-checklist/{equipment_id}?inspection_type_id={id}`

### Step 5: Print Checklist
- The printable checklist displays with:
  - PMO code
  - Machine information
  - All parts and assemblies
  - PM task instructions
  - Inspection items with measurement methods
  - Fields for measured values, conditions, remarks
  - Signature sections
- Click **"Print Checklist"** button to print

---

## Troubleshooting:

### Issue: "No due PM schedules found"
**Solution:** You need to create PM schedules first.

Run this URL to create test schedules:
```
http://localhost/factorymanager/pm-setup/create-test
```

### Issue: "No inspection types available"
**Solution:** Check if inspection types exist in database.

### Issue: "Empty checklist generated"
**Possible causes:**
1. No PM tasks assigned to parts
2. No checklist templates assigned to parts
3. No due schedules in tracking table

---

## Quick Test Setup:

### 1. Create Test Schedules (if not already done):
```
http://localhost/factorymanager/pm-setup/create-test
```

### 2. Verify Data:
Check these tables have data:
- `equipment`
- `parts`
- `pm_tasks`
- `pm_part_tasks`
- `pm_schedule`
- `pm_schedule_tracking`
- `pm_inspection_types`

### 3. Access PM Dashboard:
```
http://localhost/factorymanager/pmo/dashboard
```

---

## Alternative: Direct URL Access

If you know the equipment ID and inspection type ID:
```
http://localhost/factorymanager/pmo/generate-checklist/{equipment_id}?inspection_type_id={inspection_type_id}
```

Example:
```
http://localhost/factorymanager/pmo/generate-checklist/1?inspection_type_id=1
```

---

## Database Check Queries:

### Check if you have due schedules:
```sql
SELECT * FROM pm_schedule_tracking 
WHERE next_due_date <= CURDATE() 
AND status = 'scheduled';
```

### Check equipment with PM schedules:
```sql
SELECT DISTINCT e.id, e.name, e.equipment_id
FROM equipment e
JOIN pm_schedule ps ON e.id = ps.equipment_id
JOIN pm_schedule_tracking pst ON ps.schedule_id = pst.schedule_id
WHERE pst.next_due_date <= CURDATE();
```

### Check inspection types:
```sql
SELECT * FROM pm_inspection_types;
```

---

## Common Issues:

1. **Empty Dashboard**: No due schedules exist
   - Solution: Run `/pm-setup/create-test` to create test data

2. **No Inspection Types**: Inspection types not in database
   - Solution: Insert inspection types manually or via migration

3. **Empty Checklist**: No checklist items for parts
   - Solution: Assign checklist templates to parts

4. **404 Error**: Routes not loaded
   - Solution: Clear cache: `php spark cache:clear`
