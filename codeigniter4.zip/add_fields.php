<?php

require 'vendor/autoload.php';

$db = \Config\Database::connect();

// Add fields to work_orders
$sql = "
ALTER TABLE work_orders 
ADD COLUMN IF NOT EXISTS is_breakdown BOOLEAN DEFAULT FALSE AFTER type,
ADD COLUMN IF NOT EXISTS technical_description TEXT NULL AFTER description,
ADD COLUMN IF NOT EXISTS trade_activity ENUM('mechanical', 'electrical', 'civil', 'facility', 'workshop', 'other') DEFAULT 'mechanical' AFTER type,
ADD COLUMN IF NOT EXISTS delivery_date_required DATE NULL AFTER scheduled_date,
ADD COLUMN IF NOT EXISTS repair_started_date DATETIME NULL AFTER completed_date,
ADD COLUMN IF NOT EXISTS repair_ended_date DATETIME NULL AFTER repair_started_date,
ADD COLUMN IF NOT EXISTS technician_report TEXT NULL AFTER notes,
ADD COLUMN IF NOT EXISTS failure_description TEXT NULL AFTER technician_report,
ADD COLUMN IF NOT EXISTS cause_description TEXT NULL AFTER failure_description,
ADD COLUMN IF NOT EXISTS action_description TEXT NULL AFTER cause_description,
ADD COLUMN IF NOT EXISTS general_remarks TEXT NULL AFTER action_description,
ADD COLUMN IF NOT EXISTS operator_signature VARCHAR(255) NULL AFTER general_remarks,
ADD COLUMN IF NOT EXISTS line_manager_signature VARCHAR(255) NULL AFTER operator_signature,
ADD COLUMN IF NOT EXISTS supervisor_signature VARCHAR(255) NULL AFTER line_manager_signature,
ADD COLUMN IF NOT EXISTS downtime_hours DECIMAL(10,2) NULL AFTER estimated_hours
";

try {
    $db->query($sql);
    echo "✓ Work order fields added successfully\n";
} catch (\Exception $e) {
    echo "Note: " . $e->getMessage() . "\n";
}

// Create materials table
$sql2 = "
CREATE TABLE IF NOT EXISTS work_order_materials (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    gt_code VARCHAR(100) NULL,
    description TEXT NOT NULL,
    quantity_issued DECIMAL(10,2) NOT NULL,
    remarks TEXT NULL,
    receiver_signature VARCHAR(255) NULL,
    store_clerk_signature VARCHAR(255) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
";

try {
    $db->query($sql2);
    echo "✓ Work order materials table created successfully\n";
} catch (\Exception $e) {
    echo "Note: " . $e->getMessage() . "\n";
}

echo "\nDone!\n";
