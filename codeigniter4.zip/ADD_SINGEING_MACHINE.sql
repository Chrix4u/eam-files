-- Add Singeing Desizing Machine Sample Asset
-- Run this SQL in phpMyAdmin

-- Insert the machine
INSERT INTO `assets` (
    `asset_name`, 
    `asset_code`, 
    `asset_type`, 
    `manufacturer`, 
    `model_number`, 
    `serial_number`, 
    `status`, 
    `criticality`, 
    `department_id`,
    `location`,
    `installation_date`,
    `acquisition_cost`,
    `description`,
    `created_at`,
    `updated_at`
) VALUES (
    'Singeing Desizing Machine #1',
    'SDM-001',
    'machine',
    'Textile Machinery Co.',
    'SDM-5000',
    'SDM5000-2024-001',
    'active',
    'high',
    1,
    'Production Floor - Section A',
    '2024-01-15',
    125000.00,
    'High-speed singeing and desizing machine for fabric processing. Removes protruding fibers and sizing agents from woven fabrics.',
    NOW(),
    NOW()
);

-- Get the inserted machine ID (you'll need to check this after insert)
-- SET @machine_id = LAST_INSERT_ID();

-- Optional: Add some components for the machine
-- Uncomment and update @machine_id with actual ID after first insert

/*
INSERT INTO `assets` (`asset_name`, `asset_code`, `asset_type`, `parent_id`, `status`, `criticality`, `created_at`, `updated_at`) VALUES
('Singeing Burner Assembly', 'SDM-001-BA', 'component', @machine_id, 'active', 'critical', NOW(), NOW()),
('Desizing Chemical Tank', 'SDM-001-CT', 'component', @machine_id, 'active', 'high', NOW(), NOW()),
('Fabric Feed Roller', 'SDM-001-FR', 'component', @machine_id, 'active', 'medium', NOW(), NOW()),
('Temperature Control Unit', 'SDM-001-TC', 'component', @machine_id, 'active', 'high', NOW(), NOW());
*/

-- Optional: Add initial meter reading
/*
INSERT INTO `meter_readings` (`asset_id`, `meter_type`, `reading_value`, `unit`, `reading_date`, `recorded_by`, `created_at`) VALUES
(@machine_id, 'runtime_hours', 0, 'hours', NOW(), 1, NOW());
*/

-- Optional: Add preventive maintenance schedule
/*
INSERT INTO `pm_schedules` (`asset_id`, `task_name`, `frequency_days`, `last_performed`, `next_due`, `priority`, `created_at`) VALUES
(@machine_id, 'Burner Inspection & Cleaning', 30, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 'high', NOW()),
(@machine_id, 'Chemical Tank Refill', 7, NOW(), DATE_ADD(NOW(), INTERVAL 7 DAY), 'medium', NOW()),
(@machine_id, 'Roller Alignment Check', 90, NOW(), DATE_ADD(NOW(), INTERVAL 90 DAY), 'medium', NOW());
*/

SELECT 'Singeing Desizing Machine added successfully!' as message;
