-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 7: ACCOUNTS & FINANCE
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- ACCOUNTS TABLE
ALTER TABLE `accounts` ADD INDEX IF NOT EXISTS `idx_account_type` (`account_type`);
ALTER TABLE `accounts` ADD INDEX IF NOT EXISTS `idx_account_number` (`account_number`(50));
ALTER TABLE `accounts` ADD INDEX IF NOT EXISTS `idx_is_bank` (`account_is_bank`);
ALTER TABLE `accounts` ADD INDEX IF NOT EXISTS `idx_is_transferrable` (`account_is_transferrable`);

-- ACCOUNTS_PAYABLE TABLE
ALTER TABLE `accounts_payable` ADD INDEX IF NOT EXISTS `idx_supplier` (`supplier_id`);
ALTER TABLE `accounts_payable` ADD INDEX IF NOT EXISTS `idx_po_code` (`po_code`(50));
ALTER TABLE `accounts_payable` ADD INDEX IF NOT EXISTS `idx_status_payable` (`status`(50));
ALTER TABLE `accounts_payable` ADD INDEX IF NOT EXISTS `idx_track_code` (`track_code`(50));
ALTER TABLE `accounts_payable` ADD INDEX IF NOT EXISTS `idx_account_payable` (`account_id`);
ALTER TABLE `accounts_payable` ADD INDEX IF NOT EXISTS `idx_date_payable` (`date`(50));

-- EXPENSE_CATEGORY TABLE
ALTER TABLE `expense_category` ADD INDEX IF NOT EXISTS `idx_expense_name` (`name`(100));

-- BENEFIT_CATEGORY TABLE
ALTER TABLE `benefit_category` ADD INDEX IF NOT EXISTS `idx_benefit_name` (`name`(100));

-- SALARY_TYPE TABLE
ALTER TABLE `salary_type` ADD INDEX IF NOT EXISTS `idx_salary_type_name` (`salary_type`);
ALTER TABLE `salary_type` ADD INDEX IF NOT EXISTS `idx_create_date_salary` (`create_date`);

-- ACCOUNT_TYPE TABLE
ALTER TABLE `account_type` ADD INDEX IF NOT EXISTS `idx_account_type_name` (`name`(100));

COMMIT;
