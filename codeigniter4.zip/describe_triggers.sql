DESCRIBE pm_triggers;
