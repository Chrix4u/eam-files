# 🔹 PHASE 3: DATA MODEL & API DESIGN - PART 2
## Job Planning, SLA Tracking & Models

**Architect**: Senior EAM System Expert  
**Date**: January 2025

---

## 3. JOB PLANNING API

### JobPlanController.php

```php
<?php

namespace App\Controllers\Api\V1;

use CodeIgniter\RESTful\ResourceController;

class JobPlanController extends ResourceController
{
    protected $modelName = 'App\Models\WorkOrderJobPlanModel';
    protected $format = 'json';

    /**
     * POST /api/v1/eam/work-orders/{id}/job-plan
     */
    public function create($workOrderId)
    {
        $data = $this->request->getJSON(true);
        
        $planId = $this->model->insert([
            'work_order_id' => $workOrderId,
            'plan_name' => $data['plan_name'] ?? null,
            'estimated_duration' => $data['estimated_duration'] ?? null,
            'required_skills' => json_encode($data['required_skills'] ?? []),
            'required_tools' => json_encode($data['required_tools'] ?? []),
            'required_parts' => json_encode($data['required_parts'] ?? []),
            'safety_requirements' => $data['safety_requirements'] ?? null,
            'step_by_step_instructions' => $data['step_by_step_instructions'] ?? null,
            'permits_required' => json_encode($data['permits_required'] ?? []),
            'special_instructions' => $data['special_instructions'] ?? null,
            'created_by' => $this->request->user_id,
            'status' => 'draft'
        ]);
        
        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Job plan created',
            'data' => ['id' => $planId]
        ]);
    }

    /**
     * GET /api/v1/eam/work-orders/{id}/job-plan
     */
    public function show($workOrderId)
    {
        $plan = $this->model->where('work_order_id', $workOrderId)->first();
        
        if (!$plan) {
            return $this->failNotFound('Job plan not found');
        }
        
        // Decode JSON fields
        $plan['required_skills'] = json_decode($plan['required_skills'], true);
        $plan['required_tools'] = json_decode($plan['required_tools'], true);
        $plan['required_parts'] = json_decode($plan['required_parts'], true);
        $plan['permits_required'] = json_decode($plan['permits_required'], true);
        
        return $this->respond([
            'status' => 'success',
            'data' => $plan
        ]);
    }

    /**
     * PUT /api/v1/eam/work-orders/{id}/job-plan
     */
    public function update($workOrderId)
    {
        $data = $this->request->getJSON(true);
        $plan = $this->model->where('work_order_id', $workOrderId)->first();
        
        if (!$plan) {
            return $this->failNotFound('Job plan not found');
        }
        
        $updateData = [];
        if (isset($data['plan_name'])) $updateData['plan_name'] = $data['plan_name'];
        if (isset($data['estimated_duration'])) $updateData['estimated_duration'] = $data['estimated_duration'];
        if (isset($data['required_skills'])) $updateData['required_skills'] = json_encode($data['required_skills']);
        if (isset($data['required_tools'])) $updateData['required_tools'] = json_encode($data['required_tools']);
        if (isset($data['required_parts'])) $updateData['required_parts'] = json_encode($data['required_parts']);
        if (isset($data['safety_requirements'])) $updateData['safety_requirements'] = $data['safety_requirements'];
        if (isset($data['step_by_step_instructions'])) $updateData['step_by_step_instructions'] = $data['step_by_step_instructions'];
        if (isset($data['permits_required'])) $updateData['permits_required'] = json_encode($data['permits_required']);
        
        $this->model->update($plan['id'], $updateData);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Job plan updated'
        ]);
    }

    /**
     * POST /api/v1/eam/work-orders/{id}/job-plan/approve
     */
    public function approve($workOrderId)
    {
        $plan = $this->model->where('work_order_id', $workOrderId)->first();
        
        if (!$plan) {
            return $this->failNotFound('Job plan not found');
        }
        
        $this->model->update($plan['id'], [
            'status' => 'approved',
            'approved_by' => $this->request->user_id,
            'approved_at' => date('Y-m-d H:i:s')
        ]);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Job plan approved'
        ]);
    }

    /**
     * POST /api/v1/eam/work-orders/{id}/resources/reserve
     */
    public function reserveResources($workOrderId)
    {
        $data = $this->request->getJSON(true);
        $reservationModel = model('WorkOrderResourceReservationModel');
        
        $db = \Config\Database::connect();
        $db->transStart();
        
        // Reserve parts
        if (!empty($data['parts'])) {
            foreach ($data['parts'] as $part) {
                $reservationModel->insert([
                    'work_order_id' => $workOrderId,
                    'resource_type' => 'part',
                    'resource_id' => $part['part_id'],
                    'quantity' => $part['quantity'],
                    'reserved_by' => $this->request->user_id,
                    'reserved_at' => date('Y-m-d H:i:s'),
                    'status' => 'reserved'
                ]);
            }
        }
        
        // Reserve tools
        if (!empty($data['tools'])) {
            foreach ($data['tools'] as $tool) {
                $reservationModel->insert([
                    'work_order_id' => $workOrderId,
                    'resource_type' => 'tool',
                    'resource_id' => $tool['tool_id'],
                    'quantity' => $tool['quantity'],
                    'reserved_by' => $this->request->user_id,
                    'reserved_at' => date('Y-m-d H:i:s'),
                    'status' => 'reserved'
                ]);
            }
        }
        
        $db->transComplete();
        
        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Resources reserved'
        ]);
    }

    /**
     * GET /api/v1/eam/work-orders/{id}/resources/check-availability
     */
    public function checkAvailability($workOrderId)
    {
        $plan = $this->model->where('work_order_id', $workOrderId)->first();
        
        if (!$plan) {
            return $this->failNotFound('Job plan not found');
        }
        
        $requiredParts = json_decode($plan['required_parts'], true) ?? [];
        $requiredTools = json_decode($plan['required_tools'], true) ?? [];
        
        $availability = [
            'parts' => [],
            'tools' => [],
            'all_available' => true
        ];
        
        // Check parts availability
        $partsModel = model('PartModel');
        foreach ($requiredParts as $part) {
            $partData = $partsModel->find($part['part_id']);
            $available = $partData && $partData['quantity_on_hand'] >= $part['quantity'];
            
            $availability['parts'][] = [
                'part_id' => $part['part_id'],
                'required' => $part['quantity'],
                'available' => $partData['quantity_on_hand'] ?? 0,
                'is_available' => $available
            ];
            
            if (!$available) $availability['all_available'] = false;
        }
        
        // Check tools availability
        $toolsModel = model('ToolModel');
        foreach ($requiredTools as $tool) {
            $toolData = $toolsModel->find($tool['tool_id']);
            $available = $toolData && $toolData['status'] === 'available';
            
            $availability['tools'][] = [
                'tool_id' => $tool['tool_id'],
                'is_available' => $available
            ];
            
            if (!$available) $availability['all_available'] = false;
        }
        
        return $this->respond([
            'status' => 'success',
            'data' => $availability
        ]);
    }
}
```

---

## 4. SLA TRACKING API

### SLAController.php

```php
<?php

namespace App\Controllers\Api\V1;

use CodeIgniter\RESTful\ResourceController;

class SLAController extends ResourceController
{
    protected $modelName = 'App\Models\WorkOrderSLATrackingModel';
    protected $format = 'json';

    /**
     * GET /api/v1/eam/work-orders/{id}/sla-status
     */
    public function getStatus($workOrderId)
    {
        $sla = $this->model
            ->select('work_order_sla_tracking.*, sla_definitions.name as sla_name')
            ->join('sla_definitions', 'sla_definitions.id = work_order_sla_tracking.sla_definition_id')
            ->where('work_order_id', $workOrderId)
            ->first();
        
        if (!$sla) {
            return $this->failNotFound('SLA tracking not found');
        }
        
        $now = time();
        
        // Calculate response SLA
        $responseSLA = [
            'target' => $sla['target_response_time'],
            'actual' => $sla['actual_response_time'],
            'status' => $sla['response_breached'] ? 'breached' : ($sla['actual_response_time'] ? 'met' : 'pending'),
            'remaining_minutes' => null
        ];
        
        if (!$sla['actual_response_time'] && !$sla['response_breached']) {
            $remaining = strtotime($sla['target_response_time']) - $now;
            $responseSLA['remaining_minutes'] = max(0, round($remaining / 60));
            $responseSLA['status'] = $remaining > 0 ? 'on_track' : 'at_risk';
        }
        
        // Calculate resolution SLA
        $resolutionSLA = [
            'target' => $sla['target_resolution_time'],
            'actual' => $sla['actual_resolution_time'],
            'status' => $sla['resolution_breached'] ? 'breached' : ($sla['actual_resolution_time'] ? 'met' : 'pending'),
            'remaining_minutes' => null
        ];
        
        if (!$sla['actual_resolution_time'] && !$sla['resolution_breached']) {
            $remaining = strtotime($sla['target_resolution_time']) - $now;
            $resolutionSLA['remaining_minutes'] = max(0, round($remaining / 60));
            $resolutionSLA['status'] = $remaining > 0 ? 'on_track' : 'at_risk';
        }
        
        return $this->respond([
            'status' => 'success',
            'data' => [
                'sla_name' => $sla['sla_name'],
                'response_sla' => $responseSLA,
                'resolution_sla' => $resolutionSLA,
                'escalation_level' => $sla['current_escalation_level'],
                'escalated_to' => $sla['escalated_to']
            ]
        ]);
    }

    /**
     * GET /api/v1/eam/work-orders/sla-breached
     */
    public function getBreached()
    {
        $breached = $this->model
            ->select('work_order_sla_tracking.*, maintenance_orders.order_number, maintenance_orders.title')
            ->join('maintenance_orders', 'maintenance_orders.id = work_order_sla_tracking.work_order_id')
            ->groupStart()
                ->where('response_breached', true)
                ->orWhere('resolution_breached', true)
            ->groupEnd()
            ->orderBy('current_escalation_level', 'DESC')
            ->findAll();
        
        return $this->respond([
            'status' => 'success',
            'data' => $breached
        ]);
    }

    /**
     * POST /api/v1/eam/work-orders/{id}/escalate
     */
    public function escalate($workOrderId)
    {
        $data = $this->request->getJSON(true);
        
        $sla = $this->model->where('work_order_id', $workOrderId)->first();
        
        if (!$sla) {
            return $this->failNotFound('SLA tracking not found');
        }
        
        $this->model->update($sla['id'], [
            'current_escalation_level' => $data['escalation_level'],
            'escalated_to' => $data['escalate_to'],
            'escalated_at' => date('Y-m-d H:i:s'),
            'escalation_notes' => $data['reason']
        ]);
        
        // Send notification
        $this->sendEscalationNotification($workOrderId, $data['escalate_to'], $data['escalation_level']);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Work order escalated'
        ]);
    }

    /**
     * GET /api/v1/eam/sla-dashboard
     */
    public function dashboard()
    {
        $db = \Config\Database::connect();
        
        $stats = [
            'total_work_orders' => $db->table('work_order_sla_tracking')->countAll(),
            'sla_met' => $db->table('work_order_sla_tracking')
                ->where('response_breached', false)
                ->where('resolution_breached', false)
                ->countAllResults(),
            'response_breached' => $db->table('work_order_sla_tracking')
                ->where('response_breached', true)
                ->countAllResults(),
            'resolution_breached' => $db->table('work_order_sla_tracking')
                ->where('resolution_breached', true)
                ->countAllResults(),
            'at_risk' => $db->query("
                SELECT COUNT(*) as count
                FROM work_order_sla_tracking
                WHERE actual_resolution_time IS NULL
                AND TIMESTAMPDIFF(MINUTE, NOW(), target_resolution_time) BETWEEN 0 AND 120
            ")->getRow()->count
        ];
        
        $stats['compliance_rate'] = $stats['total_work_orders'] > 0 
            ? round(($stats['sla_met'] / $stats['total_work_orders']) * 100, 2) 
            : 0;
        
        return $this->respond([
            'status' => 'success',
            'data' => $stats
        ]);
    }

    private function sendEscalationNotification($workOrderId, $escalateTo, $level)
    {
        $notificationService = service('notification');
        $notificationService->notifyEscalation($workOrderId, $escalateTo, $level);
    }
}
```

---

## 5. COMPLETE MODELS

### WorkOrderTeamMemberModel.php

```php
<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkOrderTeamMemberModel extends Model
{
    protected $table = 'work_order_team_members';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'work_order_id', 'technician_id', 'role', 'assigned_date', 'assigned_by',
        'accepted_date', 'declined_date', 'status', 'labor_hours', 'notes'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    protected $validationRules = [
        'work_order_id' => 'required|integer',
        'technician_id' => 'required|integer',
        'role' => 'required|in_list[team_lead,assistant,specialist]'
    ];
}
```

### WorkOrderAssistanceRequestModel.php

```php
<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkOrderAssistanceRequestModel extends Model
{
    protected $table = 'work_order_assistance_requests';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'work_order_id', 'requested_by', 'requested_at', 'skill_required',
        'reason', 'urgency', 'status', 'approved_by', 'approved_at',
        'assigned_technician_id', 'fulfilled_at', 'rejection_reason'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    
    protected $validationRules = [
        'work_order_id' => 'required|integer',
        'reason' => 'required',
        'urgency' => 'in_list[low,medium,high]'
    ];
}
```

### WorkOrderJobPlanModel.php

```php
<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkOrderJobPlanModel extends Model
{
    protected $table = 'work_order_job_plans';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'work_order_id', 'plan_name', 'estimated_duration', 'required_skills',
        'required_tools', 'required_parts', 'safety_requirements',
        'step_by_step_instructions', 'permits_required', 'special_instructions',
        'created_by', 'approved_by', 'approved_at', 'status'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
}
```

### WorkOrderResourceReservationModel.php

```php
<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkOrderResourceReservationModel extends Model
{
    protected $table = 'work_order_resource_reservations';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'work_order_id', 'resource_type', 'resource_id', 'quantity',
        'reserved_by', 'reserved_at', 'released_at', 'status', 'notes'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
}
```

### WorkOrderSLATrackingModel.php

```php
<?php

namespace App\Models;

use CodeIgniter\Model;

class WorkOrderSLATrackingModel extends Model
{
    protected $table = 'work_order_sla_tracking';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'work_order_id', 'sla_definition_id', 'target_response_time',
        'actual_response_time', 'target_resolution_time', 'actual_resolution_time',
        'response_breached', 'resolution_breached', 'response_breach_duration',
        'resolution_breach_duration', 'current_escalation_level', 'escalated_to',
        'escalated_at', 'escalation_notes'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
}
```

### SLADefinitionModel.php

```php
<?php

namespace App\Models;

use CodeIgniter\Model;

class SLADefinitionModel extends Model
{
    protected $table = 'sla_definitions';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $allowedFields = [
        'name', 'priority', 'order_type', 'response_time_hours',
        'resolution_time_hours', 'escalation_level_1_hours',
        'escalation_level_2_hours', 'escalation_level_3_hours', 'active'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
}
```

---

## 6. ROUTES REGISTRATION

### Add to Routes.php

```php
// Team Management
$routes->group('work-orders', function($routes) {
    $routes->post('(:num)/team/assign', 'WorkOrderTeamController::assignTeam/$1');
    $routes->get('(:num)/team', 'WorkOrderTeamController::getTeam/$1');
    $routes->post('(:num)/team/add-member', 'WorkOrderTeamController::addMember/$1');
    $routes->delete('(:num)/team/remove-member/(:num)', 'WorkOrderTeamController::removeMember/$1/$2');
    $routes->put('(:num)/team/change-lead', 'WorkOrderTeamController::changeLead/$1');
    $routes->post('(:num)/team/accept', 'WorkOrderTeamController::acceptAssignment/$1');
});

// Assistance Requests
$routes->group('', function($routes) {
    $routes->post('work-orders/(:num)/assistance/request', 'AssistanceRequestController::requestAssistance/$1');
    $routes->get('assistance-requests/pending', 'AssistanceRequestController::getPending');
    $routes->post('assistance-requests/(:num)/approve', 'AssistanceRequestController::approve/$1');
    $routes->post('assistance-requests/(:num)/reject', 'AssistanceRequestController::reject/$1');
});

// Job Planning
$routes->group('work-orders', function($routes) {
    $routes->post('(:num)/job-plan', 'JobPlanController::create/$1');
    $routes->get('(:num)/job-plan', 'JobPlanController::show/$1');
    $routes->put('(:num)/job-plan', 'JobPlanController::update/$1');
    $routes->post('(:num)/job-plan/approve', 'JobPlanController::approve/$1');
    $routes->post('(:num)/resources/reserve', 'JobPlanController::reserveResources/$1');
    $routes->get('(:num)/resources/check-availability', 'JobPlanController::checkAvailability/$1');
});

// SLA Tracking
$routes->group('', function($routes) {
    $routes->get('work-orders/(:num)/sla-status', 'SLAController::getStatus/$1');
    $routes->get('work-orders/sla-breached', 'SLAController::getBreached');
    $routes->post('work-orders/(:num)/escalate', 'SLAController::escalate/$1');
    $routes->get('sla-dashboard', 'SLAController::dashboard');
});
```

---

**PHASE 3 COMPLETE**  
**Total Delivered**:
- 11 Database Tables
- 4 Controllers (22 endpoints)
- 6 Models
- Complete Routes

**Next**: Phase 4 - Implementation

*Prepared by: Senior EAM System Architect*  
*Date: January 2025*
