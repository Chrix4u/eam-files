<?php

/**
 * EAM Module Generator Script
 * Run: php generate_eam_modules.php
 */

$modules = [
    'WorkOrderTasks' => ['controller' => true, 'service' => true, 'repository' => true],
    'WorkOrderMaterials' => ['controller' => true, 'service' => true, 'repository' => true],
    'StockTransactions' => ['controller' => true, 'service' => true, 'repository' => true],
    'MeterReadings' => ['controller' => true, 'service' => false, 'repository' => true],
    'Production' => ['controller' => true, 'service' => true, 'repository' => true],
];

$basePath = __DIR__ . '/app';

// Controller Template
function generateController($name) {
    return "<?php

namespace App\Controllers\Api\V1;

class {$name}Controller extends BaseApiController
{
    protected \$service;

    public function __construct()
    {
        \$this->service = new \App\Services\\{$name}Service();
    }

    public function index()
    {
        // GET /api/v1/" . strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $name)) . "
        \$result = \$this->service->getAll(\$this->request->getGet());
        return \$this->respond(\$result);
    }

    public function show(\$id = null)
    {
        // GET /api/v1/" . strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $name)) . "/{id}
        \$result = \$this->service->getById(\$id);
        return \$this->respond(\$result);
    }

    public function create()
    {
        // POST /api/v1/" . strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $name)) . "
        \$data = \$this->request->getJSON(true);
        \$result = \$this->service->create(\$data);
        return \$this->respond(\$result, \$result['status'] === 200 ? 201 : 400);
    }

    public function update(\$id = null)
    {
        // PUT /api/v1/" . strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $name)) . "/{id}
        \$data = \$this->request->getJSON(true);
        \$result = \$this->service->update(\$id, \$data);
        return \$this->respond(\$result);
    }

    public function delete(\$id = null)
    {
        // DELETE /api/v1/" . strtolower(preg_replace('/(?<!^)[A-Z]/', '-$0', $name)) . "/{id}
        \$result = \$this->service->delete(\$id);
        return \$this->respond(\$result);
    }
}
";
}

// Service Template
function generateService($name) {
    return "<?php

namespace App\Services;

use App\Repositories\\{$name}Repository;

class {$name}Service
{
    protected \$repository;

    public function __construct()
    {
        \$this->repository = new {$name}Repository();
    }

    public function getAll(array \$params = []): array
    {
        \$data = \$this->repository->findAll(\$params);
        return apiSuccess(\$data);
    }

    public function getById(int \$id): array
    {
        \$data = \$this->repository->findById(\$id);
        if (!\$data) {
            return apiError('Not found', 404);
        }
        return apiSuccess(\$data);
    }

    public function create(array \$data): array
    {
        \$id = \$this->repository->create(\$data);
        return apiSuccess(['id' => \$id], 'Created successfully');
    }

    public function update(int \$id, array \$data): array
    {
        \$updated = \$this->repository->update(\$id, \$data);
        if (!\$updated) {
            return apiError('Update failed', 400);
        }
        return apiSuccess(null, 'Updated successfully');
    }

    public function delete(int \$id): array
    {
        \$deleted = \$this->repository->delete(\$id);
        if (!\$deleted) {
            return apiError('Delete failed', 400);
        }
        return apiSuccess(null, 'Deleted successfully');
    }
}
";
}

// Repository Template
function generateRepository($name) {
    $table = strtolower(preg_replace('/(?<!^)[A-Z]/', '_$0', $name));
    return "<?php

namespace App\Repositories;

class {$name}Repository extends BaseRepository
{
    protected \$table = '{$table}';

    public function findAll(array \$params = []): array
    {
        \$builder = \$this->db->table(\$this->table);
        
        // Pagination
        \$page = \$params['page'] ?? 1;
        \$perPage = \$params['per_page'] ?? 20;
        \$offset = (\$page - 1) * \$perPage;
        
        \$builder->limit(\$perPage, \$offset);
        
        return \$builder->get()->getResultArray();
    }

    public function findById(int \$id): ?array
    {
        return \$this->db->table(\$this->table)
            ->where('id', \$id)
            ->get()
            ->getRowArray();
    }

    public function create(array \$data): int
    {
        \$this->db->table(\$this->table)->insert(\$data);
        return \$this->db->insertID();
    }

    public function update(int \$id, array \$data): bool
    {
        return \$this->db->table(\$this->table)
            ->where('id', \$id)
            ->update(\$data);
    }

    public function delete(int \$id): bool
    {
        return \$this->db->table(\$this->table)
            ->where('id', \$id)
            ->delete();
    }
}
";
}

// Generate files
foreach ($modules as $name => $config) {
    if ($config['controller']) {
        $file = "$basePath/Controllers/Api/V1/{$name}Controller.php";
        file_put_contents($file, generateController($name));
        echo "Created: $file\n";
    }
    
    if ($config['service']) {
        $file = "$basePath/Services/{$name}Service.php";
        file_put_contents($file, generateService($name));
        echo "Created: $file\n";
    }
    
    if ($config['repository']) {
        $file = "$basePath/Repositories/{$name}Repository.php";
        file_put_contents($file, generateRepository($name));
        echo "Created: $file\n";
    }
}

echo "\n✅ All EAM modules generated successfully!\n";
