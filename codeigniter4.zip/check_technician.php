<?php
// Check technician credentials
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "=== TECHNICIAN USERS ===\n\n";

$result = $conn->query("SELECT id, username, email, role, full_name FROM users WHERE role = 'technician'");

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "ID: " . $row['id'] . "\n";
        echo "Username: " . $row['username'] . "\n";
        echo "Email: " . $row['email'] . "\n";
        echo "Full Name: " . $row['full_name'] . "\n";
        echo "Active: Yes\n";
        echo "Password: technician123 (default)\n";
        echo "---\n";
    }
} else {
    echo "No technician users found!\n";
    echo "Creating technician user...\n\n";
    
    $password = password_hash('technician123', PASSWORD_DEFAULT);
    $query = "INSERT INTO users (username, email, password, role, full_name, created_at) 
              VALUES ('technician', 'technician@factory.com', '$password', 'technician', 'John Technician', NOW())";
    
    if ($conn->query($query) === TRUE) {
        echo "✓ Technician user created!\n";
        echo "Username: technician\n";
        echo "Password: technician123\n";
    } else {
        echo "Error: " . $conn->error . "\n";
    }
}

echo "\n=== ALL USERS (for reference) ===\n\n";
$result = $conn->query("SELECT username, role FROM users ORDER BY role");
while($row = $result->fetch_assoc()) {
    echo $row['role'] . " -> " . $row['username'] . " (password: " . $row['username'] . "123)\n";
}

$conn->close();
