<?php

$host = 'localhost';
$dbname = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Creating pm_template_materials table...\n";
    
    // Create PM Template Materials table for spare parts
    $sql = "CREATE TABLE IF NOT EXISTS pm_template_materials (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        pm_template_id BIGINT UNSIGNED NOT NULL,
        item_id BIGINT UNSIGNED NOT NULL,
        quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
        is_required BOOLEAN DEFAULT TRUE,
        created_at DATETIME NULL,
        INDEX idx_template (pm_template_id),
        INDEX idx_item (item_id),
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE,
        FOREIGN KEY (item_id) REFERENCES eam_inventory_items(id) ON DELETE CASCADE
    )";
    $pdo->exec($sql);
    echo "✅ pm_template_materials created\n";
    
    // Insert sample template materials
    $sql = "INSERT IGNORE INTO pm_template_materials (pm_template_id, item_id, quantity, is_required, created_at) VALUES
    (1, 1, 1.00, 1, NOW()),
    (1, 2, 2.00, 0, NOW()),
    (2, 3, 0.50, 1, NOW()),
    (3, 4, 1.00, 1, NOW())";
    $pdo->exec($sql);
    echo "✅ Sample template materials inserted\n";
    
    echo "\n🎉 PM template materials table created successfully!\n";
    
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}