-- Add department workflow columns to users table
ALTER TABLE users 
ADD COLUMN department_id INT NULL AFTER role,
ADD COLUMN supervisor_id INT NULL AFTER department_id;

-- Add workflow columns to maintenance_requests table
ALTER TABLE maintenance_requests 
ADD COLUMN assigned_planner_id INT NULL AFTER approved_by,
ADD COLUMN assigned_planner_type ENUM('engineering', 'production') NULL AFTER assigned_planner_id,
ADD COLUMN supervisor_notes TEXT NULL AFTER assigned_planner_type;

-- Update status enum to include 'assigned_to_planner'
ALTER TABLE maintenance_requests 
MODIFY COLUMN status ENUM('pending', 'approved', 'rejected', 'assigned_to_planner', 'converted', 'completed') DEFAULT 'pending';
