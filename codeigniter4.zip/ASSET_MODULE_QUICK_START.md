# Asset Management Module - Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Create Database Tables (1 minute)
```bash
cd C:\wamp64\www\factorymanager
php create_asset_module_tables.php
```

### Step 2: Verify Backend (1 minute)
Test the API:
```bash
curl http://localhost/factorymanager/public/index.php/api/v1/eam/assets/machines
```

Expected response:
```json
{
  "success": true,
  "data": []
}
```

### Step 3: Access Frontend (30 seconds)
Open browser: `http://localhost:3000/assets/machines`

---

## 📖 Basic Usage

### Create a Machine

**Via API:**
```bash
curl -X POST "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/machines" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Weaving Machine 10",
    "model": "WM-2000",
    "manufacturer": "GTP",
    "serial_number": "SN-12345",
    "category": "weaving",
    "criticality": "high",
    "status": "active",
    "install_date": "2024-01-01",
    "purchase_date": "2023-11-15",
    "warranty_expiry": "2026-11-15"
  }'
```

**Via Frontend:**
1. Go to `http://localhost:3000/assets/machines`
2. Click "+ Add Machine"
3. Fill the form
4. Click "Create Machine"

### Add Assembly to Machine

```bash
curl -X POST "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/machines/1/assemblies" \
  -H "Content-Type: application/json" \
  -d '{
    "code": "ASM-001",
    "name": "Main Drive Assembly",
    "description": "Primary drive mechanism",
    "assembly_type": "mechanical",
    "sequence": 1
  }'
```

### Add Part to Assembly

```bash
curl -X POST "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/assemblies/1/parts" \
  -H "Content-Type: application/json" \
  -d '{
    "code": "PART-001",
    "name": "Drive Belt",
    "description": "Main drive belt",
    "manufacturer": "BeltCo",
    "part_number": "DB-2000",
    "material": "Rubber",
    "expected_life_usage": 5000,
    "spare_required": true
  }'
```

### Add Sub-Part (Nested)

```bash
curl -X POST "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/assemblies/1/parts" \
  -H "Content-Type: application/json" \
  -d '{
    "parent_part_id": 1,
    "code": "PART-001-A",
    "name": "Belt Buckle",
    "description": "Belt fastening mechanism"
  }'
```

### Import BOM from CSV

**CSV Format:**
```csv
Assembly ID,Part ID,Quantity,Unit,Reference Location
1,1,2,EA,Section A
1,2,4,EA,Section B
```

**Upload:**
```bash
curl -X POST "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/bom/import" \
  -F "file=@bom.csv" \
  -F "machine_id=1"
```

### Export BOM to CSV

```bash
curl "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/bom/export?machine_id=1" \
  -o bom_export.csv
```

### Get Complete Asset Tree

```bash
curl "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/tree/1"
```

Response structure:
```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Weaving Machine 10",
    "asset_tag": "AST-...",
    "assemblies": [
      {
        "id": 1,
        "name": "Main Drive Assembly",
        "parts": [
          {
            "id": 1,
            "name": "Drive Belt",
            "children": [
              {
                "id": 2,
                "name": "Belt Buckle",
                "children": []
              }
            ]
          }
        ]
      }
    ]
  }
}
```

---

## 🔍 Common Operations

### Filter Machines
```bash
# By status
curl "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/machines?status=active"

# By category
curl "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/machines?category=weaving"
```

### Update Machine
```bash
curl -X PUT "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/machines/1" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "maintenance",
    "criticality": "critical"
  }'
```

### Upload Part Media
```bash
curl -X POST "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/parts/1/media" \
  -F "file=@part_image.jpg" \
  -F "type=image"
```

### Get BOM Entries
```bash
# For specific machine
curl "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/bom?machine_id=1"

# For specific assembly
curl "http://localhost/factorymanager/public/index.php/api/v1/eam/assets/bom?assembly_id=1"
```

---

## 🐛 Troubleshooting

### Issue: "Table not found"
**Solution:** Run the database setup script
```bash
php create_asset_module_tables.php
```

### Issue: "Route not found"
**Solution:** Clear route cache
```bash
php spark cache:clear
```

### Issue: "Upload failed"
**Solution:** Check upload directory permissions
```bash
mkdir writable/uploads/parts
chmod 755 writable/uploads/parts
```

### Issue: "Cannot create machine"
**Solution:** Check required fields
- `name` is required
- `status` must be one of: commissioned, active, idle, maintenance, retired
- `criticality` must be one of: low, medium, high, critical

---

## 📊 Sample Data

### Create Sample Machine
```sql
INSERT INTO machines (asset_tag, name, model, manufacturer, serial_number, category, status, criticality, created_at) 
VALUES ('AST-SAMPLE-001', 'Sample Weaving Machine', 'WM-2000', 'GTP', 'SN-12345', 'weaving', 'active', 'high', NOW());
```

### Create Sample Assembly
```sql
INSERT INTO assemblies (machine_id, code, name, description, sequence, created_at) 
VALUES (1, 'ASM-001', 'Main Drive', 'Primary drive assembly', 1, NOW());
```

### Create Sample Part
```sql
INSERT INTO parts (assembly_id, code, name, manufacturer, spare_required, created_at) 
VALUES (1, 'PART-001', 'Drive Belt', 'BeltCo', 1, NOW());
```

---

## 🎓 Learning Path

### Day 1: Basics
1. ✅ Create machine
2. ✅ View machine list
3. ✅ View machine details
4. ✅ Add assembly

### Day 2: Intermediate
1. ✅ Add parts
2. ✅ Create nested parts
3. ✅ Add BOM entries
4. ✅ Upload media

### Day 3: Advanced
1. ✅ Import BOM CSV
2. ✅ Export BOM CSV
3. ✅ Get asset tree
4. ✅ Link parts to inventory

---

## 📞 API Reference

### Base URL
```
http://localhost/factorymanager/public/index.php/api/v1/eam/assets
```

### Endpoints Summary
- **Machines:** `/machines` (GET, POST), `/machines/{id}` (GET, PUT, DELETE)
- **Assemblies:** `/machines/{id}/assemblies` (POST), `/assemblies/{id}` (PUT)
- **Parts:** `/assemblies/{id}/parts` (POST), `/parts/{id}` (GET, PUT)
- **BOM:** `/bom` (GET, POST), `/bom/import` (POST), `/bom/export` (GET)
- **Tree:** `/tree/{machineId}` (GET)

### Response Format
All endpoints return:
```json
{
  "success": true|false,
  "data": {...},
  "error": "error message" // only on failure
}
```

---

## ✅ Verification Checklist

After setup, verify:

- [ ] Can access machines list page
- [ ] Can create new machine
- [ ] Can view machine details
- [ ] Can add assembly
- [ ] Can add part
- [ ] Can create nested part
- [ ] Can add BOM entry
- [ ] Can import BOM CSV
- [ ] Can export BOM CSV
- [ ] Can get asset tree
- [ ] Can upload part media

If all checked, you're ready to go! 🎉

---

**Need Help?** Check the full documentation in `ASSET_MODULE_IMPLEMENTATION.md`
