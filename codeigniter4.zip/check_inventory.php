<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();

echo "Checking inventory_items table...\n\n";

// Check if table exists
$tables = $db->listTables();
if (!in_array('inventory_items', $tables)) {
    echo "ERROR: inventory_items table does not exist!\n";
    echo "Available tables: " . implode(', ', $tables) . "\n";
    exit;
}

// Count records
$count = $db->table('inventory_items')->countAllResults();
echo "Total records in inventory_items: $count\n\n";

// Show first 5 records
if ($count > 0) {
    echo "First 5 records:\n";
    $items = $db->table('inventory_items')->limit(5)->get()->getResultArray();
    foreach ($items as $item) {
        echo "ID: {$item['id']}, Name: {$item['item_name']}, Code: {$item['item_code']}, Qty: {$item['quantity_on_hand']}\n";
    }
} else {
    echo "Table is EMPTY!\n";
}
