# EAM API - Real-World Workflow Examples

## 🎯 Scenario 1: New Equipment Setup

### Business Need
Add a new CNC machine to the production line and set up monthly preventive maintenance.

### API Workflow

**Step 1: Create the Equipment**
```bash
POST /api/v1/eam/equipment
{
  "system_id": 1,
  "equipment_code": "CNC-002",
  "equipment_name": "CNC Milling Machine #2",
  "manufacturer": "Haas",
  "model": "VF-3",
  "serial_number": "SN987654",
  "installation_date": "2025-01-15",
  "warranty_expiry": "2027-01-15"
}
```

**Step 2: Create PM Rule**
```bash
POST /api/v1/eam/pm-rules
{
  "rule_name": "Monthly CNC-002 Inspection",
  "asset_type": "equipment",
  "asset_id": 3,
  "frequency_type": "monthly",
  "frequency_value": 1,
  "estimated_duration": 120,
  "priority": "medium",
  "description": "Monthly inspection and lubrication"
}
```

**Step 3: Generate PM Schedules for 2025**
```bash
POST /api/v1/eam/pm-schedules/generate
{
  "rule_id": 3,
  "start_date": "2025-02-01",
  "end_date": "2025-12-31"
}
```

**Result:** 11 PM schedules created, work orders will be auto-generated 7 days before each due date.

---

## 🔧 Scenario 2: Emergency Repair

### Business Need
CNC Machine #1 breaks down, needs immediate repair with parts from inventory.

### API Workflow

**Step 1: Create Emergency Work Order**
```bash
POST /api/v1/eam/work-orders
{
  "title": "CNC-001 Motor Failure",
  "description": "Motor overheating, unusual noise, emergency shutdown",
  "asset_type": "equipment",
  "asset_id": 1,
  "priority": "critical",
  "wo_type": "corrective",
  "scheduled_date": "2025-01-10"
}
```

**Step 2: Assign to Senior Technician**
```bash
POST /api/v1/eam/work-orders/5/assign
{
  "assigned_to": 2,
  "notes": "Senior tech needed for motor replacement"
}
```

**Step 3: Reserve Required Parts**
```bash
POST /api/v1/eam/inventory/reserve
{
  "inventory_id": 1,
  "quantity": 2,
  "work_order_id": 5
}
```

**Step 4: Complete Work Order**
```bash
POST /api/v1/eam/work-orders/5/complete
{
  "completion_notes": "Replaced motor and bearings, tested successfully",
  "actual_duration": 180,
  "downtime_minutes": 240
}
```

**Result:** Work order completed, inventory updated, equipment back online.

---

## 📦 Scenario 3: Inventory Replenishment

### Business Need
Receive shipment of hydraulic filters and update inventory.

### API Workflow

**Step 1: Check Current Stock**
```bash
GET /api/v1/eam/inventory/1
```

**Response:**
```json
{
  "part_number": "PART001",
  "part_name": "Hydraulic Oil Filter",
  "quantity_on_hand": 8,
  "reorder_point": 10,
  "status": "Below Reorder Point"
}
```

**Step 2: Stock In from Purchase Order**
```bash
POST /api/v1/eam/inventory/stock-in
{
  "inventory_id": 1,
  "quantity": 50,
  "reference_number": "PO-2025-045",
  "unit_cost": 24.50,
  "supplier": "Industrial Supply Co",
  "notes": "Bulk order - 10% discount applied"
}
```

**Step 3: Verify Updated Stock**
```bash
GET /api/v1/eam/inventory/1
```

**Response:**
```json
{
  "quantity_on_hand": 58,
  "last_stock_date": "2025-01-10",
  "status": "In Stock"
}
```

**Result:** Inventory updated, transaction recorded, reorder alert cleared.

---

## 📅 Scenario 4: Monthly PM Schedule Review

### Business Need
Review and manage all preventive maintenance for the upcoming month.

### API Workflow

**Step 1: Get All PM Schedules for February**
```bash
GET /api/v1/eam/pm-schedules?start_date=2025-02-01&end_date=2025-02-29
```

**Step 2: Get Work Orders Generated from PM**
```bash
GET /api/v1/eam/work-orders?wo_type=preventive&status=open&month=2025-02
```

**Step 3: Assign Work Orders to Technicians**
```bash
# Assign multiple work orders
POST /api/v1/eam/work-orders/10/assign
{"assigned_to": 2}

POST /api/v1/eam/work-orders/11/assign
{"assigned_to": 3}

POST /api/v1/eam/work-orders/12/assign
{"assigned_to": 2}
```

**Step 4: Reserve Parts for All PM Work**
```bash
POST /api/v1/eam/inventory/reserve
{
  "inventory_id": 1,
  "quantity": 5,
  "work_order_id": 10
}
```

**Result:** Month's PM work planned, assigned, and parts reserved.

---

## 🏭 Scenario 5: New Facility Setup

### Business Need
Open a new warehouse facility with complete asset hierarchy.

### API Workflow

**Step 1: Create Facility**
```bash
POST /api/v1/eam/facilities
{
  "facility_code": "WH-001",
  "facility_name": "Distribution Warehouse",
  "location": "Building D",
  "address": "123 Industrial Blvd",
  "city": "Springfield"
}
```

**Step 2: Create Systems**
```bash
# Material Handling System
POST /api/v1/eam/systems
{
  "facility_id": 3,
  "system_code": "MH-001",
  "system_name": "Material Handling System"
}

# HVAC System
POST /api/v1/eam/systems
{
  "facility_id": 3,
  "system_code": "HVAC-001",
  "system_name": "Climate Control System"
}
```

**Step 3: Add Equipment**
```bash
# Forklift
POST /api/v1/eam/equipment
{
  "system_id": 3,
  "equipment_code": "FL-001",
  "equipment_name": "Electric Forklift #1",
  "manufacturer": "Toyota",
  "model": "8FBE20U"
}

# Conveyor
POST /api/v1/eam/equipment
{
  "system_id": 3,
  "equipment_code": "CV-001",
  "equipment_name": "Conveyor Belt System",
  "manufacturer": "Dorner"
}
```

**Step 4: Setup PM Rules for All Equipment**
```bash
# Forklift Weekly Check
POST /api/v1/eam/pm-rules
{
  "rule_name": "Weekly Forklift Inspection",
  "asset_type": "equipment",
  "asset_id": 5,
  "frequency_type": "weekly",
  "frequency_value": 1,
  "estimated_duration": 30
}

# Conveyor Monthly Maintenance
POST /api/v1/eam/pm-rules
{
  "rule_name": "Monthly Conveyor Maintenance",
  "asset_type": "equipment",
  "asset_id": 6,
  "frequency_type": "monthly",
  "frequency_value": 1,
  "estimated_duration": 90
}
```

**Result:** Complete facility hierarchy created with automated PM schedules.

---

## 👥 Scenario 6: User & Team Management

### Business Need
Onboard new maintenance team and assign appropriate roles.

### API Workflow

**Step 1: Create Users**
```bash
# Maintenance Manager
POST /api/v1/eam/users
{
  "username": "manager1",
  "email": "manager@factory.com",
  "password": "secure123",
  "full_name": "Sarah Manager",
  "department": "Maintenance"
}

# Technicians
POST /api/v1/eam/users
{
  "username": "tech2",
  "email": "tech2@factory.com",
  "password": "secure123",
  "full_name": "Mike Technician"
}
```

**Step 2: Create Roles (if not exists)**
```bash
POST /api/v1/eam/roles
{
  "role_name": "Maintenance Manager",
  "description": "Full access to maintenance operations"
}

POST /api/v1/eam/roles
{
  "role_name": "Technician",
  "description": "Execute work orders and update status"
}
```

**Step 3: Assign Roles**
```bash
POST /api/v1/eam/users/4/assign-role
{"role_id": 2}

POST /api/v1/eam/users/5/assign-role
{"role_id": 3}
```

**Result:** Team created with appropriate access levels.

---

## 📊 Scenario 7: Monthly Reporting

### Business Need
Generate monthly maintenance report with key metrics.

### API Workflow

**Step 1: Get All Work Orders for January**
```bash
GET /api/v1/eam/work-orders?start_date=2025-01-01&end_date=2025-01-31
```

**Step 2: Get Completed Work Orders**
```bash
GET /api/v1/eam/work-orders?status=completed&start_date=2025-01-01&end_date=2025-01-31
```

**Step 3: Get Inventory Transactions**
```bash
GET /api/v1/eam/inventory/transactions?start_date=2025-01-01&end_date=2025-01-31
```

**Step 4: Get PM Compliance**
```bash
GET /api/v1/eam/pm-schedules?status=completed&month=2025-01
```

**Metrics to Calculate:**
- Total work orders: 45
- Completed on time: 38 (84%)
- Average completion time: 95 minutes
- PM compliance: 92%
- Parts consumed: $2,450
- Equipment downtime: 18 hours

---

## 🔄 Scenario 8: Equipment Transfer

### Business Need
Move equipment from one system to another.

### API Workflow

**Step 1: Get Current Equipment Details**
```bash
GET /api/v1/eam/equipment/2
```

**Step 2: Update Equipment Location**
```bash
PUT /api/v1/eam/equipment/2
{
  "system_id": 4,
  "notes": "Transferred from Production Line 1 to Production Line 2"
}
```

**Step 3: Update PM Rules**
```bash
PUT /api/v1/eam/pm-rules/2
{
  "notes": "Equipment transferred - schedule updated"
}
```

**Step 4: Create Transfer Work Order**
```bash
POST /api/v1/eam/work-orders
{
  "title": "Equipment Transfer - Conveyor Belt",
  "description": "Transfer and reinstall conveyor from Line 1 to Line 2",
  "asset_type": "equipment",
  "asset_id": 2,
  "priority": "medium",
  "wo_type": "project"
}
```

**Result:** Equipment transferred with updated records and PM schedules.

---

## 🎯 Integration Patterns

### Pattern 1: Batch Operations
```bash
# Create multiple assets in sequence
for equipment in equipment_list:
    POST /api/v1/eam/equipment
    
# Generate PM schedules for all rules
for rule in pm_rules:
    POST /api/v1/eam/pm-schedules/generate
```

### Pattern 2: Cascading Updates
```bash
# Update facility → affects all child systems
PUT /api/v1/eam/facilities/1
{
  "location": "New Building A"
}

# All systems, equipment, etc. inherit location change
```

### Pattern 3: Transaction Rollback
```bash
# If work order completion fails:
1. Revert inventory stock-out
2. Revert work order status
3. Log error for review
```

### Pattern 4: Notification Triggers
```bash
# Events that should trigger notifications:
- Work order assigned → Email technician
- PM due in 7 days → Email manager
- Inventory below reorder → Email purchasing
- Equipment downtime > 4 hours → Alert management
```

---

## 💡 Best Practices

### 1. Always Use Transactions
For operations affecting multiple tables:
```
Start Transaction
  → Create Work Order
  → Reserve Inventory
  → Update Equipment Status
Commit or Rollback
```

### 2. Validate Before Operations
```bash
# Before creating work order
GET /api/v1/eam/equipment/1  # Verify equipment exists

# Before stock-out
GET /api/v1/eam/inventory/1  # Check sufficient quantity
```

### 3. Use Pagination for Large Datasets
```bash
GET /api/v1/eam/work-orders?page=1&limit=50
```

### 4. Implement Retry Logic
```javascript
async function apiCall(endpoint, data, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      return await fetch(endpoint, data);
    } catch (error) {
      if (i === retries - 1) throw error;
      await sleep(1000 * (i + 1));
    }
  }
}
```

### 5. Cache Reference Data
```javascript
// Cache facilities, systems, users
const facilities = await fetchOnce('/api/v1/eam/facilities');
const users = await fetchOnce('/api/v1/eam/users');
```

---

## 🚀 Quick Reference

### Common Workflows
| Workflow | Endpoints Used | Order |
|----------|---------------|-------|
| New Equipment | facilities → systems → equipment → pm-rules | 4 calls |
| Emergency Repair | work-orders → assign → reserve → complete | 4 calls |
| Stock Replenishment | inventory (GET) → stock-in → inventory (GET) | 3 calls |
| Monthly PM | pm-schedules → work-orders → assign → reserve | 4+ calls |

### Response Time Expectations
| Operation | Expected Time |
|-----------|--------------|
| Authentication | < 200ms |
| List (paginated) | < 300ms |
| Single record GET | < 100ms |
| Create/Update | < 200ms |
| PM Generation | < 2s (for 1 year) |
| Batch operations | Varies |

### Error Recovery
| Error | Action |
|-------|--------|
| 401 Unauthorized | Refresh token or re-login |
| 404 Not Found | Verify ID exists |
| 400 Bad Request | Check request payload |
| 500 Server Error | Retry or contact support |

---

**Use these examples as templates for your own workflows!**
