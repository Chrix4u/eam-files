-- ============================================================================
-- ENTERPRISE-GRADE PARTS & INVENTORY INTEGRATION FIX
-- ============================================================================
-- System: iFactory EAM v2.0
-- Date: 2026-01-27
-- Purpose: Integrate Parts, Inventory, and Unified Assets
-- Standard: ISO 55000, MIMOSA OSA-EAI
-- ============================================================================

USE factory_manager;

-- ============================================================================
-- STEP 1: FIX COLLATION ISSUES
-- ============================================================================

ALTER TABLE parts 
MODIFY part_number VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci;

ALTER TABLE parts 
MODIFY part_code VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci;

-- ============================================================================
-- STEP 2: CREATE ENTERPRISE LINK TABLE (Parts ↔ Inventory)
-- ============================================================================

CREATE TABLE IF NOT EXISTS part_inventory_links (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    part_id INT NOT NULL COMMENT 'FK to parts table',
    inventory_item_id INT UNSIGNED NOT NULL COMMENT 'FK to inventory_items table',
    quantity_per_unit DECIMAL(10,3) DEFAULT 1.000 COMMENT 'How many inventory items per part unit',
    is_primary BOOLEAN DEFAULT TRUE COMMENT 'Primary inventory item for this part',
    substitute_priority INT DEFAULT 0 COMMENT '0=primary, 1=first substitute, etc',
    notes TEXT COMMENT 'Usage notes or specifications',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    
    UNIQUE KEY unique_part_inventory (part_id, inventory_item_id),
    INDEX idx_part_id (part_id),
    INDEX idx_inventory_item_id (inventory_item_id),
    INDEX idx_primary (is_primary)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci
COMMENT='Links parts to inventory items for stock management';

-- ============================================================================
-- STEP 3: ENHANCE ASSET_SPARE_PARTS TABLE
-- ============================================================================

-- Drop and recreate with proper structure
DROP TABLE IF EXISTS asset_spare_parts;

CREATE TABLE asset_spare_parts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_node_id INT UNSIGNED NOT NULL COMMENT 'FK to asset_nodes',
    inventory_item_id INT UNSIGNED NOT NULL COMMENT 'FK to inventory_items',
    part_id INT NULL COMMENT 'Optional FK to parts for BOM reference',
    quantity_required DECIMAL(10,2) DEFAULT 1.00 COMMENT 'Quantity needed for this asset',
    criticality ENUM('critical','high','medium','low') DEFAULT 'medium',
    replacement_frequency_days INT NULL COMMENT 'Expected replacement interval',
    last_replaced_date DATE NULL,
    next_replacement_date DATE NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (asset_node_id) REFERENCES asset_nodes(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL,
    
    UNIQUE KEY unique_asset_inventory (asset_node_id, inventory_item_id),
    INDEX idx_asset_node (asset_node_id),
    INDEX idx_inventory_item (inventory_item_id),
    INDEX idx_criticality (criticality),
    INDEX idx_next_replacement (next_replacement_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci
COMMENT='Links assets to required spare parts inventory';

-- ============================================================================
-- STEP 4: CREATE PM MATERIALS PLANNING TABLE
-- ============================================================================

CREATE TABLE IF NOT EXISTS pm_task_materials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pm_task_id INT NOT NULL COMMENT 'FK to part_pm_tasks or pm_schedules',
    part_id INT NULL COMMENT 'Optional FK to parts',
    inventory_item_id INT UNSIGNED NOT NULL COMMENT 'FK to inventory_items',
    planned_quantity DECIMAL(10,3) NOT NULL DEFAULT 1.000,
    unit_of_measure VARCHAR(50) DEFAULT 'EA',
    is_critical BOOLEAN DEFAULT FALSE COMMENT 'Must have to complete PM',
    substitute_allowed BOOLEAN DEFAULT TRUE,
    estimated_cost DECIMAL(10,2) NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    
    INDEX idx_pm_task (pm_task_id),
    INDEX idx_part (part_id),
    INDEX idx_inventory (inventory_item_id),
    INDEX idx_critical (is_critical)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci
COMMENT='Materials required for PM tasks';

-- ============================================================================
-- STEP 5: CREATE WORK ORDER MATERIALS TABLE (if not exists)
-- ============================================================================

CREATE TABLE IF NOT EXISTS work_order_materials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT UNSIGNED NOT NULL,
    inventory_item_id INT UNSIGNED NOT NULL,
    part_id INT NULL COMMENT 'Reference to parts if applicable',
    planned_quantity DECIMAL(10,3) DEFAULT 0,
    actual_quantity DECIMAL(10,3) DEFAULT 0,
    unit_cost DECIMAL(10,2) DEFAULT 0,
    total_cost DECIMAL(10,2) GENERATED ALWAYS AS (actual_quantity * unit_cost) STORED,
    issued_date DATETIME NULL,
    issued_by INT UNSIGNED NULL,
    returned_quantity DECIMAL(10,3) DEFAULT 0,
    status ENUM('planned','reserved','issued','consumed','returned') DEFAULT 'planned',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL,
    
    INDEX idx_work_order (work_order_id),
    INDEX idx_inventory (inventory_item_id),
    INDEX idx_status (status),
    INDEX idx_issued_date (issued_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci
COMMENT='Materials used in work orders';

-- ============================================================================
-- STEP 6: ADD INVENTORY RESERVATION TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS inventory_reservations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NULL,
    pm_task_id INT NULL,
    reserved_quantity DECIMAL(10,3) NOT NULL,
    reserved_by INT UNSIGNED NOT NULL,
    reserved_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NULL,
    status ENUM('active','consumed','cancelled','expired') DEFAULT 'active',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE CASCADE,
    
    INDEX idx_inventory (inventory_item_id),
    INDEX idx_work_order (work_order_id),
    INDEX idx_status (status),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci
COMMENT='Tracks reserved inventory for work orders and PM tasks';

-- ============================================================================
-- STEP 7: ADD CALCULATED COLUMNS TO INVENTORY_ITEMS
-- ============================================================================

ALTER TABLE inventory_items 
ADD COLUMN IF NOT EXISTS quantity_reserved DECIMAL(15,2) DEFAULT 0 COMMENT 'Quantity reserved for work orders',
ADD COLUMN IF NOT EXISTS quantity_available DECIMAL(15,2) GENERATED ALWAYS AS (quantity_on_hand - quantity_reserved) STORED COMMENT 'Available = On Hand - Reserved',
ADD COLUMN IF NOT EXISTS min_stock_level DECIMAL(15,2) DEFAULT 0 COMMENT 'Minimum stock level alert',
ADD COLUMN IF NOT EXISTS max_stock_level DECIMAL(15,2) DEFAULT 0 COMMENT 'Maximum stock level',
ADD COLUMN IF NOT EXISTS abc_classification ENUM('A','B','C') DEFAULT 'C' COMMENT 'ABC inventory classification',
ADD COLUMN IF NOT EXISTS last_issued_date DATETIME NULL,
ADD COLUMN IF NOT EXISTS last_received_date DATETIME NULL;

-- ============================================================================
-- STEP 8: CREATE VIEWS FOR EASY ACCESS
-- ============================================================================

-- View: Parts with Inventory Status
CREATE OR REPLACE VIEW vw_parts_inventory_status AS
SELECT 
    p.id AS part_id,
    p.part_name,
    p.part_number,
    p.part_code,
    p.spare_availability,
    p.criticality AS part_criticality,
    pil.inventory_item_id,
    ii.item_code,
    ii.item_name,
    ii.quantity_on_hand,
    ii.quantity_reserved,
    ii.quantity_available,
    ii.reorder_point,
    ii.location,
    ii.unit_cost,
    CASE 
        WHEN ii.quantity_available <= 0 THEN 'OUT_OF_STOCK'
        WHEN ii.quantity_available <= ii.reorder_point THEN 'LOW_STOCK'
        WHEN ii.quantity_available > ii.reorder_point THEN 'IN_STOCK'
        ELSE 'NO_INVENTORY'
    END AS stock_status,
    pil.quantity_per_unit,
    pil.is_primary
FROM parts p
LEFT JOIN part_inventory_links pil ON p.id = pil.part_id AND pil.is_primary = TRUE
LEFT JOIN inventory_items ii ON pil.inventory_item_id = ii.id;

-- View: Asset Spare Parts Availability
CREATE OR REPLACE VIEW vw_asset_spare_parts_status AS
SELECT 
    asp.id,
    asp.asset_node_id,
    an.node_name AS asset_name,
    an.node_code AS asset_code,
    asp.inventory_item_id,
    ii.item_name,
    ii.item_code,
    asp.quantity_required,
    ii.quantity_available,
    CASE 
        WHEN ii.quantity_available >= asp.quantity_required THEN 'AVAILABLE'
        WHEN ii.quantity_available > 0 THEN 'PARTIAL'
        ELSE 'NOT_AVAILABLE'
    END AS availability_status,
    asp.criticality,
    asp.next_replacement_date,
    DATEDIFF(asp.next_replacement_date, CURDATE()) AS days_until_replacement
FROM asset_spare_parts asp
JOIN asset_nodes an ON asp.asset_node_id = an.id
JOIN inventory_items ii ON asp.inventory_item_id = ii.id;

-- View: PM Tasks with Material Availability
CREATE OR REPLACE VIEW vw_pm_materials_readiness AS
SELECT 
    ppt.id AS pm_task_id,
    ppt.part_id,
    p.part_name,
    ptm.inventory_item_id,
    ii.item_name,
    ptm.planned_quantity,
    ii.quantity_available,
    ptm.is_critical,
    CASE 
        WHEN ii.quantity_available >= ptm.planned_quantity THEN 'READY'
        WHEN ii.quantity_available > 0 THEN 'PARTIAL'
        WHEN ptm.is_critical = TRUE THEN 'BLOCKED'
        ELSE 'NOT_READY'
    END AS material_status,
    ppt.next_due_date
FROM part_pm_tasks ppt
JOIN parts p ON ppt.part_id = p.id
LEFT JOIN pm_task_materials ptm ON ppt.id = ptm.pm_task_id
LEFT JOIN inventory_items ii ON ptm.inventory_item_id = ii.id
WHERE ppt.is_active = 1;

-- ============================================================================
-- STEP 9: CREATE STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Procedure: Check Material Availability for PM Task
CREATE PROCEDURE sp_check_pm_materials_availability(
    IN p_pm_task_id INT,
    OUT p_is_ready BOOLEAN,
    OUT p_missing_items TEXT
)
BEGIN
    DECLARE v_missing_count INT DEFAULT 0;
    
    SELECT COUNT(*) INTO v_missing_count
    FROM pm_task_materials ptm
    JOIN inventory_items ii ON ptm.inventory_item_id = ii.id
    WHERE ptm.pm_task_id = p_pm_task_id
    AND ptm.is_critical = TRUE
    AND ii.quantity_available < ptm.planned_quantity;
    
    SET p_is_ready = (v_missing_count = 0);
    
    SELECT GROUP_CONCAT(
        CONCAT(ii.item_name, ' (Need: ', ptm.planned_quantity, ', Available: ', ii.quantity_available, ')')
        SEPARATOR '; '
    ) INTO p_missing_items
    FROM pm_task_materials ptm
    JOIN inventory_items ii ON ptm.inventory_item_id = ii.id
    WHERE ptm.pm_task_id = p_pm_task_id
    AND ii.quantity_available < ptm.planned_quantity;
END //

-- Procedure: Reserve Materials for Work Order
CREATE PROCEDURE sp_reserve_materials_for_work_order(
    IN p_work_order_id INT,
    IN p_reserved_by INT,
    OUT p_success BOOLEAN,
    OUT p_message TEXT
)
BEGIN
    DECLARE v_error_count INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_success = FALSE;
        SET p_message = 'Error reserving materials';
    END;
    
    START TRANSACTION;
    
    -- Check if all materials are available
    SELECT COUNT(*) INTO v_error_count
    FROM work_order_materials wom
    JOIN inventory_items ii ON wom.inventory_item_id = ii.id
    WHERE wom.work_order_id = p_work_order_id
    AND wom.status = 'planned'
    AND ii.quantity_available < wom.planned_quantity;
    
    IF v_error_count > 0 THEN
        SET p_success = FALSE;
        SET p_message = 'Insufficient inventory for some materials';
        ROLLBACK;
    ELSE
        -- Create reservations
        INSERT INTO inventory_reservations (
            inventory_item_id, work_order_id, reserved_quantity, 
            reserved_by, expires_at, status
        )
        SELECT 
            wom.inventory_item_id,
            wom.work_order_id,
            wom.planned_quantity,
            p_reserved_by,
            DATE_ADD(NOW(), INTERVAL 7 DAY),
            'active'
        FROM work_order_materials wom
        WHERE wom.work_order_id = p_work_order_id
        AND wom.status = 'planned';
        
        -- Update inventory reserved quantities
        UPDATE inventory_items ii
        JOIN work_order_materials wom ON ii.id = wom.inventory_item_id
        SET ii.quantity_reserved = ii.quantity_reserved + wom.planned_quantity
        WHERE wom.work_order_id = p_work_order_id
        AND wom.status = 'planned';
        
        -- Update work order materials status
        UPDATE work_order_materials
        SET status = 'reserved'
        WHERE work_order_id = p_work_order_id
        AND status = 'planned';
        
        SET p_success = TRUE;
        SET p_message = 'Materials reserved successfully';
        COMMIT;
    END IF;
END //

DELIMITER ;

-- ============================================================================
-- STEP 10: CREATE TRIGGERS FOR AUTOMATIC UPDATES
-- ============================================================================

DELIMITER //

-- Trigger: Update inventory when materials are issued
CREATE TRIGGER trg_work_order_materials_issued
AFTER UPDATE ON work_order_materials
FOR EACH ROW
BEGIN
    IF NEW.status = 'issued' AND OLD.status = 'reserved' THEN
        UPDATE inventory_items
        SET quantity_on_hand = quantity_on_hand - NEW.actual_quantity,
            quantity_reserved = quantity_reserved - NEW.planned_quantity,
            last_issued_date = NEW.issued_date
        WHERE id = NEW.inventory_item_id;
        
        -- Cancel reservation
        UPDATE inventory_reservations
        SET status = 'consumed'
        WHERE work_order_id = NEW.work_order_id
        AND inventory_item_id = NEW.inventory_item_id
        AND status = 'active';
    END IF;
END //

DELIMITER ;

-- ============================================================================
-- STEP 11: INSERT SAMPLE DATA (Optional - for testing)
-- ============================================================================

-- Link existing parts to inventory (where part_number matches item_code)
INSERT IGNORE INTO part_inventory_links (part_id, inventory_item_id, is_primary)
SELECT p.id, i.id, TRUE
FROM parts p
JOIN inventory_items i ON BINARY p.part_number = BINARY i.item_code
WHERE p.spare_availability = 'yes';

-- ============================================================================
-- STEP 12: CREATE INDEXES FOR PERFORMANCE
-- ============================================================================

-- Additional indexes for better query performance
CREATE INDEX idx_parts_spare_availability ON parts(spare_availability);
CREATE INDEX idx_parts_criticality ON parts(criticality);
CREATE INDEX idx_inventory_status ON inventory_items(status);
CREATE INDEX idx_inventory_abc ON inventory_items(abc_classification);
CREATE INDEX idx_inventory_available ON inventory_items(quantity_available);

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Check part-inventory links
SELECT 'Part-Inventory Links' AS check_name, COUNT(*) AS count FROM part_inventory_links;

-- Check parts with inventory
SELECT 'Parts with Inventory' AS check_name, COUNT(DISTINCT p.id) AS count 
FROM parts p 
JOIN part_inventory_links pil ON p.id = pil.part_id;

-- Check inventory availability
SELECT 'Inventory Items' AS check_name, COUNT(*) AS count FROM inventory_items;

-- Check views
SELECT 'Parts Inventory Status View' AS check_name, COUNT(*) AS count FROM vw_parts_inventory_status;

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================

SELECT '✅ ENTERPRISE-GRADE PARTS & INVENTORY INTEGRATION COMPLETE' AS status,
       'All tables, views, procedures, and triggers created successfully' AS message;

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
