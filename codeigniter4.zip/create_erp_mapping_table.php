<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS erp_field_mappings (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entity_type VARCHAR(50) NOT NULL,
    eam_field VARCHAR(100) NOT NULL,
    erp_field VARCHAR(100) NOT NULL,
    data_type VARCHAR(50) DEFAULT 'string',
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_mapping (entity_type, eam_field)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "erp_field_mappings table created successfully\n";
    
    // Insert default mappings
    $mappings = [
        ['asset', 'asset_id', 'EQUNR'],
        ['asset', 'name', 'EQKTX'],
        ['asset', 'cost_center', 'KOSTL'],
        ['asset', 'location', 'TPLNR'],
        ['work_order', 'work_order_id', 'AUFNR'],
        ['work_order', 'description', 'KTEXT'],
        ['work_order', 'priority', 'PRIOK'],
        ['inventory', 'part_number', 'MATNR'],
        ['inventory', 'quantity', 'MENGE'],
        ['inventory', 'unit', 'MEINS']
    ];
    
    foreach ($mappings as $map) {
        $conn->query("INSERT IGNORE INTO erp_field_mappings (entity_type, eam_field, erp_field, is_active, created_at) 
                      VALUES ('{$map[0]}', '{$map[1]}', '{$map[2]}', 1, NOW())");
    }
    
    echo "Default mappings inserted\n";
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
