# 🚀 Database Migration Guide

## Step-by-Step Migration Process

### Step 1: Check Current Migration Status
```bash
cd c:\wamp64\www\factorymanager
php spark migrate:status
```

This shows which migrations have already run.

---

### Step 2: Run All Pending Migrations
```bash
php spark migrate
```

**Expected Output:**
```
Running: 2024-01-15-000002_CreateCommentsTable
Migrated: 2024-01-15-000002_CreateCommentsTable

Running: 2024-01-15-000003_CreateAttachmentsTable
Migrated: 2024-01-15-000003_CreateAttachmentsTable

Running: 2024-01-15-000004_CreateNotificationsTable
Migrated: 2024-01-15-000004_CreateNotificationsTable

Running: 2024-01-20-000001_CreateMaintenanceRequestSystem
Migrated: 2024-01-20-000001_CreateMaintenanceRequestSystem

Done
```

---

### Step 3: Verify Tables Were Created
```bash
# Check if tables exist
php spark db:table comments
php spark db:table attachments
php spark db:table notifications
php spark db:table maintenance_requests
php spark db:table work_orders
php spark db:table work_order_activities
php spark db:table maintenance_notifications
php spark db:table system_modules
```

**OR use MySQL directly:**
```sql
-- Connect to MySQL
mysql -u root -p

-- Use your database
USE factorymanager;

-- Show all tables
SHOW TABLES;

-- Check specific tables
DESCRIBE comments;
DESCRIBE attachments;
DESCRIBE notifications;
DESCRIBE maintenance_requests;
DESCRIBE work_orders;
DESCRIBE work_order_activities;
DESCRIBE maintenance_notifications;
DESCRIBE system_modules;
```

---

### Step 4: Create Upload Directory
```bash
# Create directory for file uploads
mkdir c:\wamp64\www\factorymanager\writable\uploads

# Or if it exists, ensure it's writable
# (Windows automatically handles permissions)
```

---

## 🔧 Troubleshooting

### Issue 1: Migration Already Exists Error
**Error:** `Migration already exists`

**Solution:**
```bash
# Check migration status
php spark migrate:status

# If already migrated, skip to verification
```

---

### Issue 2: Database Connection Error
**Error:** `Unable to connect to database`

**Solution:**
1. Check `.env` file:
```env
database.default.hostname = localhost
database.default.database = factorymanager
database.default.username = root
database.default.password = your_password
database.default.DBDriver = MySQLi
```

2. Ensure MySQL is running:
```bash
# Check WAMP services
# Green icon = running
```

---

### Issue 3: Table Already Exists
**Error:** `Table 'comments' already exists`

**Solution:**
```bash
# Rollback specific migration
php spark migrate:rollback

# Or rollback all
php spark migrate:rollback -all

# Then re-run
php spark migrate
```

---

### Issue 4: Permission Denied on writable/uploads
**Solution:**
```bash
# Windows: Right-click folder → Properties → Security
# Ensure "Users" has Full Control
```

---

## ✅ Verification Checklist

After running migrations, verify:

### 1. Check Migration Status
```bash
php spark migrate:status
```
**Expected:** All 4 migrations should show as "Migrated"

### 2. Count Tables
```sql
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_schema = 'factorymanager' 
AND table_name IN (
    'comments',
    'attachments', 
    'notifications',
    'maintenance_requests',
    'work_orders',
    'work_order_activities',
    'maintenance_notifications',
    'system_modules'
);
```
**Expected:** 8 tables

### 3. Test Insert
```sql
-- Test comments table
INSERT INTO comments (entity_type, entity_id, comment, user_id, created_at) 
VALUES ('test', 1, 'Test comment', 1, NOW());

SELECT * FROM comments;

-- Clean up
DELETE FROM comments WHERE entity_type = 'test';
```

### 4. Check Indexes
```sql
SHOW INDEX FROM comments;
SHOW INDEX FROM attachments;
SHOW INDEX FROM notifications;
```

---

## 📋 Quick Command Reference

```bash
# Run all pending migrations
php spark migrate

# Check migration status
php spark migrate:status

# Rollback last batch
php spark migrate:rollback

# Rollback all migrations
php spark migrate:rollback -all

# Refresh (rollback all + migrate)
php spark migrate:refresh

# Check database connection
php spark db:table users
```

---

## 🎯 Expected Final State

After successful migration, you should have:

✅ **8 New Tables:**
1. comments
2. attachments
3. notifications
4. maintenance_requests
5. work_orders
6. work_order_activities
7. maintenance_notifications
8. system_modules

✅ **Indexes Created:**
- comments: (entity_type, entity_id)
- attachments: (entity_type, entity_id)
- notifications: (user_id, is_read)
- maintenance_requests: (request_number, status)
- work_orders: (work_order_number, status)

✅ **Upload Directory:**
- c:\wamp64\www\factorymanager\writable\uploads

---

## 🚀 Next Steps After Migration

1. **Test API Endpoints:**
```bash
# Test comments API
curl http://localhost/factorymanager/public/index.php/api/v1/eam/maintenance/comments/work_order/1
```

2. **Seed Initial Data (Optional):**
```bash
php spark db:seed MaintenanceSeeder
```

3. **Start Frontend:**
```bash
cd c:\devs\factorymanager
npm run dev
```

4. **Access Application:**
```
Frontend: http://localhost:3000
Backend API: http://localhost/factorymanager/public/index.php/api/v1/eam
```

---

## 📞 Support

If you encounter issues:

1. **Check PHP Error Log:**
   - `c:\wamp64\logs\php_error.log`

2. **Check MySQL Error Log:**
   - `c:\wamp64\logs\mysql.log`

3. **Enable Debug Mode:**
   - Edit `.env`: `CI_ENVIRONMENT = development`

4. **Check Migration Files:**
   - Ensure all 4 files exist in `app/Database/Migrations/`

---

**Ready to migrate? Run:** `php spark migrate`

**Status:** Production Ready ✅
