<?php
/**
 * Delete duplicate controllers that are truly redundant
 */

echo "=== DELETING DUPLICATE CONTROLLERS ===\n\n";

$toDelete = [
    'app/Controllers/Api/V1/AssetsController.php',
    'app/Controllers/Api/V1/AssetUnifiedController.php',
    'app/Controllers/Api/V1/AssetTreeController.php',
    'app/Controllers/Api/V1/AssetHierarchyController.php',
];

$deleted = 0;
$failed = 0;

foreach ($toDelete as $file) {
    $fullPath = "c:\\wamp64\\www\\factorymanager\\$file";
    
    if (file_exists($fullPath)) {
        if (unlink($fullPath)) {
            echo "✓ Deleted: $file\n";
            $deleted++;
        } else {
            echo "✗ Failed to delete: $file\n";
            $failed++;
        }
    } else {
        echo "⊘ Not found: $file\n";
    }
}

echo "\n=== SUMMARY ===\n";
echo "Deleted: $deleted files\n";
echo "Failed: $failed files\n";
echo "Total: " . count($toDelete) . " files\n\n";

if ($deleted > 0) {
    echo "✅ Cleanup complete!\n";
    echo "Removed $deleted duplicate controllers.\n";
    echo "All functionality preserved in Asset/ namespace controllers.\n";
}
?>
