-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 4: EMPLOYEE & HR
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- EMPLOYEE TABLE
ALTER TABLE `employee` ADD INDEX IF NOT EXISTS `idx_em_id` (`em_id`);
ALTER TABLE `employee` ADD INDEX IF NOT EXISTS `idx_em_code` (`em_code`);
ALTER TABLE `employee` ADD INDEX IF NOT EXISTS `idx_em_email` (`em_email`);
ALTER TABLE `employee` ADD INDEX IF NOT EXISTS `idx_des_dep` (`des_id`, `dep_id`);
ALTER TABLE `employee` ADD INDEX IF NOT EXISTS `idx_status_emp` (`status`);
ALTER TABLE `employee` ADD INDEX IF NOT EXISTS `idx_role` (`em_role`);

-- EMP_ATTENDANCE TABLE
ALTER TABLE `emp_attendance` ADD INDEX IF NOT EXISTS `idx_emp_date` (`emp_id`, `atten_date`);
ALTER TABLE `emp_attendance` ADD INDEX IF NOT EXISTS `idx_status_emp_att` (`status`);
ALTER TABLE `emp_attendance` ADD INDEX IF NOT EXISTS `idx_signin_time` (`signin_time`);

-- EMP_LEAVE TABLE
ALTER TABLE `emp_leave` ADD INDEX IF NOT EXISTS `idx_emp_leave` (`em_id`, `typeid`);
ALTER TABLE `emp_leave` ADD INDEX IF NOT EXISTS `idx_leave_status` (`leave_status`);
ALTER TABLE `emp_leave` ADD INDEX IF NOT EXISTS `idx_leave_dates` (`start_date`, `end_date`);

-- EMP_SALARY TABLE
ALTER TABLE `emp_salary` ADD INDEX IF NOT EXISTS `idx_emp_salary` (`emp_id`, `type_id`);

-- PAY_SALARY TABLE
ALTER TABLE `pay_salary` ADD INDEX IF NOT EXISTS `idx_emp_pay` (`emp_id`, `type_id`);
ALTER TABLE `pay_salary` ADD INDEX IF NOT EXISTS `idx_month_year` (`month`, `year`);
ALTER TABLE `pay_salary` ADD INDEX IF NOT EXISTS `idx_status_pay` (`status`);

-- ADDITION TABLE
ALTER TABLE `addition` ADD INDEX IF NOT EXISTS `idx_salary_addition` (`salary_id`);

-- DEDUCTION TABLE
ALTER TABLE `deduction` ADD INDEX IF NOT EXISTS `idx_salary_deduction` (`salary_id`);

-- LOAN TABLE
ALTER TABLE `loan` ADD INDEX IF NOT EXISTS `idx_emp_loan` (`emp_id`);
ALTER TABLE `loan` ADD INDEX IF NOT EXISTS `idx_loan_number` (`loan_number`);
ALTER TABLE `loan` ADD INDEX IF NOT EXISTS `idx_status_loan` (`status`);

-- LOAN_INSTALLMENT TABLE
ALTER TABLE `loan_installment` ADD INDEX IF NOT EXISTS `idx_loan_install` (`loan_id`, `emp_id`);
ALTER TABLE `loan_installment` ADD INDEX IF NOT EXISTS `idx_loan_num_install` (`loan_number`);

-- ASSIGN_LEAVE TABLE
ALTER TABLE `assign_leave` ADD INDEX IF NOT EXISTS `idx_emp_leave_assign` (`emp_id`, `type_id`);
ALTER TABLE `assign_leave` ADD INDEX IF NOT EXISTS `idx_dateyear` (`dateyear`);

-- LEAVE_TYPES TABLE
ALTER TABLE `leave_types` ADD INDEX IF NOT EXISTS `idx_status_leave_type` (`status`);

-- DEPARTMENT TABLE
ALTER TABLE `department` ADD INDEX IF NOT EXISTS `idx_dep_name` (`dep_name`);

-- DESIGNATION TABLE
ALTER TABLE `designation` ADD INDEX IF NOT EXISTS `idx_des_name` (`des_name`);

-- EDUCATION TABLE
ALTER TABLE `education` ADD INDEX IF NOT EXISTS `idx_emp_education` (`emp_id`);

-- EMP_EXPERIENCE TABLE
ALTER TABLE `emp_experience` ADD INDEX IF NOT EXISTS `idx_emp_exp` (`emp_id`);

-- EMP_BANK_INFO TABLE
ALTER TABLE `emp_bank_info` ADD INDEX IF NOT EXISTS `idx_emp_bank` (`em_id`);

-- EMP_ADDRESS TABLE
ALTER TABLE `emp_address` ADD INDEX IF NOT EXISTS `idx_emp_address` (`emp_id`, `type`);

-- SOCIAL_MEDIA TABLE
ALTER TABLE `social_media` ADD INDEX IF NOT EXISTS `idx_emp_social` (`emp_id`);

-- DESCIPLINARY TABLE
ALTER TABLE `desciplinary` ADD INDEX IF NOT EXISTS `idx_emp_discipline` (`em_id`);

-- EMP_PENALTY TABLE
ALTER TABLE `emp_penalty` ADD INDEX IF NOT EXISTS `idx_emp_penalty` (`emp_id`, `penalty_id`);

-- PENALTY TABLE
ALTER TABLE `penalty` ADD INDEX IF NOT EXISTS `idx_status_penalty` (`status`);

-- EARNED_LEAVE TABLE
ALTER TABLE `earned_leave` ADD INDEX IF NOT EXISTS `idx_emp_earned` (`em_id`, `present_date`);
ALTER TABLE `earned_leave` ADD INDEX IF NOT EXISTS `idx_status_earned` (`status`);

COMMIT;
