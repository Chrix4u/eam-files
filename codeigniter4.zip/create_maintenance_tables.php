<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "=== CREATING MAINTENANCE ENHANCEMENT TABLES ===\n\n";

// Maintenance Attachments
$sql = "CREATE TABLE IF NOT EXISTS maintenance_attachments (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT(11) UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(100),
    file_size INT(11),
    uploaded_by INT(11) UNSIGNED,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request_id (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($db, $sql)) {
    echo "✓ maintenance_attachments table created\n";
} else {
    echo "✗ Error creating maintenance_attachments: " . mysqli_error($db) . "\n";
}

// Maintenance Comments
$sql = "CREATE TABLE IF NOT EXISTS maintenance_comments (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT(11) UNSIGNED NOT NULL,
    user_id INT(11) UNSIGNED NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_request_id (request_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($db, $sql)) {
    echo "✓ maintenance_comments table created\n";
} else {
    echo "✗ Error creating maintenance_comments: " . mysqli_error($db) . "\n";
}

// Maintenance Notifications
$sql = "CREATE TABLE IF NOT EXISTS maintenance_notifications (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) UNSIGNED NOT NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_is_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($db, $sql)) {
    echo "✓ maintenance_notifications table created\n";
} else {
    echo "✗ Error creating maintenance_notifications: " . mysqli_error($db) . "\n";
}

echo "\n=== TABLES CREATED SUCCESSFULLY ===\n";

mysqli_close($db);
