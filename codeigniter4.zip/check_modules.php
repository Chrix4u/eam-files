<?php
require 'vendor/autoload.php';

$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');
$result = mysqli_query($db, 'SELECT module_code, module_name, is_core, is_system_licensed FROM system_modules ORDER BY id');

while ($row = mysqli_fetch_assoc($result)) {
    echo $row['module_code'] . ' | ' . $row['module_name'] . ' | is_core=' . $row['is_core'] . ' | is_system_licensed=' . $row['is_system_licensed'] . PHP_EOL;
}
