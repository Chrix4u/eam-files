<?php
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "=== FIXING USER ROLES ===\n\n";

// Check current roles
$result = $db->query("SELECT id, username, role FROM users ORDER BY id");
echo "Current roles:\n";
while ($row = $result->fetch_assoc()) {
    echo "  {$row['id']}. {$row['username']} - {$row['role']}\n";
}
echo "\n";

// Fix roles
$updates = [
    ['username' => 'admin', 'role' => 'admin'],
    ['username' => 'operator1', 'role' => 'operator'],
    ['username' => 'manager1', 'role' => 'manager'],
    ['username' => 'planner1', 'role' => 'planner'],
    ['username' => 'technician1', 'role' => 'technician'],
    ['username' => 'supervisor1', 'role' => 'supervisor'],
];

foreach ($updates as $update) {
    $stmt = $db->prepare("UPDATE users SET role = ? WHERE username = ?");
    $stmt->bind_param('ss', $update['role'], $update['username']);
    $stmt->execute();
    echo "✓ Updated {$update['username']} to role: {$update['role']}\n";
}

echo "\n";

// Verify
$result = $db->query("SELECT id, username, role FROM users ORDER BY id");
echo "Updated roles:\n";
while ($row = $result->fetch_assoc()) {
    echo "  {$row['id']}. {$row['username']} - {$row['role']}\n";
}

$db->close();
echo "\n=== DONE ===\n";
