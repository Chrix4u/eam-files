<?php
require 'vendor/autoload.php';

// Direct database connection
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) {
    die('Connection failed: ' . $db->connect_error);
}

// Check if table exists
$query = $db->query("SHOW TABLES LIKE 'skill_categories'");
if ($query && $query->num_rows > 0) {
    echo "Table 'skill_categories' already exists.\n";
} else {
    // Create table
    $sql = "CREATE TABLE `skill_categories` (
        `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `category_name` VARCHAR(100) NOT NULL,
        `description` TEXT NULL,
        `is_active` TINYINT(1) DEFAULT 1,
        `created_at` DATETIME NULL,
        `updated_at` DATETIME NULL,
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
    
    if ($db->query($sql)) {
        echo "Table 'skill_categories' created successfully.\n";
    } else {
        echo "Error creating table: " . $db->error . "\n";
    }
}

// Insert default categories
$categories = [
    ['category_name' => 'Technical', 'description' => 'Technical skills'],
    ['category_name' => 'Safety', 'description' => 'Safety and compliance skills'],
    ['category_name' => 'Mechanical', 'description' => 'Mechanical maintenance skills'],
    ['category_name' => 'Electrical', 'description' => 'Electrical maintenance skills'],
    ['category_name' => 'Instrumentation', 'description' => 'Instrumentation and control skills'],
];

foreach ($categories as $cat) {
    $stmt = $db->prepare("SELECT COUNT(*) as cnt FROM skill_categories WHERE category_name = ?");
    $stmt->bind_param('s', $cat['category_name']);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if ($result['cnt'] == 0) {
        $stmt = $db->prepare("INSERT INTO skill_categories (category_name, description, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param('ss', $cat['category_name'], $cat['description']);
        $stmt->execute();
        echo "Inserted category: {$cat['category_name']}\n";
    }
}

$db->close();
echo "Done!\n";
