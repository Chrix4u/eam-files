# 🔹 PHASE 2: EXPERT RECOMMENDATIONS
## Enterprise Maintenance & Repairs Module Architecture

**Architect**: Senior EAM System Expert  
**Date**: January 2025  
**Standards**: ISO 55000, ITIL, SAP PM, IBM Maximo, Oracle EAM

---

## 📋 EXECUTIVE SUMMARY

Based on Phase 1 audit, this document provides enterprise-grade recommendations to transform the current B+ system into an A++ world-class EAM platform.

**Focus Areas**:
1. Multi-technician team assignment with lead designation
2. Dynamic assistance request workflow
3. Structured job planning
4. SLA tracking and escalation
5. Enhanced PM integration
6. Complete audit trail

---

## A. MAINTENANCE TYPES - FULL SUPPORT

### 1. Corrective / Breakdown Maintenance ✅ EXISTING
**Status**: Well implemented

**Current Support**:
- Emergency work orders
- Failure code tracking
- Root cause analysis
- Downtime impact recording

**Enhancements Needed**:
- Add failure pattern analysis
- Implement recurring failure alerts
- Add MTBF tracking per asset

### 2. Preventive Maintenance (PM) ⚠️ NEEDS ENHANCEMENT

**Current State**: Basic PM support via pm_task_id

**Required Enhancements**:

#### Time-Based PM
```sql
-- Enhance pm_schedules table
ALTER TABLE pm_schedules ADD COLUMN auto_generate_wo BOOLEAN DEFAULT TRUE;
ALTER TABLE pm_schedules ADD COLUMN lead_time_days INT DEFAULT 7;
ALTER TABLE pm_schedules ADD COLUMN last_generated_date DATE;
ALTER TABLE pm_schedules ADD COLUMN next_due_date DATE;
```

**Workflow**:
```
PM Schedule Defined (e.g., every 30 days)
    ↓
System Checks Daily (cron job)
    ↓
Due Date - Lead Time Reached
    ↓
Auto-Generate Work Order
    ↓
Assign to Planner
    ↓
Planner Schedules & Assigns Team
    ↓
Execution
    ↓
Update PM Schedule (next_due_date)
```

#### Meter-Based PM
```sql
-- Add meter-based triggers
CREATE TABLE pm_meter_triggers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pm_schedule_id INT NOT NULL,
    meter_id INT NOT NULL,
    trigger_value INT NOT NULL,
    last_reading INT,
    last_wo_generated_at DATETIME,
    FOREIGN KEY (pm_schedule_id) REFERENCES pm_schedules(id),
    FOREIGN KEY (meter_id) REFERENCES meters(id)
);
```

**Workflow**:
```
Meter Reading Recorded
    ↓
System Checks PM Triggers
    ↓
Reading >= Trigger Value
    ↓
Auto-Generate Work Order
    ↓
Assign to Planner
```

### 3. Predictive Maintenance ❌ NEW IMPLEMENTATION

**Approach**: Inspection-driven with condition monitoring

**Required Tables**:
```sql
CREATE TABLE predictive_maintenance_inspections (
    id INT PRIMARY KEY AUTO_INCREMENT,
    asset_id INT NOT NULL,
    inspection_type ENUM('vibration', 'temperature', 'oil_analysis', 'visual', 'ultrasonic') NOT NULL,
    reading_value DECIMAL(10,2),
    threshold_warning DECIMAL(10,2),
    threshold_critical DECIMAL(10,2),
    status ENUM('normal', 'warning', 'critical') NOT NULL,
    inspector_id INT NOT NULL,
    inspection_date DATETIME NOT NULL,
    next_inspection_date DATE,
    notes TEXT,
    work_order_generated BOOLEAN DEFAULT FALSE,
    work_order_id INT,
    FOREIGN KEY (asset_id) REFERENCES assets_unified(id),
    INDEX idx_status (status),
    INDEX idx_next_inspection (next_inspection_date)
);
```

**Workflow**:
```
Technician Performs Inspection
    ↓
Records Reading (e.g., vibration = 8.5mm/s)
    ↓
System Compares to Thresholds
    ↓
IF Critical (>10mm/s):
    - Auto-generate URGENT work order
    - Notify supervisor immediately
IF Warning (7-10mm/s):
    - Flag for review
    - Schedule follow-up inspection
IF Normal (<7mm/s):
    - Log reading
    - Schedule next inspection
```

### 4. Emergency / Urgent Maintenance ✅ EXISTING
**Status**: Supported via priority field

**Enhancements**:
- Add auto-escalation for urgent orders
- Implement emergency response team assignment
- Add emergency contact notification

### 5. Planned Shutdown / Overhaul Maintenance ❌ NEW

**Required Tables**:
```sql
CREATE TABLE shutdown_events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(255) NOT NULL,
    event_type ENUM('planned_shutdown', 'turnaround', 'overhaul') NOT NULL,
    facility_id INT,
    planned_start_date DATE NOT NULL,
    planned_end_date DATE NOT NULL,
    actual_start_date DATE,
    actual_end_date DATE,
    status ENUM('planning', 'approved', 'in_progress', 'completed', 'cancelled') DEFAULT 'planning',
    budget DECIMAL(15,2),
    actual_cost DECIMAL(15,2),
    coordinator_id INT NOT NULL,
    created_at DATETIME,
    updated_at DATETIME,
    FOREIGN KEY (coordinator_id) REFERENCES users(id)
);

CREATE TABLE shutdown_work_orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    shutdown_event_id INT NOT NULL,
    work_order_id INT NOT NULL,
    sequence_order INT,
    critical_path BOOLEAN DEFAULT FALSE,
    dependencies JSON COMMENT 'Array of work_order_ids that must complete first',
    FOREIGN KEY (shutdown_event_id) REFERENCES shutdown_events(id),
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id),
    INDEX idx_shutdown (shutdown_event_id, sequence_order)
);
```

**Workflow**:
```
Shutdown Event Created
    ↓
Planner Creates Multiple Work Orders
    ↓
Links WOs to Shutdown Event
    ↓
Defines Dependencies & Critical Path
    ↓
Assigns Teams to Each WO
    ↓
Shutdown Begins
    ↓
WOs Execute in Sequence
    ↓
Track Progress vs Plan
    ↓
Shutdown Completed
    ↓
Post-Shutdown Review
```

---

## B. END-TO-END WORK ORDER LIFECYCLE

### Complete Workflow Design

```
┌─────────────────────────────────────────────────────────────┐
│                    MAINTENANCE REQUEST                       │
│  Operator/Department raises request with priority & details  │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│                  SUPERVISOR REVIEW                           │
│  • Review request details                                    │
│  • Approve / Reject / Request Clarification                  │
│  • Assign priority if not set                                │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│              PLANNING & SCHEDULING                           │
│  Planner:                                                    │
│  • Creates Work Order from Request                           │
│  • Creates Job Plan:                                         │
│    - Estimate duration                                       │
│    - Identify required skills                                │
│    - List required tools                                     │
│    - List required spare parts                               │
│    - Identify permits needed (PTW, LOTO)                     │
│    - Create safety checklist                                 │
│  • Reserves Resources:                                       │
│    - Check parts availability                                │
│    - Reserve parts from inventory                            │
│    - Book tools                                              │
│    - Request permits                                         │
│  • Assigns Team:                                             │
│    - Select Team Lead (primary technician)                   │
│    - Add Assistant Technicians                               │
│    - Verify skill match                                      │
│  • Sets Schedule (start/end dates)                           │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│                    EXECUTION                                 │
│  Team Lead:                                                  │
│  • Accepts work order                                        │
│  • Reviews job plan                                          │
│  • Coordinates team                                          │
│  • Starts work (time tracking begins)                        │
│                                                               │
│  During Execution:                                           │
│  • Team members log hours                                    │
│  • Record parts used                                         │
│  • Update progress                                           │
│  • Request assistance if needed:                             │
│    - Technician submits assistance request                   │
│    - Supervisor approves                                     │
│    - Additional technician assigned                          │
│    - New member joins team                                   │
│  • Complete safety checklists                                │
│  • Take photos (before/during/after)                         │
│                                                               │
│  Team Lead:                                                  │
│  • Stops work (time tracking ends)                           │
│  • Submits completion report:                                │
│    - Work performed                                          │
│    - Root cause (if breakdown)                               │
│    - Corrective actions taken                                │
│    - Parts used summary                                      │
│    - Labor hours summary                                     │
│    - Observations & recommendations                          │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│              QUALITY CONTROL & CLOSE-OUT                     │
│  Supervisor:                                                 │
│  • Reviews completion report                                 │
│  • Verifies work quality                                     │
│  • Records failure codes (if applicable)                     │
│  • Approves or requests rework                               │
│  • Closes work order                                         │
│                                                               │
│  System:                                                     │
│  • Updates asset maintenance history                         │
│  • Calculates total costs                                    │
│  • Updates PM schedule (if PM work)                          │
│  • Generates performance metrics                             │
└────────────────────┬────────────────────────────────────────┘
                     ↓
┌─────────────────────────────────────────────────────────────┐
│              REPORTING & HISTORY                             │
│  • Asset maintenance history updated                         │
│  • Cost tracking (labor + parts + external)                  │
│  • Downtime tracking                                         │
│  • KPI calculations (MTTR, MTBF, etc.)                       │
│  • Audit trail complete                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## C. ENTERPRISE FEATURES - DETAILED RECOMMENDATIONS

### 1. Multi-Technician Team Assignment ⭐ CRITICAL

#### Database Schema
```sql
CREATE TABLE work_order_team_members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT NOT NULL,
    technician_id INT NOT NULL,
    role ENUM('team_lead', 'assistant', 'specialist') NOT NULL,
    assigned_date DATETIME NOT NULL,
    assigned_by INT NOT NULL,
    accepted_date DATETIME,
    declined_date DATETIME,
    status ENUM('assigned', 'accepted', 'declined', 'working', 'completed') DEFAULT 'assigned',
    labor_hours DECIMAL(10,2) DEFAULT 0,
    notes TEXT,
    created_at DATETIME,
    updated_at DATETIME,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES users(id),
    FOREIGN KEY (assigned_by) REFERENCES users(id),
    UNIQUE KEY unique_wo_tech (work_order_id, technician_id),
    INDEX idx_role (role),
    INDEX idx_status (status)
);
```

#### API Endpoints
```php
// WorkOrderTeamController.php

POST   /api/v1/eam/work-orders/{id}/team/assign
Body: {
    "team_lead_id": 5,
    "assistant_ids": [12, 18, 24],
    "notes": "Requires electrical and mechanical skills"
}

GET    /api/v1/eam/work-orders/{id}/team
Response: {
    "team_lead": {...},
    "assistants": [...],
    "total_hours": 24.5
}

POST   /api/v1/eam/work-orders/{id}/team/add-member
Body: {
    "technician_id": 30,
    "role": "specialist",
    "reason": "Requires welding expertise"
}

DELETE /api/v1/eam/work-orders/{id}/team/remove-member/{techId}

PUT    /api/v1/eam/work-orders/{id}/team/change-lead
Body: {
    "new_lead_id": 12,
    "reason": "Original lead unavailable"
}

POST   /api/v1/eam/work-orders/{id}/team/accept
// Team lead accepts the assignment

GET    /api/v1/eam/technicians/{id}/active-assignments
// Get all active work orders for a technician
```

#### Business Rules
1. **One Team Lead Required**: Every work order must have exactly one team lead
2. **Lead Acceptance**: Work cannot start until team lead accepts
3. **Lead Responsibilities**:
   - Coordinate team
   - Submit completion report
   - Approve assistant hours
4. **Assistant Capabilities**:
   - Log own hours
   - Record parts used
   - Add notes
   - Cannot submit final report
5. **Reassignment**: Only planner/supervisor can reassign team members
6. **Lead Change**: Requires supervisor approval

### 2. Dynamic Assistance Request ⭐ CRITICAL

#### Database Schema
```sql
CREATE TABLE work_order_assistance_requests (
    id INT PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT NOT NULL,
    requested_by INT NOT NULL,
    requested_at DATETIME NOT NULL,
    skill_required VARCHAR(100),
    reason TEXT NOT NULL,
    urgency ENUM('low', 'medium', 'high') DEFAULT 'medium',
    status ENUM('pending', 'approved', 'rejected', 'fulfilled', 'cancelled') DEFAULT 'pending',
    approved_by INT,
    approved_at DATETIME,
    assigned_technician_id INT,
    fulfilled_at DATETIME,
    rejection_reason TEXT,
    created_at DATETIME,
    updated_at DATETIME,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (assigned_technician_id) REFERENCES users(id),
    INDEX idx_status (status),
    INDEX idx_urgency (urgency)
);
```

#### API Endpoints
```php
POST   /api/v1/eam/work-orders/{id}/assistance/request
Body: {
    "skill_required": "Electrical",
    "reason": "Need help with motor wiring",
    "urgency": "high"
}

GET    /api/v1/eam/assistance-requests/pending
// For supervisors to see pending requests

POST   /api/v1/eam/assistance-requests/{id}/approve
Body: {
    "assigned_technician_id": 25,
    "notes": "Assigned John (electrician)"
}

POST   /api/v1/eam/assistance-requests/{id}/reject
Body: {
    "reason": "No electricians available, reschedule"
}

GET    /api/v1/eam/work-orders/{id}/assistance/history
// View all assistance requests for a work order
```

#### Workflow
```
Technician Working → Needs Help
    ↓
Clicks "Request Assistance"
    ↓
Fills Form (skill, reason, urgency)
    ↓
Submits Request
    ↓
Supervisor Notified (real-time)
    ↓
Supervisor Reviews:
    - Checks available technicians
    - Verifies skill match
    - Approves or Rejects
    ↓
If Approved:
    - Assigns technician
    - New technician added to team
    - Original technician notified
    ↓
Assistance Provided
    ↓
Request Marked as Fulfilled
```

### 3. Job Planning Module ⭐ HIGH PRIORITY

#### Database Schema
```sql
CREATE TABLE work_order_job_plans (
    id INT PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT NOT NULL,
    plan_name VARCHAR(255),
    estimated_duration INT COMMENT 'minutes',
    required_skills JSON COMMENT '["Electrical", "Mechanical"]',
    required_tools JSON COMMENT '[{"tool_id": 1, "quantity": 1}]',
    required_parts JSON COMMENT '[{"part_id": 45, "quantity": 2}]',
    safety_requirements TEXT,
    step_by_step_instructions TEXT,
    permits_required JSON COMMENT '["PTW", "LOTO"]',
    special_instructions TEXT,
    created_by INT NOT NULL,
    approved_by INT,
    approved_at DATETIME,
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    created_at DATETIME,
    updated_at DATETIME,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

CREATE TABLE work_order_resource_reservations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT NOT NULL,
    resource_type ENUM('part', 'tool', 'equipment') NOT NULL,
    resource_id INT NOT NULL,
    quantity INT NOT NULL,
    reserved_by INT NOT NULL,
    reserved_at DATETIME NOT NULL,
    released_at DATETIME,
    status ENUM('reserved', 'issued', 'returned', 'consumed') DEFAULT 'reserved',
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id),
    INDEX idx_resource (resource_type, resource_id),
    INDEX idx_status (status)
);
```

#### API Endpoints
```php
POST   /api/v1/eam/work-orders/{id}/job-plan
Body: {
    "plan_name": "Motor Bearing Replacement",
    "estimated_duration": 240,
    "required_skills": ["Mechanical", "Electrical"],
    "required_tools": [{"tool_id": 5, "quantity": 1}],
    "required_parts": [{"part_id": 45, "quantity": 2}],
    "safety_requirements": "LOTO required, confined space",
    "step_by_step_instructions": "1. Isolate power\n2. Remove old bearings..."
}

GET    /api/v1/eam/work-orders/{id}/job-plan

POST   /api/v1/eam/work-orders/{id}/job-plan/approve

POST   /api/v1/eam/work-orders/{id}/resources/reserve
Body: {
    "parts": [{"part_id": 45, "quantity": 2}],
    "tools": [{"tool_id": 5, "quantity": 1}]
}

GET    /api/v1/eam/work-orders/{id}/resources/check-availability
// Check if all required resources are available

POST   /api/v1/eam/work-orders/{id}/resources/issue
// Issue reserved resources to technician

POST   /api/v1/eam/work-orders/{id}/resources/return
// Return unused resources
```

### 4. SLA Tracking & Escalation ⭐ HIGH PRIORITY

#### Database Schema
```sql
CREATE TABLE sla_definitions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL,
    order_type ENUM('corrective', 'preventive', 'predictive', 'emergency') NOT NULL,
    response_time_hours INT NOT NULL COMMENT 'Time to assign',
    resolution_time_hours INT NOT NULL COMMENT 'Time to complete',
    escalation_level_1_hours INT,
    escalation_level_2_hours INT,
    escalation_level_3_hours INT,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME,
    updated_at DATETIME,
    UNIQUE KEY unique_priority_type (priority, order_type)
);

CREATE TABLE work_order_sla_tracking (
    id INT PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT NOT NULL,
    sla_definition_id INT NOT NULL,
    target_response_time DATETIME NOT NULL,
    actual_response_time DATETIME,
    target_resolution_time DATETIME NOT NULL,
    actual_resolution_time DATETIME,
    response_breached BOOLEAN DEFAULT FALSE,
    resolution_breached BOOLEAN DEFAULT FALSE,
    response_breach_duration INT COMMENT 'minutes',
    resolution_breach_duration INT COMMENT 'minutes',
    current_escalation_level INT DEFAULT 0,
    escalated_to INT,
    escalated_at DATETIME,
    escalation_notes TEXT,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id),
    FOREIGN KEY (sla_definition_id) REFERENCES sla_definitions(id),
    INDEX idx_breached (response_breached, resolution_breached),
    INDEX idx_escalation (current_escalation_level)
);
```

#### API Endpoints
```php
GET    /api/v1/eam/work-orders/{id}/sla-status
Response: {
    "response_sla": {
        "target": "2025-01-28 10:00:00",
        "actual": "2025-01-28 09:30:00",
        "status": "met",
        "remaining_minutes": null
    },
    "resolution_sla": {
        "target": "2025-01-28 18:00:00",
        "actual": null,
        "status": "on_track",
        "remaining_minutes": 120
    },
    "escalation_level": 0
}

GET    /api/v1/eam/work-orders/sla-breached
// List all work orders with breached SLAs

POST   /api/v1/eam/work-orders/{id}/escalate
Body: {
    "escalation_level": 1,
    "escalate_to": 15,
    "reason": "Approaching SLA breach"
}

GET    /api/v1/eam/sla-dashboard
Response: {
    "total_work_orders": 150,
    "sla_met": 135,
    "sla_breached": 15,
    "at_risk": 8,
    "compliance_rate": 90.0
}
```

#### Auto-Escalation Logic
```php
// Cron job runs every 15 minutes
foreach ($activeWorkOrders as $wo) {
    $sla = $wo->sla_tracking;
    $now = time();
    
    // Check response SLA
    if (!$wo->assigned_to && $now > strtotime($sla->target_response_time)) {
        // Breach - escalate to level 1
        escalate($wo, 1, "Response SLA breached");
    }
    
    // Check resolution SLA
    $timeRemaining = strtotime($sla->target_resolution_time) - $now;
    
    if ($timeRemaining < 0) {
        // Breached - escalate to level 3
        escalate($wo, 3, "Resolution SLA breached");
    } elseif ($timeRemaining < 3600) {
        // 1 hour remaining - escalate to level 2
        escalate($wo, 2, "Resolution SLA at risk");
    } elseif ($timeRemaining < 7200) {
        // 2 hours remaining - escalate to level 1
        escalate($wo, 1, "Resolution SLA warning");
    }
}
```

---

## D. ROLE-BASED ACCESS CONTROL (RBAC)

### Enhanced Permissions Matrix

| Action | Operator | Technician | Team Lead | Supervisor | Planner | Manager |
|--------|----------|------------|-----------|------------|---------|---------|
| Create Request | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Approve Request | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Create Work Order | ❌ | ❌ | ❌ | ⚠️ | ✅ | ✅ |
| Create Job Plan | ❌ | ❌ | ❌ | ⚠️ | ✅ | ✅ |
| Assign Team | ❌ | ❌ | ❌ | ⚠️ | ✅ | ✅ |
| Designate Team Lead | ❌ | ❌ | ❌ | ⚠️ | ✅ | ✅ |
| Accept Assignment | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Start Work | ❌ | ⚠️ | ✅ | ❌ | ❌ | ❌ |
| Log Hours | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Record Parts Used | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Request Assistance | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ |
| Approve Assistance | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Submit Completion | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |
| Approve Completion | ❌ | ❌ | ❌ | ✅ | ⚠️ | ✅ |
| Close Work Order | ❌ | ❌ | ❌ | ✅ | ⚠️ | ✅ |
| Reassign Team | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Change Team Lead | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| View All WOs | ❌ | ⚠️ | ⚠️ | ✅ | ✅ | ✅ |
| View Analytics | ❌ | ⚠️ | ⚠️ | ✅ | ✅ | ✅ |

Legend: ✅ Full Access | ⚠️ Limited Access | ❌ No Access

---

## E. KPIs & DASHBOARDS

### Critical KPIs to Implement

#### 1. MTBF (Mean Time Between Failures)
```sql
SELECT 
    asset_id,
    AVG(TIMESTAMPDIFF(HOUR, previous_failure, failure_date)) as mtbf_hours
FROM (
    SELECT 
        asset_id,
        actual_start as failure_date,
        LAG(actual_start) OVER (PARTITION BY asset_id ORDER BY actual_start) as previous_failure
    FROM maintenance_orders
    WHERE order_type = 'corrective'
    AND status = 'completed'
) failures
GROUP BY asset_id;
```

#### 2. First-Time Fix Rate
```sql
SELECT 
    COUNT(CASE WHEN repeat_work = FALSE THEN 1 END) * 100.0 / COUNT(*) as first_time_fix_rate
FROM maintenance_orders
WHERE status = 'completed'
AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY);
```

#### 3. Planned vs Unplanned Ratio
```sql
SELECT 
    order_type,
    COUNT(*) as count,
    COUNT(*) * 100.0 / SUM(COUNT(*)) OVER () as percentage
FROM maintenance_orders
WHERE status = 'completed'
GROUP BY order_type;
```

#### 4. Team Efficiency
```sql
SELECT 
    tm.technician_id,
    u.name,
    COUNT(DISTINCT tm.work_order_id) as jobs_completed,
    SUM(tm.labor_hours) as total_hours,
    AVG(mo.actual_hours / mo.estimated_hours) as efficiency_ratio
FROM work_order_team_members tm
JOIN users u ON u.id = tm.technician_id
JOIN maintenance_orders mo ON mo.id = tm.work_order_id
WHERE mo.status = 'completed'
AND tm.status = 'completed'
GROUP BY tm.technician_id;
```

---

**PHASE 2 COMPLETE**  
**Next**: Phase 3 - Data Model & API Design

*Prepared by: Senior EAM System Architect*  
*Date: January 2025*
