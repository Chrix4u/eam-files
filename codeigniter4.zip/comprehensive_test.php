<?php
// Comprehensive System Test
$pdo = new PDO("mysql:host=localhost;dbname=factory_manager", "root", "myjesus4mE");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║     FACTORY MANAGER EAM SYSTEM - COMPREHENSIVE TEST       ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

// Test categories
$tests = [];

// 1. CORE SYSTEM
echo "📊 1. CORE SYSTEM\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$userCount = $stmt->fetchColumn();
echo "   Users: $userCount\n";
$tests['users'] = $userCount > 0;

$stmt = $pdo->query("SELECT COUNT(*) FROM roles");
$roleCount = $stmt->fetchColumn();
echo "   Roles: $roleCount\n";
$tests['roles'] = $roleCount > 0;

$stmt = $pdo->query("SELECT COUNT(*) FROM permissions");
$permCount = $stmt->fetchColumn();
echo "   Permissions: $permCount\n";
$tests['permissions'] = $permCount > 0;

$stmt = $pdo->query("SELECT COUNT(*) FROM company_settings");
$companyCount = $stmt->fetchColumn();
echo "   Company Settings: $companyCount\n";
echo "\n";

// 2. ASSET MANAGEMENT
echo "🏭 2. ASSET MANAGEMENT\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM facilities");
$facCount = $stmt->fetchColumn();
echo "   Facilities: $facCount\n";
$tests['facilities'] = true;

$stmt = $pdo->query("SELECT COUNT(*) FROM systems");
$sysCount = $stmt->fetchColumn();
echo "   Systems: $sysCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM assemblies");
$asmCount = $stmt->fetchColumn();
echo "   Assemblies: $asmCount\n";
$tests['assemblies'] = $asmCount > 0;

$stmt = $pdo->query("SELECT COUNT(*) FROM parts");
$partCount = $stmt->fetchColumn();
echo "   Parts: $partCount\n";
$tests['parts'] = $partCount > 0;

$stmt = $pdo->query("SELECT COUNT(*) FROM assets");
$assetCount = $stmt->fetchColumn();
echo "   Assets: $assetCount\n";
echo "\n";

// 3. WORK ORDER MANAGEMENT
echo "📋 3. WORK ORDER MANAGEMENT\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM work_orders");
$woCount = $stmt->fetchColumn();
echo "   Work Orders: $woCount\n";
$tests['work_orders'] = true;

if ($woCount > 0) {
    $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM work_orders GROUP BY status");
    $statuses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($statuses as $status) {
        echo "      - {$status['status']}: {$status['count']}\n";
    }
}

$stmt = $pdo->query("SELECT COUNT(*) FROM work_order_tasks");
$taskCount = $stmt->fetchColumn();
echo "   Work Order Tasks: $taskCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM work_order_materials");
$matCount = $stmt->fetchColumn();
echo "   Work Order Materials: $matCount\n";
echo "\n";

// 4. PREVENTIVE MAINTENANCE
echo "🔧 4. PREVENTIVE MAINTENANCE\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM pm_templates");
$pmTempCount = $stmt->fetchColumn();
echo "   PM Templates: $pmTempCount\n";
$tests['pm_templates'] = true;

$stmt = $pdo->query("SELECT COUNT(*) FROM pm_schedules");
$pmSchedCount = $stmt->fetchColumn();
echo "   PM Schedules: $pmSchedCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM pm_checklists");
$pmCheckCount = $stmt->fetchColumn();
echo "   PM Checklists: $pmCheckCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM pm_history");
$pmHistCount = $stmt->fetchColumn();
echo "   PM History: $pmHistCount\n";
echo "\n";

// 5. INVENTORY MANAGEMENT
echo "📦 5. INVENTORY MANAGEMENT\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM inventory_items");
$invCount = $stmt->fetchColumn();
echo "   Inventory Items: $invCount\n";
$tests['inventory'] = true;

$stmt = $pdo->query("SELECT COUNT(*) FROM stock_transactions");
$stockCount = $stmt->fetchColumn();
echo "   Stock Transactions: $stockCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM vendors");
$vendorCount = $stmt->fetchColumn();
echo "   Vendors: $vendorCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM purchase_orders");
$poCount = $stmt->fetchColumn();
echo "   Purchase Orders: $poCount\n";
echo "\n";

// 6. PRODUCTION MANAGEMENT
echo "⚙️ 6. PRODUCTION MANAGEMENT\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM production_surveys");
$surveyCount = $stmt->fetchColumn();
echo "   Production Surveys: $surveyCount\n";
$tests['production'] = true;

$stmt = $pdo->query("SELECT COUNT(*) FROM production_runs");
$runCount = $stmt->fetchColumn();
echo "   Production Runs: $runCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM shifts");
$shiftCount = $stmt->fetchColumn();
echo "   Shifts: $shiftCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM oee_metrics");
$oeeCount = $stmt->fetchColumn();
echo "   OEE Metrics: $oeeCount\n";
echo "\n";

// 7. IOT INTEGRATION
echo "📡 7. IOT INTEGRATION\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM iot_devices");
$iotDevCount = $stmt->fetchColumn();
echo "   IoT Devices: $iotDevCount\n";
$tests['iot'] = true;

$stmt = $pdo->query("SELECT COUNT(*) FROM iot_metrics");
$iotMetCount = $stmt->fetchColumn();
echo "   IoT Metrics: $iotMetCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM iot_alerts");
$iotAlertCount = $stmt->fetchColumn();
echo "   IoT Alerts: $iotAlertCount\n";
echo "\n";

// 8. GRADE-A FEATURES
echo "🏆 8. GRADE-A FEATURES\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM asset_hierarchy");
$hierCount = $stmt->fetchColumn();
echo "   Asset Hierarchy: $hierCount\n";
$tests['grade_a_hierarchy'] = true;

$stmt = $pdo->query("SELECT COUNT(*) FROM asset_relationships");
$relCount = $stmt->fetchColumn();
echo "   Asset Relationships: $relCount\n";
$tests['grade_a_relationships'] = true;

// Check if 3D models table exists
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM asset_3d_models");
    $modelCount = $stmt->fetchColumn();
    echo "   3D Models: $modelCount\n";
    $tests['grade_a_3d'] = true;
} catch (Exception $e) {
    echo "   3D Models: ❌ Table missing\n";
    $tests['grade_a_3d'] = false;
}

// Check if closure table exists
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM asset_hierarchy_closure");
    $closureCount = $stmt->fetchColumn();
    echo "   Hierarchy Closure: $closureCount\n";
    $tests['grade_a_closure'] = true;
} catch (Exception $e) {
    echo "   Hierarchy Closure: ❌ Table missing\n";
    $tests['grade_a_closure'] = false;
}
echo "\n";

// 9. ADVANCED FEATURES
echo "🚀 9. ADVANCED FEATURES\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM documents");
$docCount = $stmt->fetchColumn();
echo "   Documents: $docCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM custom_reports");
$reportCount = $stmt->fetchColumn();
echo "   Custom Reports: $reportCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM energy_consumption");
$energyCount = $stmt->fetchColumn();
echo "   Energy Records: $energyCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM non_conformances");
$ncCount = $stmt->fetchColumn();
echo "   Non-Conformances: $ncCount\n";
echo "\n";

// 10. MOBILE & NOTIFICATIONS
echo "📱 10. MOBILE & NOTIFICATIONS\n";
echo str_repeat("─", 60) . "\n";
$stmt = $pdo->query("SELECT COUNT(*) FROM notifications");
$notifCount = $stmt->fetchColumn();
echo "   Notifications: $notifCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM push_tokens");
$pushCount = $stmt->fetchColumn();
echo "   Push Tokens: $pushCount\n";

$stmt = $pdo->query("SELECT COUNT(*) FROM mobile_sync_batches");
$syncCount = $stmt->fetchColumn();
echo "   Mobile Sync Batches: $syncCount\n";
echo "\n";

// SUMMARY
echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║                      TEST SUMMARY                          ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

$passed = count(array_filter($tests));
$total = count($tests);
$percentage = round(($passed / $total) * 100);

echo "Tests Passed: $passed / $total ($percentage%)\n\n";

$categories = [
    '✅ Core System' => $tests['users'] && $tests['roles'],
    '✅ Asset Management' => $tests['assemblies'] && $tests['parts'],
    '✅ Work Orders' => $tests['work_orders'],
    '✅ PM System' => $tests['pm_templates'],
    '✅ Inventory' => $tests['inventory'],
    '✅ Production' => $tests['production'],
    '✅ IoT Integration' => $tests['iot'],
    '⚠️ Grade-A Features' => $tests['grade_a_hierarchy'] && $tests['grade_a_relationships'],
];

foreach ($categories as $cat => $status) {
    echo ($status ? "✅" : "⚠️") . " $cat\n";
}

echo "\n";

// Grade-A Status
echo "🏆 GRADE-A IMPLEMENTATION STATUS:\n";
echo "   " . ($tests['grade_a_hierarchy'] ? "✅" : "❌") . " Asset Hierarchy\n";
echo "   " . ($tests['grade_a_relationships'] ? "✅" : "❌") . " Asset Relationships\n";
echo "   " . ($tests['grade_a_3d'] ? "✅" : "❌") . " 3D Models\n";
echo "   " . ($tests['grade_a_closure'] ? "✅" : "❌") . " Hierarchy Closure\n";

$gradeAComplete = $tests['grade_a_hierarchy'] && $tests['grade_a_relationships'] && 
                  $tests['grade_a_3d'] && $tests['grade_a_closure'];

echo "\n";
if ($gradeAComplete) {
    echo "🎉 Grade-A features are FULLY IMPLEMENTED!\n";
} else {
    echo "⚠️ Grade-A features need completion. Run migrations:\n";
    echo "   php spark migrate\n";
}

echo "\n";
echo "Overall System Status: ";
if ($percentage >= 90) {
    echo "🟢 EXCELLENT\n";
} elseif ($percentage >= 70) {
    echo "🟡 GOOD\n";
} else {
    echo "🔴 NEEDS ATTENTION\n";
}

echo "\n";
echo "═══════════════════════════════════════════════════════════\n";
echo "Test completed at: " . date('Y-m-d H:i:s') . "\n";
echo "═══════════════════════════════════════════════════════════\n";
