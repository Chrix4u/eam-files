# PM System Restructure - Implementation Summary

## What Was Created

### 1. Database Migration
**File:** `app/Database/Migrations/2025-01-21-000001_RestructurePmSystem.php`

Creates three new tables:
- `pm_part_tasks` - PM tasks assigned to parts with frequencies
- `pm_schedules` - Scheduled maintenance for equipment parts
- `pm_work_orders` - Generated maintenance work orders

### 2. Models
- **PmPartTaskModel.php** - Manages PM tasks for parts
- **PmScheduleNewModel.php** - Manages PM schedules and due date calculations
- **PmWorkOrderModel.php** - Manages work orders and auto-generation

### 3. Controller
**File:** `app/Controllers/PMSystem.php`

Key methods:
- `assignTaskToPart()` - Assign PM tasks to parts
- `scheduleEquipmentPM()` - Create schedules for equipment
- `generateWorkOrders()` - Auto-generate work orders from due schedules
- `workOrders()` - View work orders
- `completeWorkOrder()` - Complete and reschedule

### 4. Views
- `maintenance/assign_pm_task.php` - Form to assign PM tasks to parts
- `maintenance/generate_work_orders.php` - View and generate work orders

### 5. Documentation
- `PM_SYSTEM_GUIDE.md` - Complete usage guide
- `pm_system_setup.sql` - SQL examples and queries
- `PM_RESTRUCTURE_SUMMARY.md` - This file

### 6. Routes
Added to `app/Config/Routes.php` under `/pm-system` group

## How It Works

### The Flow:
```
1. Assign PM Tasks to Parts
   ↓
2. Schedule PM for Equipment (creates schedules for all parts)
   ↓
3. System tracks due dates automatically
   ↓
4. Generate Work Orders for due maintenance
   ↓
5. Technicians complete work orders
   ↓
6. System auto-calculates next due date
   ↓
   (Loop back to step 3)
```

### Key Concepts:

**Part-Based Maintenance:**
- Each part can have multiple PM tasks
- Each task has its own frequency (e.g., "every 7 days", "every 3 months")
- Tasks are reusable across all machines with that part

**Equipment Schedules:**
- When you schedule PM for a machine, it creates schedules for all its parts
- Each schedule tracks: last completed date, next due date, status

**Work Orders:**
- Auto-generated from due schedules
- Assigned to technicians
- Track actual time vs estimated time
- Completing a work order automatically updates the schedule

## Installation Steps

### 1. Run Migration
```bash
cd c:\wamp64\www\factorymanager
php spark migrate
```

This creates the three new tables.

### 2. Verify Tables Created
Check your database for:
- pm_part_tasks
- pm_schedules
- pm_work_orders

### 3. Start Using the System

#### Option A: Through UI
1. Go to a part's detail page
2. Click "Assign PM Task" (you'll need to add this button)
3. Fill in task details and frequency
4. Go to equipment page
5. Click "Schedule PM" (you'll need to add this button)
6. Select tasks to schedule
7. Go to "Generate Work Orders"
8. Review and generate

#### Option B: Programmatically
```php
// 1. Assign task to part
$pmPartTaskModel = new \App\Models\PmPartTaskModel();
$pmPartTaskModel->insert([
    'part_id' => 1,
    'task_name' => 'Lubrication Check',
    'frequency_value' => 7,
    'frequency_unit' => 'days',
    'priority' => 'high'
]);

// 2. Create schedule for equipment
$pmScheduleModel = new \App\Models\PmScheduleNewModel();
$pmScheduleModel->insert([
    'part_task_id' => 1,
    'equipment_id' => 1,
    'part_id' => 1,
    'start_date' => date('Y-m-d'),
    'next_due_date' => date('Y-m-d', strtotime('+7 days')),
    'status' => 'scheduled'
]);

// 3. Generate work orders
$pmWorkOrderModel = new \App\Models\PmWorkOrderModel();
$count = $pmWorkOrderModel->generateWorkOrdersFromSchedules(1); // equipment_id = 1
```

## Integration with Existing System

### Add Buttons to Part Detail Page
In `app/Views/backend/parts/single_part.php`, add:
```php
<a href="<?= base_url('pm-system/assign-task/' . $part['id']) ?>" class="btn-primary">
    <i class="fas fa-tasks mr-2"></i>Assign PM Task
</a>
```

### Add Buttons to Equipment Detail Page
In `app/Views/backend/machine/single_machine.php`, add:
```php
<a href="<?= base_url('pm-system/schedule-equipment/' . $equipment['id']) ?>" class="btn-primary">
    <i class="fas fa-calendar-alt mr-2"></i>Schedule PM
</a>
<a href="<?= base_url('pm-system/generate-work-orders/' . $equipment['id']) ?>" class="btn-success">
    <i class="fas fa-clipboard-list mr-2"></i>Generate Work Orders
</a>
```

### Add to Navigation Menu
In `app/Views/backend/includes/navigation.php`, add:
```php
<li>
    <a href="<?= base_url('pm-system/work-orders') ?>">
        <i class="fas fa-clipboard-list"></i>
        <span>PM Work Orders</span>
    </a>
</li>
```

## Testing the System

### Test Scenario:
1. **Create a PM task for a bearing:**
   - Part: Bearing #001
   - Task: Lubrication
   - Frequency: Every 7 days
   - Priority: High

2. **Schedule it for Machine #1:**
   - Start date: Today
   - Next due: 7 days from today

3. **Wait or manually set next_due_date to today:**
   ```sql
   UPDATE pm_schedules SET next_due_date = CURDATE() WHERE id = 1;
   ```

4. **Generate work order:**
   - Visit: `/pm-system/generate-work-orders/1`
   - Should see 1 due task
   - Click "Generate Work Orders"

5. **View work orders:**
   - Visit: `/pm-system/work-orders/1`
   - Should see the generated work order

6. **Complete work order:**
   - Click on work order
   - Fill completion details
   - Submit
   - Check that next_due_date is now 7 days from completion

## Advantages Over Old System

1. **Granular Control:** PM tasks at part level, not equipment level
2. **Flexible Frequencies:** Support for days, weeks, months, years, hours, cycles
3. **Automatic Scheduling:** System calculates next due dates
4. **Work Order Management:** Clear workflow from schedule to completion
5. **No Duplicates:** System prevents duplicate work orders
6. **Scalable:** Works for any number of machines and parts
7. **Reusable Tasks:** Same task definition used across all machines

## Next Steps

1. **Run the migration**
2. **Add UI buttons** to existing pages
3. **Assign PM tasks** to your parts
4. **Create schedules** for your equipment
5. **Test work order generation**
6. **Set up automated generation** (optional cron job)

## Support Queries

### Get all PM tasks for an equipment:
```sql
SELECT pt.*, p.name as part_name
FROM pm_part_tasks pt
JOIN parts p ON pt.part_id = p.id
JOIN assemblies a ON p.assembly_id = a.id
WHERE a.equipment_id = 1 AND pt.is_active = 1;
```

### Get due maintenance for an equipment:
```sql
SELECT ps.*, pt.task_name, p.name as part_name
FROM pm_schedules ps
JOIN pm_part_tasks pt ON ps.part_task_id = pt.id
JOIN parts p ON ps.part_id = p.id
WHERE ps.equipment_id = 1 
  AND ps.next_due_date <= CURDATE()
  AND ps.status IN ('scheduled', 'due', 'overdue');
```

### Get work order statistics:
```sql
SELECT 
    status,
    COUNT(*) as count,
    SUM(estimated_duration_minutes) as total_estimated_minutes
FROM pm_work_orders
WHERE equipment_id = 1
GROUP BY status;
```

## Troubleshooting

**Issue:** Migration fails
- Check if tables already exist
- Drop old tables if needed: `DROP TABLE IF EXISTS pm_work_orders, pm_schedules, pm_part_tasks;`

**Issue:** Work orders not generating
- Check if schedules exist: `SELECT * FROM pm_schedules WHERE equipment_id = 1;`
- Check if due: `SELECT * FROM pm_schedules WHERE next_due_date <= CURDATE();`
- Check for existing work orders: `SELECT * FROM pm_work_orders WHERE schedule_id = X;`

**Issue:** Next due date not calculating
- Verify frequency_unit is valid: days, weeks, months, years
- Check last_completed_date is set
- Review calculateNextDueDate() method in PmScheduleNewModel

## Contact
For questions or issues, refer to PM_SYSTEM_GUIDE.md for detailed documentation.
