USE factory_manager;

-- Create work_order_tool_request_items table without FK
CREATE TABLE IF NOT EXISTS work_order_tool_request_items (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    tool_request_id INT(11) UNSIGNED NOT NULL,
    tool_id INT(11) UNSIGNED NOT NULL,
    quantity INT(11) DEFAULT 1,
    issued_quantity INT(11) DEFAULT 0,
    condition_on_issue ENUM('GOOD','FAIR') NULL,
    condition_on_return ENUM('GOOD','FAIR','DAMAGED','LOST') NULL,
    damage_notes TEXT NULL,
    penalty_cost DECIMAL(10,2) DEFAULT 0.00,
    created_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_tool_request_id (tool_request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add foreign key separately
ALTER TABLE work_order_tool_request_items 
ADD CONSTRAINT fk_tool_request_items_request 
FOREIGN KEY (tool_request_id) REFERENCES work_order_tool_requests(id) ON DELETE CASCADE;

-- Update tool_issue_logs
ALTER TABLE tool_issue_logs ADD COLUMN tool_id INT(11) UNSIGNED NULL AFTER tool_request_id;
ALTER TABLE tool_issue_logs CHANGE tool_request_id tool_request_item_id INT(11) UNSIGNED;
