# 🔹 PHASE 3: DATA MODEL & API DESIGN
## Complete Database Schema & RESTful API Architecture

**Architect**: Senior EAM System Expert  
**Date**: January 2025  
**Version**: 3.0.0

---

## 📋 COMPLETE DATABASE MIGRATION SCRIPT

```sql
-- ============================================
-- ENTERPRISE MAINTENANCE MODULE UPGRADE
-- Version 3.0.0 - Team Assignment & Job Planning
-- ============================================

-- 1. TEAM ASSIGNMENT TABLES
CREATE TABLE IF NOT EXISTS work_order_team_members (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    role ENUM('team_lead', 'assistant', 'specialist') NOT NULL,
    assigned_date DATETIME NOT NULL,
    assigned_by INT UNSIGNED NOT NULL,
    accepted_date DATETIME NULL,
    declined_date DATETIME NULL,
    status ENUM('assigned', 'accepted', 'declined', 'working', 'completed') DEFAULT 'assigned',
    labor_hours DECIMAL(10,2) DEFAULT 0.00,
    notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (technician_id) REFERENCES users(id),
    FOREIGN KEY (assigned_by) REFERENCES users(id),
    UNIQUE KEY unique_wo_tech (work_order_id, technician_id),
    INDEX idx_role (role),
    INDEX idx_status (status),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. ASSISTANCE REQUEST TABLE
CREATE TABLE IF NOT EXISTS work_order_assistance_requests (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    requested_by INT UNSIGNED NOT NULL,
    requested_at DATETIME NOT NULL,
    skill_required VARCHAR(100) NULL,
    reason TEXT NOT NULL,
    urgency ENUM('low', 'medium', 'high') DEFAULT 'medium',
    status ENUM('pending', 'approved', 'rejected', 'fulfilled', 'cancelled') DEFAULT 'pending',
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    assigned_technician_id INT UNSIGNED NULL,
    fulfilled_at DATETIME NULL,
    rejection_reason TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    FOREIGN KEY (assigned_technician_id) REFERENCES users(id),
    INDEX idx_status (status),
    INDEX idx_urgency (urgency),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. JOB PLANNING TABLE
CREATE TABLE IF NOT EXISTS work_order_job_plans (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    plan_name VARCHAR(255) NULL,
    estimated_duration INT NULL COMMENT 'minutes',
    required_skills JSON NULL COMMENT '["Electrical", "Mechanical"]',
    required_tools JSON NULL COMMENT '[{"tool_id": 1, "quantity": 1}]',
    required_parts JSON NULL COMMENT '[{"part_id": 45, "quantity": 2}]',
    safety_requirements TEXT NULL,
    step_by_step_instructions TEXT NULL,
    permits_required JSON NULL COMMENT '["PTW", "LOTO"]',
    special_instructions TEXT NULL,
    created_by INT UNSIGNED NOT NULL,
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id),
    INDEX idx_status (status),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. RESOURCE RESERVATION TABLE
CREATE TABLE IF NOT EXISTS work_order_resource_reservations (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    resource_type ENUM('part', 'tool', 'equipment') NOT NULL,
    resource_id INT UNSIGNED NOT NULL,
    quantity INT NOT NULL,
    reserved_by INT UNSIGNED NOT NULL,
    reserved_at DATETIME NOT NULL,
    released_at DATETIME NULL,
    status ENUM('reserved', 'issued', 'returned', 'consumed') DEFAULT 'reserved',
    notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (reserved_by) REFERENCES users(id),
    INDEX idx_resource (resource_type, resource_id),
    INDEX idx_status (status),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. STATUS HISTORY TABLE
CREATE TABLE IF NOT EXISTS work_order_status_history (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(50) NULL,
    to_status VARCHAR(50) NOT NULL,
    changed_by INT UNSIGNED NOT NULL,
    changed_at DATETIME NOT NULL,
    reason TEXT NULL,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES users(id),
    INDEX idx_wo_status (work_order_id, changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. SLA DEFINITIONS TABLE
CREATE TABLE IF NOT EXISTS sla_definitions (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL,
    order_type ENUM('corrective', 'preventive', 'predictive', 'emergency') NOT NULL,
    response_time_hours INT NOT NULL COMMENT 'Time to assign',
    resolution_time_hours INT NOT NULL COMMENT 'Time to complete',
    escalation_level_1_hours INT NULL,
    escalation_level_2_hours INT NULL,
    escalation_level_3_hours INT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_priority_type (priority, order_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. SLA TRACKING TABLE
CREATE TABLE IF NOT EXISTS work_order_sla_tracking (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    sla_definition_id INT UNSIGNED NOT NULL,
    target_response_time DATETIME NOT NULL,
    actual_response_time DATETIME NULL,
    target_resolution_time DATETIME NOT NULL,
    actual_resolution_time DATETIME NULL,
    response_breached BOOLEAN DEFAULT FALSE,
    resolution_breached BOOLEAN DEFAULT FALSE,
    response_breach_duration INT NULL COMMENT 'minutes',
    resolution_breach_duration INT NULL COMMENT 'minutes',
    current_escalation_level INT DEFAULT 0,
    escalated_to INT UNSIGNED NULL,
    escalated_at DATETIME NULL,
    escalation_notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    FOREIGN KEY (sla_definition_id) REFERENCES sla_definitions(id),
    FOREIGN KEY (escalated_to) REFERENCES users(id),
    INDEX idx_breached (response_breached, resolution_breached),
    INDEX idx_escalation (current_escalation_level),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. SHUTDOWN EVENTS TABLE
CREATE TABLE IF NOT EXISTS shutdown_events (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(255) NOT NULL,
    event_type ENUM('planned_shutdown', 'turnaround', 'overhaul') NOT NULL,
    facility_id INT UNSIGNED NULL,
    planned_start_date DATE NOT NULL,
    planned_end_date DATE NOT NULL,
    actual_start_date DATE NULL,
    actual_end_date DATE NULL,
    status ENUM('planning', 'approved', 'in_progress', 'completed', 'cancelled') DEFAULT 'planning',
    budget DECIMAL(15,2) NULL,
    actual_cost DECIMAL(15,2) NULL,
    coordinator_id INT UNSIGNED NOT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (coordinator_id) REFERENCES users(id),
    INDEX idx_status (status),
    INDEX idx_dates (planned_start_date, planned_end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. SHUTDOWN WORK ORDERS TABLE
CREATE TABLE IF NOT EXISTS shutdown_work_orders (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    shutdown_event_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NOT NULL,
    sequence_order INT NULL,
    critical_path BOOLEAN DEFAULT FALSE,
    dependencies JSON NULL COMMENT 'Array of work_order_ids that must complete first',
    created_at DATETIME NULL,
    FOREIGN KEY (shutdown_event_id) REFERENCES shutdown_events(id) ON DELETE CASCADE,
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id) ON DELETE CASCADE,
    INDEX idx_shutdown (shutdown_event_id, sequence_order),
    INDEX idx_critical (critical_path)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. PREDICTIVE MAINTENANCE TABLE
CREATE TABLE IF NOT EXISTS predictive_maintenance_inspections (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    asset_id INT UNSIGNED NOT NULL,
    inspection_type ENUM('vibration', 'temperature', 'oil_analysis', 'visual', 'ultrasonic') NOT NULL,
    reading_value DECIMAL(10,2) NULL,
    threshold_warning DECIMAL(10,2) NULL,
    threshold_critical DECIMAL(10,2) NULL,
    status ENUM('normal', 'warning', 'critical') NOT NULL,
    inspector_id INT UNSIGNED NOT NULL,
    inspection_date DATETIME NOT NULL,
    next_inspection_date DATE NULL,
    notes TEXT NULL,
    work_order_generated BOOLEAN DEFAULT FALSE,
    work_order_id INT UNSIGNED NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (asset_id) REFERENCES assets_unified(id),
    FOREIGN KEY (inspector_id) REFERENCES users(id),
    FOREIGN KEY (work_order_id) REFERENCES maintenance_orders(id),
    INDEX idx_status (status),
    INDEX idx_next_inspection (next_inspection_date),
    INDEX idx_asset (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. PM METER TRIGGERS TABLE
CREATE TABLE IF NOT EXISTS pm_meter_triggers (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    pm_schedule_id INT UNSIGNED NOT NULL,
    meter_id INT UNSIGNED NOT NULL,
    trigger_value INT NOT NULL,
    last_reading INT NULL,
    last_wo_generated_at DATETIME NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (pm_schedule_id) REFERENCES pm_schedules(id) ON DELETE CASCADE,
    INDEX idx_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. ENHANCE PM SCHEDULES TABLE
ALTER TABLE pm_schedules 
ADD COLUMN IF NOT EXISTS auto_generate_wo BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS lead_time_days INT DEFAULT 7,
ADD COLUMN IF NOT EXISTS last_generated_date DATE NULL,
ADD COLUMN IF NOT EXISTS next_due_date DATE NULL;

-- 13. INSERT DEFAULT SLA DEFINITIONS
INSERT INTO sla_definitions (name, priority, order_type, response_time_hours, resolution_time_hours, escalation_level_1_hours, escalation_level_2_hours, escalation_level_3_hours) VALUES
('Urgent Corrective', 'urgent', 'corrective', 1, 4, 2, 3, 4),
('High Corrective', 'high', 'corrective', 2, 8, 4, 6, 8),
('Medium Corrective', 'medium', 'corrective', 4, 24, 12, 18, 24),
('Low Corrective', 'low', 'corrective', 8, 48, 24, 36, 48),
('Urgent Emergency', 'urgent', 'emergency', 0.5, 2, 1, 1.5, 2),
('High Emergency', 'high', 'emergency', 1, 4, 2, 3, 4),
('Medium Preventive', 'medium', 'preventive', 24, 72, 48, 60, 72),
('Low Preventive', 'low', 'preventive', 48, 168, 96, 132, 168)
ON DUPLICATE KEY UPDATE name=name;

-- 14. INSERT MIGRATION RECORD
INSERT IGNORE INTO migrations (version, class, `group`, namespace, time, batch) 
VALUES 
('2025-01-29-000001', 'App\\Database\\Migrations\\EnterpriseMaintenanceUpgrade', 'default', 'App', UNIX_TIMESTAMP(), 
    (SELECT COALESCE(MAX(batch), 0) + 1 FROM (SELECT batch FROM migrations) AS temp));

-- VERIFICATION
SELECT 'Enterprise Maintenance Module Upgrade Complete!' AS Status;
SELECT COUNT(*) AS 'New Tables Created' FROM information_schema.tables 
WHERE table_schema = DATABASE() 
AND table_name IN (
    'work_order_team_members',
    'work_order_assistance_requests',
    'work_order_job_plans',
    'work_order_resource_reservations',
    'work_order_status_history',
    'sla_definitions',
    'work_order_sla_tracking',
    'shutdown_events',
    'shutdown_work_orders',
    'predictive_maintenance_inspections',
    'pm_meter_triggers'
);
```

---

## 📡 COMPLETE API ENDPOINT SPECIFICATION

### 1. TEAM MANAGEMENT API

#### WorkOrderTeamController.php

```php
<?php

namespace App\Controllers\Api\V1;

use CodeIgniter\RESTful\ResourceController;

class WorkOrderTeamController extends ResourceController
{
    protected $modelName = 'App\Models\WorkOrderTeamMemberModel';
    protected $format = 'json';

    /**
     * POST /api/v1/eam/work-orders/{id}/team/assign
     * Assign team to work order with designated lead
     */
    public function assignTeam($workOrderId)
    {
        $data = $this->request->getJSON(true);
        
        // Validate team lead
        if (empty($data['team_lead_id'])) {
            return $this->fail('Team lead is required');
        }
        
        $db = \Config\Database::connect();
        $db->transStart();
        
        // Assign team lead
        $this->model->insert([
            'work_order_id' => $workOrderId,
            'technician_id' => $data['team_lead_id'],
            'role' => 'team_lead',
            'assigned_date' => date('Y-m-d H:i:s'),
            'assigned_by' => $this->request->user_id,
            'status' => 'assigned'
        ]);
        
        // Assign assistants
        if (!empty($data['assistant_ids'])) {
            foreach ($data['assistant_ids'] as $techId) {
                $this->model->insert([
                    'work_order_id' => $workOrderId,
                    'technician_id' => $techId,
                    'role' => 'assistant',
                    'assigned_date' => date('Y-m-d H:i:s'),
                    'assigned_by' => $this->request->user_id,
                    'status' => 'assigned'
                ]);
            }
        }
        
        $db->transComplete();
        
        if ($db->transStatus() === false) {
            return $this->fail('Failed to assign team');
        }
        
        // Send notifications
        $this->sendTeamNotifications($workOrderId, $data['team_lead_id'], $data['assistant_ids'] ?? []);
        
        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Team assigned successfully'
        ]);
    }

    /**
     * GET /api/v1/eam/work-orders/{id}/team
     * Get team members for work order
     */
    public function getTeam($workOrderId)
    {
        $team = $this->model
            ->select('work_order_team_members.*, users.name, users.email')
            ->join('users', 'users.id = work_order_team_members.technician_id')
            ->where('work_order_id', $workOrderId)
            ->orderBy('role', 'ASC')
            ->findAll();
        
        $teamLead = array_filter($team, fn($m) => $m['role'] === 'team_lead');
        $assistants = array_filter($team, fn($m) => $m['role'] !== 'team_lead');
        
        return $this->respond([
            'status' => 'success',
            'data' => [
                'team_lead' => reset($teamLead) ?: null,
                'assistants' => array_values($assistants),
                'total_hours' => array_sum(array_column($team, 'labor_hours'))
            ]
        ]);
    }

    /**
     * POST /api/v1/eam/work-orders/{id}/team/add-member
     * Add member to existing team
     */
    public function addMember($workOrderId)
    {
        $data = $this->request->getJSON(true);
        
        $this->model->insert([
            'work_order_id' => $workOrderId,
            'technician_id' => $data['technician_id'],
            'role' => $data['role'] ?? 'assistant',
            'assigned_date' => date('Y-m-d H:i:s'),
            'assigned_by' => $this->request->user_id,
            'status' => 'assigned',
            'notes' => $data['reason'] ?? null
        ]);
        
        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Team member added'
        ]);
    }

    /**
     * DELETE /api/v1/eam/work-orders/{id}/team/remove-member/{techId}
     * Remove member from team
     */
    public function removeMember($workOrderId, $techId)
    {
        $member = $this->model
            ->where('work_order_id', $workOrderId)
            ->where('technician_id', $techId)
            ->first();
        
        if (!$member) {
            return $this->failNotFound('Team member not found');
        }
        
        if ($member['role'] === 'team_lead') {
            return $this->fail('Cannot remove team lead. Assign new lead first.');
        }
        
        $this->model->delete($member['id']);
        
        return $this->respondDeleted([
            'status' => 'success',
            'message' => 'Team member removed'
        ]);
    }

    /**
     * PUT /api/v1/eam/work-orders/{id}/team/change-lead
     * Change team lead
     */
    public function changeLead($workOrderId)
    {
        $data = $this->request->getJSON(true);
        
        $db = \Config\Database::connect();
        $db->transStart();
        
        // Demote current lead to assistant
        $this->model
            ->where('work_order_id', $workOrderId)
            ->where('role', 'team_lead')
            ->set(['role' => 'assistant'])
            ->update();
        
        // Promote new lead
        $this->model
            ->where('work_order_id', $workOrderId)
            ->where('technician_id', $data['new_lead_id'])
            ->set(['role' => 'team_lead'])
            ->update();
        
        $db->transComplete();
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Team lead changed'
        ]);
    }

    /**
     * POST /api/v1/eam/work-orders/{id}/team/accept
     * Team lead accepts assignment
     */
    public function acceptAssignment($workOrderId)
    {
        $userId = $this->request->user_id;
        
        $member = $this->model
            ->where('work_order_id', $workOrderId)
            ->where('technician_id', $userId)
            ->where('role', 'team_lead')
            ->first();
        
        if (!$member) {
            return $this->fail('You are not the team lead for this work order');
        }
        
        $this->model->update($member['id'], [
            'status' => 'accepted',
            'accepted_date' => date('Y-m-d H:i:s')
        ]);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Assignment accepted'
        ]);
    }

    private function sendTeamNotifications($workOrderId, $leadId, $assistantIds)
    {
        // Implementation for sending notifications
        $notificationService = service('notification');
        $notificationService->notifyTeamAssignment($workOrderId, $leadId, $assistantIds);
    }
}
```

### 2. ASSISTANCE REQUEST API

#### AssistanceRequestController.php

```php
<?php

namespace App\Controllers\Api\V1;

use CodeIgniter\RESTful\ResourceController;

class AssistanceRequestController extends ResourceController
{
    protected $modelName = 'App\Models\WorkOrderAssistanceRequestModel';
    protected $format = 'json';

    /**
     * POST /api/v1/eam/work-orders/{id}/assistance/request
     * Request assistance for work order
     */
    public function requestAssistance($workOrderId)
    {
        $data = $this->request->getJSON(true);
        
        $requestId = $this->model->insert([
            'work_order_id' => $workOrderId,
            'requested_by' => $this->request->user_id,
            'requested_at' => date('Y-m-d H:i:s'),
            'skill_required' => $data['skill_required'] ?? null,
            'reason' => $data['reason'],
            'urgency' => $data['urgency'] ?? 'medium',
            'status' => 'pending'
        ]);
        
        // Notify supervisor
        $this->notifySupervisor($workOrderId, $requestId);
        
        return $this->respondCreated([
            'status' => 'success',
            'message' => 'Assistance request submitted',
            'data' => ['id' => $requestId]
        ]);
    }

    /**
     * GET /api/v1/eam/assistance-requests/pending
     * Get pending assistance requests (for supervisors)
     */
    public function getPending()
    {
        $requests = $this->model
            ->select('work_order_assistance_requests.*, maintenance_orders.order_number, users.name as requested_by_name')
            ->join('maintenance_orders', 'maintenance_orders.id = work_order_assistance_requests.work_order_id')
            ->join('users', 'users.id = work_order_assistance_requests.requested_by')
            ->where('work_order_assistance_requests.status', 'pending')
            ->orderBy('urgency', 'DESC')
            ->orderBy('requested_at', 'ASC')
            ->findAll();
        
        return $this->respond([
            'status' => 'success',
            'data' => $requests
        ]);
    }

    /**
     * POST /api/v1/eam/assistance-requests/{id}/approve
     * Approve assistance request and assign technician
     */
    public function approve($id)
    {
        $data = $this->request->getJSON(true);
        
        $request = $this->model->find($id);
        if (!$request) {
            return $this->failNotFound('Request not found');
        }
        
        $db = \Config\Database::connect();
        $db->transStart();
        
        // Update request
        $this->model->update($id, [
            'status' => 'approved',
            'approved_by' => $this->request->user_id,
            'approved_at' => date('Y-m-d H:i:s'),
            'assigned_technician_id' => $data['assigned_technician_id']
        ]);
        
        // Add technician to team
        $teamModel = model('WorkOrderTeamMemberModel');
        $teamModel->insert([
            'work_order_id' => $request['work_order_id'],
            'technician_id' => $data['assigned_technician_id'],
            'role' => 'assistant',
            'assigned_date' => date('Y-m-d H:i:s'),
            'assigned_by' => $this->request->user_id,
            'status' => 'assigned',
            'notes' => 'Added via assistance request'
        ]);
        
        $db->transComplete();
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Assistance approved and technician assigned'
        ]);
    }

    /**
     * POST /api/v1/eam/assistance-requests/{id}/reject
     * Reject assistance request
     */
    public function reject($id)
    {
        $data = $this->request->getJSON(true);
        
        $this->model->update($id, [
            'status' => 'rejected',
            'approved_by' => $this->request->user_id,
            'approved_at' => date('Y-m-d H:i:s'),
            'rejection_reason' => $data['reason']
        ]);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Assistance request rejected'
        ]);
    }

    private function notifySupervisor($workOrderId, $requestId)
    {
        // Get work order supervisor
        $woModel = model('MaintenanceOrderModel');
        $wo = $woModel->find($workOrderId);
        
        if ($wo && $wo['supervisor_id']) {
            $notificationService = service('notification');
            $notificationService->notifyAssistanceRequest($wo['supervisor_id'], $requestId);
        }
    }
}
```

---

**PHASE 3 PART 1 COMPLETE**  
**Next**: Job Planning API, SLA API, and Models

*Prepared by: Senior EAM System Architect*  
*Date: January 2025*
