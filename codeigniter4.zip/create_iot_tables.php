<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// IoT Devices Table
$sql1 = "CREATE TABLE IF NOT EXISTS iot_devices (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(100) UNIQUE,
    asset_id INT UNSIGNED,
    device_type VARCHAR(50),
    status ENUM('active','inactive','error') DEFAULT 'active',
    last_seen DATETIME NULL,
    config JSON NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    KEY asset_id (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// IoT Metrics Table
$sql2 = "CREATE TABLE IF NOT EXISTS iot_metrics (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id VARCHAR(100),
    asset_id INT UNSIGNED,
    metric_type VARCHAR(50),
    value DECIMAL(10,2),
    timestamp DATETIME,
    KEY asset_timestamp (asset_id, timestamp),
    KEY metric_timestamp (metric_type, timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// IoT Alerts Table
$sql3 = "CREATE TABLE IF NOT EXISTS iot_alerts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED,
    metric_type VARCHAR(50),
    value DECIMAL(10,2),
    threshold DECIMAL(10,2),
    severity ENUM('warning','critical') DEFAULT 'warning',
    acknowledged TINYINT(1) DEFAULT 0,
    acknowledged_at DATETIME NULL,
    acknowledged_by INT UNSIGNED NULL,
    created_at DATETIME,
    KEY asset_id (asset_id),
    KEY acknowledged (acknowledged)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql1) === TRUE) {
    echo "iot_devices table created successfully\n";
} else {
    echo "Error creating iot_devices: " . $conn->error . "\n";
}

if ($conn->query($sql2) === TRUE) {
    echo "iot_metrics table created successfully\n";
} else {
    echo "Error creating iot_metrics: " . $conn->error . "\n";
}

if ($conn->query($sql3) === TRUE) {
    echo "iot_alerts table created successfully\n";
} else {
    echo "Error creating iot_alerts: " . $conn->error . "\n";
}

$conn->close();
echo "\nAll IoT tables created successfully!\n";
