<?php

// Add missing last_login column to users table
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔧 Adding last_login column to users table...\n";
    
    $sql = "ALTER TABLE users ADD COLUMN last_login DATETIME NULL AFTER password";
    $pdo->exec($sql);
    
    echo "✅ Column added successfully\n";
    
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "✅ Column already exists\n";
    } else {
        echo "❌ Database Error: " . $e->getMessage() . "\n";
    }
}