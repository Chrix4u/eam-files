<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to database successfully!\n\n";
    
    // Check inventory_items table
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM inventory_items");
    $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    echo "inventory_items table has $count records\n\n";
    
    if ($count > 0) {
        echo "First 5 records:\n";
        $stmt = $pdo->query("SELECT id, item_name, item_code, quantity_on_hand FROM inventory_items LIMIT 5");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "ID: {$row['id']}, Name: {$row['item_name']}, Code: {$row['item_code']}, Qty: {$row['quantity_on_hand']}\n";
        }
    } else {
        echo "Table is EMPTY! No inventory items found.\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
