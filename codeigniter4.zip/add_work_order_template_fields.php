<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

echo "Adding work order template fields...\n";

// Check and add planner section fields one by one
$fields = [
    "maintenance_order_code VARCHAR(50) NULL AFTER work_order_number",
    "work_order_type ENUM('breakdown', 'preventive', 'corrective', 'other') DEFAULT 'corrective' AFTER type",
    "technical_description TEXT NULL AFTER description",
    "trade_activity VARCHAR(100) NULL",
    "assigned_by INT UNSIGNED NULL",
    "planner_id INT UNSIGNED NULL",
    "delivery_date_required DATE NULL",
    "date_sent DATETIME NULL",
    "time_sent TIME NULL",
    "is_breakdown TINYINT(1) DEFAULT 0",
    "received_by_engineering DATETIME NULL",
    "completed_by_engineering DATETIME NULL",
    "total_downtime_hours DECIMAL(10,2) NULL",
    "repair_started DATETIME NULL",
    "repair_ended DATETIME NULL",
    "technician_remarks TEXT NULL",
    "technician_brief_report TEXT NULL",
    "failure_description TEXT NULL",
    "cause_description TEXT NULL",
    "action_description TEXT NULL",
    "general_remarks TEXT NULL",
    "operator_signature VARCHAR(255) NULL",
    "line_manager_signature VARCHAR(255) NULL",
    "supervisor_signature VARCHAR(255) NULL",
    "operator_signed_at DATETIME NULL",
    "line_manager_signed_at DATETIME NULL",
    "supervisor_signed_at DATETIME NULL"
];

foreach ($fields as $field) {
    $columnName = explode(' ', $field)[0];
    $result = $mysqli->query("SHOW COLUMNS FROM work_orders LIKE '$columnName'");
    if ($result->num_rows == 0) {
        $mysqli->query("ALTER TABLE work_orders ADD COLUMN $field");
        echo "Added $columnName\n";
    } else {
        echo "$columnName already exists\n";
    }
}

echo "All fields processed!\n";

$mysqli->close();
echo "\nMigration completed successfully!\n";
