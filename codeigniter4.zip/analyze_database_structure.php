<?php
/**
 * Database Structure Analyzer
 * Analyzes current database tables and generates migration files
 */

// Database connection - Update these values if needed
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to database: $database\n\n";
    
    // Get all tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    // Focus on maintenance work order related tables
    $workOrderTables = array_filter($tables, function($table) {
        return stripos($table, 'work_order') !== false || 
               stripos($table, 'maintenance') !== false ||
               stripos($table, 'labor') !== false ||
               stripos($table, 'user') !== false ||
               stripos($table, 'department') !== false ||
               stripos($table, 'skill') !== false;
    });
    
    $outputDir = __DIR__ . '/database_structure_analysis';
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0777, true);
    }
    
    $allStructures = [];
    
    foreach ($workOrderTables as $table) {
        echo "Analyzing table: $table\n";
        
        // Get table structure
        $columns = $pdo->query("SHOW FULL COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        
        // Get indexes
        $indexes = $pdo->query("SHOW INDEX FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        
        // Get foreign keys
        $foreignKeys = $pdo->query("
            SELECT 
                CONSTRAINT_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = '$database'
            AND TABLE_NAME = '$table'
            AND REFERENCED_TABLE_NAME IS NOT NULL
        ")->fetchAll(PDO::FETCH_ASSOC);
        
        // Get table comment
        $tableInfo = $pdo->query("
            SELECT TABLE_COMMENT 
            FROM information_schema.TABLES 
            WHERE TABLE_SCHEMA = '$database' 
            AND TABLE_NAME = '$table'
        ")->fetch(PDO::FETCH_ASSOC);
        
        $allStructures[$table] = [
            'columns' => $columns,
            'indexes' => $indexes,
            'foreign_keys' => $foreignKeys,
            'comment' => $tableInfo['TABLE_COMMENT'] ?? ''
        ];
        
        // Generate migration file content
        $migrationContent = generateMigrationFile($table, $allStructures[$table]);
        
        // Save migration file
        $filename = $outputDir . '/' . date('Y-m-d_His') . '_' . ucfirst($table) . '.php';
        file_put_contents($filename, $migrationContent);
    }
    
    // Generate comprehensive summary
    $summary = generateSummary($allStructures);
    file_put_contents($outputDir . '/DATABASE_STRUCTURE_SUMMARY.md', $summary);
    
    echo "\n✅ Analysis complete! Files saved to: $outputDir\n";
    
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage() . "\n");
}

function generateMigrationFile($tableName, $structure) {
    $className = 'Create' . str_replace('_', '', ucwords($tableName, '_')) . 'Table';
    $timestamp = date('Y-m-d-His');
    
    $content = "<?php\n\nnamespace App\\Database\\Migrations;\n\n";
    $content .= "use CodeIgniter\\Database\\Migration;\n\n";
    $content .= "/**\n * Migration: $className\n * Generated from actual database structure\n";
    $content .= " * Date: " . date('Y-m-d H:i:s') . "\n */\n";
    $content .= "class $className extends Migration\n{\n";
    $content .= "    public function up()\n    {\n";
    $content .= "        \$this->forge->addField([\n";
    
    foreach ($structure['columns'] as $column) {
        $content .= "            '{$column['Field']}' => [\n";
        $content .= "                'type' => '" . parseType($column['Type']) . "',\n";
        
        if (preg_match('/\((\d+)\)/', $column['Type'], $matches)) {
            $content .= "                'constraint' => {$matches[1]},\n";
        }
        
        if ($column['Null'] === 'YES') {
            $content .= "                'null' => true,\n";
        }
        
        if ($column['Default'] !== null) {
            $default = $column['Default'];
            if ($default === 'CURRENT_TIMESTAMP') {
                $content .= "                'default' => 'CURRENT_TIMESTAMP',\n";
            } else {
                $content .= "                'default' => '$default',\n";
            }
        }
        
        if ($column['Extra'] === 'auto_increment') {
            $content .= "                'auto_increment' => true,\n";
        }
        
        if ($column['Comment']) {
            $content .= "                'comment' => '" . addslashes($column['Comment']) . "',\n";
        }
        
        $content .= "            ],\n";
    }
    
    $content .= "        ]);\n\n";
    
    // Add primary key
    $primaryKeys = array_filter($structure['indexes'], function($idx) {
        return $idx['Key_name'] === 'PRIMARY';
    });
    if (!empty($primaryKeys)) {
        $pkColumn = reset($primaryKeys)['Column_name'];
        $content .= "        \$this->forge->addKey('$pkColumn', true);\n";
    }
    
    // Add other indexes
    $otherIndexes = array_filter($structure['indexes'], function($idx) {
        return $idx['Key_name'] !== 'PRIMARY';
    });
    $indexGroups = [];
    foreach ($otherIndexes as $idx) {
        $indexGroups[$idx['Key_name']][] = $idx['Column_name'];
    }
    foreach ($indexGroups as $indexName => $columns) {
        $columnsStr = "'" . implode("', '", $columns) . "'";
        $content .= "        \$this->forge->addKey([$columnsStr]);\n";
    }
    
    $content .= "\n        \$this->forge->createTable('$tableName', true);\n";
    $content .= "    }\n\n";
    $content .= "    public function down()\n    {\n";
    $content .= "        \$this->forge->dropTable('$tableName', true);\n";
    $content .= "    }\n";
    $content .= "}\n";
    
    return $content;
}

function parseType($mysqlType) {
    $type = strtoupper(preg_replace('/\(.*\)/', '', $mysqlType));
    
    $typeMap = [
        'INT' => 'INT',
        'BIGINT' => 'BIGINT',
        'TINYINT' => 'TINYINT',
        'SMALLINT' => 'SMALLINT',
        'VARCHAR' => 'VARCHAR',
        'TEXT' => 'TEXT',
        'LONGTEXT' => 'LONGTEXT',
        'MEDIUMTEXT' => 'MEDIUMTEXT',
        'DATETIME' => 'DATETIME',
        'TIMESTAMP' => 'TIMESTAMP',
        'DATE' => 'DATE',
        'TIME' => 'TIME',
        'DECIMAL' => 'DECIMAL',
        'FLOAT' => 'FLOAT',
        'DOUBLE' => 'DOUBLE',
        'ENUM' => 'ENUM',
        'JSON' => 'JSON',
    ];
    
    return $typeMap[$type] ?? 'VARCHAR';
}

function generateSummary($structures) {
    $summary = "# Database Structure Analysis\n\n";
    $summary .= "**Generated:** " . date('Y-m-d H:i:s') . "\n\n";
    $summary .= "## Maintenance Work Order System Tables\n\n";
    
    foreach ($structures as $tableName => $structure) {
        $summary .= "### Table: `$tableName`\n\n";
        
        if ($structure['comment']) {
            $summary .= "**Description:** {$structure['comment']}\n\n";
        }
        
        $summary .= "**Columns:**\n\n";
        $summary .= "| Column | Type | Null | Default | Extra | Comment |\n";
        $summary .= "|--------|------|------|---------|-------|----------|\n";
        
        foreach ($structure['columns'] as $col) {
            $summary .= "| {$col['Field']} | {$col['Type']} | {$col['Null']} | ";
            $summary .= ($col['Default'] ?? 'NULL') . " | {$col['Extra']} | ";
            $summary .= ($col['Comment'] ?? '') . " |\n";
        }
        
        if (!empty($structure['foreign_keys'])) {
            $summary .= "\n**Foreign Keys:**\n\n";
            foreach ($structure['foreign_keys'] as $fk) {
                $summary .= "- `{$fk['COLUMN_NAME']}` → `{$fk['REFERENCED_TABLE_NAME']}.{$fk['REFERENCED_COLUMN_NAME']}`\n";
            }
        }
        
        $summary .= "\n---\n\n";
    }
    
    return $summary;
}
