# Proposed Final Folder Structure

```
factorymanager/
├── app/
│   ├── Commands/
│   │   └── PmScheduler.php                    # Cron job for PM scheduling
│   │
│   ├── Config/
│   │   ├── App.php
│   │   ├── Database.php
│   │   ├── Filters.php                        # Register all filters
│   │   ├── Routes.php                         # Main routes (redirect to API)
│   │   ├── RoutesApi.php                      # API v1 routes
│   │   └── Services.php
│   │
│   ├── Controllers/
│   │   └── Api/
│   │       └── V1/
│   │           ├── AuthController.php         # Login, logout, refresh
│   │           ├── FacilitiesController.php   # Facilities CRUD
│   │           ├── SystemsController.php      # Systems CRUD
│   │           ├── EquipmentController.php    # Equipment CRUD
│   │           ├── AssembliesController.php   # Assemblies CRUD
│   │           ├── ComponentsController.php   # Components CRUD
│   │           ├── PartsController.php        # Parts CRUD
│   │           ├── MetersController.php       # Meters CRUD + readings
│   │           ├── PmRulesController.php      # PM rules CRUD
│   │           ├── PmSchedulesController.php  # PM schedules view/generate
│   │           ├── WorkOrdersController.php   # Work orders CRUD + actions
│   │           ├── InventoryController.php    # Inventory CRUD + stock ops
│   │           ├── VendorsController.php      # Vendors CRUD
│   │           ├── PurchaseOrdersController.php # PO CRUD + actions
│   │           ├── UsersController.php        # Users CRUD + role assign
│   │           ├── RolesController.php        # Roles CRUD + permissions
│   │           ├── ReportsController.php      # Reports generation
│   │           ├── NotificationsController.php # Notifications
│   │           ├── AuditLogsController.php    # Audit trail
│   │           └── HealthController.php       # Health check
│   │
│   ├── Database/
│   │   ├── Migrations/
│   │   │   ├── 2025-11-14-000001_CreateFacilities.php
│   │   │   ├── 2025-11-14-000002_CreateSystems.php
│   │   │   ├── 2025-11-14-000003_CreateEquipment.php
│   │   │   ├── 2025-11-14-000004_CreateAssemblies.php
│   │   │   ├── 2025-11-14-000005_CreateComponents.php
│   │   │   ├── 2025-11-14-000006_CreateParts.php
│   │   │   ├── 2025-11-14-000007_CreateMeters.php
│   │   │   ├── 2025-11-14-000008_CreateMeterReadings.php
│   │   │   ├── 2025-11-14-000009_CreatePmRules.php
│   │   │   ├── 2025-11-14-000010_CreatePmSchedules.php
│   │   │   ├── 2025-11-14-000011_CreateWorkOrders.php
│   │   │   ├── 2025-11-14-000012_CreateWorkOrderTasks.php
│   │   │   ├── 2025-11-14-000013_CreateInventoryItems.php
│   │   │   ├── 2025-11-14-000014_CreateStockTransactions.php
│   │   │   ├── 2025-11-14-000015_CreateVendors.php
│   │   │   ├── 2025-11-14-000016_CreatePurchaseOrders.php
│   │   │   ├── 2025-11-14-000017_CreateUsers.php
│   │   │   ├── 2025-11-14-000018_CreateRoles.php
│   │   │   ├── 2025-11-14-000019_CreatePermissions.php
│   │   │   ├── 2025-11-14-000020_CreateUserRoles.php
│   │   │   ├── 2025-11-14-000021_CreateRolePermissions.php
│   │   │   ├── 2025-11-14-000022_CreateAuditLogs.php
│   │   │   └── 2025-11-14-000023_AddIndexes.php
│   │   │
│   │   └── Seeds/
│   │       ├── RolesSeeder.php
│   │       ├── PermissionsSeeder.php
│   │       ├── AdminUserSeeder.php
│   │       └── TestDataSeeder.php
│   │
│   ├── Entities/
│   │   ├── Facility.php
│   │   ├── System.php
│   │   ├── Equipment.php
│   │   ├── Assembly.php
│   │   ├── Component.php
│   │   ├── Part.php
│   │   ├── Meter.php
│   │   ├── MeterReading.php
│   │   ├── PmRule.php
│   │   ├── PmSchedule.php
│   │   ├── WorkOrder.php
│   │   ├── WorkOrderTask.php
│   │   ├── InventoryItem.php
│   │   ├── StockTransaction.php
│   │   ├── Vendor.php
│   │   ├── PurchaseOrder.php
│   │   ├── User.php
│   │   ├── Role.php
│   │   └── Permission.php
│   │
│   ├── Exceptions/
│   │   ├── ApiException.php
│   │   ├── ValidationException.php
│   │   ├── NotFoundException.php
│   │   ├── UnauthorizedException.php
│   │   └── ForbiddenException.php
│   │
│   ├── Filters/
│   │   ├── JwtAuthFilter.php                  # JWT authentication
│   │   ├── PermissionFilter.php               # RBAC authorization
│   │   ├── RateLimitFilter.php                # Rate limiting
│   │   ├── CorsFilter.php                     # CORS handling
│   │   └── LoggingFilter.php                  # Request/response logging
│   │
│   ├── Helpers/
│   │   ├── api_response_helper.php            # Standardized responses
│   │   ├── permission_helper.php              # Permission checks
│   │   └── date_helper.php                    # Date utilities
│   │
│   ├── Libraries/
│   │   ├── JWT/
│   │   │   └── JWTHandler.php                 # JWT token management
│   │   ├── Cache/
│   │   │   └── CacheManager.php               # Redis cache wrapper
│   │   └── Logger/
│   │       └── ApiLogger.php                  # Structured logging
│   │
│   ├── Models/
│   │   ├── FacilityModel.php
│   │   ├── SystemModel.php
│   │   ├── EquipmentModel.php
│   │   ├── AssemblyModel.php
│   │   ├── ComponentModel.php
│   │   ├── PartModel.php
│   │   ├── MeterModel.php
│   │   ├── MeterReadingModel.php
│   │   ├── PmRuleModel.php
│   │   ├── PmScheduleModel.php
│   │   ├── WorkOrderModel.php
│   │   ├── WorkOrderTaskModel.php
│   │   ├── InventoryItemModel.php
│   │   ├── StockTransactionModel.php
│   │   ├── VendorModel.php
│   │   ├── PurchaseOrderModel.php
│   │   ├── UserModel.php
│   │   ├── RoleModel.php
│   │   ├── PermissionModel.php
│   │   └── AuditLogModel.php
│   │
│   ├── Repositories/
│   │   ├── BaseRepository.php                 # Base CRUD operations
│   │   ├── FacilityRepository.php
│   │   ├── SystemRepository.php
│   │   ├── EquipmentRepository.php
│   │   ├── AssemblyRepository.php
│   │   ├── ComponentRepository.php
│   │   ├── PartRepository.php
│   │   ├── MeterRepository.php
│   │   ├── PmRepository.php
│   │   ├── WorkOrderRepository.php
│   │   ├── InventoryRepository.php
│   │   ├── VendorRepository.php
│   │   ├── PurchaseOrderRepository.php
│   │   ├── UserRepository.php
│   │   ├── RoleRepository.php
│   │   └── AuditLogRepository.php
│   │
│   ├── Services/
│   │   ├── AuthService.php                    # Authentication logic
│   │   ├── FacilityService.php                # Business logic
│   │   ├── SystemService.php
│   │   ├── EquipmentService.php
│   │   ├── AssemblyService.php
│   │   ├── ComponentService.php
│   │   ├── PartService.php
│   │   ├── MeterService.php
│   │   ├── PmSchedulingEngine.php             # PM scheduling algorithm
│   │   ├── PmService.php
│   │   ├── WorkOrderService.php
│   │   ├── InventoryService.php
│   │   ├── VendorService.php
│   │   ├── PurchaseOrderService.php
│   │   ├── UserService.php
│   │   ├── RoleService.php
│   │   ├── NotificationService.php
│   │   ├── ReportService.php
│   │   └── AuditService.php
│   │
│   ├── Traits/
│   │   ├── ApiResponseTrait.php               # Response formatting
│   │   ├── QueryBuilderTrait.php              # Filtering/sorting/pagination
│   │   └── AuditableTrait.php                 # Audit logging
│   │
│   └── Validation/
│       ├── FacilityRules.php
│       ├── EquipmentRules.php
│       ├── WorkOrderRules.php
│       ├── InventoryRules.php
│       ├── UserRules.php
│       └── AuthRules.php
│
├── public/
│   ├── .htaccess
│   ├── index.php
│   └── favicon.ico
│
├── tests/
│   ├── Unit/
│   │   ├── Services/
│   │   │   ├── AuthServiceTest.php
│   │   │   ├── FacilityServiceTest.php
│   │   │   ├── WorkOrderServiceTest.php
│   │   │   └── PmSchedulingEngineTest.php
│   │   └── Repositories/
│   │       ├── FacilityRepositoryTest.php
│   │       └── WorkOrderRepositoryTest.php
│   │
│   └── Integration/
│       ├── Api/
│       │   ├── AuthTest.php
│       │   ├── FacilitiesTest.php
│       │   ├── WorkOrdersTest.php
│       │   └── InventoryTest.php
│       └── Database/
│           └── MigrationTest.php
│
├── writable/
│   ├── cache/
│   ├── logs/
│   ├── session/
│   └── uploads/
│
├── .env                                        # Environment config
├── .env.example                                # Example config
├── .gitignore
├── composer.json
├── composer.lock
├── openapi.yaml                                # API documentation
├── README.md
└── spark                                       # CLI tool
```

## Key Changes from Current Structure

### ✅ Removed
- `app/Views/` - All UI code
- `app/Controllers/Admin/`, `Manager/`, etc. - Dashboard controllers
- Legacy controllers: Admin.php, Analytics.php, Assembly.php, Auth.php, Machine.php, etc.
- `app/Controllers/Api/V1/BaseApiController.php` - Merged into trait

### ✅ Added
- `app/Exceptions/` - Custom exception classes
- `app/Validation/` - Validation rules
- `app/Traits/QueryBuilderTrait.php` - Reusable query logic
- `app/Libraries/Cache/` - Caching layer
- `app/Libraries/Logger/` - Structured logging
- Comprehensive test structure

### ✅ Reorganized
- All API controllers under `Api/V1/`
- Consistent naming (removed "Eam" prefix)
- Separated concerns (validation, exceptions, traits)

## File Naming Conventions

- **Controllers:** `{Resource}Controller.php` (plural)
- **Services:** `{Resource}Service.php` (singular)
- **Repositories:** `{Resource}Repository.php` (singular)
- **Models:** `{Resource}Model.php` (singular)
- **Entities:** `{Resource}.php` (singular)
- **Tests:** `{Class}Test.php`

## API Endpoint Structure

```
/api/v1/
├── /auth
│   ├── POST /login
│   ├── POST /logout
│   └── POST /refresh
├── /facilities
├── /systems
├── /equipment
├── /assemblies
├── /components
├── /parts
├── /meters
├── /pm-rules
├── /pm-schedules
├── /work-orders
├── /inventory
├── /vendors
├── /purchase-orders
├── /users
├── /roles
├── /reports
├── /notifications
├── /audit-logs
└── /health
```

All resources follow RESTful conventions:
- GET /{resource} - List
- POST /{resource} - Create
- GET /{resource}/{id} - Show
- PUT /{resource}/{id} - Update
- DELETE /{resource}/{id} - Delete
