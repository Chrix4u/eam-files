<?php
$host = 'localhost';
$dbname = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$db = new mysqli($host, $user, $pass, $dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "All tables in factory_manager database:\n";
echo str_repeat("=", 80) . "\n\n";

$result = $db->query("SHOW TABLES");

$tables = [];
while ($row = $result->fetch_array()) {
    $tables[] = $row[0];
}

sort($tables);

foreach ($tables as $table) {
    // Get record count
    $countResult = $db->query("SELECT COUNT(*) as count FROM `{$table}`");
    $count = $countResult->fetch_assoc()['count'];
    
    echo sprintf("%-40s %10s records\n", $table, number_format($count));
}

echo "\nTotal tables: " . count($tables) . "\n";

$db->close();
