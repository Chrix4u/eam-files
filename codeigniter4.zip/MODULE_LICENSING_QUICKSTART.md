# Module Licensing System - Quick Start Guide

## 🚀 5-Minute Setup

### Step 1: Database Setup (1 min)
```bash
cd c:\wamp64\www\factorymanager
php spark migrate
php spark db:seed ModuleLicensingSeeder
```

### Step 2: Environment Config (1 min)
Already added to `.env`:
```env
LICENSE_ENCRYPTION_KEY=iFactory-EAM-2025-SecureKey-32
LICENSE_GRACE_PERIOD_DAYS=30
LICENSE_CHECK_ENABLED=true
LICENSE_SUPER_ADMIN_ROLE=super_admin
```

### Step 3: Verify Backend (1 min)
```bash
curl http://localhost/factorymanager/public/index.php/api/v1/eam/licenses/system-modules
# Should return 401 (auth required) - Route works!
```

### Step 4: Start Frontend (1 min)
```bash
cd c:\devs\factorymanager
npm run dev
```

### Step 5: Access Pages (1 min)
- System Modules: http://localhost:3000/admin/system/modules
- Company Modules: http://localhost:3000/admin/company/modules

---

## ✅ What's Working

### Backend
- ✅ 4 database tables with 12 modules
- ✅ 8 API endpoints
- ✅ Automatic route protection
- ✅ License key encryption
- ✅ Audit logging

### Frontend
- ✅ System admin page
- ✅ Company admin page
- ✅ Status badges
- ✅ Expiry warnings

---

## 🎯 Quick Test

### Test 1: View Modules
```bash
# Login first to get token
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Use token to get modules
curl http://localhost/factorymanager/public/index.php/api/v1/eam/licenses/system-modules \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Test 2: Enable Module
```bash
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/licenses/system-modules/HRMS/enable \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"valid_until":"2026-12-31","license_type":"subscription"}'
```

### Test 3: Activate for Company
```bash
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/licenses/company-modules/HRMS/activate \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"company_id":1,"user_id":1,"valid_until":"2026-12-31"}'
```

---

## 📊 Current Status

### Licensed Modules (9)
- ✅ CORE (Always enabled)
- ✅ ASSET
- ✅ RWOP
- ✅ MRMP
- ✅ IMS
- ✅ MPMP
- ✅ TRAC
- ✅ IOT
- ✅ REPORTS

### Not Licensed (3)
- ❌ HRMS
- ❌ DIGITAL_TWIN
- ❌ MOBILE

---

## 🔧 Common Tasks

### Disable License Checking (Dev Mode)
```env
LICENSE_CHECK_ENABLED=false
```

### Check Database
```sql
SELECT module_code, module_name, is_system_licensed 
FROM system_modules;

SELECT company_id, module_code, is_active, valid_until 
FROM company_module_licenses;
```

### View Access Logs
```sql
SELECT * FROM module_usage_logs 
ORDER BY created_at DESC 
LIMIT 20;
```

---

## 🎉 You're Done!

The system is fully operational. Access the admin pages to manage licenses.

**Need help?** Check MODULE_LICENSING_COMPLETE.md for full documentation.
