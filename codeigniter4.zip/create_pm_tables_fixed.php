<?php

// Create PM tables directly
$host = 'localhost';
$dbname = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Creating PM tables...\n";
    
    // PM Templates
    $pdo->exec("CREATE TABLE IF NOT EXISTS pm_templates (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(50) UNIQUE,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        asset_node_type ENUM('machine', 'assembly', 'part', 'subpart') NOT NULL,
        asset_node_id INT NOT NULL,
        maintenance_type ENUM('inspection', 'lubrication', 'replace', 'clean', 'calibration', 'other') NOT NULL,
        priority ENUM('low', 'medium', 'high', 'critical') NOT NULL,
        estimated_hours DECIMAL(5,2) NOT NULL,
        active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
    
    // PM Triggers
    $pdo->exec("CREATE TABLE IF NOT EXISTS pm_triggers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pm_template_id INT NOT NULL,
        trigger_type ENUM('time', 'usage', 'production', 'event') NOT NULL,
        period_days INT NULL,
        usage_meter_id INT NULL,
        usage_threshold INT NULL,
        production_metric VARCHAR(100) NULL,
        event_name VARCHAR(100) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE
    )");
    
    // PM Checklists
    $pdo->exec("CREATE TABLE IF NOT EXISTS pm_checklists (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pm_template_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        sequence INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE
    )");
    
    // PM Checklist Items
    $pdo->exec("CREATE TABLE IF NOT EXISTS pm_checklist_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pm_checklist_id INT NOT NULL,
        item_text TEXT NOT NULL,
        item_type ENUM('yesno', 'passfail', 'numeric', 'text', 'photo') NOT NULL,
        required BOOLEAN DEFAULT FALSE,
        sequence INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pm_checklist_id) REFERENCES pm_checklists(id) ON DELETE CASCADE
    )");
    
    // PM Schedules
    $pdo->exec("CREATE TABLE IF NOT EXISTS pm_schedules (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pm_template_id INT NOT NULL,
        next_due_date DATE NULL,
        next_due_usage INT NULL,
        status ENUM('waiting', 'generated', 'assigned', 'in_progress', 'completed', 'closed', 'overdue') DEFAULT 'waiting',
        generated_work_order_id INT NULL,
        last_completed_at TIMESTAMP NULL,
        last_generated_at TIMESTAMP NULL,
        created_usage_snapshot INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (pm_template_id) REFERENCES pm_templates(id) ON DELETE CASCADE
    )");
    
    // PM History
    $pdo->exec("CREATE TABLE IF NOT EXISTS pm_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        pm_schedule_id INT NOT NULL,
        action ENUM('generated', 'assigned', 'started', 'completed', 'rescheduled') NOT NULL,
        comment TEXT NULL,
        performed_by INT NULL,
        performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pm_schedule_id) REFERENCES pm_schedules(id) ON DELETE CASCADE
    )");
    
    // Work Orders table (if not exists)
    $pdo->exec("CREATE TABLE IF NOT EXISTS work_orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        wo_number VARCHAR(50) UNIQUE NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        type ENUM('corrective', 'preventive', 'emergency') DEFAULT 'preventive',
        priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
        status ENUM('draft', 'assigned', 'in_progress', 'completed', 'closed') DEFAULT 'assigned',
        pm_schedule_id INT NULL,
        asset_id INT NULL,
        assigned_user_id INT NULL,
        requested_by INT NULL,
        estimated_hours DECIMAL(5,2) NULL,
        actual_hours DECIMAL(5,2) NULL,
        planned_start DATETIME NULL,
        planned_end DATETIME NULL,
        actual_start DATETIME NULL,
        actual_end DATETIME NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (pm_schedule_id) REFERENCES pm_schedules(id) ON DELETE SET NULL
    )");
    
    echo "✅ All PM tables created successfully!\n";
    
    // Insert sample data
    echo "\nInserting sample data...\n";
    
    $pdo->exec("INSERT IGNORE INTO pm_templates (id, title, description, asset_node_type, asset_node_id, maintenance_type, priority, estimated_hours) VALUES 
        (1, 'Monthly Safety Inspection', 'Check safety guards and interlocks', 'machine', 1, 'inspection', 'high', 2.0),
        (2, 'Quarterly Lubrication', 'Lubricate all bearings and moving parts', 'machine', 1, 'lubrication', 'medium', 1.5)");
    
    $pdo->exec("INSERT IGNORE INTO pm_triggers (pm_template_id, trigger_type, period_days) VALUES 
        (1, 'time', 30),
        (2, 'time', 90)");
    
    echo "✅ Sample data inserted!\n";
    
} catch(PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>