<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();

echo "=== Current Users ===\n";
$users = $db->table('users')
    ->select('id, username, role, department_id, supervisor_id')
    ->get()
    ->getResultArray();

foreach ($users as $user) {
    echo sprintf(
        "ID: %d | User: %s | Role: %s | Dept: %s | Supervisor: %s\n",
        $user['id'],
        $user['username'],
        $user['role'],
        $user['department_id'] ?? 'NULL',
        $user['supervisor_id'] ?? 'NULL'
    );
}

echo "\n=== Departments ===\n";
$depts = $db->table('departments')
    ->select('id, department_name')
    ->get()
    ->getResultArray();

foreach ($depts as $dept) {
    echo sprintf("ID: %d | Name: %s\n", $dept['id'], $dept['department_name']);
}
