# CORS Quick Start Guide

## ✅ What Was Done

1. ✅ Created `app/Filters/CORS.php` - Handles all CORS headers and OPTIONS requests
2. ✅ Updated `app/Config/Filters.php` - Registered CORS filter globally
3. ✅ Updated `public/.htaccess` - Added Apache CORS headers
4. ✅ Removed old `CorsFilter.php` - Cleaned up duplicate filter

## 🚀 Quick Setup (3 Steps)

### Step 1: Enable Apache mod_headers
1. Click WAMP icon in system tray
2. Go to: **Apache → Apache modules**
3. Check: ☑ **headers_module**
4. Check: ☑ **rewrite_module** (should already be checked)

### Step 2: Restart Apache
- Click WAMP icon → **Restart All Services**

### Step 3: Test CORS
Open: `http://localhost:3000` (your Next.js app)

Try creating a department - it should work now!

## 🧪 Quick Test

### Browser Console Test
```javascript
fetch('http://localhost/factorymanager/public/api/v1/eam/departments')
  .then(r => r.json())
  .then(d => console.log('✅ CORS Works:', d))
  .catch(e => console.error('❌ Failed:', e));
```

### Expected Result
```
✅ CORS Works: {status: "success", data: [...]}
```

## ✅ Validation

Check Network tab in DevTools:

**OPTIONS Request (Preflight):**
- Status: `200 OK` ✅
- Headers include: `Access-Control-Allow-Origin: http://localhost:3000` ✅

**GET/POST Request:**
- Status: `200 OK` ✅
- Headers include: `Access-Control-Allow-Origin: http://localhost:3000` ✅
- Data received successfully ✅

## 🔧 If Still Not Working

### 1. Clear Browser Cache
Press: `Ctrl + Shift + R` (hard refresh)

### 2. Check Apache Error Log
Location: `C:\wamp64\logs\apache_error.log`

### 3. Verify mod_headers is Active
Create test file: `C:\wamp64\www\test.php`
```php
<?php
header('X-Test: Working');
echo 'Test';
```
Visit: `http://localhost/test.php`
Check response headers for `X-Test: Working`

### 4. Restart Everything
1. Stop WAMP
2. Close all browsers
3. Start WAMP
4. Open browser
5. Test again

## 📝 Files Modified

```
Backend (CodeIgniter 4):
├── app/Filters/CORS.php (NEW)
├── app/Config/Filters.php (UPDATED)
└── public/.htaccess (UPDATED)

Frontend (Next.js):
└── No changes needed - CORS is server-side only
```

## ✅ Success Indicators

- ✅ No CORS errors in browser console
- ✅ Department creation works
- ✅ All API calls from localhost:3000 succeed
- ✅ OPTIONS requests return 200 OK
- ✅ Postman still works normally

---

**That's it! CORS is now fully configured.**

If you see ✅ in all checks above, you're done!
