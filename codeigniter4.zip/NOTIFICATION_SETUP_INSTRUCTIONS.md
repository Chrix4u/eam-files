# Notification System Setup

## Quick Setup (1 minute)

### Step 1: Run Setup Script
Open your browser and visit:
```
http://localhost/factorymanager/public/setup_notifications.php
```

This will:
- ✅ Create the notifications table
- ✅ Insert 3 sample notifications for testing

### Step 2: Test the Notification Bell
1. Refresh your shifts page: `http://localhost:3000/admin/shifts`
2. You should see the notification bell with a badge showing "2" unread notifications
3. Click the bell to see the dropdown with notifications

### Step 3: Done! 🎉
The notification system is now working!

---

## What Was Implemented

### Backend (CodeIgniter)
- ✅ NotificationService with database methods
- ✅ NotificationsController with all endpoints
- ✅ BaseApiController with getUser() helper
- ✅ CORS configuration
- ✅ JWT authentication for notifications

### Frontend (Next.js)
- ✅ notificationService.ts - API client
- ✅ NotificationBell.tsx - UI component
- ✅ Integrated into shifts page

### Features
- 🔔 Real-time notification bell
- 📊 Unread count badge
- ✅ Mark as read (click notification)
- ✅ Mark all as read button
- 🔄 Auto-refresh every 30 seconds
- 📱 Responsive dropdown

---

## API Endpoints Available

```
GET    /api/v1/eam/notifications              - Get all notifications
PUT    /api/v1/eam/notifications/{id}/read    - Mark as read
POST   /api/v1/eam/notifications/mark-all-read - Mark all as read
POST   /api/v1/eam/notifications              - Create notification
```

---

## Troubleshooting

### If you see 500 error:
1. Make sure you ran the setup script
2. Check that the notifications table exists in your database
3. Verify you're logged in (JWT token exists)

### If CORS error:
- Already fixed! CORS filter is configured

### If no notifications show:
- Run the setup script to insert sample data
- Check browser console for errors

---

## Next Steps (Optional)

You can now:
1. Add notification bell to other pages
2. Create notifications when shifts are assigned
3. Add real-time WebSocket updates
4. Customize notification types and priorities

---

**Status**: ✅ Ready to use!
