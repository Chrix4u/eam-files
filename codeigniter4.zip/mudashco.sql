-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 22, 2026 at 12:17 PM
-- Server version: 10.11.15-MariaDB-cll-lve
-- PHP Version: 8.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `razystud_test_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `ac_accounts`
--

CREATE TABLE `ac_accounts` (
  `id` int(5) NOT NULL,
  `count_id` int(5) DEFAULT NULL,
  `store_id` int(5) DEFAULT NULL,
  `parent_id` int(5) DEFAULT NULL,
  `sort_code` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `account_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `account_code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `balance` double(20,4) DEFAULT NULL,
  `note` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `system_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `delete_bit` int(1) DEFAULT 0,
  `account_selection_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `paymenttypes_id` int(1) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `expense_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ac_accounts`
--

INSERT INTO `ac_accounts` (`id`, `count_id`, `store_id`, `parent_id`, `sort_code`, `account_name`, `account_code`, `balance`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`, `delete_bit`, `account_selection_name`, `paymenttypes_id`, `customer_id`, `supplier_id`, `expense_id`) VALUES
(1, 1, 2, 0, '3', 'Purchase Account', 'AC/02/0001', 0.0000, '', 'Alhassan', '2023-04-15', '07:55:47 pm', '102.176.75.177', '102-176-75-177-dedicated.vodafone.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(2, 2, 2, 0, '2', 'Sales Account', 'AC/02/0002', 21869.0000, '', 'Alhassan', '2023-04-15', '07:56:01 pm', '102.176.75.177', '102-176-75-177-dedicated.vodafone.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(3, 3, 2, 0, '3', 'Bank Account', 'AC/02/0003', 0.0000, '', 'Alhassan', '2023-04-18', '07:52:51 pm', '102.176.94.82', '102-176-94-82-dedicated.vodafone.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(4, 4, 2, 0, '4', 'Cash Account', 'AC/02/0004', 0.0000, '', 'Alhassan', '2023-04-18', '07:53:17 pm', '102.176.94.82', '102-176-94-82-dedicated.vodafone.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(5, 5, 2, 0, '5', 'Momo Account', 'AC/02/0005', 0.0000, '', 'Alhassan', '2023-05-06', '01:13:19 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(6, 6, 2, 2, '2.1', 'Daily Sales', 'AC/02/0006', 0.0000, '', 'Alhassan', '2023-05-06', '01:14:55 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(7, 7, 2, 2, '2.2', 'Monthly Sales', 'AC/02/0007', 0.0000, '', 'Alhassan', '2023-05-06', '01:15:18 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(8, 8, 2, 2, '2.3', 'Annual Sales', 'AC/02/0008', 0.0000, '', 'Alhassan', '2023-05-06', '01:15:40 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(9, 9, 2, 1, '3.1', 'Daily Purchase', 'AC/02/0009', 0.0000, '', 'Alhassan', '2023-05-06', '01:15:58 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(10, 10, 2, 1, '3.2', 'Monthly Purchase', 'AC/02/0010', 0.0000, '', 'Alhassan', '2023-05-06', '01:16:18 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL),
(11, 11, 2, 1, '3.3', 'Annual Purchase', 'AC/02/0011', 0.0000, '', 'Alhassan', '2023-05-06', '01:16:36 pm', '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', 1, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ac_moneydeposits`
--

CREATE TABLE `ac_moneydeposits` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `deposit_date` date DEFAULT NULL,
  `reference_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `debit_account_id` int(11) DEFAULT NULL,
  `credit_account_id` int(11) DEFAULT NULL,
  `amount` double(20,4) DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ac_moneytransfer`
--

CREATE TABLE `ac_moneytransfer` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL,
  `transfer_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  `reference_no` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `debit_account_id` int(11) DEFAULT NULL,
  `credit_account_id` int(11) DEFAULT NULL,
  `amount` double(20,4) DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ac_transactions`
--

CREATE TABLE `ac_transactions` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `payment_code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `transaction_type` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `debit_account_id` int(5) DEFAULT NULL,
  `credit_account_id` int(5) DEFAULT NULL,
  `debit_amt` double(20,4) DEFAULT NULL,
  `credit_amt` double(20,4) DEFAULT NULL,
  `note` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `ref_accounts_id` int(5) DEFAULT NULL COMMENT 'reference table',
  `ref_moneytransfer_id` int(5) DEFAULT NULL COMMENT 'reference table',
  `ref_moneydeposits_id` int(5) DEFAULT NULL COMMENT 'reference table',
  `ref_salespayments_id` int(5) DEFAULT NULL,
  `ref_salespaymentsreturn_id` int(5) DEFAULT NULL,
  `ref_purchasepayments_id` int(5) DEFAULT NULL,
  `ref_purchasepaymentsreturn_id` int(5) DEFAULT NULL,
  `ref_expense_id` int(5) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `short_code` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ac_transactions`
--

INSERT INTO `ac_transactions` (`id`, `store_id`, `payment_code`, `transaction_date`, `transaction_type`, `debit_account_id`, `credit_account_id`, `debit_amt`, `credit_amt`, `note`, `created_by`, `created_date`, `ref_accounts_id`, `ref_moneytransfer_id`, `ref_moneydeposits_id`, `ref_salespayments_id`, `ref_salespaymentsreturn_id`, `ref_purchasepayments_id`, `ref_purchasepaymentsreturn_id`, `ref_expense_id`, `customer_id`, `supplier_id`, `short_code`) VALUES
(833, 2, '', '2023-04-15', 'OPENING BALANCE', NULL, 1, NULL, 0.0000, '', 'Alhassan', '2023-04-15', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(834, 2, '', '2023-04-15', 'OPENING BALANCE', NULL, 2, NULL, 0.0000, '', 'Alhassan', '2023-04-15', 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(837, 2, '', '2023-04-18', 'OPENING BALANCE', NULL, 3, NULL, 0.0000, '', 'Alhassan', '2023-04-18', 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(838, 2, '', '2023-04-18', 'OPENING BALANCE', NULL, 4, NULL, 0.0000, '', 'Alhassan', '2023-04-18', 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(842, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 5, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(843, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 6, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(844, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 7, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(845, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 8, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(846, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 9, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(847, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 10, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(848, 2, '', '2023-05-06', 'OPENING BALANCE', NULL, 11, NULL, 0.0000, '', 'Alhassan', '2023-05-06', 11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('0d1883277d11fd26e02fe1f7d0d987174e30f4b6', '143.105.209.70', 1771172870, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137323837303b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b6661696c65647c733a32363a22496e76616c696420456d61696c206f722050617373776f726421223b5f5f63695f766172737c613a313a7b733a363a226661696c6564223b733a333a226f6c64223b7d),
('d97ea2bf78553b9c399ed19071b0cf5969119b91', '143.105.209.70', 1771173592, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137333539323b6c616e67756167657c733a373a22456e676c697368223b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('a279701fac00cce17282053d604a4f242f8256d3', '143.105.209.70', 1771173471, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137333231343b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('1ad9577c0806a2a4ed0cc129e2fd638ff2e00ef4', '143.105.209.70', 1771173238, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137333233383b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('8beda6094d5007bde6bf0020a5ad7bfc1c457cc3', '143.105.209.70', 1771173451, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137333435313b6c616e67756167657c733a373a22456e676c697368223b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('da13e71f49b31afc2983f693e276de992c7f8f07', '143.105.209.70', 1771173592, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137333539323b6c616e67756167657c733a373a22456e676c697368223b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('58d6bee787cc776b1a1ad171b07cff97bb3e9fef', '154.161.144.73', 1771174883, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343838333b63757272656e63797c733a333a22e282b5223b63757272656e63795f706c6163656d656e747c733a343a224c656674223b63757272656e63795f636f64657c733a353a224748e282b5223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2230223b73746f72655f6e616d657c733a31373a224f666669636520496e76656e746f727920223b696e765f757365726e616d657c733a31333a2261646d696e406d616e61676572223b757365725f6c6e616d657c733a353a225573657273223b696e765f7573657269647c733a333a22313032223b6c6f676765645f696e7c623a313b726f6c655f69647c733a323a223331223b726f6c655f6e616d657c733a373a224d616e61676572223b73746f72655f69647c733a313a2232223b656d61696c7c733a32333a2272617a7973747564696f31303040676d61696c2e636f6d223b6c616e67756167657c733a373a22456e676c697368223b6c616e67756167655f69647c733a313a2231223b),
('9d2f881f6684381632ba488471f31cebc0d0fcf6', '142.250.32.4', 1771174679, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343637393b),
('81292454766e57657a50a5d7610e3a7223f8dead', '142.250.32.4', 1771174680, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343638303b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('3b16946cc2b73a7985897d4cf798805440ef081a', '142.250.32.4', 1771174708, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343730383b),
('b066dfbfcd949fffe1c0a699a30aa28a00c2aa85', '142.250.32.5', 1771174709, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343730393b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('724e09a1a49c8f3a6d484a19ab0f0004aa7f1261', '142.250.32.3', 1771174740, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343734303b),
('0bbc586aad55025cfc8b7837a0cda88ef6b96361', '142.250.32.3', 1771174740, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343734303b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('9463a707d206a9b6991ec34761ac0ce65e194565', '142.250.32.5', 1771174763, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343736333b),
('051f7449fbee6e36ad09a4c4be626a1a06994115', '142.250.32.3', 1771174763, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343736333b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('571330c462c030e4bbf5207262d44be5e2bd06aa', '142.250.32.3', 1771174782, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343738323b),
('133693f44cb54049e1e0a6c566aaeeb104fcc473', '142.250.32.5', 1771174782, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343738323b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('fd8c260b9729e3aa09cf25d3c5297c616457cecf', '142.250.32.4', 1771174827, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343832373b),
('aef715ba3d2c56776044565fcfbe3bb310452800', '142.250.32.5', 1771174828, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343832383b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('7968185abf953879e81dc8d46bfa948b9c573b07', '154.161.144.73', 1771174979, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343838333b63757272656e63797c733a333a22e282b5223b63757272656e63795f706c6163656d656e747c733a343a224c656674223b63757272656e63795f636f64657c733a353a224748e282b5223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2230223b73746f72655f6e616d657c733a31373a224f666669636520496e76656e746f727920223b696e765f757365726e616d657c733a31333a2261646d696e406d616e61676572223b757365725f6c6e616d657c733a353a225573657273223b696e765f7573657269647c733a333a22313032223b6c6f676765645f696e7c623a313b726f6c655f69647c733a323a223331223b726f6c655f6e616d657c733a373a224d616e61676572223b73746f72655f69647c733a313a2232223b656d61696c7c733a32333a2272617a7973747564696f31303040676d61696c2e636f6d223b6c616e67756167657c733a373a22456e676c697368223b6c616e67756167655f69647c733a313a2231223b),
('7f22b31d8b5320db05f4edec7b582eb9abdf3c92', '142.250.32.3', 1771174885, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343838353b),
('76d871e292a19d876294154196de48f5160fe731', '142.250.32.5', 1771174886, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343838363b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('21e902bfd0a29f23bec0c964765cc4877898337b', '142.250.32.3', 1771174971, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343937313b),
('9fc33a5db40703381b0128f15531aa0afff728c1', '142.250.32.5', 1771174972, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313137343937323b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('b03cd0f391e4bbebb922055f77d49795718aa24b', '209.38.44.96', 1771321587, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313332313538373b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('efff528ca3b48d3859c5f764ebf6570a98105f42', '143.105.209.224', 1771342435, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313334323433353b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('180c3673768825a899ba1ea2f60a7719b6eb9885', '205.169.39.76', 1771357471, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313335373437313b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('80aff6a9c23737ae3ef0f72ab1df432d160daa39', '205.169.39.76', 1771357483, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313335373438333b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('a5443b9ef526aaf35927e2dbbb2456470f052a8d', '54.82.229.81', 1771359499, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313335393439393b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('3a03b091e14576d0982e067530efda747488dfc3', '54.82.229.81', 1771363812, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313336333831323b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b),
('0f38c1677ff0eb8ec3827b6bb2e7dfbcde5f8ff8', '98.83.57.80', 1771695321, 0x5f5f63695f6c6173745f726567656e65726174657c693a313737313639353332313b63757272656e63797c733a303a22223b63757272656e63795f706c6163656d656e747c733a303a22223b63757272656e63795f636f64657c733a303a22223b766965775f646174657c733a31303a2264642d6d6d2d79797979223b766965775f74696d657c733a323a223132223b646563696d616c737c733a313a2232223b7174795f646563696d616c737c733a313a2232223b73746f72655f6e616d657c733a31303a22534141532041444d494e223b);

-- --------------------------------------------------------

--
-- Table structure for table `db_bankdetails`
--

CREATE TABLE `db_bankdetails` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `holder_name` varchar(250) DEFAULT NULL,
  `bank_name` varchar(250) DEFAULT NULL,
  `branch_name` varchar(250) DEFAULT NULL,
  `code` varchar(250) DEFAULT NULL COMMENT 'IFSC or Bank Code',
  `account_type` varchar(250) DEFAULT NULL,
  `account_number` varchar(250) DEFAULT NULL,
  `other_details` mediumtext DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_bankdetails`
--

INSERT INTO `db_bankdetails` (`id`, `store_id`, `country_id`, `holder_name`, `bank_name`, `branch_name`, `code`, `account_type`, `account_number`, `other_details`, `description`, `status`) VALUES
(1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_brands`
--

CREATE TABLE `db_brands` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `brand_code` varchar(50) DEFAULT NULL,
  `brand_name` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_brands`
--

INSERT INTO `db_brands` (`id`, `store_id`, `brand_code`, `brand_name`, `description`, `status`) VALUES
(327, 2, NULL, 'Real steel', '', 1),
(328, 2, NULL, 'Apollo', '', 1),
(329, 2, NULL, 'Sunda', '', 1),
(330, 2, NULL, 'DBS', '', 1),
(331, 2, NULL, 'B5', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_category`
--

CREATE TABLE `db_category` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create category Code',
  `category_code` varchar(50) DEFAULT NULL,
  `category_name` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_category`
--

INSERT INTO `db_category` (`id`, `store_id`, `count_id`, `category_code`, `category_name`, `description`, `company_id`, `status`) VALUES
(82, 2, 1, 'CT/02/0001', 'Mild Steel', '', NULL, 1),
(83, 2, 2, 'CT/02/0002', 'Galvanized', '', NULL, 1),
(84, 2, 3, 'CT/02/0003', 'Spices', '', NULL, 1),
(85, 2, 4, 'CT/02/0004', 'Accomodation', 'Housing and Property', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_cobpayments`
--

CREATE TABLE `db_cobpayments` (
  `id` int(5) NOT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(10,2) DEFAULT NULL,
  `payment_note` mediumtext DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_company`
--

CREATE TABLE `db_company` (
  `id` double DEFAULT NULL,
  `company_code` varchar(150) DEFAULT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `company_website` varchar(150) DEFAULT NULL,
  `mobile` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(250) DEFAULT NULL,
  `company_logo` text DEFAULT NULL,
  `logo` mediumtext DEFAULT NULL,
  `upi_id` varchar(50) DEFAULT NULL,
  `upi_code` text DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `state` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `postcode` varchar(50) DEFAULT NULL,
  `gst_no` varchar(50) DEFAULT NULL,
  `vat_no` varchar(50) DEFAULT NULL,
  `pan_no` varchar(50) DEFAULT NULL,
  `bank_details` mediumtext DEFAULT NULL,
  `cid` int(10) DEFAULT NULL,
  `category_init` varchar(5) DEFAULT NULL,
  `item_init` varchar(5) DEFAULT NULL COMMENT 'INITAL CODE',
  `supplier_init` varchar(5) DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_init` varchar(5) DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_return_init` varchar(5) DEFAULT NULL,
  `customer_init` varchar(5) DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_init` varchar(5) DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_return_init` varchar(5) DEFAULT NULL,
  `expense_init` varchar(5) DEFAULT NULL,
  `invoice_view` int(5) DEFAULT NULL COMMENT '1=Standard,2=Indian GST',
  `status` int(1) DEFAULT NULL,
  `sms_status` int(1) DEFAULT NULL COMMENT '1=Enable 0=Disable',
  `sales_terms_and_conditions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_company`
--

INSERT INTO `db_company` (`id`, `company_code`, `company_name`, `company_website`, `mobile`, `phone`, `email`, `website`, `company_logo`, `logo`, `upi_id`, `upi_code`, `country`, `state`, `city`, `address`, `postcode`, `gst_no`, `vat_no`, `pan_no`, `bank_details`, `cid`, `category_init`, `item_init`, `supplier_init`, `purchase_init`, `purchase_return_init`, `customer_init`, `sales_init`, `sales_return_init`, `expense_init`, `invoice_view`, `status`, `sms_status`, `sales_terms_and_conditions`) VALUES
(1, '', 'Company Name', NULL, '9999999999', '', 'admin@example.com', '', 'company_logo.png', 'logo-0.png', NULL, NULL, 'India', 'Karnataka', 'Belgaum', 'Address Details', '', '', '', '', '', 1, 'CT', 'IT', 'SP', 'PU', 'PR', 'CU', 'SL', 'PR', 'EX', 1, 1, 0, NULL),
(1, '', 'Company Name', NULL, '9999999999', '', 'admin@example.com', '', 'company_logo.png', 'logo-0.png', NULL, NULL, 'India', 'Karnataka', 'Belgaum', 'Address Details', '', '', '', '', '', 1, 'CT', 'IT', 'SP', 'PU', 'PR', 'CU', 'SL', 'PR', 'EX', 1, 1, 0, NULL),
(1, '', 'Company Name', NULL, '9999999999', '', 'admin@example.com', '', 'company_logo.png', 'logo-0.png', NULL, NULL, 'India', 'Karnataka', 'Belgaum', 'Address Details', '', '', '', '', '', 1, 'CT', 'IT', 'SP', 'PU', 'PR', 'CU', 'SL', 'PR', 'EX', 1, 1, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_country`
--

CREATE TABLE `db_country` (
  `id` int(5) NOT NULL,
  `country` varchar(4050) DEFAULT NULL,
  `added_on` date DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_country`
--

INSERT INTO `db_country` (`id`, `country`, `added_on`, `status`) VALUES
(1, 'Abkhazia', '2020-11-03', 1),
(2, 'Afghanistan', '2020-11-03', 1),
(3, 'Albania', '2020-11-03', 1),
(4, 'Algeria', '2020-11-03', 1),
(5, 'Andorra', '2020-11-03', 1),
(6, 'Angola', '2020-11-03', 1),
(7, 'Antigua and Barbuda', '2020-11-03', 1),
(8, 'Argentina', '2020-11-03', 1),
(9, 'Armenia', '2020-11-03', 1),
(10, 'Australia', '2020-11-03', 1),
(11, 'Austria', '2020-11-03', 1),
(12, 'Azerbaijan', '2020-11-03', 1),
(13, 'Bahamas', '2020-11-03', 1),
(14, 'Bahrain', '2020-11-03', 1),
(15, 'Bangladesh', '2020-11-03', 1),
(16, 'Barbados', '2020-11-03', 1),
(17, 'Belarus', '2020-11-03', 1),
(18, 'Belgium', '2020-11-03', 1),
(19, 'Belize', '2020-11-03', 1),
(20, 'Benin', '2020-11-03', 1),
(21, 'Bhutan', '2020-11-03', 1),
(22, 'Bolivia', '2020-11-03', 1),
(23, 'Bosnia and Herzegovina', '2020-11-03', 1),
(24, 'Botswana', '2020-11-03', 1),
(25, 'Brazil', '2020-11-03', 1),
(26, 'Brunei', '2020-11-03', 1),
(27, 'Bulgaria', '2020-11-03', 1),
(28, 'Burkina Faso', '2020-11-03', 1),
(29, 'Burma', '2020-11-03', 1),
(30, 'Burundi', '2020-11-03', 1),
(31, 'Cambodia', '2020-11-03', 1),
(32, 'Cameroon', '2020-11-03', 1),
(33, 'Canada', '2020-11-03', 1),
(34, 'Cape Verde', '2020-11-03', 1),
(35, 'Central African Republic', '2020-11-03', 1),
(36, 'Chad', '2020-11-03', 1),
(37, 'Chile', '2020-11-03', 1),
(38, 'China', '2020-11-03', 1),
(39, 'Colombia', '2020-11-03', 1),
(40, 'Comoros', '2020-11-03', 1),
(41, 'Congo', '2020-11-03', 1),
(42, 'Cook Islands', '2020-11-03', 1),
(43, 'Costa Rica', '2020-11-03', 1),
(44, 'Croatia', '2020-11-03', 1),
(45, 'Cuba', '2020-11-03', 1),
(46, 'Cyprus', '2020-11-03', 1),
(47, 'Czech Republic', '2020-11-03', 1),
(48, 'C?te d\'Ivoire', '2020-11-03', 1),
(49, 'Denmark', '2020-11-03', 1),
(50, 'Djibouti', '2020-11-03', 1),
(51, 'Dominica', '2020-11-03', 1),
(52, 'Dominican Republic', '2020-11-03', 1),
(53, 'East Timor', '2020-11-03', 1),
(54, 'Ecuador', '2020-11-03', 1),
(55, 'Egypt', '2020-11-03', 1),
(56, 'El Salvador', '2020-11-03', 1),
(57, 'Equatorial Guinea', '2020-11-03', 1),
(58, 'Eritrea', '2020-11-03', 1),
(59, 'Estonia', '2020-11-03', 1),
(60, 'Ethiopia', '2020-11-03', 1),
(61, 'Fiji', '2020-11-03', 1),
(62, 'Finland', '2020-11-03', 1),
(63, 'France', '2020-11-03', 1),
(64, 'Gabon', '2020-11-03', 1),
(65, 'Gambia', '2020-11-03', 1),
(66, 'Georgia', '2020-11-03', 1),
(67, 'Germany', '2020-11-03', 1),
(68, 'Ghana', '2020-11-03', 1),
(69, 'Greece', '2020-11-03', 1),
(70, 'Grenada', '2020-11-03', 1),
(71, 'Guatemala', '2020-11-03', 1),
(72, 'Guinea', '2020-11-03', 1),
(73, 'Guinea-Bissau', '2020-11-03', 1),
(74, 'Guyana', '2020-11-03', 1),
(75, 'Haiti', '2020-11-03', 1),
(76, 'Honduras', '2020-11-03', 1),
(77, 'Hungary', '2020-11-03', 1),
(78, 'Iceland', '2020-11-03', 1),
(79, 'India', '2020-11-03', 1),
(80, 'Indonesia', '2020-11-03', 1),
(81, 'Iran', '2020-11-03', 1),
(82, 'Iraq', '2020-11-03', 1),
(83, 'Ireland', '2020-11-03', 1),
(84, 'Israel', '2020-11-03', 1),
(85, 'Italy', '2020-11-03', 1),
(86, 'Ivory Coast', '2020-11-03', 1),
(87, 'Jamaica', '2020-11-03', 1),
(88, 'Japan', '2020-11-03', 1),
(89, 'Jordan', '2020-11-03', 1),
(90, 'Kazakhstan', '2020-11-03', 1),
(91, 'Kenya', '2020-11-03', 1),
(92, 'Kiribati', '2020-11-03', 1),
(93, 'Korea, North', '2020-11-03', 1),
(94, 'Korea, South', '2020-11-03', 1),
(95, 'Kosovo', '2020-11-03', 1),
(96, 'Kuwait', '2020-11-03', 1),
(97, 'Kyrgyzstan', '2020-11-03', 1),
(98, 'Laos', '2020-11-03', 1),
(99, 'Latvia', '2020-11-03', 1),
(100, 'Lebanon', '2020-11-03', 1),
(101, 'Lesotho', '2020-11-03', 1),
(102, 'Liberia', '2020-11-03', 1),
(103, 'Libya', '2020-11-03', 1),
(104, 'Liechtenstein', '2020-11-03', 1),
(105, 'Lithuania', '2020-11-03', 1),
(106, 'Luxembourg', '2020-11-03', 1),
(107, 'Macedonia', '2020-11-03', 1),
(108, 'Madagascar', '2020-11-03', 1),
(109, 'Malawi', '2020-11-03', 1),
(110, 'Malaysia', '2020-11-03', 1),
(111, 'Maldives', '2020-11-03', 1),
(112, 'Mali', '2020-11-03', 1),
(113, 'Malta', '2020-11-03', 1),
(114, 'Marshall Islands', '2020-11-03', 1),
(115, 'Mauritania', '2020-11-03', 1),
(116, 'Mauritius', '2020-11-03', 1),
(117, 'Mexico', '2020-11-03', 1),
(118, 'Micronesia', '2020-11-03', 1),
(119, 'Moldova', '2020-11-03', 1),
(120, 'Monaco', '2020-11-03', 1),
(121, 'Mongolia', '2020-11-03', 1),
(122, 'Montenegro', '2020-11-03', 1),
(123, 'Morocco', '2020-11-03', 1),
(124, 'Mozambique', '2020-11-03', 1),
(125, 'Myanmar / Burma', '2020-11-03', 1),
(126, 'Nagorno-Karabakh', '2020-11-03', 1),
(127, 'Namibia', '2020-11-03', 1),
(128, 'Nauru', '2020-11-03', 1),
(129, 'Nepal', '2020-11-03', 1),
(130, 'Netherlands', '2020-11-03', 1),
(131, 'New Zealand', '2020-11-03', 1),
(132, 'Nicaragua', '2020-11-03', 1),
(133, 'Niger', '2020-11-03', 1),
(134, 'Nigeria', '2020-11-03', 1),
(135, 'Niue', '2020-11-03', 1),
(136, 'Northern Cyprus', '2020-11-03', 1),
(137, 'Norway', '2020-11-03', 1),
(138, 'Oman', '2020-11-03', 1),
(139, 'Pakistan', '2020-11-03', 1),
(140, 'Palau', '2020-11-03', 1),
(141, 'Palestine', '2020-11-03', 1),
(142, 'Panama', '2020-11-03', 1),
(143, 'Papua New Guinea', '2020-11-03', 1),
(144, 'Paraguay', '2020-11-03', 1),
(145, 'Peru', '2020-11-03', 1),
(146, 'Philippines', '2020-11-03', 1),
(147, 'Poland', '2020-11-03', 1),
(148, 'Portugal', '2020-11-03', 1),
(149, 'Qatar', '2020-11-03', 1),
(150, 'Romania', '2020-11-03', 1),
(151, 'Russia', '2020-11-03', 1),
(152, 'Rwanda', '2020-11-03', 1),
(153, 'Sahrawi Arab Democratic Republic', '2020-11-03', 1),
(154, 'Saint Kitts and Nevis', '2020-11-03', 1),
(155, 'Saint Lucia', '2020-11-03', 1),
(156, 'Saint Vincent and the Grenadines', '2020-11-03', 1),
(157, 'Samoa', '2020-11-03', 1),
(158, 'San Marino', '2020-11-03', 1),
(159, 'Saudi Arabia', '2020-11-03', 1),
(160, 'Senegal', '2020-11-03', 1),
(161, 'Serbia', '2020-11-03', 1),
(162, 'Seychelles', '2020-11-03', 1),
(163, 'Sierra Leone', '2020-11-03', 1),
(164, 'Singapore', '2020-11-03', 1),
(165, 'Slovakia', '2020-11-03', 1),
(166, 'Slovenia', '2020-11-03', 1),
(167, 'Solomon Islands', '2020-11-03', 1),
(168, 'Somalia', '2020-11-03', 1),
(169, 'Somaliland', '2020-11-03', 1),
(170, 'South Africa', '2020-11-03', 1),
(171, 'South Ossetia', '2020-11-03', 1),
(172, 'Spain', '2020-11-03', 1),
(173, 'Sri Lanka', '2020-11-03', 1),
(174, 'Sudan', '2020-11-03', 1),
(175, 'Suriname', '2020-11-03', 1),
(176, 'Swaziland', '2020-11-03', 1),
(177, 'Sweden', '2020-11-03', 1),
(178, 'Switzerland', '2020-11-03', 1),
(179, 'Syria', '2020-11-03', 1),
(180, 'S?o Tom? and Pr?ncipe', '2020-11-03', 1),
(181, 'Taiwan', '2020-11-03', 1),
(182, 'Tajikistan', '2020-11-03', 1),
(183, 'Tanzania', '2020-11-03', 1),
(184, 'Thailand', '2020-11-03', 1),
(185, 'Timor-Leste / East Timor', '2020-11-03', 1),
(186, 'Togo', '2020-11-03', 1),
(187, 'Tonga', '2020-11-03', 1),
(188, 'Trinidad and Tobago', '2020-11-03', 1),
(189, 'Tunisia', '2020-11-03', 1),
(190, 'Turkey', '2020-11-03', 1),
(191, 'Turkmenistan', '2020-11-03', 1),
(192, 'Tuvalu', '2020-11-03', 1),
(193, 'Uganda', '2020-11-03', 1),
(194, 'Ukraine', '2020-11-03', 1),
(195, 'United Arab Emirates', '2020-11-03', 1),
(196, 'United Kingdom', '2020-11-03', 1),
(197, 'United States', '2020-11-03', 1),
(198, 'Uruguay', '2020-11-03', 1),
(199, 'Uzbekistan', '2020-11-03', 1),
(200, 'Vanuatu', '2020-11-03', 1),
(201, 'Vatican City', '2020-11-03', 1),
(202, 'Venezuela', '2020-11-03', 1),
(203, 'Vietnam', '2020-11-03', 1),
(204, 'Yemen', '2020-11-03', 1),
(205, 'Zambia', '2020-11-03', 1),
(206, 'Zimbabwe', '2020-11-03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_coupons`
--

CREATE TABLE `db_coupons` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `value` double(20,2) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(100) DEFAULT NULL,
  `system_name` varchar(250) DEFAULT NULL,
  `system_ip` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_currency`
--

CREATE TABLE `db_currency` (
  `id` int(5) NOT NULL,
  `currency_name` varchar(50) DEFAULT NULL,
  `currency_code` varchar(20) DEFAULT NULL,
  `currency` blob DEFAULT NULL,
  `symbol` mediumtext DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_currency`
--

INSERT INTO `db_currency` (`id`, `currency_name`, `currency_code`, `currency`, `symbol`, `status`) VALUES
(1, 'Bulgaria-Bulgarian lev(BGN)', NULL, 0xd0bbd0b2, NULL, 1),
(2, 'Switzerland \r-Swiss franc (CHF)', NULL, 0x434846, NULL, 1),
(3, 'Czechia-Czech koruna(CZK))', NULL, 0x4bc48d20, NULL, 1),
(4, 'Denmark-Danish krone(DKK)', NULL, 0x6b7220, NULL, 1),
(5, 'Euro area countries -Euro(EUR)', NULL, 0xe282ac20, NULL, 1),
(6, 'United Kingdom-Pounds sterling (GBP)', NULL, 0xc2a3, NULL, 1),
(7, 'Croatia -Croatian Kuna (HRK)', NULL, 0x6b6e, NULL, 1),
(8, 'Georgia -Georgian lari (GEL)', NULL, 0x2623383338323b, NULL, 1),
(9, 'Hungary -Hungarian forint (HUF)', NULL, 0x6674, NULL, 1),
(10, 'Norway -Norwegian krone (NOK)', NULL, 0x6b72, NULL, 1),
(11, 'Poland -Polish zloty (PLN)', NULL, 0x7ac58220, NULL, 1),
(12, 'Russia -Russian ruble (RUB)', NULL, 0x2623383338313b20, NULL, 1),
(13, 'Romania -Romanian leu (RON)', NULL, 0x6c6569, NULL, 1),
(14, 'Sweden - Swedish krona (SEK)', NULL, 0x6b72, NULL, 1),
(15, 'Turkey -Turkish lira (TRY)', NULL, 0x2623383337383b20, NULL, 1),
(16, 'Ukraine - Ukrainian hryvna  (UAH)', NULL, 0xe282b420, NULL, 1),
(17, 'UAE -Emirati dirham (AED)', NULL, 0xd8af2ed8a520, NULL, 1),
(18, 'Israel - Israeli shekel (ILS)', NULL, 0x2623383336323b20, NULL, 1),
(19, 'Kenya - Kenyan shilling(KES)', NULL, 0x4b7368, NULL, 1),
(20, 'Morocco - Moroccan dirham (MAD)', NULL, 0x2ed8af2ed98520, NULL, 1),
(21, 'Nigeria - Nigerian naira (NGN)', NULL, 0xe282a620, NULL, 1),
(22, 'South Africa -South african rand** (ZAR)', NULL, 0x52, NULL, 1),
(23, 'Brazil- Brazilian real(BRL)', NULL, 0x5224, NULL, 1),
(24, 'Canada-Canadian dollars (CAD)', NULL, 0x24, NULL, 1),
(25, 'Chile -Chilean peso (CLP)', NULL, 0x24, NULL, 1),
(26, 'Colombia -Colombian peso (COP)', NULL, 0x24, NULL, 1),
(27, 'Mexico - Mexican peso (MXN)', NULL, 0x24, NULL, 1),
(28, 'Peru -Peruvian sol(PEN)', NULL, 0x532f2e20, NULL, 1),
(29, 'USA -US dollar (USD)', NULL, 0x24, NULL, 1),
(30, 'Australia -Australian dollars (AUD)', NULL, 0x24, NULL, 1),
(31, 'Bangladesh -Bangladeshi taka (BDT) ', NULL, 0x2623323534373b20, NULL, 1),
(32, 'China - Chinese yuan (CNY)', NULL, 0x262332303830333b20, NULL, 1),
(33, 'Hong Kong - Hong Kong dollar(HKD)', NULL, 0x262333363b20, NULL, 1),
(34, 'Indonesia - Indonesian rupiah (IDR)', NULL, 0x5270, NULL, 1),
(35, 'India - Indian rupee', 'INR', 0xe282b9, '?', 1),
(36, 'Japan - Japanese yen (JPY)', NULL, 0xc2a5, NULL, 1),
(37, 'Malaysia - Malaysian ringgit (MYR)', NULL, 0x524d, NULL, 1),
(38, 'New Zealand - New Zealand dollar (NZD)', NULL, 0x24, NULL, 1),
(39, 'Philippines- Philippine peso (PHP)', NULL, 0xe282b120, NULL, 1),
(40, 'Pakistan- Pakistani rupee (PKR)', NULL, 0x527320, NULL, 1),
(41, 'Singapore - Singapore dollar (SGD)', NULL, 0x24, NULL, 1),
(42, 'South Korea - South Korean won (KRW)', NULL, 0x2623383336313b20, NULL, 1),
(43, 'Sri Lanka - Sri Lankan rupee (LKR)', NULL, 0x5273, NULL, 1),
(44, 'Thailand- Thai baht (THB)', NULL, 0x2623333634373b20, NULL, 1),
(45, 'Vietnam - Vietnamese dong', 'VND', 0xe282ab, NULL, 1),
(46, 'Bitcoin - BTC or XBT', 'BTC ', 0xe282bf, NULL, 1),
(47, 'Ripples', 'XRP', 0x585250, NULL, 1),
(48, 'Monero', 'XMR', 0xc9b1, NULL, 1),
(49, 'Litecoin', 'LTC', 0xc581, NULL, 1),
(50, 'Ethereum', 'ETH', 0xce9e, NULL, 1),
(51, 'Euro', 'EUR', 0xe282ac, NULL, 1),
(52, 'Pounds sterling', 'GBP', 0xc2a3, NULL, 1),
(53, 'US dollar', 'USD', 0x24, NULL, 1),
(54, 'Japanese yen', 'JPY', 0xc2a5, NULL, 1),
(55, 'Omani rial', 'OMR', 0xd8b12ed8b92e, NULL, 1),
(60, 'GHANA CEDIS', 'GH₵', 0xe282b5, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_custadvance`
--

CREATE TABLE `db_custadvance` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `count_id` int(5) DEFAULT NULL,
  `payment_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `amount` double(20,4) DEFAULT NULL,
  `payment_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_ip` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_customers`
--

CREATE TABLE `db_customers` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create Customer Code',
  `customer_code` varchar(20) DEFAULT NULL,
  `customer_name` varchar(50) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `gstin` varchar(100) DEFAULT NULL,
  `tax_number` varchar(50) DEFAULT NULL,
  `vatin` varchar(100) DEFAULT NULL,
  `opening_balance` double(20,4) DEFAULT NULL,
  `sales_due` double(20,4) DEFAULT NULL,
  `sales_return_due` double(20,4) DEFAULT NULL,
  `country_id` int(50) DEFAULT NULL,
  `state_id` int(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `ship_country_id` int(5) DEFAULT NULL,
  `ship_state_id` int(5) DEFAULT NULL,
  `ship_city` varchar(100) DEFAULT NULL,
  `ship_postcode` varchar(10) DEFAULT NULL,
  `ship_address` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `location_link` text DEFAULT NULL,
  `attachment_1` text DEFAULT NULL,
  `price_level_type` varchar(50) DEFAULT 'Increase',
  `price_level` double(20,4) DEFAULT 0.0000,
  `delete_bit` int(1) DEFAULT 0,
  `tot_advance` double(20,4) DEFAULT NULL,
  `credit_limit` double(20,4) DEFAULT -1.0000,
  `shippingaddress_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_customers`
--

INSERT INTO `db_customers` (`id`, `store_id`, `count_id`, `customer_code`, `customer_name`, `mobile`, `phone`, `email`, `gstin`, `tax_number`, `vatin`, `opening_balance`, `sales_due`, `sales_return_due`, `country_id`, `state_id`, `city`, `postcode`, `address`, `ship_country_id`, `ship_state_id`, `ship_city`, `ship_postcode`, `ship_address`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `location_link`, `attachment_1`, `price_level_type`, `price_level`, `delete_bit`, `tot_advance`, `credit_limit`, `shippingaddress_id`) VALUES
(1, 1, NULL, 'CU0001', 'Walk-in customer', NULL, '', '', '', '', NULL, 0.0000, 0.0000, 0.0000, 1, NULL, NULL, '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2019-01-01', '10:55:54 pm', 'admin', NULL, 1, NULL, NULL, 'Increase', 0.0000, 1, NULL, -1.0000, 1),
(2, 2, 1, 'CU/02/0001', 'Walk-in customer', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0.0000, 0.0000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '127.0.0.1', 'LAPTOP-I5OUIM4R', '2021-02-12', '05:53:37 pm', '', NULL, 1, NULL, NULL, 'Increase', 0.0000, 1, 0.0000, -1.0000, 2);

-- --------------------------------------------------------

--
-- Table structure for table `db_customer_coupons`
--

CREATE TABLE `db_customer_coupons` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `value` double(20,2) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(100) DEFAULT NULL,
  `system_name` varchar(250) DEFAULT NULL,
  `system_ip` varchar(250) DEFAULT NULL,
  `customer_id` int(10) DEFAULT NULL,
  `coupon_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_customer_payments`
--

CREATE TABLE `db_customer_payments` (
  `id` int(5) NOT NULL,
  `salespayment_id` int(5) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment` double(10,2) DEFAULT NULL,
  `payment_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_emailtemplates`
--

CREATE TABLE `db_emailtemplates` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `key` varchar(150) DEFAULT NULL,
  `template_name` varchar(100) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `variables` text DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `undelete_bit` int(5) DEFAULT NULL,
  `admin_only` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_emailtemplates`
--

INSERT INTO `db_emailtemplates` (`id`, `store_id`, `key`, `template_name`, `content`, `variables`, `status`, `undelete_bit`, `admin_only`) VALUES
(1, 1, 'SAAS_FORGOT_PASSWORD_EMAIL', 'Site forgot password email template', 'Hi {{user_name}},\r\n\r\nyour OTP is {{email_otp}}\r\n\r\nThank you\r\n{{saas_name}}', '{{user_name}}<br>\r\n{{saas_name}}<br>\r\n{{email_otp}}<br>', 1, 1, 1),
(2, 1, 'SAAS_WELCOME_EMAIL', 'Site welcome email', 'Hi {{user_name}},\r\nYour email id {{email_id}},\r\nwelcome to our {{saas_name}},\r\n\r\nThank you', '{{user_name}}<br>\r\n{{email_id}}<br>\r\n{{saas_name}}<br>', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_expense`
--

CREATE TABLE `db_expense` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create Expense Code',
  `expense_code` varchar(50) DEFAULT NULL,
  `category_id` int(5) DEFAULT NULL,
  `expense_date` date DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `expense_for` varchar(100) DEFAULT NULL,
  `expense_amt` double(20,4) DEFAULT NULL,
  `payment_type` varchar(100) DEFAULT NULL,
  `account_id` int(5) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_expense`
--

INSERT INTO `db_expense` (`id`, `store_id`, `count_id`, `expense_code`, `category_id`, `expense_date`, `reference_no`, `expense_for`, `expense_amt`, `payment_type`, `account_id`, `note`, `created_by`, `created_date`, `created_time`, `system_ip`, `system_name`, `status`) VALUES
(34, 2, 1, 'EX/2021/02/0001', 61, '2023-05-30', 'For Gbetsile Warehouse', 'Roofing Leakge Repair', 1800.0000, 'Momo', NULL, '', 'Admin', '2023-06-11', '09:28:11 pm', '102.176.94.57', '102-176-94-57-dedicated.vodafone.com.gh', 1),
(35, 2, 2, 'EX/2021/02/0002', 61, '2023-05-30', 'For Gbetsile Warehouse', 'Roofing Leakge Repair', 500.0000, 'Cash', NULL, '', 'Admin', '2023-06-11', '09:29:55 pm', '102.176.94.57', '102-176-94-57-dedicated.vodafone.com.gh', 1),
(36, 2, 3, 'EX/2021/02/0003', 63, '2023-06-16', 'Japan Motor Ghana Ltd', 'Purchase of New Company Truck', 150000.0000, 'Cheque', NULL, 'Initial Deposit including registration, excluding insurance ', 'Admin', '2023-06-24', '11:03:50 am', '102.176.94.243', '102-176-94-243-dedicated.vodafone.com.gh', 1),
(37, 2, 4, 'EX/2021/02/0004', 63, '2023-06-24', 'Japan Motor Ghana Ltd', 'Insurance of New Company Truck', 32526.0000, 'Cash', NULL, 'Insurance payment (GLICO INSURANCE)', 'Admin', '2023-06-24', '11:05:34 am', '102.176.94.243', '102-176-94-243-dedicated.vodafone.com.gh', 1),
(38, 2, 5, 'EX/2021/02/0005', 64, '2023-05-30', 'One year (15th feb 2023 - 15th Feb 2024)', 'Mathaheko Store Rent', 6000.0000, 'Cash', NULL, 'Eyum Royal Estate (Store Number 7)\r\nLandlord (Mr Eyum Micheal Kwame)', 'Admin', '2023-06-24', '11:57:04 pm', '154.160.6.13', 'dyn-as-mobile-154-160-6-13.mtn.com.gh', 1),
(39, 2, 6, 'EX/2021/02/0006', 61, '2023-05-05', 'For Ashaiman', 'Store', 150.0000, 'Cash', 10, '', 'Admin', '2023-09-16', '11:19:53 am', '41.215.165.248', '41.215.165.248', 1),
(40, 2, 7, 'EX/2021/02/0007', 61, '2023-07-15', 'For Gbetsile', 'Container Key Replacement', 150.0000, 'Cash', 9, '', 'Admin', '2023-09-16', '11:29:52 am', '41.215.165.248', '41.215.165.248', 1),
(41, 2, 8, 'EX/2021/02/0008', 61, '2023-06-26', 'For Afienyan', 'Store', 40.0000, 'Cash', 7, '', 'Admin', '2023-09-16', '11:32:30 am', '41.215.165.248', '41.215.165.248', 1),
(42, 2, 9, 'EX/2021/02/0009', 61, '2023-05-17', 'For Afienyan', 'Store', 40.0000, 'Cash', 7, '', 'Admin', '2023-09-16', '11:33:48 am', '41.215.165.248', '41.215.165.248', 1),
(43, 2, 10, 'EX/2021/02/0010', 61, '2023-05-01', 'For Afienyan', 'Store Stand Division', 450.0000, 'Cash', 7, '', 'Admin', '2023-09-16', '11:34:57 am', '41.215.165.248', '41.215.165.248', 1),
(44, 2, 11, 'EX/2021/02/0011', 61, '2023-09-11', 'For Gbetsile', 'Store Padlock replacement', 150.0000, 'Cash', 9, '', 'Admin', '2023-09-16', '11:37:16 am', '41.215.165.248', '41.215.165.248', 1),
(45, 2, 12, 'EX/2021/02/0012', 61, '2023-10-03', '', 'welding', 300.0000, 'Cash', 9, 'workmanship for welding', 'Gloria', '2023-10-05', '07:38:55 pm', '102.176.65.18', '102-176-65-18-dedicated.vodafone.com.gh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_expense_category`
--

CREATE TABLE `db_expense_category` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `category_code` varchar(50) DEFAULT NULL,
  `category_name` varchar(50) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_expense_category`
--

INSERT INTO `db_expense_category` (`id`, `store_id`, `category_code`, `category_name`, `description`, `created_by`, `status`) VALUES
(59, 2, 'EC0001', 'Purchase', 'Expenses on goods purchased', 'Alhassan', 1),
(60, 2, 'EC0060', 'Sales', 'Expenses on sales', 'Alhassan', 1),
(61, 2, 'EC0061', 'Maintenance', 'Expenses on maintenance', 'Alhassan', 1),
(62, 2, 'EC0062', 'Miscellaneous', 'Other necessary expenses', 'Alhassan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_fivemojo`
--

CREATE TABLE `db_fivemojo` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `instance_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_fivemojo`
--

INSERT INTO `db_fivemojo` (`id`, `store_id`, `url`, `token`, `instance_id`, `status`) VALUES
(4, 2, 'https://app.fivemojo.com/api/send.php', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `db_hold`
--

CREATE TABLE `db_hold` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `reference_id` varchar(50) DEFAULT NULL COMMENT 'Temprary',
  `reference_no` varchar(50) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `sales_status` varchar(50) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL,
  `round_off` double(20,2) DEFAULT NULL,
  `grand_total` double(20,4) DEFAULT NULL,
  `sales_note` text DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_holditems`
--

CREATE TABLE `db_holditems` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `hold_id` int(5) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `sales_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,4) DEFAULT NULL,
  `discount_type` varchar(50) DEFAULT NULL,
  `discount_input` double(20,4) DEFAULT NULL,
  `discount_amt` double(20,4) DEFAULT NULL,
  `unit_total_cost` double(20,4) DEFAULT NULL,
  `total_cost` double(20,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_instamojo`
--

CREATE TABLE `db_instamojo` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `sandbox` int(1) DEFAULT NULL,
  `api_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `api_token` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_instamojo`
--

INSERT INTO `db_instamojo` (`id`, `store_id`, `sandbox`, `api_key`, `api_token`, `updated_at`, `updated_by`, `status`) VALUES
(1, 1, 1, '', '', '2021-02-22', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_instamojopayments`
--

CREATE TABLE `db_instamojopayments` (
  `id` int(10) UNSIGNED NOT NULL,
  `phone` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `buyer_name` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `amount` decimal(16,2) NOT NULL,
  `purpose` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `expires_at` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `send_sms` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'false',
  `send_email` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'false',
  `sms_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `email_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `shorturl` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `longurl` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `redirect_url` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `webhook` mediumtext CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `allow_repeated_payments` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT 'false',
  `customer_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `created_at` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `modified_at` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_items`
--

CREATE TABLE `db_items` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create ITEM Code',
  `item_code` varchar(50) DEFAULT NULL,
  `item_name` varchar(100) DEFAULT NULL,
  `category_id` int(10) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `hsn` varchar(50) DEFAULT NULL,
  `sac` varchar(50) DEFAULT NULL,
  `unit_id` int(10) DEFAULT NULL,
  `alert_qty` int(10) DEFAULT NULL,
  `brand_id` int(5) DEFAULT NULL,
  `lot_number` varchar(50) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `price` double(20,4) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `purchase_price` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `profit_margin` double(20,2) DEFAULT NULL,
  `sales_price` double(20,4) DEFAULT NULL,
  `stock` double(20,2) DEFAULT NULL,
  `item_image` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `discount_type` varchar(100) DEFAULT 'Percentage',
  `discount` double(20,2) DEFAULT 0.00,
  `service_bit` int(1) DEFAULT 0,
  `seller_points` double(20,2) DEFAULT 0.00,
  `custom_barcode` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `item_group` varchar(50) DEFAULT NULL,
  `parent_id` int(5) DEFAULT NULL,
  `variant_id` int(5) DEFAULT NULL,
  `child_bit` int(1) DEFAULT 0,
  `mrp` double(20,4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_items`
--

INSERT INTO `db_items` (`id`, `store_id`, `count_id`, `item_code`, `item_name`, `category_id`, `sku`, `hsn`, `sac`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`, `service_bit`, `seller_points`, `custom_barcode`, `description`, `item_group`, `parent_id`, `variant_id`, `child_bit`, `mrp`) VALUES
(1, 2, 1, 'IT020001', '3/4  Steel Square pipe', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 23.0000, 149, 23.0000, 'Inclusive', 9.00, 25.0000, 2714.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '11:14:21 am', 'Alhassan', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(2, 2, 2, 'IT020002', '3/4 Galv. square pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 26.5000, 149, 27.0000, 'Inclusive', 0.00, 27.0000, 44739.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:11:55 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(3, 2, 3, 'IT020003', '1&quot; steel square', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 33.0000, 149, 33.0000, 'Inclusive', 0.00, 33.0000, 2668.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:21:32 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(4, 2, 4, 'IT020004', '1&amp; 1/4 steel square', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 43.0000, 149, 43.0000, 'Inclusive', 0.00, 43.0000, 121.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:26:22 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(5, 2, 5, 'IT020005', '1 &amp; 1/2 steel square', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 59.0000, 149, 59.0000, 'Inclusive', 0.00, 59.0000, 256.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:28:14 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(6, 2, 6, 'IT020006', '3/4*1&amp; 1/2 steel square', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 45.0000, 149, 45.0000, 'Inclusive', 0.00, 45.0000, 1215.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:30:43 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(7, 2, 7, 'IT020007', '2/1 steel square', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 60.0000, 149, 60.0000, 'Inclusive', 0.00, 60.0000, 105.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:33:01 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(8, 2, 8, 'IT020008', '2&quot; steel square pipe', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 80.0000, 149, 80.0000, 'Inclusive', 0.00, 80.0000, 53.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '12:37:37 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(9, 2, 9, 'IT020009', '1&quot; Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 37.0000, 149, 37.0000, 'Inclusive', 0.00, 37.0000, 175.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:11:45 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(10, 2, 10, 'IT020010', '1 &amp; 1/4 Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 47.0000, 149, 47.0000, 'Inclusive', 0.00, 47.0000, 485.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:13:28 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(11, 2, 11, 'IT020011', '1 &amp; 1/2 Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 62.0000, 149, 62.0000, 'Inclusive', 0.00, 62.0000, 1199.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:14:56 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(12, 2, 12, 'IT020012', '2&quot; Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 110.0000, 149, 110.0000, 'Inclusive', 0.00, 110.0000, 439.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:16:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(13, 2, 13, 'IT020013', '2 &amp; 1/2 Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 300.0000, 149, 300.0000, 'Inclusive', 0.00, 300.0000, 50.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:18:16 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(14, 2, 14, 'IT020014', '3&quot; Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 500.0000, 149, 500.0000, 'Inclusive', 0.00, 500.0000, 51.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:19:37 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(15, 2, 15, 'IT020015', '4&quot; Steel Angle bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 800.0000, 149, 800.0000, 'Inclusive', 0.00, 800.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:20:50 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(16, 2, 16, 'IT020016', '1mm steel plate (L)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 143.0000, 149, 143.0000, 'Inclusive', 0.00, 143.0000, 687.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:22:24 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(17, 2, 17, 'IT020017', '1mm steel plate (T)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 192.0000, 149, 192.0000, 'Inclusive', 0.00, 192.0000, 695.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:23:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(18, 2, 18, 'IT020018', '1mm Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 215.0000, 149, 215.0000, 'Inclusive', 0.00, 215.0000, 2107.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:25:15 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(19, 2, 19, 'IT020019', '1.25mm steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 275.0000, 149, 275.0000, 'Inclusive', 0.00, 275.0000, 91.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:27:14 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(20, 2, 20, 'IT020020', '1.25mm Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 315.0000, 149, 315.0000, 'Inclusive', 0.00, 315.0000, 2790.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:28:33 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(21, 2, 21, 'IT020021', '1.6mm steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 425.0000, 149, 425.0000, 'Inclusive', 0.00, 425.0000, 13.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:30:13 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(22, 2, 22, 'IT020022', '1.6mm Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 445.0000, 149, 445.0000, 'Inclusive', 0.00, 445.0000, 395.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:31:58 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(23, 2, 23, 'IT020023', '2mm steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 540.0000, 149, 540.0000, 'Inclusive', 0.00, 540.0000, 270.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:33:24 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(24, 2, 24, 'IT020024', '2mm Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 640.0000, 149, 640.0000, 'Inclusive', 0.00, 640.0000, 10.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:34:52 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(25, 2, 25, 'IT020025', '2mm Steel Checkered plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 700.0000, 149, 700.0000, 'Inclusive', 0.00, 700.0000, 21.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:37:40 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(26, 2, 26, 'IT020026', '3mm steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 870.0000, 149, 870.0000, 'Inclusive', 0.00, 870.0000, 181.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:38:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(27, 2, 27, 'IT020027', '3mm Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 1200.0000, 149, 1200.0000, 'Inclusive', 0.00, 1200.0000, 2.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:39:55 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(28, 2, 28, 'IT020028', '4mm steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1250.0000, 149, 1250.0000, 'Inclusive', 0.00, 1250.0000, 65.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:41:03 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(29, 2, 29, 'IT020029', '5mm steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1350.0000, 149, 1350.0000, 'Inclusive', 0.00, 1350.0000, 26.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:42:12 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(30, 2, 30, 'IT020030', 'Moulded steel plate (L)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 145.0000, 149, 145.0000, 'Inclusive', 0.00, 145.0000, 681.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:44:27 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(31, 2, 31, 'IT020031', 'Moulded steel plate (T)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 194.0000, 149, 194.0000, 'Inclusive', 0.00, 194.0000, 448.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:45:38 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(32, 2, 32, 'IT020032', 'Moulded Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 230.0000, 149, 230.0000, 'Inclusive', 0.00, 230.0000, 35.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:49:02 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(33, 2, 33, 'IT020033', 'Design/Roofing steel plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 155.0000, 149, 155.0000, 'Inclusive', 0.00, 155.0000, 75.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:50:56 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(34, 2, 34, 'IT020034', 'Design/Roofing Galv. plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 230.0000, 149, 230.0000, 'Inclusive', 0.00, 230.0000, 29.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:52:57 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(35, 2, 35, 'IT020035', '1.6mm Galv. Checkered plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 520.0000, 149, 520.0000, 'Inclusive', 0.00, 520.0000, 19.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:54:32 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(36, 2, 36, 'IT020036', 'China Galv. Design plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 265.0000, 149, 265.0000, 'Inclusive', 0.00, 265.0000, 67.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:56:52 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(37, 2, 37, 'IT020037', 'China Steel Design plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 250.0000, 149, 250.0000, 'Inclusive', 0.00, 250.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '01:58:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(38, 2, 38, 'IT020038', '5/8 Steel Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 19.5000, 149, 20.0000, 'Inclusive', 0.00, 20.0000, 2167.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:00:19 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(39, 2, 39, 'IT020039', '3/4 Steel Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 22.5000, 149, 23.0000, 'Inclusive', 0.00, 23.0000, 1511.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:01:25 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(40, 2, 40, 'IT020040', '1&quot; Steel Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 38.0000, 149, 38.0000, 'Inclusive', 0.00, 38.0000, 18.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:02:24 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(41, 2, 41, 'IT020041', '1 &amp; 1/2 Steel Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 70.0000, 149, 70.0000, 'Inclusive', 0.00, 70.0000, 180.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:03:28 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(42, 2, 42, 'IT020042', '2&quot; Steel Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 85.0000, 149, 85.0000, 'Inclusive', 0.00, 85.0000, 76.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:04:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(43, 2, 43, 'IT020043', '3&quot; Steel Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 330.0000, 149, 330.0000, 'Inclusive', 0.00, 330.0000, 4.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:05:55 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(44, 2, 44, 'IT020044', '1/2&quot; Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 38.0000, 149, 38.0000, 'Inclusive', 0.00, 38.0000, 10999.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:07:56 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(45, 2, 45, 'IT020045', '3/4 Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 48.0000, 149, 48.0000, 'Inclusive', 0.00, 48.0000, 20165.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:09:00 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(46, 2, 46, 'IT020046', '1&quot; Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 68.0000, 149, 68.0000, 'Inclusive', 0.00, 68.0000, 2386.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:10:06 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(47, 2, 47, 'IT020047', '1 &amp; 1/4 Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 90.0000, 149, 90.0000, 'Inclusive', 0.00, 90.0000, 6151.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:11:39 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(48, 2, 48, 'IT020048', '1 &amp; 1/2 Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 103.0000, 149, 103.0000, 'Inclusive', 0.00, 103.0000, 3962.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:14:41 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(49, 2, 49, 'IT020049', '2&quot; Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 128.0000, 149, 128.0000, 'Inclusive', 0.00, 128.0000, 3330.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:15:32 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(50, 2, 50, 'IT020050', '2 &amp; 1/2 Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 195.0000, 149, 195.0000, 'Inclusive', 0.00, 195.0000, 600.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:16:44 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(51, 2, 51, 'IT020051', '3&quot; Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 300.0000, 149, 300.0000, 'Inclusive', 0.00, 300.0000, 851.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:19:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(52, 2, 52, 'IT020052', '4&quot; Galv. Round pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 400.0000, 149, 400.0000, 'Inclusive', 0.00, 400.0000, 43.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:22:59 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(53, 2, 53, 'IT020053', '5/8 Galv. Flat bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 22.0000, 149, 22.0000, 'Inclusive', 0.00, 22.0000, 23912.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:36:46 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(54, 2, 54, 'IT020054', '3/4 Galv. Flat bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 26.5000, 149, 27.0000, 'Inclusive', 0.00, 27.0000, 6772.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:37:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(55, 2, 55, 'IT020055', '1&quot; Galv. Flat bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 46.0000, 149, 46.0000, 'Inclusive', 0.00, 46.0000, 1796.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:38:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(56, 2, 56, 'IT020056', '1 &amp; 1/2 Galv. Flat bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 85.0000, 149, 85.0000, 'Inclusive', 0.00, 85.0000, 1285.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:39:52 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(57, 2, 57, 'IT020057', '2&quot; Galv. Flat bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 95.0000, 149, 95.0000, 'Inclusive', 0.00, 95.0000, 547.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:40:51 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(58, 2, 58, 'IT020058', '1/2&quot; Steel square pipe', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 21.0000, 149, 21.0000, 'Inclusive', 0.00, 21.0000, 5.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:42:00 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(59, 2, 59, 'IT020059', '1/2&quot; Galv. Square', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 22.0000, 149, 22.0000, 'Inclusive', 0.00, 22.0000, 37.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '02:43:04 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(60, 2, 60, 'IT020060', '1&quot; Galv. Square', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 36.5000, 149, 37.0000, 'Inclusive', 0.00, 37.0000, 13477.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:03:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(61, 2, 61, 'IT020061', '1 &amp; 1/4 Galv. Square', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 46.0000, 149, 46.0000, 'Inclusive', 0.00, 46.0000, 2340.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:05:07 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(62, 2, 62, 'IT020062', '1 &amp; 1/2 Galv. Square', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 63.0000, 149, 63.0000, 'Inclusive', 0.00, 63.0000, 7441.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:05:56 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(63, 2, 63, 'IT020063', '3/4*1 &amp; 1/2 Galv. Rect.', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 48.0000, 149, 48.0000, 'Inclusive', 0.00, 48.0000, 7554.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:07:15 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(64, 2, 64, 'IT020064', '2/1 Galv. Rect.', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 63.0000, 149, 63.0000, 'Inclusive', 0.00, 63.0000, 13014.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:08:11 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(65, 2, 65, 'IT020065', '2&quot; Galv. Square', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 91.0000, 149, 91.0000, 'Inclusive', 0.00, 91.0000, 2221.50, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:09:02 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(66, 2, 66, 'IT020066', '2/4 Galv. Rect.', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 400.0000, 149, 400.0000, 'Inclusive', 0.00, 400.0000, 572.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:10:52 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(67, 2, 67, 'IT020067', '1 &amp; 1/2*3 Galv. Rect. (L)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 180.0000, 149, 180.0000, 'Inclusive', 0.00, 180.0000, 738.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:15:11 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(68, 2, 68, 'IT020068', '1 &amp; 1/2*3 Galv. Rect. (M)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 250.0000, 149, 250.0000, 'Inclusive', 0.00, 250.0000, 8.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:16:33 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(69, 2, 69, 'IT020069', '1 &amp; 1/4 Galv. Angle bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 80.0000, 149, 80.0000, 'Inclusive', 0.00, 80.0000, 559.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:18:51 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(70, 2, 70, 'IT020070', '1 &amp; 1/2 Galv. Angle bar', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 150.0000, 149, 150.0000, 'Inclusive', 0.00, 150.0000, 989.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:19:50 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(71, 2, 71, 'IT020071', '2&quot; Galv. Angle bar (L)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 200.0000, 149, 200.0000, 'Inclusive', 0.00, 200.0000, 456.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:20:53 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(72, 2, 72, 'IT020072', '2&quot; Galv. Angle bar (T)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 350.0000, 149, 350.0000, 'Inclusive', 0.00, 350.0000, 4.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:23:22 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(73, 2, 73, 'IT020073', 'Galv. Net Plate (4*8)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 400.0000, 149, 400.0000, 'Inclusive', 0.00, 400.0000, 152.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:25:40 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(74, 2, 74, 'IT020074', '2&quot; U- channel', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 400.0000, 149, 400.0000, 'Inclusive', 0.00, 400.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:29:36 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(75, 2, 75, 'IT020075', '3&quot; U- Channel', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 500.0000, 149, 500.0000, 'Inclusive', 0.00, 500.0000, 50.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:30:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(76, 2, 76, 'IT020076', '4&quot; U- Channel (L)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 550.0000, 149, 550.0000, 'Inclusive', 0.00, 550.0000, 202.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:32:21 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(77, 2, 77, 'IT020077', '4&quot; U- Channel (T)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 600.0000, 149, 600.0000, 'Inclusive', 0.00, 600.0000, 2.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:33:24 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(78, 2, 78, 'IT020078', '5&quot; U- Channel (L)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 750.0000, 149, 750.0000, 'Inclusive', 0.00, 750.0000, 20.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:34:28 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(79, 2, 79, 'IT020079', '5&quot; U- Channel (T)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1100.0000, 149, 1100.0000, 'Inclusive', 0.00, 1100.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:35:52 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(80, 2, 80, 'IT020080', '6&quot; U- Channel', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1850.0000, 149, 1850.0000, 'Inclusive', 0.00, 1850.0000, 48.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:36:45 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(81, 2, 81, 'IT020081', 'Galv. Kallo Plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 265.0000, 149, 265.0000, 'Inclusive', 0.00, 265.0000, 12.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:40:34 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(82, 2, 82, 'IT020082', 'Big (Grinding) Disc', 84, '', '', NULL, 61, 0, 0, NULL, NULL, 20.0000, 149, 20.0000, 'Inclusive', 0.00, 20.0000, 8.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:49:18 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(83, 2, 83, 'IT020083', 'Small (Grinding) Disc', 84, '', '', NULL, 61, 0, 0, NULL, NULL, 15.0000, 149, 15.0000, 'Inclusive', 0.00, 15.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:50:50 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(84, 2, 84, 'IT020084', 'Big (Cutting) Disc', 84, '', '', NULL, 61, 0, 0, NULL, NULL, 20.0000, 149, 20.0000, 'Inclusive', 0.00, 20.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:54:17 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(85, 2, 85, 'IT020085', 'Small (Cutting) Disc', 84, '', '', NULL, 61, 0, 0, NULL, NULL, 12.0000, 149, 12.0000, 'Inclusive', 0.00, 12.0000, 8.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:55:31 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(86, 2, 86, 'IT020086', 'Electrode (Grade 10)', 84, '', '', NULL, 64, 0, 0, NULL, NULL, 400.0000, 149, 400.0000, 'Inclusive', 0.00, 400.0000, 442.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '03:57:31 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(87, 2, 87, 'IT020087', 'Electrode (Grade 10)', 84, '', '', NULL, 63, 0, 0, NULL, NULL, 100.0000, 149, 100.0000, 'Inclusive', 0.00, 100.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:00:57 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(88, 2, 88, 'IT020088', 'Electrode (Grade 12)', 84, '', '', NULL, 64, 0, 0, NULL, NULL, 420.0000, 149, 420.0000, 'Inclusive', 0.00, 420.0000, 256.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:02:21 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(89, 2, 89, 'IT020089', 'Electrode (Grade 12)', 84, '', '', NULL, 63, 0, 0, NULL, NULL, 105.0000, 149, 105.0000, 'Inclusive', 0.00, 105.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:07:19 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(90, 2, 90, 'IT020090', '3/4&quot; Inches', 84, '', '', NULL, 65, 0, 0, NULL, NULL, 12.0000, 149, 12.0000, 'Inclusive', 0.00, 12.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:09:02 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(91, 2, 91, 'IT020091', '1&quot; Inches', 84, '', '', NULL, 65, 0, 0, NULL, NULL, 18.0000, 149, 18.0000, 'Inclusive', 0.00, 18.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:09:51 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(92, 2, 92, 'IT020092', '1 &amp; 1/4 Inches', 84, '', '', NULL, 65, 0, 0, NULL, NULL, 30.0000, 149, 30.0000, 'Inclusive', 0.00, 30.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:10:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(93, 2, 93, 'IT020093', '1 &amp; 1/2 Inches', 84, '', '', NULL, 65, 0, 0, NULL, NULL, 45.0000, 149, 45.0000, 'Inclusive', 0.00, 45.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:14:03 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(94, 2, 94, 'IT020094', 'Anti-rust Paint', 84, '', '', NULL, 66, 0, 0, NULL, NULL, 130.0000, 149, 130.0000, 'Inclusive', 0.00, 130.0000, 0.00, NULL, '102.176.75.137', '102-176-75-137-dedicated.vodafone.com.gh', '2023-04-10', '04:19:35 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(95, 2, 95, 'IT020095', '3/4 Galv. square  Thick', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 65.0000, 149, 65.0000, 'Inclusive', 0.00, 65.0000, 2361.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '03:05:37 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(96, 2, 96, 'IT020096', '1&quot; Galv. Square Thick', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 120.0000, 149, 120.0000, 'Inclusive', 0.00, 120.0000, 113.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '03:07:18 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(97, 2, 97, 'IT020097', '1&quot; Galv. Square  Thick (M)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 90.0000, 149, 90.0000, 'Inclusive', 0.00, 90.0000, 510.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '03:09:23 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(98, 2, 98, 'IT020098', '1 &amp; 1/4 Galv. Square (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 180.0000, 149, 180.0000, 'Inclusive', 0.00, 180.0000, 10.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '03:10:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(99, 2, 99, 'IT020099', '2/1 Galv. Rect. (DBS)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 70.0000, 149, 70.0000, 'Inclusive', 0.00, 70.0000, 136.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '03:12:01 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(100, 2, 100, 'IT020100', '2/4 Galv. Rect. (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 650.0000, 149, 650.0000, 'Inclusive', 0.00, 650.0000, 4.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '03:13:01 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(101, 2, 101, 'IT020101', '1 &amp; 1/2 Steel Flat bar (Thick)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 280.0000, 149, 280.0000, 'Inclusive', 0.00, 280.0000, 5.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '05:11:02 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(102, 2, 102, 'IT020102', '1 &amp; 1/2 Steel Angle bar (Thick)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 90.0000, 149, 90.0000, 'Inclusive', 0.00, 90.0000, 69.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '05:25:17 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(103, 2, 103, 'IT020103', '1 &amp; 1/2 Galv. Square (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 150.0000, 149, 150.0000, 'Inclusive', 0.00, 150.0000, 1710.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '05:26:51 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(104, 2, 104, 'IT020104', '3/4 Galv. square (Perfect)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 35.0000, 149, 35.0000, 'Inclusive', 0.00, 35.0000, 103.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '05:28:16 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(105, 2, 105, 'IT020105', '2/1 Galv. Rect. (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 140.0000, 149, 140.0000, 'Inclusive', 0.00, 140.0000, 711.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '05:30:00 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(106, 2, 106, 'IT020106', '2&quot; Galv. Square (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 200.0000, 149, 200.0000, 'Inclusive', 0.00, 200.0000, 2295.00, NULL, '102.176.94.6', '102-176-94-6-dedicated.vodafone.com.gh', '2023-04-12', '05:41:07 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(107, 2, 107, 'IT020107', '2/4  Steel Rect. Pipe (Thick)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 480.0000, 149, 480.0000, 'Inclusive', 0.00, 480.0000, 3.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '12:02:25 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(108, 2, 108, 'IT020108', '3&quot; Galv. Round pipe (Medium)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 550.0000, 149, 550.0000, 'Inclusive', 0.00, 550.0000, 2.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '01:51:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(109, 2, 109, 'IT020109', '2&quot; Galv. Square (Medium)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 180.0000, 149, 180.0000, 'Inclusive', 0.00, 180.0000, 85.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '01:53:11 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(110, 2, 110, 'IT020110', '2&quot; Galv. Round pipe (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 280.0000, 149, 280.0000, 'Inclusive', 0.00, 280.0000, 58.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '02:52:29 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(111, 2, 111, 'IT020111', '2 &amp; 1/2 Galv. Square', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 280.0000, 149, 280.0000, 'Inclusive', 0.00, 280.0000, 27.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '03:56:51 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(112, 2, 112, 'IT020112', 'Hacksaw Blade', 84, '', '', NULL, 61, 0, 0, NULL, NULL, 10.0000, 149, 10.0000, 'Inclusive', 0.00, 10.0000, 23.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '05:09:29 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(113, 2, 113, 'IT020113', 'Galv. Egg Plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 280.0000, 149, 280.0000, 'Inclusive', 0.00, 280.0000, 14.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '05:15:04 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(114, 2, 114, 'IT020114', 'Egg Plate steel', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 250.0000, 149, 250.0000, 'Inclusive', 0.00, 250.0000, 0.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '05:16:04 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(115, 2, 115, 'IT020115', '3/4*1 &amp; 1/2 Galv. Rect. (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 125.0000, 149, 125.0000, 'Inclusive', 0.00, 125.0000, 32.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '05:22:47 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(116, 2, 116, 'IT020116', '3/4 Galv. Round pipe (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 95.0000, 149, 95.0000, 'Inclusive', 0.00, 95.0000, 4.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '05:27:02 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(117, 2, 117, 'IT020117', '3/4  Steel Square pipe (Thick)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 60.0000, 149, 60.0000, 'Inclusive', 0.00, 60.0000, 5.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '05:32:58 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(118, 2, 118, 'IT020118', '2&quot; Steel Angle bar (Thick)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 170.0000, 149, 170.0000, 'Inclusive', 0.00, 170.0000, 82.00, NULL, '102.176.94.175', '102-176-94-175-dedicated.vodafone.com.gh', '2023-04-13', '06:01:47 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(119, 2, 119, 'IT020119', '1&quot; Galv. Round pipe (Thread)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 80.0000, 149, 80.0000, 'Inclusive', 0.00, 80.0000, 4.00, NULL, '102.176.94.207', '102-176-94-207-dedicated.vodafone.com.gh', '2023-04-14', '02:55:17 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(120, 2, 120, 'IT020120', '4&quot; Galv. Round pipe (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 750.0000, 149, 750.0000, 'Inclusive', 0.00, 750.0000, 2.00, NULL, '102.176.94.207', '102-176-94-207-dedicated.vodafone.com.gh', '2023-04-14', '02:56:08 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(121, 2, 121, 'IT020121', '1 &amp; 1/2 Galv. Round pipe (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 300.0000, 149, 300.0000, 'Inclusive', 0.00, 300.0000, 36.00, NULL, '102.176.94.207', '102-176-94-207-dedicated.vodafone.com.gh', '2023-04-14', '03:44:26 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(122, 2, 122, 'IT020122', '0.8mm Steel Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 140.0000, 149, 140.0000, 'Inclusive', 1.00, 142.0000, 2600.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '04:45:00 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(123, 2, 123, 'IT020123', '5mm steel Checkered Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1650.0000, 149, 1650.0000, 'Inclusive', 12.00, 1850.0000, 10.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '04:52:20 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(124, 2, 124, 'IT020124', '3&quot; Angle bar (70*70) 5mm', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 435.0000, 149, 435.0000, 'Inclusive', 15.00, 500.0000, 100.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '04:54:56 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(125, 2, 125, 'IT020125', '8mm Steel Plate (4*8)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 2820.0000, 149, 2820.0000, 'Inclusive', 6.00, 3000.0000, 6.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '04:56:53 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(126, 2, 126, 'IT020126', '10mm Steel Plate (4*8)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 3390.0000, 149, 3390.0000, 'Inclusive', 6.00, 3600.0000, 8.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '04:58:26 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(127, 2, 127, 'IT020127', '12mm Steel Plate (4*8)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 4400.0000, 149, 4400.0000, 'Inclusive', 14.00, 5000.0000, 4.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '04:59:40 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(128, 2, 128, 'IT020128', '16mm Steel Plate (4*8)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 5530.0000, 149, 5530.0000, 'Inclusive', 8.00, 6000.0000, 8.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '05:01:16 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(129, 2, 129, 'IT020129', '1&quot; Galv. Round Pipe  (Thick)2mm', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 130.0000, 149, 130.0000, 'Inclusive', 15.00, 150.0000, 200.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '05:57:23 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(130, 2, 130, 'IT020130', '3/4 Galv. Square (Local)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 23.5000, 149, 23.5000, 'Inclusive', 4.00, 24.5000, 1000.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '06:06:28 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(131, 2, 131, 'IT020131', '457*191 (l- Beam)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 17500.0000, 149, 17500.0000, 'Inclusive', 6.00, 18500.0000, 1.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '06:10:25 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(132, 2, 132, 'IT020132', '16mm Smooth rod', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 170.0000, 149, 170.0000, 'Inclusive', 29.00, 220.0000, 6.00, NULL, '154.160.2.11', '154.160.2.11', '2023-04-18', '06:13:50 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(133, 2, 133, 'IT020133', '3mm Checkered Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1020.0000, 149, 1020.0000, 'Inclusive', 13.00, 1150.0000, 25.00, NULL, '154.160.9.28', '154.160.9.28', '2023-04-19', '08:33:54 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(134, 2, 134, 'IT020134', '4mm Checkered Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1250.0000, 149, 1250.0000, 'Inclusive', 16.00, 1450.0000, 35.00, NULL, '154.160.9.28', '154.160.9.28', '2023-04-19', '08:35:31 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(135, 2, 135, 'IT020135', '3&quot; Angle bar (75*75*6mm)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 530.0000, 149, 530.0000, 'Inclusive', 17.00, 620.0000, 20.00, NULL, '154.160.9.28', '154.160.9.28', '2023-04-19', '08:47:42 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(136, 2, 136, 'IT020136', '100*6mm Flat bar', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 450.0000, 149, 450.0000, 'Inclusive', 22.00, 550.0000, 20.00, NULL, '154.160.9.28', '154.160.9.28', '2023-04-19', '08:49:13 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(137, 2, 137, 'IT020137', '25*5mm Gratings', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 4650.0000, 149, 4650.0000, 'Inclusive', 18.00, 5500.0000, 4.00, NULL, '154.160.23.40', '154.160.23.40', '2023-04-19', '09:48:38 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(138, 2, 138, 'IT020138', '1&quot; Galv. Square (1.5mm )', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 97.0000, 149, 97.0000, 'Inclusive', 24.00, 120.0000, 200.00, NULL, '154.160.5.125', '154.160.5.125', '2023-04-19', '10:10:15 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(139, 2, 139, 'IT020139', '2&quot; Flat bar (50*5mm)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 128.0000, 149, 128.0000, 'Inclusive', 17.00, 150.0000, 100.00, NULL, '154.160.5.125', '154.160.5.125', '2023-04-19', '10:12:12 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(140, 2, 140, 'IT020140', '80*40 Galv. Rectangle (1.5mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 155.0000, 149, 155.0000, 'Inclusive', 29.00, 200.0000, 394.00, NULL, '154.160.5.125', '154.160.5.125', '2023-04-19', '10:20:19 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(141, 2, 141, 'IT020141', '80*40 Galv. Rectangle (2mm)', 83, '', '', NULL, 62, 0, 0, NULL, NULL, 230.0000, 149, 230.0000, 'Inclusive', 17.00, 270.0000, 1.00, NULL, '154.160.5.125', '154.160.5.125', '2023-04-19', '10:22:29 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(142, 2, 142, 'IT020142', '1&amp; 1/2 Galv. Square (40*40 Galv. sq.)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 62.0000, 149, 62.0000, 'Inclusive', 0.00, 62.0000, 1.00, NULL, '154.160.6.36', '154.160.6.36', '2023-04-19', '11:02:33 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(143, 2, 143, 'IT020143', '1&amp; 1/2 Galv. Square Thick (2mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 160.0000, 149, 160.0000, 'Inclusive', 0.00, 160.0000, 300.00, NULL, '154.160.6.36', '154.160.6.36', '2023-04-19', '11:32:57 am', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(144, 2, 144, 'IT020144', '5&quot; U-Channel 120mm', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 540.0000, 149, 540.0000, 'Inclusive', 48.00, 800.0000, 200.00, NULL, '154.160.5.51', '154.160.5.51', '2023-04-19', '03:38:47 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(145, 2, 145, 'IT020145', '4&quot; U-Channel 100mm', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 465.0000, 149, 465.0000, 'Inclusive', 29.00, 600.0000, 400.00, NULL, '154.160.5.51', '154.160.5.51', '2023-04-19', '03:40:13 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(146, 2, 146, 'IT020146', '1.5mm Galv. Plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 415.0000, 149, 415.0000, 'Inclusive', 0.00, 415.0000, 3000.00, NULL, '154.160.5.51', '154.160.5.51', '2023-04-19', '03:41:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(147, 2, 147, 'IT020147', '1&quot; Galv. Square pipe (1.15mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 83.0000, 149, 83.0000, 'Inclusive', 14.00, 95.0000, 2048.00, NULL, '154.160.5.51', '154.160.5.51', '2023-04-19', '04:04:04 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(148, 2, 148, 'IT020148', '2&quot; Galv. Square pipe (1.3mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 180.0000, 149, 180.0000, 'Inclusive', 22.00, 220.0000, 1120.00, NULL, '154.160.1.46', '154.160.1.46', '2023-04-19', '04:10:24 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(149, 2, 149, 'IT020149', '0.9mm Galv. Plate', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 168.0000, 149, 168.0000, 'Inclusive', 28.00, 215.0000, 1450.00, NULL, '41.204.44.141', '41-204-44-141-dedicated.4u.com.gh', '2023-04-19', '04:56:28 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000);
INSERT INTO `db_items` (`id`, `store_id`, `count_id`, `item_code`, `item_name`, `category_id`, `sku`, `hsn`, `sac`, `unit_id`, `alert_qty`, `brand_id`, `lot_number`, `expire_date`, `price`, `tax_id`, `purchase_price`, `tax_type`, `profit_margin`, `sales_price`, `stock`, `item_image`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `company_id`, `status`, `discount_type`, `discount`, `service_bit`, `seller_points`, `custom_barcode`, `description`, `item_group`, `parent_id`, `variant_id`, `child_bit`, `mrp`) VALUES
(150, 2, 150, 'IT020150', '1.5mm Galv. Plate (Heavy)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 403.2000, 149, 403.2000, 'Inclusive', 17.00, 470.0000, 800.00, NULL, '41.204.44.141', '41-204-44-141-dedicated.4u.com.gh', '2023-04-19', '04:58:11 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(151, 2, 151, 'IT020151', '100*50 U-Channel(L)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 475.2000, 149, 475.2000, 'Inclusive', 9.00, 520.0000, 200.00, NULL, '41.204.44.141', '41-204-44-141-dedicated.4u.com.gh', '2023-04-19', '04:59:12 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(152, 2, 152, 'IT020152', '1.5mm Steel Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 375.0000, 149, 375.0000, 'Inclusive', 7.00, 400.0000, 170.00, NULL, '41.204.44.141', '41-204-44-141-dedicated.4u.com.gh', '2023-04-19', '05:06:04 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(154, 2, 154, 'IT020154', '3/4 Galv. square (1.15mm)', 83, '', '', NULL, 62, 0, 0, NULL, NULL, 55.5000, 149, 55.5000, 'Inclusive', 35.00, 75.0000, 3871.00, NULL, '41.204.44.141', '41-204-44-141-dedicated.4u.com.gh', '2023-04-19', '05:23:03 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(155, 2, 155, 'IT020155', '80*50 U-Channel (L)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 414.0000, 149, 414.0000, 'Inclusive', 16.00, 480.0000, 200.00, NULL, '41.204.44.141', '41-204-44-141-dedicated.4u.com.gh', '2023-04-19', '05:28:21 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(156, 2, 156, 'IT020156', '0.9mm Steel Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 142.0000, 149, 142.0000, 'Inclusive', 0.00, 142.0000, 1000.00, NULL, '154.160.4.89', '154.160.4.89', '2023-04-19', '06:03:39 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(157, 2, 157, 'IT020157', '1&amp; 1/2 Galv. Square  (1.15mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 110.4000, 149, 110.4000, 'Inclusive', 36.00, 150.0000, 1800.00, NULL, '154.160.4.89', '154.160.4.89', '2023-04-19', '06:16:42 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(158, 2, 158, 'IT020158', '1&amp; 1/2 Galv. Square (1.3mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 123.0000, 149, 123.0000, 'Inclusive', 46.00, 180.0000, 2270.00, NULL, '154.160.4.89', '154.160.4.89', '2023-04-19', '06:20:50 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(159, 2, 159, 'IT020159', '40*80 Galv. Rect. (1.15mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 177.0000, 149, 177.0000, 'Inclusive', 13.00, 200.0000, 400.00, NULL, '154.160.4.89', '154.160.4.89', '2023-04-19', '06:30:31 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(160, 2, 160, 'IT020160', '3/4*1&amp; 1/2 Galv. Rect. (1.2mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 90.3000, 149, 90.3000, 'Inclusive', 38.00, 125.0000, 1000.00, NULL, '154.160.4.89', '154.160.4.89', '2023-04-19', '06:32:35 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(161, 2, 161, 'IT020161', '3/4 Galv. Square (1.3mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 62.0000, 149, 62.0000, 'Inclusive', 21.00, 75.0000, 359.00, NULL, '154.160.2.158', '154.160.2.158', '2023-04-20', '02:24:27 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(162, 2, 162, 'IT020162', '1&quot; Galv. Square (1mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 58.0000, 149, 58.0000, 'Inclusive', 55.00, 90.0000, 1700.00, NULL, '154.160.2.158', '154.160.2.158', '2023-04-20', '02:28:54 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(163, 2, 163, 'IT020163', '1&amp; 1/2 Galv. Square (1mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 99.0000, 149, 99.0000, 'Inclusive', 41.00, 140.0000, 653.00, NULL, '154.160.2.158', '154.160.2.158', '2023-04-20', '02:30:15 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(164, 2, 164, 'IT020164', '2&quot; Galv. Square (1.15mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 139.2000, 149, 139.2000, 'Inclusive', 29.00, 180.0000, 1279.00, NULL, '154.160.3.155', '154.160.3.155', '2023-04-20', '02:42:47 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(165, 2, 165, 'IT020165', '2/1 Galv. Rect. (1.15)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 112.5000, 149, 112.5000, 'Inclusive', 29.00, 145.0000, 1500.00, NULL, '154.160.3.155', '154.160.3.155', '2023-04-20', '02:44:32 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(166, 2, 166, 'IT020166', '40*80Galv. Rect.', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 179.6000, 149, 179.6000, 'Inclusive', 11.00, 200.0000, 300.00, NULL, '154.160.3.155', '154.160.3.155', '2023-04-20', '02:58:44 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(167, 2, 167, 'IT020167', '3/4 Galv. Flat bar (Thick)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 70.0000, 149, 70.0000, 'Inclusive', 0.00, 70.0000, 20.00, NULL, '154.160.6.56', '154.160.6.56', '2023-04-20', '04:14:20 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(168, 2, 168, 'IT020168', '1&quot; Galv. Square (DESIGN)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 45.0000, 149, 45.0000, 'Inclusive', 0.00, 45.0000, 450.00, NULL, '154.160.4.39', '154.160.4.39', '2023-04-21', '02:55:03 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(169, 2, 169, 'IT020169', '1&amp; 1/2 Galv. Square (DESIGN)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 72.0000, 149, 72.0000, 'Inclusive', 0.00, 72.0000, 150.00, NULL, '154.160.4.39', '154.160.4.39', '2023-04-21', '02:56:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(170, 2, 170, 'IT020170', '2&quot; Ga lv. Square (DESIGN)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 110.0000, 149, 110.0000, 'Inclusive', 0.00, 110.0000, 50.00, NULL, '41.215.163.175', '41.215.163.175', '2023-04-21', '02:59:43 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(171, 2, 171, 'IT020171', '40*80 Galv. Rect. (1.3mm)', 83, '', '', NULL, 62, 0, 0, NULL, NULL, 190.0000, 149, 190.0000, 'Inclusive', 0.00, 190.0000, 1500.00, NULL, '102.176.94.115', '102-176-94-115-dedicated.vodafone.com.gh', '2023-04-24', '04:40:15 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(172, 2, 172, 'IT020172', '3&quot; Galv. Pipe (Threaded)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 340.0000, 149, 340.0000, 'Inclusive', 0.00, 340.0000, 111.00, NULL, '102.176.94.115', '102-176-94-115-dedicated.vodafone.com.gh', '2023-04-24', '05:08:53 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(173, 2, 173, 'IT020173', '1&amp; 1/2 Galv. Square (DESIGN) 1.3mm', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 136.5000, 149, 136.5000, 'Inclusive', 0.00, 136.5000, 200.00, NULL, '154.160.4.195', '154.160.4.195', '2023-04-26', '03:13:48 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(174, 2, 174, 'IT020174', '3&quot; Galv. Square Pipe', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 850.0000, 149, 850.0000, 'Inclusive', 0.00, 850.0000, 21.00, NULL, '154.160.10.139', '154.160.10.139', '2023-04-26', '03:34:05 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(175, 2, 175, 'IT020175', '1&amp; 1/2*3 Galv. Rect. Pipe Thick', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 400.0000, 149, 400.0000, 'Inclusive', 0.00, 400.0000, 2.00, NULL, '154.160.0.190', 'dyn-as-mobile-154-160-0-190.mtn.com.gh', '2023-04-28', '06:04:23 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(176, 2, 176, 'IT020176', '3&quot; Galv. Round Pipe (Threaded)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 330.0000, 149, 330.0000, 'Inclusive', 0.00, 330.0000, 1.00, NULL, '154.160.2.154', 'dyn-as-mobile-154-160-2-154.mtn.com.gh', '2023-05-04', '04:05:49 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(177, 2, 177, 'IT020177', '2&quot; Steel Flat Bar Thick', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 150.0000, 149, 150.0000, 'Inclusive', 0.00, 150.0000, 4.00, NULL, '102.176.94.35', '102-176-94-35-dedicated.vodafone.com.gh', '2023-05-04', '07:38:24 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(178, 2, 178, 'IT020178', '80*40 steel rectangle', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 40.0000, 151, 40.0000, 'Inclusive', 100.00, 80.0000, 1068.00, NULL, '102.176.94.35', '102-176-94-35-dedicated.vodafone.com.gh', '2023-05-04', '08:54:37 pm', 'Alhassan', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(179, 2, 179, 'IT020179', '60*40 steel rectangular', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 40.0000, 151, 40.0000, 'Inclusive', 50.00, 60.0000, 380.00, NULL, '102.176.94.35', '102-176-94-35-dedicated.vodafone.com.gh', '2023-05-04', '08:55:35 pm', 'Alhassan', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(180, 2, 180, 'IT020180', '20/25/30 steel mixed pipes', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 20.0000, 151, 20.0000, 'Inclusive', 25.00, 25.0000, 931.00, NULL, '102.176.94.35', '102-176-94-35-dedicated.vodafone.com.gh', '2023-05-04', '08:56:41 pm', 'Alhassan', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(181, 2, 181, 'IT020181', '1&amp;1/2 steel angle bar (T)', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 50.0000, 151, 50.0000, 'Inclusive', 100.00, 100.0000, 80.00, NULL, '102.176.94.35', '102-176-94-35-dedicated.vodafone.com.gh', '2023-05-04', '09:02:05 pm', 'Alhassan', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(182, 2, 182, 'IT020182', '2-Bedroom Apartment', 85, NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, 500.0000, 152, 500.0000, 'Inclusive', NULL, 500.0000, NULL, NULL, '102.176.94.35', '102-176-94-35-dedicated.vodafone.com.gh', '2023-05-04', '09:09:45 pm', 'Alhassan', NULL, 1, 'Percentage', 0.00, 1, 0.00, '', '', 'Single', NULL, NULL, 0, NULL),
(183, 2, 183, 'IT020183', '6mm Steel Plate', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 1675.0000, 149, 1675.0000, 'Inclusive', 0.00, 1675.0000, 10.00, NULL, '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', '2023-05-06', '01:15:25 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(184, 2, 184, 'IT020184', '3&quot; U- Channel Thick', 82, '', '', NULL, 61, 0, 0, NULL, NULL, 440.0000, 149, 440.0000, 'Inclusive', 18.18, 520.0000, 50.00, NULL, '154.160.1.9', 'dyn-as-mobile-154-160-1-9.mtn.com.gh', '2023-05-06', '01:31:59 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(185, 2, 185, 'IT020185', '2/4 Galv rectangle (1.3mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 273.0000, 149, 273.0000, 'Inclusive', 46.52, 400.0000, 106.00, NULL, '102.176.75.154', '102-176-75-154-dedicated.vodafone.com.gh', '2023-05-06', '05:53:38 pm', 'Alhassan', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000),
(186, 2, 186, 'IT020186', '3/4 Galv. square (1mm)', 83, '', '', NULL, 61, 0, 0, NULL, NULL, 44.2000, 149, 44.2000, 'Inclusive', 58.37, 70.0000, 400.00, NULL, '102.176.75.154', '102-176-75-154-dedicated.vodafone.com.gh', '2023-05-06', '05:57:32 pm', 'Gloria', NULL, 1, 'Percentage', 0.00, 0, 0.00, '', '', 'Single', NULL, NULL, 0, 0.0000);

-- --------------------------------------------------------

--
-- Table structure for table `db_languages`
--

CREATE TABLE `db_languages` (
  `id` int(5) NOT NULL,
  `language` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_languages`
--

INSERT INTO `db_languages` (`id`, `language`, `status`) VALUES
(1, 'English', 1),
(2, 'Russian', 1),
(3, 'Spanish', 1),
(4, 'Arabic', 1),
(5, 'Bangla', 1),
(6, 'French', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_package`
--

CREATE TABLE `db_package` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `package_type` varchar(50) DEFAULT NULL,
  `package_code` varchar(20) DEFAULT NULL,
  `package_name` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `monthly_price` double(20,2) DEFAULT NULL,
  `annual_price` double(20,2) DEFAULT NULL,
  `trial_days` int(10) DEFAULT NULL,
  `max_users` int(10) DEFAULT NULL,
  `max_items` int(10) DEFAULT NULL,
  `max_invoices` int(10) DEFAULT NULL,
  `max_warehouses` int(10) DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `plan_type` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_package`
--

INSERT INTO `db_package` (`id`, `store_id`, `package_type`, `package_code`, `package_name`, `description`, `monthly_price`, `annual_price`, `trial_days`, `max_users`, `max_items`, `max_invoices`, `max_warehouses`, `expire_date`, `system_ip`, `system_name`, `created_date`, `created_time`, `created_by`, `status`, `plan_type`) VALUES
(1, 1, 'Free', NULL, 'Free', 'Test description', 0.00, 0.00, 10, 2, 20, 20, 2, '2021-01-14', '127.0.0.1', 'LAPTOP-I5OUIM4R', '2021-01-13', '06:37:21 pm', 'admin', 1, NULL),
(2, 1, 'Paid', NULL, 'Regular', 'Test description', 250.00, 2000.00, 15, 20, 200, 200, 20, NULL, '127.0.0.1', 'LAPTOP-I5OUIM4R', '2021-01-13', '06:39:23 pm', 'admin', 1, NULL),
(3, 1, 'Paid', NULL, 'Ultimate', 'Description', 500.00, 5000.00, 15, -1, -1, -1, -1, NULL, '127.0.0.1', 'LAPTOP-I5OUIM4R', '2021-01-24', '12:35:30 pm', 'admin', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_paymenttypes`
--

CREATE TABLE `db_paymenttypes` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_paypal`
--

CREATE TABLE `db_paypal` (
  `id` int(5) NOT NULL,
  `store_id` int(10) DEFAULT NULL,
  `sandbox` int(1) DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_paypal`
--

INSERT INTO `db_paypal` (`id`, `store_id`, `sandbox`, `email`, `updated_at`, `updated_by`, `status`) VALUES
(1, 1, 1, '', '2021-02-22', 'Admin', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_paypalpaylog`
--

CREATE TABLE `db_paypalpaylog` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `txn_id` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_gross` float(10,2) NOT NULL,
  `currency_code` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payer_email` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_status` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_permissions`
--

CREATE TABLE `db_permissions` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `permissions` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_permissions`
--

INSERT INTO `db_permissions` (`id`, `store_id`, `role_id`, `permissions`) VALUES
(4414, 1, 17, 'items_add'),
(4415, 1, 17, 'items_edit'),
(4416, 1, 17, 'items_delete'),
(4417, 1, 17, 'items_view'),
(4418, 1, 17, 'import_items'),
(4419, 1, 17, 'brand_add'),
(4420, 1, 17, 'brand_edit'),
(4421, 1, 17, 'brand_delete'),
(4422, 1, 17, 'brand_view'),
(4423, 1, 17, 'customers_add'),
(4424, 1, 17, 'customers_edit'),
(4425, 1, 17, 'customers_delete'),
(4426, 1, 17, 'customers_view'),
(4427, 1, 17, 'sales_add'),
(4428, 1, 17, 'sales_edit'),
(4429, 1, 17, 'sales_delete'),
(4430, 1, 17, 'sales_view'),
(4431, 1, 17, 'sales_payment_view'),
(4432, 1, 17, 'sales_payment_add'),
(4433, 1, 17, 'sales_payment_delete'),
(4434, 1, 17, 'sales_report'),
(4435, 1, 17, 'sales_payments_report'),
(4436, 1, 17, 'items_category_add'),
(4437, 1, 17, 'items_category_edit'),
(4438, 1, 17, 'items_category_delete'),
(4439, 1, 17, 'items_category_view'),
(4440, 1, 17, 'print_labels'),
(4441, 1, 17, 'dashboard_view'),
(4442, 1, 17, 'dashboard_info_box_1'),
(4443, 1, 17, 'dashboard_info_box_2'),
(4444, 1, 17, 'dashboard_pur_sal_chart'),
(4445, 1, 17, 'dashboard_recent_items'),
(4446, 1, 17, 'dashboard_stock_alert'),
(4447, 1, 17, 'dashboard_trending_items_chart'),
(4448, 1, 17, 'sales_return_add'),
(4449, 1, 17, 'sales_return_edit'),
(4450, 1, 17, 'sales_return_delete'),
(4451, 1, 17, 'sales_return_view'),
(4452, 1, 17, 'sales_return_report'),
(4453, 1, 17, 'sales_return_payment_view'),
(4454, 1, 17, 'sales_return_payment_add'),
(4455, 1, 17, 'sales_return_payment_delete'),
(4456, 1, 17, 'payment_types_add'),
(4457, 1, 17, 'payment_types_edit'),
(4458, 1, 17, 'payment_types_delete'),
(4459, 1, 17, 'payment_types_view'),
(4460, 1, 17, 'import_customers'),
(4461, 1, 17, 'stock_transfer_add'),
(4462, 1, 17, 'stock_transfer_edit'),
(4463, 1, 17, 'stock_transfer_delete'),
(4464, 1, 17, 'stock_transfer_view'),
(4465, 1, 17, 'seller_points_report'),
(4466, 1, 17, 'services_add'),
(4467, 1, 17, 'services_edit'),
(4468, 1, 17, 'services_delete'),
(4469, 1, 17, 'services_view'),
(4470, 1, 17, 'import_services'),
(4471, 1, 17, 'stock_adjustment_add'),
(4472, 1, 17, 'stock_adjustment_edit'),
(4473, 1, 17, 'stock_adjustment_delete'),
(4474, 1, 17, 'stock_adjustment_view'),
(4475, 1, 17, 'variant_add'),
(4476, 1, 17, 'variant_edit'),
(4477, 1, 17, 'variant_delete'),
(4478, 1, 17, 'variant_view'),
(4479, 1, 17, 'accounts_add'),
(4480, 1, 17, 'accounts_edit'),
(4481, 1, 17, 'accounts_delete'),
(4482, 1, 17, 'accounts_view'),
(4483, 1, 17, 'money_transfer_add'),
(4484, 1, 17, 'money_transfer_edit'),
(4485, 1, 17, 'money_transfer_delete'),
(4486, 1, 17, 'money_transfer_view'),
(4487, 1, 17, 'money_deposit_add'),
(4488, 1, 17, 'money_deposit_edit'),
(4489, 1, 17, 'money_deposit_delete'),
(4490, 1, 17, 'money_deposit_view'),
(4491, 1, 17, 'sales_tax_report'),
(4492, 1, 18, 'tax_add'),
(4493, 1, 18, 'tax_edit'),
(4494, 1, 18, 'tax_delete'),
(4495, 1, 18, 'tax_view'),
(4496, 1, 18, 'units_add'),
(4497, 1, 18, 'units_edit'),
(4498, 1, 18, 'units_delete'),
(4499, 1, 18, 'units_view'),
(4500, 1, 18, 'items_add'),
(4501, 1, 18, 'items_edit'),
(4502, 1, 18, 'items_delete'),
(4503, 1, 18, 'items_view'),
(4504, 1, 18, 'import_items'),
(4505, 1, 18, 'brand_add'),
(4506, 1, 18, 'brand_edit'),
(4507, 1, 18, 'brand_delete'),
(4508, 1, 18, 'brand_view'),
(4509, 1, 18, 'suppliers_add'),
(4510, 1, 18, 'suppliers_edit'),
(4511, 1, 18, 'suppliers_delete'),
(4512, 1, 18, 'suppliers_view'),
(4513, 1, 18, 'purchase_add'),
(4514, 1, 18, 'purchase_edit'),
(4515, 1, 18, 'purchase_delete'),
(4516, 1, 18, 'purchase_view'),
(4517, 1, 18, 'purchase_report'),
(4518, 1, 18, 'purchase_payments_report'),
(4519, 1, 18, 'items_category_add'),
(4520, 1, 18, 'items_category_edit'),
(4521, 1, 18, 'items_category_delete'),
(4522, 1, 18, 'items_category_view'),
(4523, 1, 18, 'print_labels'),
(4524, 1, 18, 'dashboard_view'),
(4525, 1, 18, 'dashboard_info_box_1'),
(4526, 1, 18, 'dashboard_info_box_2'),
(4527, 1, 18, 'dashboard_pur_sal_chart'),
(4528, 1, 18, 'dashboard_recent_items'),
(4529, 1, 18, 'dashboard_stock_alert'),
(4530, 1, 18, 'dashboard_trending_items_chart'),
(4531, 1, 18, 'purchase_return_add'),
(4532, 1, 18, 'purchase_return_edit'),
(4533, 1, 18, 'purchase_return_delete'),
(4534, 1, 18, 'purchase_return_view'),
(4535, 1, 18, 'purchase_return_report'),
(4536, 1, 18, 'purchase_return_payment_view'),
(4537, 1, 18, 'purchase_return_payment_add'),
(4538, 1, 18, 'purchase_return_payment_delete'),
(4539, 1, 18, 'purchase_payment_view'),
(4540, 1, 18, 'purchase_payment_add'),
(4541, 1, 18, 'purchase_payment_delete'),
(4542, 1, 18, 'payment_types_add'),
(4543, 1, 18, 'payment_types_edit'),
(4544, 1, 18, 'payment_types_delete'),
(4545, 1, 18, 'payment_types_view'),
(4546, 1, 18, 'import_suppliers'),
(4547, 1, 18, 'stock_transfer_add'),
(4548, 1, 18, 'stock_transfer_edit'),
(4549, 1, 18, 'stock_transfer_delete'),
(4550, 1, 18, 'stock_transfer_view'),
(4551, 1, 18, 'warehouse_add'),
(4552, 1, 18, 'warehouse_edit'),
(4553, 1, 18, 'warehouse_delete'),
(4554, 1, 18, 'warehouse_view'),
(4555, 1, 18, 'services_add'),
(4556, 1, 18, 'services_edit'),
(4557, 1, 18, 'services_delete'),
(4558, 1, 18, 'services_view'),
(4559, 1, 18, 'import_services'),
(4560, 1, 18, 'stock_adjustment_add'),
(4561, 1, 18, 'stock_adjustment_edit'),
(4562, 1, 18, 'stock_adjustment_delete'),
(4563, 1, 18, 'stock_adjustment_view'),
(4564, 1, 18, 'variant_add'),
(4565, 1, 18, 'variant_edit'),
(4566, 1, 18, 'variant_delete'),
(4567, 1, 18, 'variant_view'),
(4568, 1, 18, 'accounts_add'),
(4569, 1, 18, 'accounts_edit'),
(4570, 1, 18, 'accounts_delete'),
(4571, 1, 18, 'accounts_view'),
(4572, 1, 18, 'money_transfer_add'),
(4573, 1, 18, 'money_transfer_edit'),
(4574, 1, 18, 'money_transfer_delete'),
(4575, 1, 18, 'money_transfer_view'),
(4576, 1, 18, 'money_deposit_add'),
(4577, 1, 18, 'money_deposit_edit'),
(4578, 1, 18, 'money_deposit_delete'),
(4579, 1, 18, 'money_deposit_view'),
(4580, 1, 18, 'purchase_tax_report'),
(5818, 1, 2, 'users_add'),
(5819, 1, 2, 'users_edit'),
(5820, 1, 2, 'users_delete'),
(5821, 1, 2, 'users_view'),
(5822, 1, 2, 'tax_add'),
(5823, 1, 2, 'tax_edit'),
(5824, 1, 2, 'tax_delete'),
(5825, 1, 2, 'tax_view'),
(5826, 1, 2, 'store_edit'),
(5827, 1, 2, 'units_add'),
(5828, 1, 2, 'units_edit'),
(5829, 1, 2, 'units_delete'),
(5830, 1, 2, 'units_view'),
(5831, 1, 2, 'roles_add'),
(5832, 1, 2, 'roles_edit'),
(5833, 1, 2, 'roles_delete'),
(5834, 1, 2, 'roles_view'),
(5835, 1, 2, 'expense_add'),
(5836, 1, 2, 'expense_edit'),
(5837, 1, 2, 'expense_delete'),
(5838, 1, 2, 'expense_view'),
(5839, 1, 2, 'items_add'),
(5840, 1, 2, 'items_edit'),
(5841, 1, 2, 'items_delete'),
(5842, 1, 2, 'items_view'),
(5843, 1, 2, 'import_items'),
(5844, 1, 2, 'brand_add'),
(5845, 1, 2, 'brand_edit'),
(5846, 1, 2, 'brand_delete'),
(5847, 1, 2, 'brand_view'),
(5848, 1, 2, 'suppliers_add'),
(5849, 1, 2, 'suppliers_edit'),
(5850, 1, 2, 'suppliers_delete'),
(5851, 1, 2, 'suppliers_view'),
(5852, 1, 2, 'customers_add'),
(5853, 1, 2, 'customers_edit'),
(5854, 1, 2, 'customers_delete'),
(5855, 1, 2, 'customers_view'),
(5856, 1, 2, 'purchase_add'),
(5857, 1, 2, 'purchase_edit'),
(5858, 1, 2, 'purchase_delete'),
(5859, 1, 2, 'purchase_view'),
(5860, 1, 2, 'sales_add'),
(5861, 1, 2, 'sales_edit'),
(5862, 1, 2, 'sales_delete'),
(5863, 1, 2, 'sales_view'),
(5864, 1, 2, 'sales_payment_view'),
(5865, 1, 2, 'sales_payment_add'),
(5866, 1, 2, 'sales_payment_delete'),
(5867, 1, 2, 'sales_report'),
(5868, 1, 2, 'purchase_report'),
(5869, 1, 2, 'expense_report'),
(5870, 1, 2, 'profit_report'),
(5871, 1, 2, 'stock_report'),
(5872, 1, 2, 'item_sales_report'),
(5873, 1, 2, 'purchase_payments_report'),
(5874, 1, 2, 'sales_payments_report'),
(5875, 1, 2, 'items_category_add'),
(5876, 1, 2, 'items_category_edit'),
(5877, 1, 2, 'items_category_delete'),
(5878, 1, 2, 'items_category_view'),
(5879, 1, 2, 'print_labels'),
(5880, 1, 2, 'expense_category_add'),
(5881, 1, 2, 'expense_category_edit'),
(5882, 1, 2, 'expense_category_delete'),
(5883, 1, 2, 'expense_category_view'),
(5884, 1, 2, 'dashboard_view'),
(5885, 1, 2, 'dashboard_info_box_1'),
(5886, 1, 2, 'dashboard_info_box_2'),
(5887, 1, 2, 'dashboard_pur_sal_chart'),
(5888, 1, 2, 'dashboard_recent_items'),
(5889, 1, 2, 'dashboard_stock_alert'),
(5890, 1, 2, 'dashboard_trending_items_chart'),
(5891, 1, 2, 'send_sms'),
(5892, 1, 2, 'sms_template_edit'),
(5893, 1, 2, 'sms_template_view'),
(5894, 1, 2, 'sms_api_view'),
(5895, 1, 2, 'sms_api_edit'),
(5896, 1, 2, 'purchase_return_add'),
(5897, 1, 2, 'purchase_return_edit'),
(5898, 1, 2, 'purchase_return_delete'),
(5899, 1, 2, 'purchase_return_view'),
(5900, 1, 2, 'purchase_return_report'),
(5901, 1, 2, 'sales_return_add'),
(5902, 1, 2, 'sales_return_edit'),
(5903, 1, 2, 'sales_return_delete'),
(5904, 1, 2, 'sales_return_view'),
(5905, 1, 2, 'sales_return_report'),
(5906, 1, 2, 'sales_return_payment_view'),
(5907, 1, 2, 'sales_return_payment_add'),
(5908, 1, 2, 'sales_return_payment_delete'),
(5909, 1, 2, 'purchase_return_payment_view'),
(5910, 1, 2, 'purchase_return_payment_add'),
(5911, 1, 2, 'purchase_return_payment_delete'),
(5912, 1, 2, 'purchase_payment_view'),
(5913, 1, 2, 'purchase_payment_add'),
(5914, 1, 2, 'purchase_payment_delete'),
(5915, 1, 2, 'payment_types_add'),
(5916, 1, 2, 'payment_types_edit'),
(5917, 1, 2, 'payment_types_delete'),
(5918, 1, 2, 'payment_types_view'),
(5919, 1, 2, 'import_customers'),
(5920, 1, 2, 'import_suppliers'),
(5921, 1, 2, 'stock_transfer_add'),
(5922, 1, 2, 'stock_transfer_edit'),
(5923, 1, 2, 'stock_transfer_delete'),
(5924, 1, 2, 'stock_transfer_view'),
(5925, 1, 2, 'warehouse_add'),
(5926, 1, 2, 'warehouse_edit'),
(5927, 1, 2, 'warehouse_delete'),
(5928, 1, 2, 'warehouse_view'),
(5929, 1, 2, 'supplier_items_report'),
(5930, 1, 2, 'seller_points_report'),
(5931, 1, 2, 'services_add'),
(5932, 1, 2, 'services_edit'),
(5933, 1, 2, 'services_delete'),
(5934, 1, 2, 'services_view'),
(5935, 1, 2, 'quotation_add'),
(5936, 1, 2, 'quotation_edit'),
(5937, 1, 2, 'quotation_delete'),
(5938, 1, 2, 'quotation_view'),
(5939, 1, 2, 'import_services'),
(5940, 1, 2, 'stock_adjustment_add'),
(5941, 1, 2, 'stock_adjustment_edit'),
(5942, 1, 2, 'stock_adjustment_delete'),
(5943, 1, 2, 'stock_adjustment_view'),
(5944, 1, 2, 'variant_add'),
(5945, 1, 2, 'variant_edit'),
(5946, 1, 2, 'variant_delete'),
(5947, 1, 2, 'variant_view'),
(5948, 1, 2, 'accounts_add'),
(5949, 1, 2, 'accounts_edit'),
(5950, 1, 2, 'accounts_delete'),
(5951, 1, 2, 'accounts_view'),
(5952, 1, 2, 'money_transfer_add'),
(5953, 1, 2, 'money_transfer_edit'),
(5954, 1, 2, 'money_transfer_delete'),
(5955, 1, 2, 'money_transfer_view'),
(5956, 1, 2, 'money_deposit_add'),
(5957, 1, 2, 'money_deposit_edit'),
(5958, 1, 2, 'money_deposit_delete'),
(5959, 1, 2, 'money_deposit_view'),
(5960, 1, 2, 'sales_tax_report'),
(5961, 1, 2, 'purchase_tax_report'),
(5962, 1, 2, 'cash_transactions'),
(5963, 1, 2, 'show_all_users_sales_invoices'),
(5964, 1, 2, 'show_all_users_sales_return_invoices'),
(5965, 1, 2, 'show_all_users_purchase_invoices'),
(5966, 1, 2, 'show_all_users_purchase_return_invoices'),
(5967, 1, 2, 'show_all_users_expenses'),
(5968, 1, 2, 'show_all_users_quotations'),
(5969, 1, 2, 'subscription'),
(5970, 1, 2, 'smtp_settings'),
(5971, 1, 2, 'send_email'),
(5972, 1, 2, 'sms_settings'),
(5973, 1, 2, 'email_template_edit'),
(5974, 1, 2, 'email_template_view'),
(5975, 1, 2, 'cust_adv_payments_add'),
(5976, 1, 2, 'cust_adv_payments_edit'),
(5977, 1, 2, 'cust_adv_payments_delete'),
(5978, 1, 2, 'cust_adv_payments_view'),
(5999, 2, 28, 'cust_adv_payments_add'),
(6000, 2, 28, 'cust_adv_payments_edit'),
(6001, 2, 28, 'cust_adv_payments_delete'),
(6002, 2, 28, 'cust_adv_payments_view'),
(6011, 2, 29, 'users_add'),
(6012, 2, 29, 'users_edit'),
(6013, 2, 29, 'users_delete'),
(6014, 2, 29, 'users_view'),
(6015, 2, 29, 'tax_add'),
(6016, 2, 29, 'tax_edit'),
(6017, 2, 29, 'tax_delete'),
(6018, 2, 29, 'tax_view'),
(6019, 2, 29, 'store_edit'),
(6020, 2, 29, 'units_add'),
(6021, 2, 29, 'units_edit'),
(6022, 2, 29, 'units_delete'),
(6023, 2, 29, 'units_view'),
(6024, 2, 29, 'roles_add'),
(6025, 2, 29, 'roles_edit'),
(6026, 2, 29, 'roles_delete'),
(6027, 2, 29, 'roles_view'),
(6028, 2, 29, 'expense_add'),
(6029, 2, 29, 'expense_edit'),
(6030, 2, 29, 'expense_delete'),
(6031, 2, 29, 'expense_view'),
(6032, 2, 29, 'items_add'),
(6033, 2, 29, 'items_edit'),
(6034, 2, 29, 'items_delete'),
(6035, 2, 29, 'items_view'),
(6036, 2, 29, 'import_items'),
(6037, 2, 29, 'brand_add'),
(6038, 2, 29, 'brand_edit'),
(6039, 2, 29, 'brand_delete'),
(6040, 2, 29, 'brand_view'),
(6041, 2, 29, 'suppliers_add'),
(6042, 2, 29, 'suppliers_edit'),
(6043, 2, 29, 'suppliers_delete'),
(6044, 2, 29, 'suppliers_view'),
(6045, 2, 29, 'customers_add'),
(6046, 2, 29, 'customers_edit'),
(6047, 2, 29, 'customers_delete'),
(6048, 2, 29, 'customers_view'),
(6049, 2, 29, 'purchase_add'),
(6050, 2, 29, 'purchase_edit'),
(6051, 2, 29, 'purchase_delete'),
(6052, 2, 29, 'purchase_view'),
(6053, 2, 29, 'sales_add'),
(6054, 2, 29, 'sales_edit'),
(6055, 2, 29, 'sales_delete'),
(6056, 2, 29, 'sales_view'),
(6057, 2, 29, 'sales_payment_view'),
(6058, 2, 29, 'sales_payment_add'),
(6059, 2, 29, 'sales_payment_delete'),
(6060, 2, 29, 'sales_report'),
(6061, 2, 29, 'purchase_report'),
(6062, 2, 29, 'expense_report'),
(6063, 2, 29, 'profit_report'),
(6064, 2, 29, 'stock_report'),
(6065, 2, 29, 'item_sales_report'),
(6066, 2, 29, 'purchase_payments_report'),
(6067, 2, 29, 'sales_payments_report'),
(6068, 2, 29, 'items_category_add'),
(6069, 2, 29, 'items_category_edit'),
(6070, 2, 29, 'items_category_delete'),
(6071, 2, 29, 'items_category_view'),
(6072, 2, 29, 'print_labels'),
(6073, 2, 29, 'expense_category_add'),
(6074, 2, 29, 'expense_category_edit'),
(6075, 2, 29, 'expense_category_delete'),
(6076, 2, 29, 'expense_category_view'),
(6077, 2, 29, 'dashboard_view'),
(6078, 2, 29, 'dashboard_info_box_1'),
(6079, 2, 29, 'dashboard_info_box_2'),
(6080, 2, 29, 'dashboard_pur_sal_chart'),
(6081, 2, 29, 'dashboard_recent_items'),
(6082, 2, 29, 'dashboard_stock_alert'),
(6083, 2, 29, 'dashboard_trending_items_chart'),
(6084, 2, 29, 'send_sms'),
(6085, 2, 29, 'sms_template_edit'),
(6086, 2, 29, 'sms_template_view'),
(6087, 2, 29, 'sms_api_view'),
(6088, 2, 29, 'sms_api_edit'),
(6089, 2, 29, 'purchase_return_add'),
(6090, 2, 29, 'purchase_return_edit'),
(6091, 2, 29, 'purchase_return_delete'),
(6092, 2, 29, 'purchase_return_view'),
(6093, 2, 29, 'purchase_return_report'),
(6094, 2, 29, 'sales_return_add'),
(6095, 2, 29, 'sales_return_edit'),
(6096, 2, 29, 'sales_return_delete'),
(6097, 2, 29, 'sales_return_view'),
(6098, 2, 29, 'sales_return_report'),
(6099, 2, 29, 'sales_return_payment_view'),
(6100, 2, 29, 'sales_return_payment_add'),
(6101, 2, 29, 'sales_return_payment_delete'),
(6102, 2, 29, 'purchase_return_payment_view'),
(6103, 2, 29, 'purchase_return_payment_add'),
(6104, 2, 29, 'purchase_return_payment_delete'),
(6105, 2, 29, 'purchase_payment_view'),
(6106, 2, 29, 'purchase_payment_add'),
(6107, 2, 29, 'purchase_payment_delete'),
(6108, 2, 29, 'payment_types_add'),
(6109, 2, 29, 'payment_types_edit'),
(6110, 2, 29, 'payment_types_delete'),
(6111, 2, 29, 'payment_types_view'),
(6112, 2, 29, 'import_customers'),
(6113, 2, 29, 'import_suppliers'),
(6114, 2, 29, 'stock_transfer_add'),
(6115, 2, 29, 'stock_transfer_edit'),
(6116, 2, 29, 'stock_transfer_delete'),
(6117, 2, 29, 'stock_transfer_view'),
(6118, 2, 29, 'warehouse_add'),
(6119, 2, 29, 'warehouse_edit'),
(6120, 2, 29, 'warehouse_delete'),
(6121, 2, 29, 'warehouse_view'),
(6122, 2, 29, 'supplier_items_report'),
(6123, 2, 29, 'seller_points_report'),
(6124, 2, 29, 'services_add'),
(6125, 2, 29, 'services_edit'),
(6126, 2, 29, 'services_delete'),
(6127, 2, 29, 'services_view'),
(6128, 2, 29, 'quotation_add'),
(6129, 2, 29, 'quotation_edit'),
(6130, 2, 29, 'quotation_delete'),
(6131, 2, 29, 'quotation_view'),
(6132, 2, 29, 'import_services'),
(6133, 2, 29, 'stock_adjustment_add'),
(6134, 2, 29, 'stock_adjustment_edit'),
(6135, 2, 29, 'stock_adjustment_delete'),
(6136, 2, 29, 'stock_adjustment_view'),
(6137, 2, 29, 'variant_add'),
(6138, 2, 29, 'variant_edit'),
(6139, 2, 29, 'variant_delete'),
(6140, 2, 29, 'variant_view'),
(6141, 2, 29, 'accounts_add'),
(6142, 2, 29, 'accounts_edit'),
(6143, 2, 29, 'accounts_delete'),
(6144, 2, 29, 'accounts_view'),
(6145, 2, 29, 'money_transfer_add'),
(6146, 2, 29, 'money_transfer_edit'),
(6147, 2, 29, 'money_transfer_delete'),
(6148, 2, 29, 'money_transfer_view'),
(6149, 2, 29, 'money_deposit_add'),
(6150, 2, 29, 'money_deposit_edit'),
(6151, 2, 29, 'money_deposit_delete'),
(6152, 2, 29, 'money_deposit_view'),
(6153, 2, 29, 'sales_tax_report'),
(6154, 2, 29, 'purchase_tax_report'),
(6155, 2, 29, 'cash_transactions'),
(6156, 2, 29, 'show_all_users_sales_invoices'),
(6157, 2, 29, 'show_all_users_sales_return_invoices'),
(6158, 2, 29, 'show_all_users_purchase_invoices'),
(6159, 2, 29, 'show_all_users_purchase_return_invoices'),
(6160, 2, 29, 'show_all_users_expenses'),
(6161, 2, 29, 'show_all_users_quotations'),
(6162, 2, 29, 'smtp_settings'),
(6163, 2, 29, 'send_email'),
(6164, 2, 29, 'sms_settings'),
(6165, 2, 29, 'email_template_edit'),
(6166, 2, 29, 'email_template_view'),
(6167, 2, 29, 'cust_adv_payments_add'),
(6168, 2, 29, 'cust_adv_payments_edit'),
(6169, 2, 29, 'cust_adv_payments_delete'),
(6170, 2, 29, 'cust_adv_payments_view'),
(6179, 1, 2, 'gstr_1_report'),
(6180, 1, 2, 'gstr_2_report'),
(6181, 1, 2, 'delivery_sheet_report'),
(6182, 1, 2, 'load_sheet_report'),
(6183, 1, 2, 'show_purchase_price'),
(6184, 1, 2, 'customer_orders_report'),
(6185, 1, 2, 'discountCouponAdd'),
(6186, 1, 2, 'discountCouponEdit'),
(6187, 1, 2, 'discountCouponDelete'),
(6188, 1, 2, 'discountCouponView'),
(6189, 2, 2, 'sales_gst_report'),
(6190, 2, 2, 'purchase_gst_report'),
(6191, 2, 2, 'subscription'),
(6192, 1, 2, 'customerCouponAdd'),
(6193, 1, 2, 'customerCouponEdit'),
(6194, 1, 2, 'customerCouponDelete'),
(6195, 1, 2, 'customerCouponView'),
(6196, 1, 2, 'return_items_report'),
(6197, 1, 2, 'help_link'),
(6198, 2, 2, 'recent_sales_invoice_list'),
(6199, 2, 31, 'users_add'),
(6200, 2, 31, 'users_edit'),
(6201, 2, 31, 'users_delete'),
(6202, 2, 31, 'users_view'),
(6203, 2, 31, 'tax_add'),
(6204, 2, 31, 'tax_edit'),
(6205, 2, 31, 'tax_delete'),
(6206, 2, 31, 'tax_view'),
(6207, 2, 31, 'store_edit'),
(6208, 2, 31, 'units_add'),
(6209, 2, 31, 'units_edit'),
(6210, 2, 31, 'units_delete'),
(6211, 2, 31, 'units_view'),
(6212, 2, 31, 'roles_add'),
(6213, 2, 31, 'roles_edit'),
(6214, 2, 31, 'roles_delete'),
(6215, 2, 31, 'roles_view'),
(6216, 2, 31, 'expense_add'),
(6217, 2, 31, 'expense_edit'),
(6218, 2, 31, 'expense_delete'),
(6219, 2, 31, 'expense_view'),
(6220, 2, 31, 'items_add'),
(6221, 2, 31, 'items_edit'),
(6222, 2, 31, 'items_delete'),
(6223, 2, 31, 'items_view'),
(6224, 2, 31, 'import_items'),
(6225, 2, 31, 'brand_add'),
(6226, 2, 31, 'brand_edit'),
(6227, 2, 31, 'brand_delete'),
(6228, 2, 31, 'brand_view'),
(6229, 2, 31, 'suppliers_add'),
(6230, 2, 31, 'suppliers_edit'),
(6231, 2, 31, 'suppliers_delete'),
(6232, 2, 31, 'suppliers_view'),
(6233, 2, 31, 'customers_add'),
(6234, 2, 31, 'customers_edit'),
(6235, 2, 31, 'customers_delete'),
(6236, 2, 31, 'customers_view'),
(6237, 2, 31, 'purchase_add'),
(6238, 2, 31, 'purchase_edit'),
(6239, 2, 31, 'purchase_delete'),
(6240, 2, 31, 'purchase_view'),
(6241, 2, 31, 'sales_add'),
(6242, 2, 31, 'sales_edit'),
(6243, 2, 31, 'sales_delete'),
(6244, 2, 31, 'sales_view'),
(6245, 2, 31, 'sales_payment_view'),
(6246, 2, 31, 'sales_payment_add'),
(6247, 2, 31, 'sales_payment_delete'),
(6248, 2, 31, 'sales_report'),
(6249, 2, 31, 'purchase_report'),
(6250, 2, 31, 'expense_report'),
(6251, 2, 31, 'profit_report'),
(6252, 2, 31, 'stock_report'),
(6253, 2, 31, 'item_sales_report'),
(6254, 2, 31, 'purchase_payments_report'),
(6255, 2, 31, 'sales_payments_report'),
(6256, 2, 31, 'items_category_add'),
(6257, 2, 31, 'items_category_edit'),
(6258, 2, 31, 'items_category_delete'),
(6259, 2, 31, 'items_category_view'),
(6260, 2, 31, 'print_labels'),
(6261, 2, 31, 'expense_category_add'),
(6262, 2, 31, 'expense_category_edit'),
(6263, 2, 31, 'expense_category_delete'),
(6264, 2, 31, 'expense_category_view'),
(6265, 2, 31, 'dashboard_view'),
(6266, 2, 31, 'dashboard_info_box_1'),
(6267, 2, 31, 'dashboard_info_box_2'),
(6268, 2, 31, 'dashboard_pur_sal_chart'),
(6269, 2, 31, 'dashboard_recent_items'),
(6270, 2, 31, 'dashboard_stock_alert'),
(6271, 2, 31, 'dashboard_trending_items_chart'),
(6272, 2, 31, 'send_sms'),
(6273, 2, 31, 'sms_template_edit'),
(6274, 2, 31, 'sms_template_view'),
(6275, 2, 31, 'sms_api_view'),
(6276, 2, 31, 'sms_api_edit'),
(6277, 2, 31, 'purchase_return_add'),
(6278, 2, 31, 'purchase_return_edit'),
(6279, 2, 31, 'purchase_return_delete'),
(6280, 2, 31, 'purchase_return_view'),
(6281, 2, 31, 'purchase_return_report'),
(6282, 2, 31, 'sales_return_add'),
(6283, 2, 31, 'sales_return_edit'),
(6284, 2, 31, 'sales_return_delete'),
(6285, 2, 31, 'sales_return_view'),
(6286, 2, 31, 'sales_return_report'),
(6287, 2, 31, 'sales_return_payment_view'),
(6288, 2, 31, 'sales_return_payment_add'),
(6289, 2, 31, 'sales_return_payment_delete'),
(6290, 2, 31, 'purchase_return_payment_view'),
(6291, 2, 31, 'purchase_return_payment_add'),
(6292, 2, 31, 'purchase_return_payment_delete'),
(6293, 2, 31, 'purchase_payment_view'),
(6294, 2, 31, 'purchase_payment_add'),
(6295, 2, 31, 'purchase_payment_delete'),
(6296, 2, 31, 'payment_types_add'),
(6297, 2, 31, 'payment_types_edit'),
(6298, 2, 31, 'payment_types_delete'),
(6299, 2, 31, 'payment_types_view'),
(6300, 2, 31, 'import_customers'),
(6301, 2, 31, 'import_suppliers'),
(6302, 2, 31, 'stock_transfer_add'),
(6303, 2, 31, 'stock_transfer_edit'),
(6304, 2, 31, 'stock_transfer_delete'),
(6305, 2, 31, 'stock_transfer_view'),
(6306, 2, 31, 'warehouse_add'),
(6307, 2, 31, 'warehouse_edit'),
(6308, 2, 31, 'warehouse_delete'),
(6309, 2, 31, 'warehouse_view'),
(6310, 2, 31, 'supplier_items_report'),
(6311, 2, 31, 'seller_points_report'),
(6312, 2, 31, 'services_add'),
(6313, 2, 31, 'services_edit'),
(6314, 2, 31, 'services_delete'),
(6315, 2, 31, 'services_view'),
(6316, 2, 31, 'quotation_add'),
(6317, 2, 31, 'quotation_edit'),
(6318, 2, 31, 'quotation_delete'),
(6319, 2, 31, 'quotation_view'),
(6320, 2, 31, 'import_services'),
(6321, 2, 31, 'stock_adjustment_add'),
(6322, 2, 31, 'stock_adjustment_edit'),
(6323, 2, 31, 'stock_adjustment_delete'),
(6324, 2, 31, 'stock_adjustment_view'),
(6325, 2, 31, 'variant_add'),
(6326, 2, 31, 'variant_edit'),
(6327, 2, 31, 'variant_delete'),
(6328, 2, 31, 'variant_view'),
(6329, 2, 31, 'accounts_add'),
(6330, 2, 31, 'accounts_edit'),
(6331, 2, 31, 'accounts_delete'),
(6332, 2, 31, 'accounts_view'),
(6333, 2, 31, 'money_transfer_add'),
(6334, 2, 31, 'money_transfer_edit'),
(6335, 2, 31, 'money_transfer_delete'),
(6336, 2, 31, 'money_transfer_view'),
(6337, 2, 31, 'money_deposit_add'),
(6338, 2, 31, 'money_deposit_edit'),
(6339, 2, 31, 'money_deposit_delete'),
(6340, 2, 31, 'money_deposit_view'),
(6341, 2, 31, 'sales_tax_report'),
(6342, 2, 31, 'purchase_tax_report'),
(6343, 2, 31, 'cash_transactions'),
(6344, 2, 31, 'show_all_users_sales_invoices'),
(6345, 2, 31, 'show_all_users_sales_return_invoices'),
(6346, 2, 31, 'show_all_users_purchase_invoices'),
(6347, 2, 31, 'show_all_users_purchase_return_invoices'),
(6348, 2, 31, 'show_all_users_expenses'),
(6349, 2, 31, 'show_all_users_quotations'),
(6350, 2, 31, 'sms_settings'),
(6351, 2, 31, 'cust_adv_payments_add'),
(6352, 2, 31, 'cust_adv_payments_edit'),
(6353, 2, 31, 'cust_adv_payments_delete'),
(6354, 2, 31, 'cust_adv_payments_view'),
(6355, 2, 31, 'gstr_1_report'),
(6356, 2, 31, 'gstr_2_report'),
(6357, 2, 31, 'customer_orders_report'),
(6358, 2, 31, 'load_sheet_report'),
(6359, 2, 31, 'delivery_sheet_report'),
(6360, 2, 31, 'show_purchase_price'),
(6361, 2, 31, 'discountCouponAdd'),
(6362, 2, 31, 'discountCouponEdit'),
(6363, 2, 31, 'discountCouponDelete'),
(6364, 2, 31, 'discountCouponView'),
(6365, 2, 31, 'sales_gst_report'),
(6366, 2, 31, 'purchase_gst_report'),
(6367, 2, 31, 'customerCouponAdd'),
(6368, 2, 31, 'customerCouponEdit'),
(6369, 2, 31, 'customerCouponDelete'),
(6370, 2, 31, 'customerCouponView'),
(6371, 2, 31, 'return_items_report'),
(6372, 2, 31, 'recent_sales_invoice_list'),
(6373, 1, 2, 'stock_transfer_report'),
(6374, 1, 2, 'pos'),
(6375, 1, 2, 'sales_summary_report'),
(6376, 1, 2, 'sales_return_payments');

-- --------------------------------------------------------

--
-- Table structure for table `db_purchase`
--

CREATE TABLE `db_purchase` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create Purchase Code',
  `purchase_code` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_status` varchar(50) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,4) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,4) DEFAULT NULL,
  `discount_to_all_input` double(20,4) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,4) DEFAULT NULL,
  `subtotal` double(20,4) DEFAULT NULL COMMENT 'Purchased qty',
  `round_off` double(20,4) DEFAULT NULL COMMENT 'Pending Qty',
  `grand_total` double(20,4) DEFAULT NULL,
  `purchase_note` text DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `paid_amount` double(20,4) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'Purchase return raised'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_purchaseitems`
--

CREATE TABLE `db_purchaseitems` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `purchase_id` int(5) DEFAULT NULL,
  `purchase_status` varchar(50) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `purchase_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,4) DEFAULT NULL,
  `discount_type` varchar(50) DEFAULT NULL,
  `discount_input` double(20,4) DEFAULT NULL,
  `discount_amt` double(20,4) DEFAULT NULL,
  `unit_total_cost` double(20,4) DEFAULT NULL,
  `total_cost` double(20,4) DEFAULT NULL,
  `profit_margin_per` double(20,4) DEFAULT NULL,
  `unit_sales_price` double(20,4) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_purchaseitemsreturn`
--

CREATE TABLE `db_purchaseitemsreturn` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `purchase_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `return_status` varchar(50) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `return_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,4) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `discount_input` double(20,4) DEFAULT NULL,
  `discount_amt` double(20,4) DEFAULT NULL,
  `discount_type` varchar(50) DEFAULT NULL,
  `unit_total_cost` double(20,4) DEFAULT NULL,
  `total_cost` double(20,4) DEFAULT NULL,
  `profit_margin_per` double(20,4) DEFAULT NULL,
  `unit_sales_price` double(20,4) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_purchasepayments`
--

CREATE TABLE `db_purchasepayments` (
  `id` int(5) NOT NULL,
  `count_id` int(5) DEFAULT NULL,
  `payment_code` varchar(50) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `purchase_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,4) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `account_id` int(5) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `short_code` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_purchasepaymentsreturn`
--

CREATE TABLE `db_purchasepaymentsreturn` (
  `id` int(5) NOT NULL,
  `count_id` int(5) DEFAULT NULL,
  `payment_code` varchar(50) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,4) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `account_id` int(5) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `short_code` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_purchasereturn`
--

CREATE TABLE `db_purchasereturn` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create Purchase Return Code',
  `warehouse_id` int(5) DEFAULT NULL,
  `purchase_id` int(11) DEFAULT NULL,
  `return_code` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_status` varchar(50) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,4) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,4) DEFAULT NULL,
  `discount_to_all_input` double(20,4) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,4) DEFAULT NULL,
  `subtotal` double(20,4) DEFAULT NULL COMMENT 'Purchased qty',
  `round_off` double(20,4) DEFAULT NULL COMMENT 'Pending Qty',
  `grand_total` double(20,4) DEFAULT NULL,
  `return_note` text DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `paid_amount` double(20,4) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_quotation`
--

CREATE TABLE `db_quotation` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create quotation Code',
  `quotation_code` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `quotation_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `quotation_status` varchar(50) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,4) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,4) DEFAULT NULL,
  `discount_to_all_input` double(20,4) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,4) DEFAULT NULL,
  `subtotal` double(20,4) DEFAULT NULL,
  `round_off` double(20,4) DEFAULT NULL,
  `grand_total` double(20,4) DEFAULT NULL,
  `quotation_note` text DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `paid_amount` double(20,4) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'quotation return raised',
  `customer_previous_due` double(20,4) DEFAULT NULL,
  `customer_total_due` double(20,4) DEFAULT NULL,
  `sales_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_quotationitems`
--

CREATE TABLE `db_quotationitems` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `quotation_id` int(5) DEFAULT NULL,
  `quotation_status` varchar(50) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `quotation_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,4) DEFAULT NULL,
  `discount_type` varchar(50) DEFAULT NULL,
  `discount_input` double(20,4) DEFAULT NULL,
  `discount_amt` double(20,4) DEFAULT NULL,
  `unit_total_cost` double(20,4) DEFAULT NULL,
  `total_cost` double(20,4) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `seller_points` double(20,4) DEFAULT 0.0000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_roles`
--

CREATE TABLE `db_roles` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_roles`
--

INSERT INTO `db_roles` (`id`, `store_id`, `role_name`, `description`, `status`) VALUES
(1, 1, 'Admin', 'All Rights Permitted.', 1),
(2, 1, 'Store Admin', 'Note: Apply this role for New Store Admin. ', 1),
(31, 2, 'Manager', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_sales`
--

CREATE TABLE `db_sales` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `init_code` varchar(100) DEFAULT NULL,
  `count_id` decimal(20,0) DEFAULT NULL COMMENT 'Use to create Sales Code',
  `sales_code` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `sales_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `sales_status` varchar(50) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,2) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,2) DEFAULT NULL,
  `discount_to_all_input` double(20,2) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,2) DEFAULT NULL,
  `subtotal` double(20,2) DEFAULT NULL,
  `round_off` double(20,2) DEFAULT NULL,
  `grand_total` double(20,4) DEFAULT NULL,
  `sales_note` text DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `paid_amount` double(20,4) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'sales return raised',
  `customer_previous_due` double(20,2) DEFAULT NULL,
  `customer_total_due` double(20,2) DEFAULT NULL,
  `quotation_id` int(5) DEFAULT NULL,
  `coupon_id` int(10) DEFAULT NULL,
  `coupon_amt` double(20,2) DEFAULT 0.00,
  `invoice_terms` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_salesitems`
--

CREATE TABLE `db_salesitems` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `sales_id` int(5) DEFAULT NULL,
  `sales_status` varchar(50) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `sales_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,4) DEFAULT NULL,
  `discount_type` varchar(50) DEFAULT NULL,
  `discount_input` double(20,4) DEFAULT NULL,
  `discount_amt` double(20,4) DEFAULT NULL,
  `unit_total_cost` double(20,4) DEFAULT NULL,
  `total_cost` double(20,4) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `seller_points` double(20,2) DEFAULT 0.00,
  `purchase_price` double(20,3) DEFAULT 0.000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_salesitemsreturn`
--

CREATE TABLE `db_salesitemsreturn` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `sales_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `return_status` varchar(50) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `return_qty` double(20,2) DEFAULT NULL,
  `price_per_unit` double(20,4) DEFAULT NULL,
  `tax_type` varchar(50) DEFAULT NULL,
  `tax_id` int(5) DEFAULT NULL,
  `tax_amt` double(20,4) DEFAULT NULL,
  `discount_input` double(20,4) DEFAULT NULL,
  `discount_amt` double(20,4) DEFAULT NULL,
  `discount_type` varchar(50) DEFAULT NULL,
  `unit_total_cost` double(20,4) DEFAULT NULL,
  `total_cost` double(20,4) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `purchase_price` double(20,3) DEFAULT 0.000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_salespayments`
--

CREATE TABLE `db_salespayments` (
  `id` int(5) NOT NULL,
  `count_id` int(5) DEFAULT NULL,
  `payment_code` varchar(50) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `sales_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,4) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `change_return` double(20,4) DEFAULT NULL COMMENT 'Refunding the greater amount',
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `account_id` int(5) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `short_code` varchar(50) DEFAULT NULL,
  `advance_adjusted` double(20,4) DEFAULT NULL,
  `cheque_number` varchar(100) DEFAULT NULL,
  `cheque_period` int(10) DEFAULT NULL,
  `cheque_status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_salespaymentsreturn`
--

CREATE TABLE `db_salespaymentsreturn` (
  `id` int(5) NOT NULL,
  `count_id` int(5) DEFAULT NULL,
  `payment_code` varchar(50) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL,
  `sales_id` int(5) DEFAULT NULL,
  `return_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(20,4) DEFAULT NULL,
  `payment_note` text DEFAULT NULL,
  `change_return` double(20,4) DEFAULT NULL COMMENT 'Refunding the greater amount',
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `account_id` int(5) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `short_code` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_salesreturn`
--

CREATE TABLE `db_salesreturn` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create Sales Return Code',
  `sales_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `return_code` varchar(50) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `return_status` varchar(50) DEFAULT NULL,
  `customer_id` int(5) DEFAULT NULL,
  `other_charges_input` double(20,4) DEFAULT NULL,
  `other_charges_tax_id` int(5) DEFAULT NULL,
  `other_charges_amt` double(20,4) DEFAULT NULL,
  `discount_to_all_input` double(20,4) DEFAULT NULL,
  `discount_to_all_type` varchar(50) DEFAULT NULL,
  `tot_discount_to_all_amt` double(20,4) DEFAULT NULL,
  `subtotal` double(20,4) DEFAULT NULL,
  `round_off` double(20,4) DEFAULT NULL,
  `grand_total` double(20,4) DEFAULT NULL,
  `return_note` text DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `paid_amount` double(20,4) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `pos` int(1) DEFAULT NULL COMMENT '1=yes 0=no',
  `status` int(1) DEFAULT NULL,
  `return_bit` int(1) DEFAULT NULL COMMENT 'Return raised or not 1 or null',
  `coupon_id` int(11) DEFAULT NULL,
  `coupon_amt` double(20,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_shippingaddress`
--

CREATE TABLE `db_shippingaddress` (
  `id` int(10) NOT NULL,
  `store_id` int(10) DEFAULT NULL,
  `country_id` int(10) DEFAULT NULL,
  `state_id` int(10) DEFAULT NULL,
  `city` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `postcode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `address` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `customer_id` int(10) DEFAULT NULL,
  `location_link` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_shippingaddress`
--

INSERT INTO `db_shippingaddress` (`id`, `store_id`, `country_id`, `state_id`, `city`, `postcode`, `address`, `status`, `customer_id`, `location_link`) VALUES
(1, 1, 1, NULL, NULL, '', '', 1, 1, NULL),
(2, 2, NULL, NULL, NULL, NULL, NULL, 1, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_sitesettings`
--

CREATE TABLE `db_sitesettings` (
  `id` int(5) NOT NULL,
  `version` varchar(10) DEFAULT NULL,
  `site_name` varchar(100) DEFAULT NULL,
  `logo` mediumtext DEFAULT NULL COMMENT 'path',
  `machine_id` text DEFAULT NULL,
  `domain` text DEFAULT NULL,
  `unique_code` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_sitesettings`
--

INSERT INTO `db_sitesettings` (`id`, `version`, `site_name`, `logo`, `machine_id`, `domain`, `unique_code`) VALUES
(1, '3.1', 'Business Inventory', '/uploads/site/Welcome_Note(Mudashco).png', '1', 'test.razystudio.com', 'wj3oqvyflcb1p5sez6na7ih82x0gkr');

-- --------------------------------------------------------

--
-- Table structure for table `db_smsapi`
--

CREATE TABLE `db_smsapi` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `info` varchar(150) DEFAULT NULL,
  `key` varchar(600) DEFAULT NULL,
  `key_value` varchar(600) DEFAULT NULL,
  `delete_bit` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_smsapi`
--

INSERT INTO `db_smsapi` (`id`, `store_id`, `info`, `key`, `key_value`, `delete_bit`) VALUES
(26, 2, 'url', 'weblink', 'http://example.com/sendmessage', NULL),
(27, 2, 'mobile', 'mobiles', '', NULL),
(28, 2, 'message', 'message', '', NULL),
(29, 1, 'url', 'weblink', 'https://www.example.com/api/mt/SendSMS?', NULL),
(30, 1, 'mobile', 'mobiles', '', NULL),
(31, 1, 'message', 'message', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_smstemplates`
--

CREATE TABLE `db_smstemplates` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `template_name` varchar(100) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `variables` text DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `undelete_bit` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_smstemplates`
--

INSERT INTO `db_smstemplates` (`id`, `store_id`, `template_name`, `content`, `variables`, `status`, `undelete_bit`) VALUES
(1, 1, 'GREETING TO CUSTOMER ON SALES', 'Hi {{customer_name}},\r\nYour sales Id is {{sales_id}},\r\nSales Date {{sales_date}},\r\nTotal amount  {{sales_amount}},\r\nYou have paid  {{paid_amt}},\r\nand due amount is  {{due_amt}}\r\nThank you Visit Again', '{{customer_name}}<br>                          \r\n{{sales_id}}<br>\r\n{{sales_date}}<br>\r\n{{sales_amount}}<br>\r\n{{paid_amt}}<br>\r\n{{due_amt}}<br>\r\n{{store_name}}<br>\r\n{{store_mobile}}<br>\r\n{{store_address}}<br>\r\n{{store_website}}<br>\r\n{{store_email}}<br>\r\n', 1, 1),
(2, 1, 'GREETING TO CUSTOMER ON SALES RETURN', 'Hi {{customer_name}},\r\nYour sales return Id is {{return_id}},\r\nReturn Date {{return_date}},\r\nTotal amount  {{return_amount}},\r\nWe paid  {{paid_amt}},\r\nand due amount is  {{due_amt}}\r\nThank you Visit Again', '{{customer_name}}<br>                          \r\n{{return_id}}<br>\r\n{{return_date}}<br>\r\n{{return_amount}}<br>\r\n{{paid_amt}}<br>\r\n{{due_amt}}<br>\r\n{{company_name}}<br>\r\n{{company_mobile}}<br>\r\n{{company_address}}<br>\r\n{{company_website}}<br>\r\n{{company_email}}<br>', 1, 1),
(12, 2, 'GREETING TO CUSTOMER ON SALES', 'Hi {{customer_name}},\r\nYour sales Id is {{sales_id}},\r\nSales Date {{sales_date}},\r\nTotal amount  {{sales_amount}},\r\nYou have paid  {{paid_amt}},\r\nand due amount is  {{due_amt}}\r\nThank you Visit Again', '{{customer_name}}                          \r\n{{sales_id}}\r\n{{sales_date}}\r\n{{sales_amount}}\r\n{{paid_amt}}\r\n{{due_amt}}\r\n{{store_name}}\r\n{{store_mobile}}\r\n{{store_address}}\r\n{{store_website}}\r\n{{store_email}}\r\n', 1, 1),
(13, 2, 'GREETING TO CUSTOMER ON SALES RETURN', 'Hi {{customer_name}},\r\nYour sales return Id is {{return_id}},\r\nReturn Date {{return_date}},\r\nTotal amount  {{return_amount}},\r\nWe paid  {{paid_amt}},\r\nand due amount is  {{due_amt}}\r\nThank you Visit Again', '{{customer_name}}                          \r\n{{return_id}}\r\n{{return_date}}\r\n{{return_amount}}\r\n{{paid_amt}}\r\n{{due_amt}}\r\n{{company_name}}\r\n{{company_mobile}}\r\n{{company_address}}\r\n{{company_website}}\r\n{{company_email}}\r\n', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_sobpayments`
--

CREATE TABLE `db_sobpayments` (
  `id` int(5) NOT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment` double(10,2) DEFAULT NULL,
  `payment_note` mediumtext DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_time` time DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_states`
--

CREATE TABLE `db_states` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `state_code` varchar(10) DEFAULT NULL,
  `state` varchar(4050) DEFAULT NULL,
  `country_code` varchar(15) DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `country` varchar(15) DEFAULT NULL,
  `added_on` date DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_states`
--

INSERT INTO `db_states` (`id`, `store_id`, `state_code`, `state`, `country_code`, `country_id`, `country`, `added_on`, `company_id`, `status`) VALUES
(23, 1, 'ST0001', 'Karnataka', 'CNT0001', NULL, 'India', '2017-07-10', 1, 1),
(24, 1, 'ST0024', 'Maharashtra', 'CNT0001', NULL, 'India', '2018-04-13', 1, 1),
(25, 2, 'ST0025', 'Andhra Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(26, 1, 'ST0026', 'Arunachal Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(27, 1, 'ST0027', 'Assam', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(28, 1, 'ST0028', 'Bihar', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(29, 1, 'ST0029', 'Chhattisgarh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(30, 1, 'ST0030', 'Goa', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(31, 1, 'ST0031', 'Gujarat', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(32, 1, 'ST0032', 'Haryana', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(33, 1, 'ST0033', 'Himachal Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(34, 1, 'ST0034', 'Jammu and Kashmir', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(35, 1, 'ST0035', 'Jharkhand', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(36, 1, 'ST0036', 'Kerala', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(37, 1, 'ST0037', 'Madhya Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(38, 1, 'ST0038', 'Manipur', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(39, 1, 'ST0039', 'Meghalaya', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(40, 1, 'ST0040', 'Mizoram', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(41, 1, 'ST0041', 'Nagaland', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(42, 1, 'ST0042', 'Odisha', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(43, 1, 'ST0043', 'Punjab', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(44, 1, 'ST0044', 'Rajasthan', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(45, 1, 'ST0045', 'Sikkim', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(46, 1, 'ST0046', 'Tamil Nadu', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(47, 1, 'ST0047', 'Telangana', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(48, 1, 'ST0048', 'Tripura', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(49, 1, 'ST0049', 'Uttar Pradesh', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(50, 1, 'ST0050', 'Uttarakhand', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(51, 1, 'ST0051', 'West Bengal', 'CNT0001', NULL, 'India', '2018-11-02', NULL, 1),
(52, 1, NULL, 'New York', NULL, NULL, 'USA', NULL, NULL, 1),
(53, 1, NULL, 'Delhi', NULL, NULL, 'India', NULL, NULL, 1),
(63, 2, NULL, 'Karnataka', NULL, 79, 'India', NULL, NULL, 1),
(64, 2, NULL, 'Greater Accra', NULL, NULL, 'Ghana', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_stockadjustment`
--

CREATE TABLE `db_stockadjustment` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `reference_no` varchar(50) DEFAULT NULL,
  `adjustment_date` date DEFAULT NULL,
  `adjustment_note` mediumtext DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_stockadjustmentitems`
--

CREATE TABLE `db_stockadjustmentitems` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `adjustment_id` int(5) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `adjustment_qty` double(20,2) DEFAULT NULL,
  `status` int(5) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_stockentry`
--

CREATE TABLE `db_stockentry` (
  `id` int(5) NOT NULL,
  `entry_date` date DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_stocktransfer`
--

CREATE TABLE `db_stocktransfer` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL COMMENT 'from store',
  `to_store_id` int(11) DEFAULT NULL COMMENT 'to store transfer',
  `warehouse_from` int(5) DEFAULT NULL,
  `warehouse_to` int(5) DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  `note` text CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `system_name` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_stocktransferitems`
--

CREATE TABLE `db_stocktransferitems` (
  `id` int(5) NOT NULL,
  `stocktransfer_id` int(5) DEFAULT NULL,
  `store_id` int(5) DEFAULT NULL COMMENT 'from store',
  `to_store_id` int(5) DEFAULT NULL COMMENT 'to store',
  `warehouse_from` int(5) DEFAULT NULL COMMENT 'warehouse ids',
  `warehouse_to` int(11) DEFAULT NULL COMMENT 'warehouse ids',
  `item_id` int(11) DEFAULT NULL,
  `transfer_qty` double(20,2) DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_store`
--

CREATE TABLE `db_store` (
  `id` int(5) NOT NULL,
  `store_code` varchar(150) DEFAULT NULL,
  `store_name` varchar(150) DEFAULT NULL,
  `store_website` varchar(150) DEFAULT NULL,
  `mobile` varchar(150) DEFAULT NULL,
  `phone` varchar(150) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(250) DEFAULT NULL,
  `store_logo` text DEFAULT NULL,
  `logo` mediumtext DEFAULT NULL,
  `upi_id` varchar(50) DEFAULT NULL,
  `upi_code` text DEFAULT NULL,
  `country` varchar(150) DEFAULT NULL,
  `state` varchar(150) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `postcode` varchar(50) DEFAULT NULL,
  `gst_no` varchar(50) DEFAULT NULL,
  `vat_no` varchar(50) DEFAULT NULL,
  `pan_no` varchar(50) DEFAULT NULL,
  `bank_details` mediumtext DEFAULT NULL,
  `cid` int(50) DEFAULT NULL,
  `category_init` varchar(50) DEFAULT NULL,
  `item_init` varchar(50) DEFAULT NULL COMMENT 'INITAL CODE',
  `supplier_init` varchar(50) DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_init` varchar(50) DEFAULT NULL COMMENT 'INITAL CODE',
  `purchase_return_init` varchar(50) DEFAULT NULL,
  `customer_init` varchar(50) DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_init` varchar(50) DEFAULT NULL COMMENT 'INITAL CODE',
  `sales_return_init` varchar(50) DEFAULT NULL,
  `expense_init` varchar(50) DEFAULT NULL,
  `accounts_init` varchar(50) DEFAULT NULL,
  `journal_init` varchar(50) DEFAULT NULL,
  `cust_advance_init` varchar(50) DEFAULT NULL,
  `invoice_view` int(5) DEFAULT NULL COMMENT '1=Standard,2=Indian GST',
  `sms_status` int(1) DEFAULT NULL COMMENT '1=Enable 0=Disable',
  `status` int(1) DEFAULT NULL,
  `language_id` int(5) DEFAULT NULL,
  `currency_id` int(5) DEFAULT NULL,
  `currency_placement` varchar(50) DEFAULT NULL,
  `timezone` varchar(50) DEFAULT NULL,
  `date_format` varchar(50) DEFAULT NULL,
  `time_format` int(5) DEFAULT NULL,
  `sales_discount` double(20,4) DEFAULT NULL,
  `currencysymbol_id` int(5) DEFAULT NULL,
  `regno_key` varchar(50) DEFAULT NULL,
  `fav_icon` text DEFAULT NULL,
  `purchase_code` text DEFAULT NULL,
  `change_return` int(2) DEFAULT NULL,
  `sales_invoice_format_id` int(5) DEFAULT NULL,
  `pos_invoice_format_id` int(5) DEFAULT NULL,
  `sales_invoice_footer_text` text DEFAULT NULL,
  `round_off` int(1) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `quotation_init` varchar(50) DEFAULT NULL,
  `decimals` int(1) DEFAULT 2,
  `money_transfer_init` varchar(50) DEFAULT NULL,
  `sales_payment_init` varchar(50) DEFAULT NULL,
  `sales_return_payment_init` varchar(50) DEFAULT NULL,
  `purchase_payment_init` varchar(50) DEFAULT NULL,
  `purchase_return_payment_init` varchar(50) DEFAULT NULL,
  `expense_payment_init` varchar(50) DEFAULT NULL,
  `current_subscriptionlist_id` int(10) DEFAULT 0,
  `smtp_host` varchar(250) DEFAULT NULL,
  `smtp_port` varchar(250) DEFAULT NULL,
  `smtp_user` varchar(250) DEFAULT NULL,
  `smtp_pass` varchar(250) DEFAULT NULL,
  `smtp_status` int(1) DEFAULT 0,
  `sms_url` text DEFAULT NULL,
  `user_id` int(5) NOT NULL,
  `mrp_column` int(1) DEFAULT 0,
  `qty_decimals` int(5) DEFAULT 2,
  `signature` text DEFAULT NULL,
  `show_signature` int(1) DEFAULT 0,
  `invoice_terms` text DEFAULT NULL,
  `previous_balance_bit` int(1) DEFAULT 1 COMMENT '1=Show, 0=Hide - Shows on sales invoice',
  `t_and_c_status` int(1) DEFAULT 1 COMMENT '1=Show, 0=Hide - Shows on sales invoice',
  `t_and_c_status_pos` int(1) DEFAULT 1,
  `number_to_words` varchar(250) DEFAULT 'Default',
  `default_account_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_store`
--

INSERT INTO `db_store` (`id`, `store_code`, `store_name`, `store_website`, `mobile`, `phone`, `email`, `website`, `store_logo`, `logo`, `upi_id`, `upi_code`, `country`, `state`, `city`, `address`, `postcode`, `gst_no`, `vat_no`, `pan_no`, `bank_details`, `cid`, `category_init`, `item_init`, `supplier_init`, `purchase_init`, `purchase_return_init`, `customer_init`, `sales_init`, `sales_return_init`, `expense_init`, `accounts_init`, `journal_init`, `cust_advance_init`, `invoice_view`, `sms_status`, `status`, `language_id`, `currency_id`, `currency_placement`, `timezone`, `date_format`, `time_format`, `sales_discount`, `currencysymbol_id`, `regno_key`, `fav_icon`, `purchase_code`, `change_return`, `sales_invoice_format_id`, `pos_invoice_format_id`, `sales_invoice_footer_text`, `round_off`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `quotation_init`, `decimals`, `money_transfer_init`, `sales_payment_init`, `sales_return_payment_init`, `purchase_payment_init`, `purchase_return_payment_init`, `expense_payment_init`, `current_subscriptionlist_id`, `smtp_host`, `smtp_port`, `smtp_user`, `smtp_pass`, `smtp_status`, `sms_url`, `user_id`, `mrp_column`, `qty_decimals`, `signature`, `show_signature`, `invoice_terms`, `previous_balance_bit`, `t_and_c_status`, `t_and_c_status_pos`, `number_to_words`, `default_account_id`) VALUES
(1, 'ST0001', 'SAAS ADMIN', '', '+919999999999', '', 'admin@example.com', 'www', 'uploads/store/company_logo.png', NULL, NULL, NULL, 'India', 'Karnataka', 'Bengalore', 'Gandhi Road', '', '', '', '', '', NULL, 'CT/01/', 'IT01', 'SU/01/', 'PU/2020/01', 'PR/2020/01/', 'CU/01/', 'SL/2020/01/', 'SR/2020/01/', 'EX/2020/01/', 'AC/01/', 'JE', 'ADV', 1, 0, 1, 1, 35, 'Left', 'Asia/Kolkata\r\n', 'dd-mm-yyyy', 12, 0.0000, NULL, NULL, NULL, NULL, 1, 3, 1, 'Its Footer, You can change it from Store Settings.', 0, NULL, NULL, NULL, NULL, NULL, 'QT/2020/01/', 2, 'MT/01/', 'SP/2020/01/', 'SRP/2020/01/', 'PP/2020/01/', 'PRP/2020/01/', 'XP/2020/01/', 26, '', '', '', '', 1, '', 0, 0, 2, NULL, 0, NULL, 1, 1, 1, 'Default', NULL),
(2, 'ST0002', 'Office Inventory ', '', '0261970296', '', 'jralhassan100@gmail.com', NULL, NULL, NULL, NULL, NULL, 'Ghana', 'Greater Accra', 'Tema', 'Admin Office', '', '', '', '', '', NULL, 'CT/02/', 'IT02', 'SU/02/', 'PU/2021/02/', 'PR/2021/02/', 'CU/02/', 'SL/2021/02/', 'SR/2021/02/', 'EX/2021/02/', 'AC/02/', NULL, 'ADV', 1, 2, 1, 1, 60, 'Left', 'Africa/Casablanca\r\n', 'dd-mm-yyyy', 12, 0.0000, NULL, NULL, NULL, NULL, 1, 3, 1, 'This is footer text. It is in Store Management.', 1, '2021-02-12', '05:53:37 pm', '', '127.0.0.1', 'LAPTOP-I5OUIM4R', 'QT/2021/02/', 2, 'MT/02/', 'SP/2021/02/', 'SRP/2021/02/', 'PP/2021/02/', 'PRP/2021/02/', 'XP/2021/02/', 28, 'mudashco.razystudio.com', ' 465', 'info@mudashco.razystudio.com', 'Alhassan1989', 1, NULL, 0, 0, 0, NULL, 0, '', 1, 1, 1, 'Default', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_stripe`
--

CREATE TABLE `db_stripe` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `sandbox` int(1) DEFAULT NULL,
  `publishable_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `api_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `updated_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_stripepayments`
--

CREATE TABLE `db_stripepayments` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `buyer_name` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `buyer_email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `paid_amount` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `paid_amount_currency` varchar(10) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `txn_id` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `payment_status` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_subscription`
--

CREATE TABLE `db_subscription` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `payment_id` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `package_id` int(5) DEFAULT NULL,
  `package_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `package_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subscription_date` date DEFAULT NULL,
  `expire_date` date DEFAULT NULL,
  `trial_days` int(10) DEFAULT NULL,
  `max_users` int(10) DEFAULT NULL,
  `max_warehouses` int(10) DEFAULT NULL,
  `max_items` int(10) DEFAULT NULL,
  `max_invoices` int(10) DEFAULT NULL,
  `payment_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `txn_id` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_gross` double(10,2) DEFAULT NULL,
  `currency_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payer_email` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_status` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `package_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment_type` varchar(250) DEFAULT NULL COMMENT 'manual subscription only',
  `package_count` int(10) DEFAULT NULL COMMENT 'manual subscription only'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_subscription`
--

INSERT INTO `db_subscription` (`id`, `store_id`, `payment_id`, `package_id`, `package_type`, `package_name`, `description`, `subscription_date`, `expire_date`, `trial_days`, `max_users`, `max_warehouses`, `max_items`, `max_invoices`, `payment_by`, `txn_id`, `payment_gross`, `currency_code`, `payer_email`, `payment_status`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `package_status`, `payment_type`, `package_count`) VALUES
(13, 22, NULL, 2, NULL, 'Regular', 'Test description', '2021-01-25', NULL, 15, 20, 20, 200, 200, 'PayPal', '48R18927X78299709', 250.00, 'USD', 'sb-9fy504805522@business.example.com', 'Pending', '2021-01-25', '01:30:45 pm', 'Tester', '127.0.0.1', 'LAPTOP-I5OUIM4R', NULL, NULL, NULL),
(14, 22, NULL, 2, 'Paid', 'Regular', 'Test description', '2021-01-25', NULL, 15, 20, 20, 200, 200, 'PayPal', '9M838440FH9266015', 250.00, 'USD', 'sb-9fy504805522@business.example.com', 'Pending', '2021-01-25', '01:32:28 pm', 'Tester', '127.0.0.1', 'LAPTOP-I5OUIM4R', NULL, NULL, NULL),
(16, 22, NULL, 2, 'Paid', 'Regular', 'Test description', '2021-01-25', '2021-02-25', 15, 20, 20, 200, 200, 'PayPal', '2PT61144W90213341', 250.00, 'USD', 'sb-9fy504805522@business.example.com', 'Pending', '2021-01-25', '02:00:38 pm', 'Tester', '127.0.0.1', 'LAPTOP-I5OUIM4R', NULL, NULL, NULL),
(26, 1, NULL, 1, 'Free', 'Free', 'Test description', '2021-01-25', '2021-02-04', 10, 2, 2, 20, 20, 'Self', '', 0.00, '', '', '', '2021-01-25', '06:32:32 pm', 'admin', '127.0.0.1', 'LAPTOP-I5OUIM4R', NULL, NULL, NULL),
(27, 24, NULL, 1, 'Free', 'Free', 'Test description', '2021-02-11', '2021-02-21', 10, 2, 2, 20, 20, 'Self', '', 0.00, '', '', '', '2021-02-11', '03:09:47 pm', 'Tester', '127.0.0.1', 'LAPTOP-I5OUIM4R', NULL, NULL, NULL),
(28, 2, NULL, 1, 'Free', 'Free', 'Test description', '2021-02-12', '2021-02-22', 10, 2, 2, 20, 20, 'Self', '', 0.00, '', '', '', '2021-02-12', '06:57:18 pm', 'Tester', '127.0.0.1', 'LAPTOP-I5OUIM4R', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_suppliers`
--

CREATE TABLE `db_suppliers` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `count_id` int(10) DEFAULT NULL COMMENT 'Use to create supplier Code',
  `supplier_code` varchar(20) DEFAULT NULL,
  `supplier_name` varchar(50) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `gstin` varchar(100) DEFAULT NULL,
  `tax_number` varchar(50) DEFAULT NULL,
  `vatin` varchar(100) DEFAULT NULL,
  `opening_balance` double(20,4) DEFAULT NULL,
  `purchase_due` double(20,4) DEFAULT NULL,
  `purchase_return_due` double(20,4) DEFAULT NULL,
  `country_id` int(5) DEFAULT NULL,
  `state_id` int(5) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postcode` varchar(10) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(30) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_supplier_payments`
--

CREATE TABLE `db_supplier_payments` (
  `id` int(5) NOT NULL,
  `purchasepayment_id` int(5) DEFAULT NULL,
  `supplier_id` int(5) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payment_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `payment` double(10,2) DEFAULT NULL,
  `payment_note` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_time` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_date` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_by` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_tax`
--

CREATE TABLE `db_tax` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `tax_name` varchar(50) DEFAULT NULL,
  `tax` double(20,4) DEFAULT NULL,
  `group_bit` int(1) DEFAULT NULL COMMENT '1=Yes, 0=No',
  `subtax_ids` varchar(10) DEFAULT NULL COMMENT 'Tax groups IDs',
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_timezone`
--

CREATE TABLE `db_timezone` (
  `id` int(5) NOT NULL,
  `timezone` varchar(100) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_timezone`
--

INSERT INTO `db_timezone` (`id`, `timezone`, `status`) VALUES
(1, 'Africa/Abidjan\r', 1),
(2, 'Africa/Accra\r', 1),
(3, 'Africa/Addis_Ababa\r', 1),
(4, 'Africa/Algiers\r', 1),
(5, 'Africa/Asmara\r', 1),
(6, 'Africa/Asmera\r', 1),
(7, 'Africa/Bamako\r', 1),
(8, 'Africa/Bangui\r', 1),
(9, 'Africa/Banjul\r', 1),
(10, 'Africa/Bissau\r', 1),
(11, 'Africa/Blantyre\r', 1),
(12, 'Africa/Brazzaville\r', 1),
(13, 'Africa/Bujumbura\r', 1),
(14, 'Africa/Cairo\r', 1),
(15, 'Africa/Casablanca\r', 1),
(16, 'Africa/Ceuta\r', 1),
(17, 'Africa/Conakry\r', 1),
(18, 'Africa/Dakar\r', 1),
(19, 'Africa/Dar_es_Salaam\r', 1),
(20, 'Africa/Djibouti\r', 1),
(21, 'Africa/Douala\r', 1),
(22, 'Africa/El_Aaiun\r', 1),
(23, 'Africa/Freetown\r', 1),
(24, 'Africa/Gaborone\r', 1),
(25, 'Africa/Harare\r', 1),
(26, 'Africa/Johannesburg\r', 1),
(27, 'Africa/Juba\r', 1),
(28, 'Africa/Kampala\r', 1),
(29, 'Africa/Khartoum\r', 1),
(30, 'Africa/Kigali\r', 1),
(31, 'Africa/Kinshasa\r', 1),
(32, 'Africa/Lagos\r', 1),
(33, 'Africa/Libreville\r', 1),
(34, 'Africa/Lome\r', 1),
(35, 'Africa/Luanda\r', 1),
(36, 'Africa/Lubumbashi\r', 1),
(37, 'Africa/Lusaka\r', 1),
(38, 'Africa/Malabo\r', 1),
(39, 'Africa/Maputo\r', 1),
(40, 'Africa/Maseru\r', 1),
(41, 'Africa/Mbabane\r', 1),
(42, 'Africa/Mogadishu\r', 1),
(43, 'Africa/Monrovia\r', 1),
(44, 'Africa/Nairobi\r', 1),
(45, 'Africa/Ndjamena\r', 1),
(46, 'Africa/Niamey\r', 1),
(47, 'Africa/Nouakchott\r', 1),
(48, 'Africa/Ouagadougou\r', 1),
(49, 'Africa/Porto-Novo\r', 1),
(50, 'Africa/Sao_Tome\r', 1),
(51, 'Africa/Timbuktu\r', 1),
(52, 'Africa/Tripoli\r', 1),
(53, 'Africa/Tunis\r', 1),
(54, 'Africa/Windhoek\r', 1),
(55, 'AKST9AKDT\r', 1),
(56, 'America/Adak\r', 1),
(57, 'America/Anchorage\r', 1),
(58, 'America/Anguilla\r', 1),
(59, 'America/Antigua\r', 1),
(60, 'America/Araguaina\r', 1),
(61, 'America/Argentina/Buenos_Aires\r', 1),
(62, 'America/Argentina/Catamarca\r', 1),
(63, 'America/Argentina/ComodRivadavia\r', 1),
(64, 'America/Argentina/Cordoba\r', 1),
(65, 'America/Argentina/Jujuy\r', 1),
(66, 'America/Argentina/La_Rioja\r', 1),
(67, 'America/Argentina/Mendoza\r', 1),
(68, 'America/Argentina/Rio_Gallegos\r', 1),
(69, 'America/Argentina/Salta\r', 1),
(70, 'America/Argentina/San_Juan\r', 1),
(71, 'America/Argentina/San_Luis\r', 1),
(72, 'America/Argentina/Tucuman\r', 1),
(73, 'America/Argentina/Ushuaia\r', 1),
(74, 'America/Aruba\r', 1),
(75, 'America/Asuncion\r', 1),
(76, 'America/Atikokan\r', 1),
(77, 'America/Atka\r', 1),
(78, 'America/Bahia\r', 1),
(79, 'America/Bahia_Banderas\r', 1),
(80, 'America/Barbados\r', 1),
(81, 'America/Belem\r', 1),
(82, 'America/Belize\r', 1),
(83, 'America/Blanc-Sablon\r', 1),
(84, 'America/Boa_Vista\r', 1),
(85, 'America/Bogota\r', 1),
(86, 'America/Boise\r', 1),
(87, 'America/Buenos_Aires\r', 1),
(88, 'America/Cambridge_Bay\r', 1),
(89, 'America/Campo_Grande\r', 1),
(90, 'America/Cancun\r', 1),
(91, 'America/Caracas\r', 1),
(92, 'America/Catamarca\r', 1),
(93, 'America/Cayenne\r', 1),
(94, 'America/Cayman\r', 1),
(95, 'America/Chicago\r', 1),
(96, 'America/Chihuahua\r', 1),
(97, 'America/Coral_Harbour\r', 1),
(98, 'America/Cordoba\r', 1),
(99, 'America/Costa_Rica\r', 1),
(100, 'America/Creston\r', 1),
(101, 'America/Cuiaba\r', 1),
(102, 'America/Curacao\r', 1),
(103, 'America/Danmarkshavn\r', 1),
(104, 'America/Dawson\r', 1),
(105, 'America/Dawson_Creek\r', 1),
(106, 'America/Denver\r', 1),
(107, 'America/Detroit\r', 1),
(108, 'America/Dominica\r', 1),
(109, 'America/Edmonton\r', 1),
(110, 'America/Eirunepe\r', 1),
(111, 'America/El_Salvador\r', 1),
(112, 'America/Ensenada\r', 1),
(113, 'America/Fort_Wayne\r', 1),
(114, 'America/Fortaleza\r', 1),
(115, 'America/Glace_Bay\r', 1),
(116, 'America/Godthab\r', 1),
(117, 'America/Goose_Bay\r', 1),
(118, 'America/Grand_Turk\r', 1),
(119, 'America/Grenada\r', 1),
(120, 'America/Guadeloupe\r', 1),
(121, 'America/Guatemala\r', 1),
(122, 'America/Guayaquil\r', 1),
(123, 'America/Guyana\r', 1),
(124, 'America/Halifax\r', 1),
(125, 'America/Havana\r', 1),
(126, 'America/Hermosillo\r', 1),
(127, 'America/Indiana/Indianapolis\r', 1),
(128, 'America/Indiana/Knox\r', 1),
(129, 'America/Indiana/Marengo\r', 1),
(130, 'America/Indiana/Petersburg\r', 1),
(131, 'America/Indiana/Tell_City\r', 1),
(132, 'America/Indiana/Vevay\r', 1),
(133, 'America/Indiana/Vincennes\r', 1),
(134, 'America/Indiana/Winamac\r', 1),
(135, 'America/Indianapolis\r', 1),
(136, 'America/Inuvik\r', 1),
(137, 'America/Iqaluit\r', 1),
(138, 'America/Jamaica\r', 1),
(139, 'America/Jujuy\r', 1),
(140, 'America/Juneau\r', 1),
(141, 'America/Kentucky/Louisville\r', 1),
(142, 'America/Kentucky/Monticello\r', 1),
(143, 'America/Knox_IN\r', 1),
(144, 'America/Kralendijk\r', 1),
(145, 'America/La_Paz\r', 1),
(146, 'America/Lima\r', 1),
(147, 'America/Los_Angeles\r', 1),
(148, 'America/Louisville\r', 1),
(149, 'America/Lower_Princes\r', 1),
(150, 'America/Maceio\r', 1),
(151, 'America/Managua\r', 1),
(152, 'America/Manaus\r', 1),
(153, 'America/Marigot\r', 1),
(154, 'America/Martinique\r', 1),
(155, 'America/Matamoros\r', 1),
(156, 'America/Mazatlan\r', 1),
(157, 'America/Mendoza\r', 1),
(158, 'America/Menominee\r', 1),
(159, 'America/Merida\r', 1),
(160, 'America/Metlakatla\r', 1),
(161, 'America/Mexico_City\r', 1),
(162, 'America/Miquelon\r', 1),
(163, 'America/Moncton\r', 1),
(164, 'America/Monterrey\r', 1),
(165, 'America/Montevideo\r', 1),
(166, 'America/Montreal\r', 1),
(167, 'America/Montserrat\r', 1),
(168, 'America/Nassau\r', 1),
(169, 'America/New_York\r', 1),
(170, 'America/Nipigon\r', 1),
(171, 'America/Nome\r', 1),
(172, 'America/Noronha\r', 1),
(173, 'America/North_Dakota/Beulah\r', 1),
(174, 'America/North_Dakota/Center\r', 1),
(175, 'America/North_Dakota/New_Salem\r', 1),
(176, 'America/Ojinaga\r', 1),
(177, 'America/Panama\r', 1),
(178, 'America/Pangnirtung\r', 1),
(179, 'America/Paramaribo\r', 1),
(180, 'America/Phoenix\r', 1),
(181, 'America/Port_of_Spain\r', 1),
(182, 'America/Port-au-Prince\r', 1),
(183, 'America/Porto_Acre\r', 1),
(184, 'America/Porto_Velho\r', 1),
(185, 'America/Puerto_Rico\r', 1),
(186, 'America/Rainy_River\r', 1),
(187, 'America/Rankin_Inlet\r', 1),
(188, 'America/Recife\r', 1),
(189, 'America/Regina\r', 1),
(190, 'America/Resolute\r', 1),
(191, 'America/Rio_Branco\r', 1),
(192, 'America/Rosario\r', 1),
(193, 'America/Santa_Isabel\r', 1),
(194, 'America/Santarem\r', 1),
(195, 'America/Santiago\r', 1),
(196, 'America/Santo_Domingo\r', 1),
(197, 'America/Sao_Paulo\r', 1),
(198, 'America/Scoresbysund\r', 1),
(199, 'America/Shiprock\r', 1),
(200, 'America/Sitka\r', 1),
(201, 'America/St_Barthelemy\r', 1),
(202, 'America/St_Johns\r', 1),
(203, 'America/St_Kitts\r', 1),
(204, 'America/St_Lucia\r', 1),
(205, 'America/St_Thomas\r', 1),
(206, 'America/St_Vincent\r', 1),
(207, 'America/Swift_Current\r', 1),
(208, 'America/Tegucigalpa\r', 1),
(209, 'America/Thule\r', 1),
(210, 'America/Thunder_Bay\r', 1),
(211, 'America/Tijuana\r', 1),
(212, 'America/Toronto\r', 1),
(213, 'America/Tortola\r', 1),
(214, 'America/Vancouver\r', 1),
(215, 'America/Virgin\r', 1),
(216, 'America/Whitehorse\r', 1),
(217, 'America/Winnipeg\r', 1),
(218, 'America/Yakutat\r', 1),
(219, 'America/Yellowknife\r', 1),
(220, 'Antarctica/Casey\r', 1),
(221, 'Antarctica/Davis\r', 1),
(222, 'Antarctica/DumontDUrville\r', 1),
(223, 'Antarctica/Macquarie\r', 1),
(224, 'Antarctica/Mawson\r', 1),
(225, 'Antarctica/McMurdo\r', 1),
(226, 'Antarctica/Palmer\r', 1),
(227, 'Antarctica/Rothera\r', 1),
(228, 'Antarctica/South_Pole\r', 1),
(229, 'Antarctica/Syowa\r', 1),
(230, 'Antarctica/Vostok\r', 1),
(231, 'Arctic/Longyearbyen\r', 1),
(232, 'Asia/Aden\r', 1),
(233, 'Asia/Almaty\r', 1),
(234, 'Asia/Amman\r', 1),
(235, 'Asia/Anadyr\r', 1),
(236, 'Asia/Aqtau\r', 1),
(237, 'Asia/Aqtobe\r', 1),
(238, 'Asia/Ashgabat\r', 1),
(239, 'Asia/Ashkhabad\r', 1),
(240, 'Asia/Baghdad\r', 1),
(241, 'Asia/Bahrain\r', 1),
(242, 'Asia/Baku\r', 1),
(243, 'Asia/Bangkok\r', 1),
(244, 'Asia/Beirut\r', 1),
(245, 'Asia/Bishkek\r', 1),
(246, 'Asia/Brunei\r', 1),
(247, 'Asia/Calcutta\r', 1),
(248, 'Asia/Choibalsan\r', 1),
(249, 'Asia/Chongqing\r', 1),
(250, 'Asia/Chungking\r', 1),
(251, 'Asia/Colombo\r', 1),
(252, 'Asia/Dacca\r', 1),
(253, 'Asia/Damascus\r', 1),
(254, 'Asia/Dhaka\r', 1),
(255, 'Asia/Dili\r', 1),
(256, 'Asia/Dubai\r', 1),
(257, 'Asia/Dushanbe\r', 1),
(258, 'Asia/Gaza\r', 1),
(259, 'Asia/Harbin\r', 1),
(260, 'Asia/Hebron\r', 1),
(261, 'Asia/Ho_Chi_Minh\r', 1),
(262, 'Asia/Hong_Kong\r', 1),
(263, 'Asia/Hovd\r', 1),
(264, 'Asia/Irkutsk\r', 1),
(265, 'Asia/Istanbul\r', 1),
(266, 'Asia/Jakarta\r', 1),
(267, 'Asia/Jayapura\r', 1),
(268, 'Asia/Jerusalem\r', 1),
(269, 'Asia/Kabul\r', 1),
(270, 'Asia/Kamchatka\r', 1),
(271, 'Asia/Karachi\r', 1),
(272, 'Asia/Kashgar\r', 1),
(273, 'Asia/Kathmandu\r', 1),
(274, 'Asia/Katmandu\r', 1),
(275, 'Asia/Kolkata\r', 1),
(276, 'Asia/Krasnoyarsk\r', 1),
(277, 'Asia/Kuala_Lumpur\r', 1),
(278, 'Asia/Kuching\r', 1),
(279, 'Asia/Kuwait\r', 1),
(280, 'Asia/Macao\r', 1),
(281, 'Asia/Macau\r', 1),
(282, 'Asia/Magadan\r', 1),
(283, 'Asia/Makassar\r', 1),
(284, 'Asia/Manila\r', 1),
(285, 'Asia/Muscat\r', 1),
(286, 'Asia/Nicosia\r', 1),
(287, 'Asia/Novokuznetsk\r', 1),
(288, 'Asia/Novosibirsk\r', 1),
(289, 'Asia/Omsk\r', 1),
(290, 'Asia/Oral\r', 1),
(291, 'Asia/Phnom_Penh\r', 1),
(292, 'Asia/Pontianak\r', 1),
(293, 'Asia/Pyongyang\r', 1),
(294, 'Asia/Qatar\r', 1),
(295, 'Asia/Qyzylorda\r', 1),
(296, 'Asia/Rangoon\r', 1),
(297, 'Asia/Riyadh\r', 1),
(298, 'Asia/Saigon\r', 1),
(299, 'Asia/Sakhalin\r', 1),
(300, 'Asia/Samarkand\r', 1),
(301, 'Asia/Seoul\r', 1),
(302, 'Asia/Shanghai\r', 1),
(303, 'Asia/Singapore\r', 1),
(304, 'Asia/Taipei\r', 1),
(305, 'Asia/Tashkent\r', 1),
(306, 'Asia/Tbilisi\r', 1),
(307, 'Asia/Tehran\r', 1),
(308, 'Asia/Tel_Aviv\r', 1),
(309, 'Asia/Thimbu\r', 1),
(310, 'Asia/Thimphu\r', 1),
(311, 'Asia/Tokyo\r', 1),
(312, 'Asia/Ujung_Pandang\r', 1),
(313, 'Asia/Ulaanbaatar\r', 1),
(314, 'Asia/Ulan_Bator\r', 1),
(315, 'Asia/Urumqi\r', 1),
(316, 'Asia/Vientiane\r', 1),
(317, 'Asia/Vladivostok\r', 1),
(318, 'Asia/Yakutsk\r', 1),
(319, 'Asia/Yekaterinburg\r', 1),
(320, 'Asia/Yerevan\r', 1),
(321, 'Atlantic/Azores\r', 1),
(322, 'Atlantic/Bermuda\r', 1),
(323, 'Atlantic/Canary\r', 1),
(324, 'Atlantic/Cape_Verde\r', 1),
(325, 'Atlantic/Faeroe\r', 1),
(326, 'Atlantic/Faroe\r', 1),
(327, 'Atlantic/Jan_Mayen\r', 1),
(328, 'Atlantic/Madeira\r', 1),
(329, 'Atlantic/Reykjavik\r', 1),
(330, 'Atlantic/South_Georgia\r', 1),
(331, 'Atlantic/St_Helena\r', 1),
(332, 'Atlantic/Stanley\r', 1),
(333, 'Australia/ACT\r', 1),
(334, 'Australia/Adelaide\r', 1),
(335, 'Australia/Brisbane\r', 1),
(336, 'Australia/Broken_Hill\r', 1),
(337, 'Australia/Canberra\r', 1),
(338, 'Australia/Currie\r', 1),
(339, 'Australia/Darwin\r', 1),
(340, 'Australia/Eucla\r', 1),
(341, 'Australia/Hobart\r', 1),
(342, 'Australia/LHI\r', 1),
(343, 'Australia/Lindeman\r', 1),
(344, 'Australia/Lord_Howe\r', 1),
(345, 'Australia/Melbourne\r', 1),
(346, 'Australia/North\r', 1),
(347, 'Australia/NSW\r', 1),
(348, 'Australia/Perth\r', 1),
(349, 'Australia/Queensland\r', 1),
(350, 'Australia/South\r', 1),
(351, 'Australia/Sydney\r', 1),
(352, 'Australia/Tasmania\r', 1),
(353, 'Australia/Victoria\r', 1),
(354, 'Australia/West\r', 1),
(355, 'Australia/Yancowinna\r', 1),
(356, 'Brazil/Acre\r', 1),
(357, 'Brazil/DeNoronha\r', 1),
(358, 'Brazil/East\r', 1),
(359, 'Brazil/West\r', 1),
(360, 'Canada/Atlantic\r', 1),
(361, 'Canada/Central\r', 1),
(362, 'Canada/Eastern\r', 1),
(363, 'Canada/East-Saskatchewan\r', 1),
(364, 'Canada/Mountain\r', 1),
(365, 'Canada/Newfoundland\r', 1),
(366, 'Canada/Pacific\r', 1),
(367, 'Canada/Saskatchewan\r', 1),
(368, 'Canada/Yukon\r', 1),
(369, 'CET\r', 1),
(370, 'Chile/Continental\r', 1),
(371, 'Chile/EasterIsland\r', 1),
(372, 'CST6CDT\r', 1),
(373, 'Cuba\r', 1),
(374, 'EET\r', 1),
(375, 'Egypt\r', 1),
(376, 'Eire\r', 1),
(377, 'EST\r', 1),
(378, 'EST5EDT\r', 1),
(379, 'Etc./GMT\r', 1),
(380, 'Etc./GMT+0\r', 1),
(381, 'Etc./UCT\r', 1),
(382, 'Etc./Universal\r', 1),
(383, 'Etc./UTC\r', 1),
(384, 'Etc./Zulu\r', 1),
(385, 'Europe/Amsterdam\r', 1),
(386, 'Europe/Andorra\r', 1),
(387, 'Europe/Athens\r', 1),
(388, 'Europe/Belfast\r', 1),
(389, 'Europe/Belgrade\r', 1),
(390, 'Europe/Berlin\r', 1),
(391, 'Europe/Bratislava\r', 1),
(392, 'Europe/Brussels\r', 1),
(393, 'Europe/Bucharest\r', 1),
(394, 'Europe/Budapest\r', 1),
(395, 'Europe/Chisinau\r', 1),
(396, 'Europe/Copenhagen\r', 1),
(397, 'Europe/Dublin\r', 1),
(398, 'Europe/Gibraltar\r', 1),
(399, 'Europe/Guernsey\r', 1),
(400, 'Europe/Helsinki\r', 1),
(401, 'Europe/Isle_of_Man\r', 1),
(402, 'Europe/Istanbul\r', 1),
(403, 'Europe/Jersey\r', 1),
(404, 'Europe/Kaliningrad\r', 1),
(405, 'Europe/Kiev\r', 1),
(406, 'Europe/Lisbon\r', 1),
(407, 'Europe/Ljubljana\r', 1),
(408, 'Europe/London\r', 1),
(409, 'Europe/Luxembourg\r', 1),
(410, 'Europe/Madrid\r', 1),
(411, 'Europe/Malta\r', 1),
(412, 'Europe/Mariehamn\r', 1),
(413, 'Europe/Minsk\r', 1),
(414, 'Europe/Monaco\r', 1),
(415, 'Europe/Moscow\r', 1),
(416, 'Europe/Nicosia\r', 1),
(417, 'Europe/Oslo\r', 1),
(418, 'Europe/Paris\r', 1),
(419, 'Europe/Podgorica\r', 1),
(420, 'Europe/Prague\r', 1),
(421, 'Europe/Riga\r', 1),
(422, 'Europe/Rome\r', 1),
(423, 'Europe/Samara\r', 1),
(424, 'Europe/San_Marino\r', 1),
(425, 'Europe/Sarajevo\r', 1),
(426, 'Europe/Simferopol\r', 1),
(427, 'Europe/Skopje\r', 1),
(428, 'Europe/Sofia\r', 1),
(429, 'Europe/Stockholm\r', 1),
(430, 'Europe/Tallinn\r', 1),
(431, 'Europe/Tirane\r', 1),
(432, 'Europe/Tiraspol\r', 1),
(433, 'Europe/Uzhgorod\r', 1),
(434, 'Europe/Vaduz\r', 1),
(435, 'Europe/Vatican\r', 1),
(436, 'Europe/Vienna\r', 1),
(437, 'Europe/Vilnius\r', 1),
(438, 'Europe/Volgograd\r', 1),
(439, 'Europe/Warsaw\r', 1),
(440, 'Europe/Zagreb\r', 1),
(441, 'Europe/Zaporozhye\r', 1),
(442, 'Europe/Zurich\r', 1),
(443, 'GB\r', 1),
(444, 'GB-Eire\r', 1),
(445, 'GMT\r', 1),
(446, 'GMT+0\r', 1),
(447, 'GMT0\r', 1),
(448, 'GMT-0\r', 1),
(449, 'Greenwich\r', 1),
(450, 'Hong Kong\r', 1),
(451, 'HST\r', 1),
(452, 'Iceland\r', 1),
(453, 'Indian/Antananarivo\r', 1),
(454, 'Indian/Chagos\r', 1),
(455, 'Indian/Christmas\r', 1),
(456, 'Indian/Cocos\r', 1),
(457, 'Indian/Comoro\r', 1),
(458, 'Indian/Kerguelen\r', 1),
(459, 'Indian/Mahe\r', 1),
(460, 'Indian/Maldives\r', 1),
(461, 'Indian/Mauritius\r', 1),
(462, 'Indian/Mayotte\r', 1),
(463, 'Indian/Reunion\r', 1),
(464, 'Iran\r', 1),
(465, 'Israel\r', 1),
(466, 'Jamaica\r', 1),
(467, 'Japan\r', 1),
(468, 'JST-9\r', 1),
(469, 'Kwajalein\r', 1),
(470, 'Libya\r', 1),
(471, 'MET\r', 1),
(472, 'Mexico/BajaNorte\r', 1),
(473, 'Mexico/BajaSur\r', 1),
(474, 'Mexico/General\r', 1),
(475, 'MST\r', 1),
(476, 'MST7MDT\r', 1),
(477, 'Navajo\r', 1),
(478, 'NZ\r', 1),
(479, 'NZ-CHAT\r', 1),
(480, 'Pacific/Apia\r', 1),
(481, 'Pacific/Auckland\r', 1),
(482, 'Pacific/Chatham\r', 1),
(483, 'Pacific/Chuuk\r', 1),
(484, 'Pacific/Easter\r', 1),
(485, 'Pacific/Efate\r', 1),
(486, 'Pacific/Enderbury\r', 1),
(487, 'Pacific/Fakaofo\r', 1),
(488, 'Pacific/Fiji\r', 1),
(489, 'Pacific/Funafuti\r', 1),
(490, 'Pacific/Galapagos\r', 1),
(491, 'Pacific/Gambier\r', 1),
(492, 'Pacific/Guadalcanal\r', 1),
(493, 'Pacific/Guam\r', 1),
(494, 'Pacific/Honolulu\r', 1),
(495, 'Pacific/Johnston\r', 1),
(496, 'Pacific/Kiritimati\r', 1),
(497, 'Pacific/Kosrae\r', 1),
(498, 'Pacific/Kwajalein\r', 1),
(499, 'Pacific/Majuro\r', 1),
(500, 'Pacific/Marquesas\r', 1),
(501, 'Pacific/Midway\r', 1),
(502, 'Pacific/Nauru\r', 1),
(503, 'Pacific/Niue\r', 1),
(504, 'Pacific/Norfolk\r', 1),
(505, 'Pacific/Noumea\r', 1),
(506, 'Pacific/Pago_Pago\r', 1),
(507, 'Pacific/Palau\r', 1),
(508, 'Pacific/Pitcairn\r', 1),
(509, 'Pacific/Pohnpei\r', 1),
(510, 'Pacific/Ponape\r', 1),
(511, 'Pacific/Port_Moresby\r', 1),
(512, 'Pacific/Rarotonga\r', 1),
(513, 'Pacific/Saipan\r', 1),
(514, 'Pacific/Samoa\r', 1),
(515, 'Pacific/Tahiti\r', 1),
(516, 'Pacific/Tarawa\r', 1),
(517, 'Pacific/Tongatapu\r', 1),
(518, 'Pacific/Truk\r', 1),
(519, 'Pacific/Wake\r', 1),
(520, 'Pacific/Wallis\r', 1),
(521, 'Pacific/Yap\r', 1),
(522, 'Poland\r', 1),
(523, 'Portugal\r', 1),
(524, 'PRC\r', 1),
(525, 'PST8PDT\r', 1),
(526, 'ROC\r', 1),
(527, 'ROK\r', 1),
(528, 'Singapore\r', 1),
(529, 'Turkey\r', 1),
(530, 'UCT\r', 1),
(531, 'Universal\r', 1),
(532, 'US/Alaska\r', 1),
(533, 'US/Aleutian\r', 1),
(534, 'US/Arizona\r', 1),
(535, 'US/Central\r', 1),
(536, 'US/Eastern\r', 1),
(537, 'US/East-Indiana\r', 1),
(538, 'US/Hawaii\r', 1),
(539, 'US/Indiana-Starke\r', 1),
(540, 'US/Michigan\r', 1),
(541, 'US/Mountain\r', 1),
(542, 'US/Pacific\r', 1),
(543, 'US/Pacific-New\r', 1),
(544, 'US/Samoa\r', 1),
(545, 'UTC\r', 1),
(546, 'WET\r', 1),
(547, 'W-SU\r', 1),
(548, 'Zulu\r', 1);

-- --------------------------------------------------------

--
-- Table structure for table `db_twilio`
--

CREATE TABLE `db_twilio` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `account_sid` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `auth_token` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `twilio_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` int(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_twilio`
--

INSERT INTO `db_twilio` (`id`, `store_id`, `account_sid`, `auth_token`, `twilio_phone`, `status`) VALUES
(1, 1, '', '', '', 0),
(3, 2, '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `db_units`
--

CREATE TABLE `db_units` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `unit_name` varchar(50) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `company_id` int(5) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_users`
--

CREATE TABLE `db_users` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `password` blob DEFAULT NULL,
  `member_of` varchar(50) DEFAULT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `photo` blob DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `address` blob DEFAULT NULL,
  `postcode` varchar(50) DEFAULT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `role_id` int(5) DEFAULT NULL,
  `profile_picture` text DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(100) DEFAULT NULL,
  `system_name` varchar(100) DEFAULT NULL,
  `status` double DEFAULT NULL,
  `creater_id` int(5) DEFAULT NULL,
  `updater_id` int(5) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `default_warehouse_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_users`
--

INSERT INTO `db_users` (`id`, `store_id`, `username`, `first_name`, `last_name`, `password`, `member_of`, `firstname`, `lastname`, `mobile`, `email`, `photo`, `gender`, `dob`, `country`, `state`, `city`, `address`, `postcode`, `role_name`, `role_id`, `profile_picture`, `created_date`, `created_time`, `created_by`, `system_ip`, `system_name`, `status`, `creater_id`, `updater_id`, `updated_at`, `default_warehouse_id`) VALUES
(1, 1, 'user_240399', 'Admin', 'Power', 0x6531306164633339343962613539616262653536653035376632306638383365, '', NULL, NULL, '', 'super@example.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 'uploads/users/admin.png', '2018-11-27', '::1', NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(2, 2, 'admin@test', 'Admin', 'Admin', 0x3235663965373934333233623435333838356635313831663162363234643062, NULL, NULL, NULL, '', 'cryptosbiz100@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, 'uploads/users/avatar1.png', '2021-02-12', '05:53:37 pm', '', '127.0.0.1', 'LAPTOP-I5OUIM4R', 1, NULL, NULL, NULL, 0),
(102, 2, 'admin@manager', 'Test', 'Users', 0x3235663965373934333233623435333838356635313831663162363234643062, NULL, NULL, NULL, '', 'razystudio100@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 31, NULL, '2023-04-17', '01:09:16 pm', 'Admin', '102.176.94.118', '102-176-94-118-dedicated.vodafone.com.gh', 1, NULL, NULL, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `db_userswarehouses`
--

CREATE TABLE `db_userswarehouses` (
  `id` int(5) NOT NULL,
  `user_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_variants`
--

CREATE TABLE `db_variants` (
  `id` int(5) NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `variant_code` varchar(50) DEFAULT NULL,
  `variant_name` varchar(100) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `db_warehouse`
--

CREATE TABLE `db_warehouse` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `warehouse_type` varchar(50) DEFAULT NULL,
  `warehouse_name` varchar(50) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `db_warehouse`
--

INSERT INTO `db_warehouse` (`id`, `store_id`, `warehouse_type`, `warehouse_name`, `mobile`, `email`, `status`, `created_date`) VALUES
(1, 1, 'System', 'Warehouse-A', '', 'warehouse_a@example.com', 1, NULL),
(2, 2, 'System', 'System Warehouse', '', '', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `db_warehouseitems`
--

CREATE TABLE `db_warehouseitems` (
  `id` int(5) NOT NULL,
  `store_id` int(5) DEFAULT NULL,
  `warehouse_id` int(5) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `available_qty` double(20,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `temp_holdinvoice`
--

CREATE TABLE `temp_holdinvoice` (
  `id` int(5) NOT NULL,
  `invoice_id` int(5) DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `reference_id` varchar(50) DEFAULT NULL,
  `item_id` int(5) DEFAULT NULL,
  `item_qty` int(5) DEFAULT NULL,
  `item_price` double(10,2) DEFAULT NULL,
  `tax` double(10,2) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` varchar(50) DEFAULT NULL,
  `created_by` varchar(50) DEFAULT NULL,
  `system_ip` varchar(50) DEFAULT NULL,
  `system_name` varchar(50) DEFAULT NULL,
  `pos` int(5) DEFAULT NULL,
  `status` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ac_accounts`
--
ALTER TABLE `ac_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `paymenttypes_id` (`paymenttypes_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `expense_id` (`expense_id`);

--
-- Indexes for table `ac_moneydeposits`
--
ALTER TABLE `ac_moneydeposits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_account_id` (`debit_account_id`),
  ADD KEY `to_account_id` (`credit_account_id`),
  ADD KEY `db_moneydeposits_ibfk_3` (`store_id`);

--
-- Indexes for table `ac_moneytransfer`
--
ALTER TABLE `ac_moneytransfer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_account_id` (`debit_account_id`),
  ADD KEY `to_account_id` (`credit_account_id`),
  ADD KEY `db_moneytransfer_ibfk_3` (`store_id`);

--
-- Indexes for table `ac_transactions`
--
ALTER TABLE `ac_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `journal_id` (`transaction_type`),
  ADD KEY `account_id` (`debit_account_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `ac_accounts_id` (`ref_accounts_id`),
  ADD KEY `ac_moneytransfer_id` (`ref_moneytransfer_id`),
  ADD KEY `ac_moneydeposits_id` (`ref_moneydeposits_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `ref_salespayments_id` (`ref_salespayments_id`),
  ADD KEY `ref_purchasepayments_id` (`ref_purchasepayments_id`),
  ADD KEY `ref_purchasepaymentsreturn_id` (`ref_purchasepaymentsreturn_id`),
  ADD KEY `ac_transactions_ibfk_9` (`ref_salespaymentsreturn_id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `ref_expense_id` (`ref_expense_id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `db_bankdetails`
--
ALTER TABLE `db_bankdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_brands`
--
ALTER TABLE `db_brands`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_category`
--
ALTER TABLE `db_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_cobpayments`
--
ALTER TABLE `db_cobpayments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_country`
--
ALTER TABLE `db_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_coupons`
--
ALTER TABLE `db_coupons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_currency`
--
ALTER TABLE `db_currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_custadvance`
--
ALTER TABLE `db_custadvance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_customers`
--
ALTER TABLE `db_customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_customer_coupons`
--
ALTER TABLE `db_customer_coupons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `coupon_id` (`coupon_id`);

--
-- Indexes for table `db_customer_payments`
--
ALTER TABLE `db_customer_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `salespayment_id` (`salespayment_id`);

--
-- Indexes for table `db_emailtemplates`
--
ALTER TABLE `db_emailtemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_expense`
--
ALTER TABLE `db_expense`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `db_expense_category`
--
ALTER TABLE `db_expense_category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_fivemojo`
--
ALTER TABLE `db_fivemojo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_hold`
--
ALTER TABLE `db_hold`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `warehouse_id` (`warehouse_id`);

--
-- Indexes for table `db_holditems`
--
ALTER TABLE `db_holditems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `sales_id` (`hold_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `db_instamojo`
--
ALTER TABLE `db_instamojo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_instamojopayments`
--
ALTER TABLE `db_instamojopayments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_items`
--
ALTER TABLE `db_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_languages`
--
ALTER TABLE `db_languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_package`
--
ALTER TABLE `db_package`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_paymenttypes`
--
ALTER TABLE `db_paymenttypes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_paypal`
--
ALTER TABLE `db_paypal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_paypalpaylog`
--
ALTER TABLE `db_paypalpaylog`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `db_permissions`
--
ALTER TABLE `db_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_purchase`
--
ALTER TABLE `db_purchase`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `db_purchaseitems`
--
ALTER TABLE `db_purchaseitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `purchase_id` (`purchase_id`);

--
-- Indexes for table `db_purchaseitemsreturn`
--
ALTER TABLE `db_purchaseitemsreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `return_id` (`return_id`),
  ADD KEY `purchase_id` (`purchase_id`);

--
-- Indexes for table `db_purchasepayments`
--
ALTER TABLE `db_purchasepayments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `purchase_id` (`purchase_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `db_purchasepaymentsreturn`
--
ALTER TABLE `db_purchasepaymentsreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `return_id` (`return_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `db_purchasereturn`
--
ALTER TABLE `db_purchasereturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `purchase_id` (`purchase_id`);

--
-- Indexes for table `db_quotation`
--
ALTER TABLE `db_quotation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `warehouse_id` (`warehouse_id`);

--
-- Indexes for table `db_quotationitems`
--
ALTER TABLE `db_quotationitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `quotation_id` (`quotation_id`);

--
-- Indexes for table `db_roles`
--
ALTER TABLE `db_roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_sales`
--
ALTER TABLE `db_sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `warehouse_id` (`warehouse_id`),
  ADD KEY `coupon_id` (`coupon_id`);

--
-- Indexes for table `db_salesitems`
--
ALTER TABLE `db_salesitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `sales_id` (`sales_id`);

--
-- Indexes for table `db_salesitemsreturn`
--
ALTER TABLE `db_salesitemsreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `return_id` (`return_id`);

--
-- Indexes for table `db_salespayments`
--
ALTER TABLE `db_salespayments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `db_salespaymentsreturn`
--
ALTER TABLE `db_salespaymentsreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `return_id` (`return_id`),
  ADD KEY `db_salespaymentsreturn_ibfk_3` (`customer_id`);

--
-- Indexes for table `db_salesreturn`
--
ALTER TABLE `db_salesreturn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `sales_id` (`sales_id`),
  ADD KEY `coupon_id` (`coupon_id`);

--
-- Indexes for table `db_shippingaddress`
--
ALTER TABLE `db_shippingaddress`
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `db_sitesettings`
--
ALTER TABLE `db_sitesettings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_smsapi`
--
ALTER TABLE `db_smsapi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_smstemplates`
--
ALTER TABLE `db_smstemplates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_sobpayments`
--
ALTER TABLE `db_sobpayments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_states`
--
ALTER TABLE `db_states`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_stockadjustment`
--
ALTER TABLE `db_stockadjustment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_stockadjustmentitems`
--
ALTER TABLE `db_stockadjustmentitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_id` (`adjustment_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `warehouse_id` (`warehouse_id`);

--
-- Indexes for table `db_stockentry`
--
ALTER TABLE `db_stockentry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_stocktransfer`
--
ALTER TABLE `db_stocktransfer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `warehouse_id` (`warehouse_from`),
  ADD KEY `warehouse_to` (`warehouse_to`),
  ADD KEY `db_stocktransfer_ibfk_4` (`to_store_id`);

--
-- Indexes for table `db_stocktransferitems`
--
ALTER TABLE `db_stocktransferitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `warehouse_from` (`warehouse_from`),
  ADD KEY `warehouse_to` (`warehouse_to`),
  ADD KEY `stocktranfer_id` (`stocktransfer_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `db_stocktransferitems_ibfk_6` (`to_store_id`);

--
-- Indexes for table `db_store`
--
ALTER TABLE `db_store`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_stripe`
--
ALTER TABLE `db_stripe`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_stripepayments`
--
ALTER TABLE `db_stripepayments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_subscription`
--
ALTER TABLE `db_subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_suppliers`
--
ALTER TABLE `db_suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_supplier_payments`
--
ALTER TABLE `db_supplier_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `purchasepayment_id` (`purchasepayment_id`);

--
-- Indexes for table `db_tax`
--
ALTER TABLE `db_tax`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_timezone`
--
ALTER TABLE `db_timezone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `db_twilio`
--
ALTER TABLE `db_twilio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_units`
--
ALTER TABLE `db_units`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_users`
--
ALTER TABLE `db_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_userswarehouses`
--
ALTER TABLE `db_userswarehouses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `warehouse_id` (`warehouse_id`);

--
-- Indexes for table `db_variants`
--
ALTER TABLE `db_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_warehouse`
--
ALTER TABLE `db_warehouse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`);

--
-- Indexes for table `db_warehouseitems`
--
ALTER TABLE `db_warehouseitems`
  ADD PRIMARY KEY (`id`),
  ADD KEY `store_id` (`store_id`),
  ADD KEY `warehouse_id` (`warehouse_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `temp_holdinvoice`
--
ALTER TABLE `temp_holdinvoice`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ac_accounts`
--
ALTER TABLE `ac_accounts`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `ac_moneydeposits`
--
ALTER TABLE `ac_moneydeposits`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=670;

--
-- AUTO_INCREMENT for table `ac_moneytransfer`
--
ALTER TABLE `ac_moneytransfer`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ac_transactions`
--
ALTER TABLE `ac_transactions`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2269;

--
-- AUTO_INCREMENT for table `db_bankdetails`
--
ALTER TABLE `db_bankdetails`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_brands`
--
ALTER TABLE `db_brands`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=332;

--
-- AUTO_INCREMENT for table `db_category`
--
ALTER TABLE `db_category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `db_cobpayments`
--
ALTER TABLE `db_cobpayments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_country`
--
ALTER TABLE `db_country`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=210;

--
-- AUTO_INCREMENT for table `db_coupons`
--
ALTER TABLE `db_coupons`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=345;

--
-- AUTO_INCREMENT for table `db_currency`
--
ALTER TABLE `db_currency`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `db_custadvance`
--
ALTER TABLE `db_custadvance`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_customers`
--
ALTER TABLE `db_customers`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `db_customer_coupons`
--
ALTER TABLE `db_customer_coupons`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `db_customer_payments`
--
ALTER TABLE `db_customer_payments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_emailtemplates`
--
ALTER TABLE `db_emailtemplates`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `db_expense`
--
ALTER TABLE `db_expense`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `db_expense_category`
--
ALTER TABLE `db_expense_category`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `db_fivemojo`
--
ALTER TABLE `db_fivemojo`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `db_hold`
--
ALTER TABLE `db_hold`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `db_holditems`
--
ALTER TABLE `db_holditems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=394;

--
-- AUTO_INCREMENT for table `db_instamojo`
--
ALTER TABLE `db_instamojo`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_instamojopayments`
--
ALTER TABLE `db_instamojopayments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `db_items`
--
ALTER TABLE `db_items`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `db_languages`
--
ALTER TABLE `db_languages`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `db_package`
--
ALTER TABLE `db_package`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `db_paymenttypes`
--
ALTER TABLE `db_paymenttypes`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `db_paypal`
--
ALTER TABLE `db_paypal`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_paypalpaylog`
--
ALTER TABLE `db_paypalpaylog`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_permissions`
--
ALTER TABLE `db_permissions`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6377;

--
-- AUTO_INCREMENT for table `db_purchase`
--
ALTER TABLE `db_purchase`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `db_purchaseitems`
--
ALTER TABLE `db_purchaseitems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;

--
-- AUTO_INCREMENT for table `db_purchaseitemsreturn`
--
ALTER TABLE `db_purchaseitemsreturn`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `db_purchasepayments`
--
ALTER TABLE `db_purchasepayments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `db_purchasepaymentsreturn`
--
ALTER TABLE `db_purchasepaymentsreturn`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `db_purchasereturn`
--
ALTER TABLE `db_purchasereturn`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `db_quotation`
--
ALTER TABLE `db_quotation`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `db_quotationitems`
--
ALTER TABLE `db_quotationitems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=288;

--
-- AUTO_INCREMENT for table `db_roles`
--
ALTER TABLE `db_roles`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `db_sales`
--
ALTER TABLE `db_sales`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `db_salesitems`
--
ALTER TABLE `db_salesitems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=556;

--
-- AUTO_INCREMENT for table `db_salesitemsreturn`
--
ALTER TABLE `db_salesitemsreturn`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `db_salespayments`
--
ALTER TABLE `db_salespayments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=290;

--
-- AUTO_INCREMENT for table `db_salespaymentsreturn`
--
ALTER TABLE `db_salespaymentsreturn`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `db_salesreturn`
--
ALTER TABLE `db_salesreturn`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `db_shippingaddress`
--
ALTER TABLE `db_shippingaddress`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_sitesettings`
--
ALTER TABLE `db_sitesettings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_smsapi`
--
ALTER TABLE `db_smsapi`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `db_smstemplates`
--
ALTER TABLE `db_smstemplates`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `db_sobpayments`
--
ALTER TABLE `db_sobpayments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_states`
--
ALTER TABLE `db_states`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `db_stockadjustment`
--
ALTER TABLE `db_stockadjustment`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `db_stockadjustmentitems`
--
ALTER TABLE `db_stockadjustmentitems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=363;

--
-- AUTO_INCREMENT for table `db_stockentry`
--
ALTER TABLE `db_stockentry`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_stocktransfer`
--
ALTER TABLE `db_stocktransfer`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_stocktransferitems`
--
ALTER TABLE `db_stocktransferitems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `db_store`
--
ALTER TABLE `db_store`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `db_stripe`
--
ALTER TABLE `db_stripe`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `db_stripepayments`
--
ALTER TABLE `db_stripepayments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `db_subscription`
--
ALTER TABLE `db_subscription`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `db_suppliers`
--
ALTER TABLE `db_suppliers`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `db_supplier_payments`
--
ALTER TABLE `db_supplier_payments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=291;

--
-- AUTO_INCREMENT for table `db_tax`
--
ALTER TABLE `db_tax`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `db_timezone`
--
ALTER TABLE `db_timezone`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=549;

--
-- AUTO_INCREMENT for table `db_twilio`
--
ALTER TABLE `db_twilio`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `db_units`
--
ALTER TABLE `db_units`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `db_users`
--
ALTER TABLE `db_users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `db_userswarehouses`
--
ALTER TABLE `db_userswarehouses`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT for table `db_variants`
--
ALTER TABLE `db_variants`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- AUTO_INCREMENT for table `db_warehouse`
--
ALTER TABLE `db_warehouse`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `db_warehouseitems`
--
ALTER TABLE `db_warehouseitems`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4157;

--
-- AUTO_INCREMENT for table `temp_holdinvoice`
--
ALTER TABLE `temp_holdinvoice`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ac_accounts`
--
ALTER TABLE `ac_accounts`
  ADD CONSTRAINT `ac_accounts_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_accounts_ibfk_2` FOREIGN KEY (`paymenttypes_id`) REFERENCES `db_paymenttypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_accounts_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_accounts_ibfk_4` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_accounts_ibfk_5` FOREIGN KEY (`expense_id`) REFERENCES `db_expense` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ac_moneydeposits`
--
ALTER TABLE `ac_moneydeposits`
  ADD CONSTRAINT `ac_moneydeposits_ibfk_1` FOREIGN KEY (`debit_account_id`) REFERENCES `ac_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_moneydeposits_ibfk_2` FOREIGN KEY (`credit_account_id`) REFERENCES `ac_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_moneydeposits_ibfk_3` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ac_moneytransfer`
--
ALTER TABLE `ac_moneytransfer`
  ADD CONSTRAINT `ac_moneytransfer_ibfk_1` FOREIGN KEY (`debit_account_id`) REFERENCES `ac_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_moneytransfer_ibfk_2` FOREIGN KEY (`credit_account_id`) REFERENCES `ac_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_moneytransfer_ibfk_3` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ac_transactions`
--
ALTER TABLE `ac_transactions`
  ADD CONSTRAINT `ac_transactions_ibfk_10` FOREIGN KEY (`ref_purchasepayments_id`) REFERENCES `db_purchasepayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_11` FOREIGN KEY (`ref_purchasepaymentsreturn_id`) REFERENCES `db_purchasepaymentsreturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_12` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_13` FOREIGN KEY (`ref_expense_id`) REFERENCES `db_expense` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_3` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_4` FOREIGN KEY (`ref_accounts_id`) REFERENCES `ac_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_5` FOREIGN KEY (`ref_moneytransfer_id`) REFERENCES `ac_moneytransfer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_6` FOREIGN KEY (`ref_moneydeposits_id`) REFERENCES `ac_moneydeposits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_7` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_8` FOREIGN KEY (`ref_salespayments_id`) REFERENCES `db_salespayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ac_transactions_ibfk_9` FOREIGN KEY (`ref_salespaymentsreturn_id`) REFERENCES `db_salespaymentsreturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_bankdetails`
--
ALTER TABLE `db_bankdetails`
  ADD CONSTRAINT `db_bankdetails_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `db_brands`
--
ALTER TABLE `db_brands`
  ADD CONSTRAINT `db_brands_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_brands_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_category`
--
ALTER TABLE `db_category`
  ADD CONSTRAINT `db_category_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_coupons`
--
ALTER TABLE `db_coupons`
  ADD CONSTRAINT `db_coupons_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_coupons_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_custadvance`
--
ALTER TABLE `db_custadvance`
  ADD CONSTRAINT `db_custadvance_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_custadvance_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_customers`
--
ALTER TABLE `db_customers`
  ADD CONSTRAINT `db_customers_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_customer_coupons`
--
ALTER TABLE `db_customer_coupons`
  ADD CONSTRAINT `db_customer_coupons_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_customer_coupons_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_customer_coupons_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_customer_coupons_ibfk_4` FOREIGN KEY (`coupon_id`) REFERENCES `db_coupons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_customer_payments`
--
ALTER TABLE `db_customer_payments`
  ADD CONSTRAINT `db_customer_payments_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_customer_payments_ibfk_2` FOREIGN KEY (`salespayment_id`) REFERENCES `db_salespayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_emailtemplates`
--
ALTER TABLE `db_emailtemplates`
  ADD CONSTRAINT `db_emailtemplates_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_expense`
--
ALTER TABLE `db_expense`
  ADD CONSTRAINT `db_expense_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_expense_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `ac_accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_expense_category`
--
ALTER TABLE `db_expense_category`
  ADD CONSTRAINT `db_expense_category_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_fivemojo`
--
ALTER TABLE `db_fivemojo`
  ADD CONSTRAINT `db_fivemojo_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_hold`
--
ALTER TABLE `db_hold`
  ADD CONSTRAINT `db_hold_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_hold_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_hold_ibfk_3` FOREIGN KEY (`warehouse_id`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_holditems`
--
ALTER TABLE `db_holditems`
  ADD CONSTRAINT `db_holditems_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_holditems_ibfk_2` FOREIGN KEY (`hold_id`) REFERENCES `db_hold` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_holditems_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `db_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_instamojo`
--
ALTER TABLE `db_instamojo`
  ADD CONSTRAINT `db_instamojo_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_items`
--
ALTER TABLE `db_items`
  ADD CONSTRAINT `db_items_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_package`
--
ALTER TABLE `db_package`
  ADD CONSTRAINT `db_package_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_paymenttypes`
--
ALTER TABLE `db_paymenttypes`
  ADD CONSTRAINT `db_paymenttypes_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_paypal`
--
ALTER TABLE `db_paypal`
  ADD CONSTRAINT `db_paypal_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_permissions`
--
ALTER TABLE `db_permissions`
  ADD CONSTRAINT `db_permissions_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_purchase`
--
ALTER TABLE `db_purchase`
  ADD CONSTRAINT `db_purchase_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchase_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_purchaseitems`
--
ALTER TABLE `db_purchaseitems`
  ADD CONSTRAINT `db_purchaseitems_ibfk_1` FOREIGN KEY (`purchase_id`) REFERENCES `db_purchase` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_purchaseitemsreturn`
--
ALTER TABLE `db_purchaseitemsreturn`
  ADD CONSTRAINT `db_purchaseitemsreturn_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchaseitemsreturn_ibfk_2` FOREIGN KEY (`return_id`) REFERENCES `db_purchasereturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_purchasepayments`
--
ALTER TABLE `db_purchasepayments`
  ADD CONSTRAINT `db_purchasepayments_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchasepayments_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `db_purchase` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchasepayments_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_purchasepaymentsreturn`
--
ALTER TABLE `db_purchasepaymentsreturn`
  ADD CONSTRAINT `db_purchasepaymentsreturn_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchasepaymentsreturn_ibfk_2` FOREIGN KEY (`return_id`) REFERENCES `db_purchasereturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchasepaymentsreturn_ibfk_3` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_purchasereturn`
--
ALTER TABLE `db_purchasereturn`
  ADD CONSTRAINT `db_purchasereturn_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_purchasereturn_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `db_purchase` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_quotation`
--
ALTER TABLE `db_quotation`
  ADD CONSTRAINT `db_quotation_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_quotation_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_quotation_ibfk_3` FOREIGN KEY (`warehouse_id`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_quotationitems`
--
ALTER TABLE `db_quotationitems`
  ADD CONSTRAINT `db_quotationitems_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_quotationitems_ibfk_2` FOREIGN KEY (`quotation_id`) REFERENCES `db_quotation` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_roles`
--
ALTER TABLE `db_roles`
  ADD CONSTRAINT `db_roles_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_sales`
--
ALTER TABLE `db_sales`
  ADD CONSTRAINT `db_sales_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_sales_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_sales_ibfk_3` FOREIGN KEY (`warehouse_id`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_sales_ibfk_4` FOREIGN KEY (`coupon_id`) REFERENCES `db_customer_coupons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_salesitems`
--
ALTER TABLE `db_salesitems`
  ADD CONSTRAINT `db_salesitems_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salesitems_ibfk_2` FOREIGN KEY (`sales_id`) REFERENCES `db_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_salesitemsreturn`
--
ALTER TABLE `db_salesitemsreturn`
  ADD CONSTRAINT `db_salesitemsreturn_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salesitemsreturn_ibfk_2` FOREIGN KEY (`return_id`) REFERENCES `db_salesreturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_salespayments`
--
ALTER TABLE `db_salespayments`
  ADD CONSTRAINT `db_salespayments_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salespayments_ibfk_2` FOREIGN KEY (`sales_id`) REFERENCES `db_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salespayments_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_salespaymentsreturn`
--
ALTER TABLE `db_salespaymentsreturn`
  ADD CONSTRAINT `db_salespaymentsreturn_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salespaymentsreturn_ibfk_2` FOREIGN KEY (`return_id`) REFERENCES `db_salesreturn` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salespaymentsreturn_ibfk_3` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_salesreturn`
--
ALTER TABLE `db_salesreturn`
  ADD CONSTRAINT `db_salesreturn_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salesreturn_ibfk_2` FOREIGN KEY (`sales_id`) REFERENCES `db_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_salesreturn_ibfk_3` FOREIGN KEY (`coupon_id`) REFERENCES `db_customer_coupons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_shippingaddress`
--
ALTER TABLE `db_shippingaddress`
  ADD CONSTRAINT `db_shippingaddress_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `db_customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_shippingaddress_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_smsapi`
--
ALTER TABLE `db_smsapi`
  ADD CONSTRAINT `db_smsapi_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_smstemplates`
--
ALTER TABLE `db_smstemplates`
  ADD CONSTRAINT `db_smstemplates_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_states`
--
ALTER TABLE `db_states`
  ADD CONSTRAINT `db_states_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_stockadjustment`
--
ALTER TABLE `db_stockadjustment`
  ADD CONSTRAINT `db_stockadjustment_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_stockadjustmentitems`
--
ALTER TABLE `db_stockadjustmentitems`
  ADD CONSTRAINT `db_stockadjustmentitems_ibfk_1` FOREIGN KEY (`adjustment_id`) REFERENCES `db_stockadjustment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stockadjustmentitems_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `db_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stockadjustmentitems_ibfk_3` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stockadjustmentitems_ibfk_4` FOREIGN KEY (`warehouse_id`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_stocktransfer`
--
ALTER TABLE `db_stocktransfer`
  ADD CONSTRAINT `db_stocktransfer_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransfer_ibfk_2` FOREIGN KEY (`warehouse_from`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransfer_ibfk_3` FOREIGN KEY (`warehouse_to`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransfer_ibfk_4` FOREIGN KEY (`to_store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_stocktransferitems`
--
ALTER TABLE `db_stocktransferitems`
  ADD CONSTRAINT `db_stocktransferitems_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransferitems_ibfk_2` FOREIGN KEY (`warehouse_from`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransferitems_ibfk_3` FOREIGN KEY (`warehouse_to`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransferitems_ibfk_4` FOREIGN KEY (`stocktransfer_id`) REFERENCES `db_stocktransfer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransferitems_ibfk_5` FOREIGN KEY (`item_id`) REFERENCES `db_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_stocktransferitems_ibfk_6` FOREIGN KEY (`to_store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_stripe`
--
ALTER TABLE `db_stripe`
  ADD CONSTRAINT `db_stripe_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_suppliers`
--
ALTER TABLE `db_suppliers`
  ADD CONSTRAINT `db_suppliers_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_supplier_payments`
--
ALTER TABLE `db_supplier_payments`
  ADD CONSTRAINT `db_supplier_payments_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `db_suppliers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_supplier_payments_ibfk_2` FOREIGN KEY (`purchasepayment_id`) REFERENCES `db_purchasepayments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_tax`
--
ALTER TABLE `db_tax`
  ADD CONSTRAINT `db_tax_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_twilio`
--
ALTER TABLE `db_twilio`
  ADD CONSTRAINT `db_twilio_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_units`
--
ALTER TABLE `db_units`
  ADD CONSTRAINT `db_units_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_users`
--
ALTER TABLE `db_users`
  ADD CONSTRAINT `db_users_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_userswarehouses`
--
ALTER TABLE `db_userswarehouses`
  ADD CONSTRAINT `db_userswarehouses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `db_users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_userswarehouses_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_variants`
--
ALTER TABLE `db_variants`
  ADD CONSTRAINT `db_variants_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_variants_ibfk_2` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_warehouse`
--
ALTER TABLE `db_warehouse`
  ADD CONSTRAINT `db_warehouse_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `db_warehouseitems`
--
ALTER TABLE `db_warehouseitems`
  ADD CONSTRAINT `db_warehouseitems_ibfk_1` FOREIGN KEY (`store_id`) REFERENCES `db_store` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_warehouseitems_ibfk_2` FOREIGN KEY (`warehouse_id`) REFERENCES `db_warehouse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `db_warehouseitems_ibfk_3` FOREIGN KEY (`item_id`) REFERENCES `db_items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
