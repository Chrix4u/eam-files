<?php
/**
 * Create Model Visualization Tables for XZZ Xinzhizao Style Machine Breakdown View
 * Run: php create_model_visualization_tables.php
 */

// Load environment variables
if (file_exists('.env')) {
    $env = parse_ini_file('.env');
    foreach ($env as $key => $value) {
        $_ENV[$key] = $value;
    }
}

$host = $_ENV['database_default_hostname'] ?? 'localhost';
$database = $_ENV['database_default_database'] ?? 'factory_manager';
$username = $_ENV['database_default_username'] ?? 'root';
$password = $_ENV['database_default_password'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Creating Model Visualization Tables...\n";
    
    // 1. Machine Models Table
    $sql = "
    CREATE TABLE IF NOT EXISTS machine_models (
        id INT AUTO_INCREMENT PRIMARY KEY,
        machine_id INT NOT NULL,
        model_type ENUM('2D', '3D') NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        thumbnail_path VARCHAR(500),
        file_size INT,
        mime_type VARCHAR(100),
        metadata_json JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_machine_id (machine_id),
        INDEX idx_model_type (model_type)
    ) ENGINE=InnoDB;
    ";
    $pdo->exec($sql);
    echo "✓ machine_models table created\n";
    
    // 2. Model Hotspots Table
    $sql = "
    CREATE TABLE IF NOT EXISTS model_hotspots (
        id INT AUTO_INCREMENT PRIMARY KEY,
        model_id INT NOT NULL,
        node_type ENUM('machine', 'assembly', 'part', 'subpart') NOT NULL,
        node_id INT NOT NULL,
        label VARCHAR(255) NOT NULL,
        x DECIMAL(10,6),
        y DECIMAL(10,6),
        z DECIMAL(10,6),
        metadata_json JSON,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (model_id) REFERENCES machine_models(id) ON DELETE CASCADE,
        INDEX idx_model_node (model_id, node_type, node_id),
        INDEX idx_coordinates (x, y, z)
    ) ENGINE=InnoDB;
    ";
    $pdo->exec($sql);
    echo "✓ model_hotspots table created\n";
    
    // 3. Model Layers Table
    $sql = "
    CREATE TABLE IF NOT EXISTS model_layers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        model_id INT NOT NULL,
        layer_name VARCHAR(255) NOT NULL,
        layer_order INT DEFAULT 0,
        visible_default BOOLEAN DEFAULT TRUE,
        color VARCHAR(7),
        opacity DECIMAL(3,2) DEFAULT 1.00,
        metadata_json JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (model_id) REFERENCES machine_models(id) ON DELETE CASCADE,
        INDEX idx_model_layer (model_id, layer_order)
    ) ENGINE=InnoDB;
    ";
    $pdo->exec($sql);
    echo "✓ model_layers table created\n";
    
    // 4. Part Geometry Table
    $sql = "
    CREATE TABLE IF NOT EXISTS part_geometry (
        id INT AUTO_INCREMENT PRIMARY KEY,
        part_id INT NOT NULL,
        mesh_name VARCHAR(255),
        material VARCHAR(255),
        color VARCHAR(7),
        texture_path VARCHAR(500),
        geometry_data JSON,
        bounding_box JSON,
        metadata_json JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_part_id (part_id),
        INDEX idx_mesh_name (mesh_name)
    ) ENGINE=InnoDB;
    ";
    $pdo->exec($sql);
    echo "✓ part_geometry table created\n";
    
    // 5. Model Navigation History Table
    $sql = "
    CREATE TABLE IF NOT EXISTS model_navigation_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        model_id INT NOT NULL,
        navigation_path JSON,
        view_state JSON,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (model_id) REFERENCES machine_models(id) ON DELETE CASCADE,
        INDEX idx_user_model (user_id, model_id),
        INDEX idx_timestamp (timestamp)
    ) ENGINE=InnoDB;
    ";
    $pdo->exec($sql);
    echo "✓ model_navigation_history table created\n";
    
    echo "\nAll Model Visualization tables created successfully!\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>