<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS erp_transformations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entity_type ENUM('assets', 'work_orders', 'inventory') NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    transformation_type ENUM('value_map', 'formula', 'concat', 'split', 'date_format') NOT NULL,
    transformation_rule JSON NOT NULL,
    direction ENUM('eam_to_erp', 'erp_to_eam', 'both') DEFAULT 'both',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($db->query($sql)) {
    echo "✓ Table 'erp_transformations' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$transformations = [
    ['assets', 'status', 'value_map', '{"active":"ACT","maintenance":"MNT","retired":"RET"}', 'both'],
    ['work_orders', 'priority', 'value_map', '{"low":"L","medium":"M","high":"H","critical":"C"}', 'both'],
    ['work_orders', 'cost', 'formula', '{"expression":"value * 1.15","description":"Add 15% overhead"}', 'eam_to_erp'],
    ['assets', 'full_name', 'concat', '{"fields":["name","location"],"separator":" - "}', 'eam_to_erp'],
    ['inventory', 'last_updated', 'date_format', '{"from":"Y-m-d H:i:s","to":"Ymd"}', 'eam_to_erp']
];

foreach ($transformations as $t) {
    $stmt = $db->prepare("INSERT INTO erp_transformations (entity_type, field_name, transformation_type, transformation_rule, direction) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $t[0], $t[1], $t[2], $t[3], $t[4]);
    $stmt->execute();
}

echo "✓ Inserted 5 transformation rules\n";

$db->close();
?>
