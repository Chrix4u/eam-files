UPDATE work_orders wo
INNER JOIN maintenance_requests mr ON mr.work_order_id = wo.id
SET wo.request_id = mr.id,
    wo.department_id = mr.department_id
WHERE wo.request_id IS NULL;
