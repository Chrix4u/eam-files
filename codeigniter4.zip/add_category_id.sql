ALTER TABLE skills ADD COLUMN category_id INT(11) NULL AFTER category;
