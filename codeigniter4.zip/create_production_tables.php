<?php

// Database configuration
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create work_centers table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS work_centers (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(50) NOT NULL,
            name VARCHAR(255) NOT NULL,
            standard_speed DECIMAL(10,2) DEFAULT 0,
            target_utilization DECIMAL(5,2) DEFAULT 90,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");

    // Create daily_production_surveys table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS daily_production_surveys (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            work_center_id INT UNSIGNED NOT NULL,
            survey_date DATE NOT NULL,
            shift ENUM('morning', 'afternoon', 'night') NOT NULL,
            operator_id INT UNSIGNED NOT NULL,
            total_time_available INT DEFAULT 0,
            break_mins INT DEFAULT 0,
            repair_maint_mins INT DEFAULT 0,
            input_delivery_mins INT DEFAULT 0,
            change_over_mins INT DEFAULT 0,
            startup_cleaning_mins INT DEFAULT 0,
            others_mins INT DEFAULT 0,
            preventive_maint_mins INT DEFAULT 0,
            total_downtime INT DEFAULT 0,
            productive_time INT DEFAULT 0,
            production_yards DECIMAL(12,2) DEFAULT 0,
            target_yards DECIMAL(12,2) DEFAULT 0,
            actual_speed DECIMAL(10,2) DEFAULT 0,
            standard_speed DECIMAL(10,2) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (work_center_id) REFERENCES work_centers(id) ON DELETE CASCADE
        )
    ");

    // Create weekly_production_summaries table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS weekly_production_summaries (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            work_center_id INT UNSIGNED NOT NULL,
            week_start DATE NOT NULL,
            week_end DATE NOT NULL,
            week_number INT NOT NULL,
            total_time INT DEFAULT 0,
            total_stoppages INT DEFAULT 0,
            productive_time INT DEFAULT 0,
            total_production DECIMAL(12,2) DEFAULT 0,
            target_production DECIMAL(12,2) DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (work_center_id) REFERENCES work_centers(id) ON DELETE CASCADE
        )
    ");

    // Insert sample work centers
    $pdo->exec("
        INSERT INTO work_centers (code, name, standard_speed, target_utilization) VALUES
        ('312/1', 'SINGEING M/C', 130, 90),
        ('310/1', 'BLEACHING RANGE', 100, 80)
        ON DUPLICATE KEY UPDATE code=code
    ");

    echo "✅ Production survey tables created successfully!\n";
    echo "✅ Sample work centers added\n";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
