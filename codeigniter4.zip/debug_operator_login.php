<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

echo "=== DEBUGGING OPERATOR LOGIN ===\n\n";

// 1. Check if operator1 exists
$result = mysqli_query($db, "SELECT * FROM users WHERE username = 'operator1'");
$user = mysqli_fetch_assoc($result);

if (!$user) {
    echo "✗ User 'operator1' NOT FOUND in database!\n";
    exit;
}

echo "✓ User found:\n";
echo "  ID: {$user['id']}\n";
echo "  Username: {$user['username']}\n";
echo "  Email: {$user['email']}\n";
echo "  Role: {$user['role']}\n";
echo "  Status: {$user['status']}\n\n";

// 2. Test password
$password = 'password';
if (password_verify($password, $user['password'])) {
    echo "✓ Password verification: SUCCESS\n\n";
} else {
    echo "✗ Password verification: FAILED\n";
    echo "  Rehashing password...\n";
    $newHash = password_hash($password, PASSWORD_DEFAULT);
    mysqli_query($db, "UPDATE users SET password = '$newHash' WHERE id = {$user['id']}");
    echo "✓ Password updated\n\n";
}

// 3. Test API login
echo "Testing API login...\n";
$url = 'http://localhost/factorymanager/public/index.php/api/v1/eam/auth/login';
$data = json_encode(['username' => 'operator1', 'password' => 'password']);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($data)
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode\n";

if ($httpCode === 200) {
    echo "✓ API Login: SUCCESS\n";
    $result = json_decode($response, true);
    echo "\nResponse:\n";
    echo json_encode($result, JSON_PRETTY_PRINT) . "\n";
} else {
    echo "✗ API Login: FAILED\n";
    echo "Response: $response\n";
}

mysqli_close($db);
