<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS erp_sync_log (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    entity_type VARCHAR(50),
    status ENUM('success','failed','pending') DEFAULT 'pending',
    message TEXT NULL,
    created_at DATETIME,
    KEY entity_type (entity_type),
    KEY status (status),
    KEY created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "erp_sync_log table created successfully\n";
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
