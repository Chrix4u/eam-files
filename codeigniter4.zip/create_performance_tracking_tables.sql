-- Reliability Metrics Table
CREATE TABLE IF NOT EXISTS reliability_metrics (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    machine_id INT(11) UNSIGNED NOT NULL,
    mtbf_target DECIMAL(10,2) NULL COMMENT 'Mean Time Between Failures Target (hours)',
    mttr_target DECIMAL(10,2) NULL COMMENT 'Mean Time To Repair Target (hours)',
    mtbf_actual DECIMAL(10,2) DEFAULT 0 COMMENT 'Actual MTBF calculated',
    mttr_actual DECIMAL(10,2) DEFAULT 0 COMMENT 'Actual MTTR calculated',
    failure_count INT(11) DEFAULT 0,
    total_downtime_hours DECIMAL(10,2) DEFAULT 0,
    last_failure_date DATETIME NULL,
    last_repair_date DATETIME NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_machine_id (machine_id),
    FOREIGN KEY (machine_id) REFERENCES machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Calibration Schedules Table
CREATE TABLE IF NOT EXISTS calibration_schedules (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    machine_id INT(11) UNSIGNED NOT NULL,
    frequency_days INT(11) NOT NULL,
    last_calibration_date DATE NULL,
    next_due_date DATE NOT NULL,
    status ENUM('scheduled', 'overdue', 'completed', 'skipped') DEFAULT 'scheduled',
    calibration_type VARCHAR(100) NULL,
    performed_by VARCHAR(100) NULL,
    notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_machine_id (machine_id),
    KEY idx_next_due_date (next_due_date),
    KEY idx_status (status),
    FOREIGN KEY (machine_id) REFERENCES machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- OEE Records Table (if not exists)
CREATE TABLE IF NOT EXISTS oee_records (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    equipment_id INT(11) UNSIGNED NOT NULL,
    equipment_type ENUM('machine', 'line', 'plant') DEFAULT 'machine',
    record_date DATE NOT NULL,
    shift VARCHAR(50) NULL,
    planned_production_time DECIMAL(10,2) DEFAULT 0,
    actual_runtime DECIMAL(10,2) DEFAULT 0,
    downtime DECIMAL(10,2) DEFAULT 0,
    ideal_cycle_time DECIMAL(10,2) NULL,
    total_pieces INT(11) DEFAULT 0,
    good_pieces INT(11) DEFAULT 0,
    rejected_pieces INT(11) DEFAULT 0,
    availability DECIMAL(5,2) DEFAULT 0,
    performance DECIMAL(5,2) DEFAULT 0,
    quality DECIMAL(5,2) DEFAULT 0,
    oee DECIMAL(5,2) DEFAULT 0,
    target_oee DECIMAL(5,2) NULL,
    availability_target DECIMAL(5,2) DEFAULT 90,
    performance_target DECIMAL(5,2) DEFAULT 95,
    quality_target DECIMAL(5,2) DEFAULT 99,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_equipment (equipment_id, equipment_type),
    KEY idx_record_date (record_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Downtime Events Table
CREATE TABLE IF NOT EXISTS downtime_events (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    machine_id INT(11) UNSIGNED NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NULL,
    duration_hours DECIMAL(10,2) NULL,
    downtime_category ENUM('breakdown', 'planned_maintenance', 'changeover', 'no_operator', 'no_material', 'other') NOT NULL,
    reason TEXT NULL,
    impact ENUM('production_stop', 'reduced_capacity', 'quality_impact', 'minimal') NULL,
    work_order_id INT(11) UNSIGNED NULL,
    resolved_by VARCHAR(100) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY (id),
    KEY idx_machine_id (machine_id),
    KEY idx_start_time (start_time),
    KEY idx_category (downtime_category),
    FOREIGN KEY (machine_id) REFERENCES machines(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
