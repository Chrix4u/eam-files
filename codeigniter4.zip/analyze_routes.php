<?php
/**
 * ROUTE-BASED CONTROLLER MAPPING
 * Analyzes all routes and maps controllers to correct modules
 */

// Map of controllers found in routes → target module
$controllerMapping = [
    // From Routes.php analysis
    'EamAuthController' => ['module' => 'CORE', 'name' => 'AuthController'],
    'UserController' => ['module' => 'HRMS', 'name' => 'UsersController'],
    'Asset\\MachinesController' => ['module' => 'ASSET', 'name' => 'EquipmentController'],
    'DepartmentsController' => ['module' => 'CORE', 'name' => 'DepartmentsController'],
    'MaintenanceRequestController' => ['module' => 'RWOP', 'name' => 'MaintenanceRequestController'],
    'Asset\\AssetsUnifiedController' => ['module' => 'ASSET', 'name' => 'AssetsUnifiedController'],
    'PartController' => ['module' => 'IMS', 'name' => 'PartsController'],
    'AssemblyController' => ['module' => 'ASSET', 'name' => 'AssembliesController'],
    'WorkOrdersController' => ['module' => 'RWOP', 'name' => 'WorkOrderController'],
    'ModelLayersController' => ['module' => 'ASSET', 'name' => 'ModelLayersController'],
    'BillOfMaterialsController' => ['module' => 'ASSET', 'name' => 'BomController'],
    'OEEController' => ['module' => 'MPMP', 'name' => 'OEEController'],
    'CalibrationController' => ['module' => 'MRMP', 'name' => 'CalibrationController'],
    'DowntimeController' => ['module' => 'MPMP', 'name' => 'DowntimeController'],
    'MeterReadingsController' => ['module' => 'ASSET', 'name' => 'MetersController'],
    'ShiftHandoverController' => ['module' => 'RWOP', 'name' => 'ShiftHandoverController'],
    'TrainingRecordsController' => ['module' => 'HRMS', 'name' => 'TrainingController'],
    'RiskAssessmentController' => ['module' => 'TRAC', 'name' => 'RiskAssessmentController'],
    'WorkCenterController' => ['module' => 'MPMP', 'name' => 'WorkCenterController'],
    'ResourceAvailabilityController' => ['module' => 'TRAC', 'name' => 'ResourceController'],
    'NotificationsController' => ['module' => 'CORE', 'name' => 'NotificationsController'],
    'NotificationController' => ['module' => 'CORE', 'name' => 'NotificationsController'],
    'SearchController' => ['module' => 'CORE', 'name' => 'SearchController'],
    'AssetHealthController' => ['module' => 'ASSET', 'name' => 'HealthController'],
    'CacheController' => ['module' => 'CORE', 'name' => 'CacheController'],
    'ToolsController' => ['module' => 'TRAC', 'name' => 'ToolsController'],
    'TradesController' => ['module' => 'HRMS', 'name' => 'SkillsController'],
    'SkillsController' => ['module' => 'HRMS', 'name' => 'SkillsController'],
    'SkillCategoriesController' => ['module' => 'HRMS', 'name' => 'SkillsController'],
    'InventoryController' => ['module' => 'IMS', 'name' => 'InventoryController'],
    'ShiftsController' => ['module' => 'HRMS', 'name' => 'ShiftsController'],
    'EmployeeShiftsController' => ['module' => 'HRMS', 'name' => 'ShiftsController'],
    'SystemSettingsController' => ['module' => 'CORE', 'name' => 'SettingsController'],
    'CompanySettingsController' => ['module' => 'CORE', 'name' => 'SettingsController'],
    'EamSystemsController' => ['module' => 'ASSET', 'name' => 'SystemsController'],
    'AuditLogsController' => ['module' => 'CORE', 'name' => 'AuditLogsController'],
    'AnalyticsController' => ['module' => 'CORE', 'name' => 'AnalyticsController'],
    'FacilitiesController' => ['module' => 'ASSET', 'name' => 'FacilitiesController'],
    'SingeingDesizingController' => ['module' => 'MPMP', 'name' => 'SingeingDesizingController'],
    'PartPmTaskController' => ['module' => 'MRMP', 'name' => 'PMTasksController'],
    'PmTasksController' => ['module' => 'MRMP', 'name' => 'PmController'],
    'PmTypesController' => ['module' => 'MRMP', 'name' => 'PmController'],
    'PmTriggerTypesController' => ['module' => 'MRMP', 'name' => 'PMTriggersController'],
    'PmModesController' => ['module' => 'MRMP', 'name' => 'PmController'],
    'PmInspectionTypesController' => ['module' => 'MRMP', 'name' => 'PmController'],
    'PmWorkOrderController' => ['module' => 'MRMP', 'name' => 'PmController'],
    'PmNotificationController' => ['module' => 'CORE', 'name' => 'NotificationsController'],
    'PmAnalyticsController' => ['module' => 'CORE', 'name' => 'AnalyticsController'],
    'MaintenanceOrderController' => ['module' => 'RWOP', 'name' => 'MaintenanceOrderController'],
    'UsageBasedPmController' => ['module' => 'MRMP', 'name' => 'PmController'],
    'ShiftAssignmentController' => ['module' => 'HRMS', 'name' => 'ShiftsController'],
    'ProductionController' => ['module' => 'MPMP', 'name' => 'ProductionController'],
    'Eam\\ProductionTargetController' => ['module' => 'MPMP', 'name' => 'ProductionController'],
    'Eam\\ProductionSurveyController' => ['module' => 'MPMP', 'name' => 'ProductionController'],
    'Eam\\ShiftAssignmentController' => ['module' => 'HRMS', 'name' => 'ShiftsController'],
    'Eam\\DowntimeController' => ['module' => 'MPMP', 'name' => 'DowntimeController'],
    'Eam\\MeterReadingController' => ['module' => 'ASSET', 'name' => 'MetersController'],
    'Eam\\WorkCenterController' => ['module' => 'MPMP', 'name' => 'WorkCenterController'],
    'ProductionDataController' => ['module' => 'MPMP', 'name' => 'ProductionController'],
    'ProductionReportsController' => ['module' => 'CORE', 'name' => 'ReportsController'],
    'WorkOrderController' => ['module' => 'RWOP', 'name' => 'WorkOrderController'],
    'WorkOrderCompletionController' => ['module' => 'RWOP', 'name' => 'CompletionController'],
    'PermitToWorkController' => ['module' => 'TRAC', 'name' => 'PermitController'],
    'LOTOController' => ['module' => 'TRAC', 'name' => 'LOTOController'],
    'LOTOLockController' => ['module' => 'TRAC', 'name' => 'LOTOController'],
    'MaintenanceAnalyticsController' => ['module' => 'CORE', 'name' => 'AnalyticsController'],
    'CompletionAnalyticsController' => ['module' => 'CORE', 'name' => 'AnalyticsController'],
    'DashboardController' => ['module' => 'CORE', 'name' => 'DashboardController'],
    'WorkOrderTeamController' => ['module' => 'RWOP', 'name' => 'WorkOrderController'],
    'AssignmentsController' => ['module' => 'RWOP', 'name' => 'AssignmentsController'],
    'WorkOrderReportsController' => ['module' => 'CORE', 'name' => 'ReportsController'],
    'EamInventoryController' => ['module' => 'IMS', 'name' => 'InventoryController'],
    'MaterialRequestController' => ['module' => 'IMS', 'name' => 'MaterialRequestController'],
    'ModuleSettingsController' => ['module' => 'CORE', 'name' => 'ModuleController'],
    'WorkOrderTemplateController' => ['module' => 'RWOP', 'name' => 'WorkOrderController'],
    'RecurringWorkOrderController' => ['module' => 'RWOP', 'name' => 'WorkOrderController'],
    'LaborLogController' => ['module' => 'HRMS', 'name' => 'LaborController'],
    'WorkOrderMaterialController' => ['module' => 'RWOP', 'name' => 'WorkOrderController'],
    'FailureCodeController' => ['module' => 'RWOP', 'name' => 'FailureCodeController'],
    'SLAController' => ['module' => 'MRMP', 'name' => 'SLAController'],
    'AttachmentController' => ['module' => 'CORE', 'name' => 'AttachmentController'],
    'CommentController' => ['module' => 'CORE', 'name' => 'CommentController'],
    'GhanaEnhancementsController' => ['module' => 'CORE', 'name' => 'GhanaEnhancementsController'],
    
    // From Routes_Master_API.php
    'RCAController' => ['module' => 'RWOP', 'name' => 'RCAController'],
    'FailureModeController' => ['module' => 'RWOP', 'name' => 'FailureModeController'],
    'RCMController' => ['module' => 'MRMP', 'name' => 'RCMController'],
    'PartsOptimizationController' => ['module' => 'IMS', 'name' => 'PartsOptimizationController'],
    'KPIController' => ['module' => 'CORE', 'name' => 'AnalyticsController'],
    'MobileWorkOrderController' => ['module' => 'CORE', 'name' => 'MobileController'],
    
    // Utility controllers (keep in CORE)
    'BaseApiController' => ['module' => 'CORE', 'name' => 'BaseApiController'],
    'AdvancedControllers' => ['module' => 'CORE', 'name' => 'AdvancedControllers'],
    'AIController' => ['module' => 'CORE', 'name' => 'AIController'],
    'APIManagementController' => ['module' => 'CORE', 'name' => 'APIManagementController'],
    'BulkOperationsController' => ['module' => 'CORE', 'name' => 'BulkOperationsController'],
    'CollaborationController' => ['module' => 'CORE', 'name' => 'CollaborationController'],
    'DocsController' => ['module' => 'CORE', 'name' => 'DocsController'],
    'DocumentsController' => ['module' => 'CORE', 'name' => 'DocumentsController'],
    'EamComponentsController' => ['module' => 'ASSET', 'name' => 'ComponentsController'],
    'EnergyController' => ['module' => 'MPMP', 'name' => 'EnergyController'],
    'ERPIntegrationController' => ['module' => 'CORE', 'name' => 'ERPIntegrationController'],
    'ERPMappingController' => ['module' => 'CORE', 'name' => 'ERPMappingController'],
    'ERPScheduleController' => ['module' => 'CORE', 'name' => 'ERPScheduleController'],
    'ERPTransformationController' => ['module' => 'CORE', 'name' => 'ERPTransformationController'],
    'HealthController' => ['module' => 'CORE', 'name' => 'SystemHealthController'],
    'MetricsController' => ['module' => 'CORE', 'name' => 'MetricsController'],
    'MobileController' => ['module' => 'CORE', 'name' => 'MobileController'],
    'OperatorGroupsController' => ['module' => 'HRMS', 'name' => 'OperatorGroupsController'],
    'ProtectedController' => ['module' => 'CORE', 'name' => 'ProtectedController'],
    'SchedulerController' => ['module' => 'CORE', 'name' => 'SchedulerController'],
    'TechnicianGroupController' => ['module' => 'HRMS', 'name' => 'TechnicianGroupController'],
    'BarcodeController' => ['module' => 'ASSET', 'name' => 'BarcodeController'],
];

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║  ROUTE-BASED CONTROLLER ANALYSIS                           ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

echo "📊 Total controllers mapped from routes: " . count($controllerMapping) . "\n\n";

// Group by module
$byModule = [];
foreach ($controllerMapping as $controller => $info) {
    $module = $info['module'];
    if (!isset($byModule[$module])) {
        $byModule[$module] = [];
    }
    $byModule[$module][] = $controller . ' → ' . $info['name'];
}

echo "📦 Controllers by Module:\n\n";
foreach ($byModule as $module => $controllers) {
    echo "  $module (" . count($controllers) . " controllers)\n";
    foreach ($controllers as $ctrl) {
        echo "    - $ctrl\n";
    }
    echo "\n";
}

echo "✅ Analysis complete!\n";
echo "📋 Next: Run consolidation based on this mapping\n";
