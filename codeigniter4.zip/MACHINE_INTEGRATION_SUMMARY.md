# 🔗 Machine Creation/Update Integration Summary

## Automatic Integrations on Machine Create/Update

### ✅ Performance Tracking Integration

#### 1. **MTBF/MTTR Tracking** (`reliability_metrics` table)
**When:** Machine created/updated with `mtbf_hours` or `mttr_hours`
**Action:**
- Creates baseline record with target values
- Initializes actual values to 0
- Tracks failure_count and total_downtime_hours
- Auto-calculates actuals from downtime_events

**Usage:**
```php
// On create: Sets targets
mtbf_target = 500.00 hours
mttr_target = 2.50 hours

// System tracks:
- Downtime events → Updates mtbf_actual
- Work order repairs → Updates mttr_actual
```

#### 2. **OEE Target Tracking** (`oee_records` table)
**When:** Machine created/updated with `oee_target`
**Action:**
- Creates OEE baseline record
- Sets availability_target = 90%
- Sets performance_target = 95%
- Sets quality_target = 99%

**Usage:**
```php
// On create: Sets target
target_oee = 85.00%

// System calculates daily:
oee = availability × performance × quality
```

#### 3. **Calibration Scheduling** (`calibration_schedules` table)
**When:** Machine created with `calibration_required = 'yes'` and `calibration_frequency_days`
**Action:**
- Creates calibration schedule
- Calculates next_due_date = today + frequency_days
- Sets status = 'scheduled'
- Triggers alerts when due

**Usage:**
```php
// On create:
calibration_frequency_days = 90
next_due_date = 2025-03-22

// System:
- Sends alerts 7 days before due
- Updates status to 'overdue' if missed
```

---

### ✅ IoT Integration

#### 4. **IoT Device Initialization** (`iot_devices` table)
**When:** Machine created with `criticality = 'high'` or `'critical'`
**Action:**
- Creates IoT device placeholder
- device_name = "{machine_name} - IoT Monitor"
- device_type = 'sensor_gateway'
- status = 'pending_setup'
- connection_status = 'offline'

**Usage:**
```php
// Auto-creates for critical machines:
{
  "device_name": "CNC Machine A - IoT Monitor",
  "asset_id": 123,
  "asset_type": "machine",
  "status": "pending_setup"
}

// Admin can then:
1. Configure sensors (vibration, temperature, etc.)
2. Set alert thresholds
3. Activate monitoring
```

#### 5. **IoT Alert Rules** (`iot_alert_rules` table)
**When:** IoT device is activated
**Action:**
- Creates default alert rules based on machine specs
- Temperature alerts from `operating_temperature_range`
- Pressure alerts from `operating_pressure`
- Vibration alerts for rotating equipment

---

### ✅ ERP Integration

#### 6. **ERP Sync Queue** (`erp_sync_log` table)
**When:** Machine created or updated
**Action:**
- Queues sync to ERP system
- sync_direction = 'outbound'
- status = 'pending'
- Includes: machine_code, name, cost, department, status

**Payload Example:**
```json
{
  "machine_code": "M-0001",
  "machine_name": "CNC Machine A",
  "acquisition_cost": 150000.00,
  "department": "Production",
  "status": "active"
}
```

**ERP Sync Process:**
1. Machine created → Queued in erp_sync_log
2. Scheduled job runs (every 15 min)
3. Applies field mappings from `erp_field_mappings`
4. Applies transformations from `erp_transformations`
5. Sends to ERP API
6. Updates sync_log status

---

### ✅ Update Integration

#### 7. **Related Records Update**
**When:** Machine updated
**Actions:**
- Updates `reliability_metrics` if MTBF/MTTR changed
- Updates `oee_records` if OEE target changed
- Updates `iot_devices` name if machine name changed
- Updates `calibration_schedules` if frequency changed
- Queues ERP sync with changes

---

## 📊 Data Flow Diagram

```
Machine Create/Update
        ↓
┌───────────────────────────────────────┐
│   MachinesController                  │
│   - Validates data                    │
│   - Saves to machines table           │
└───────────────┬───────────────────────┘
                ↓
┌───────────────────────────────────────┐
│   initializePerformanceTracking()     │
├───────────────────────────────────────┤
│   1. reliability_metrics              │
│   2. oee_records                      │
│   3. calibration_schedules            │
│   4. iot_devices (if critical)        │
└───────────────┬───────────────────────┘
                ↓
┌───────────────────────────────────────┐
│   queueERPSync()                      │
│   - Adds to erp_sync_log              │
│   - Scheduled job syncs to ERP        │
└───────────────────────────────────────┘
```

---

## 🎯 Benefits

1. **Zero Manual Setup** - All tracking initialized automatically
2. **Consistent Data** - No missing baseline records
3. **ERP Sync** - Asset data flows to financial system
4. **IoT Ready** - Critical machines pre-configured for monitoring
5. **Compliance** - Calibration schedules auto-created
6. **Performance Tracking** - MTBF/MTTR/OEE ready from day 1

---

## 🔧 Configuration

### Enable/Disable Features

**ERP Sync:**
```sql
UPDATE erp_sync_schedules 
SET is_active = 1 
WHERE entity_type = 'assets';
```

**IoT Auto-Init:**
```php
// In MachinesController, modify condition:
if (!empty($data['criticality']) && in_array($data['criticality'], ['high', 'critical']))
```

**Calibration Alerts:**
```sql
-- Set alert days before due
UPDATE calibration_schedules 
SET alert_days_before = 7;
```

---

## 📝 Testing

```bash
# Test machine creation with all integrations
curl -X POST http://localhost/api/v1/eam/assets/machines \
  -d '{
    "machine_name": "Test CNC",
    "machine_code": "M-TEST-001",
    "criticality": "critical",
    "mtbf_hours": 500,
    "mttr_hours": 2.5,
    "oee_target": 85,
    "calibration_required": "yes",
    "calibration_frequency_days": 90
  }'

# Verify integrations
SELECT * FROM reliability_metrics WHERE machine_id = LAST_INSERT_ID();
SELECT * FROM oee_records WHERE equipment_id = LAST_INSERT_ID();
SELECT * FROM calibration_schedules WHERE machine_id = LAST_INSERT_ID();
SELECT * FROM iot_devices WHERE asset_id = LAST_INSERT_ID();
SELECT * FROM erp_sync_log WHERE entity_id = LAST_INSERT_ID();
```

---

## ✅ Complete Integration Checklist

- [x] MTBF/MTTR baseline tracking
- [x] OEE target initialization
- [x] Calibration scheduling
- [x] IoT device placeholder
- [x] ERP sync queueing
- [x] Update propagation to related tables
- [x] Downtime event tracking
- [x] Performance metric calculations

**System Status: Fully Integrated! 🎉**
