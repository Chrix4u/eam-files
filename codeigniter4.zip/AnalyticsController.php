<?php

namespace App\Controllers\Api\V1;

use CodeIgniter\RESTful\ResourceController;

class AnalyticsController extends ResourceController
{
    protected $format = 'json';

    public function kpis()
    {
        $db = \Config\Database::connect();
        
        try {
            // Get total assets count
            $totalAssets = $db->table('assets')->countAllResults();
            
            // Get active work orders count
            $activeWorkOrders = $db->table('work_orders')
                ->whereIn('status', ['assigned', 'in_progress', 'planned'])
                ->countAllResults();
            
            // Get overdue work orders count (using planned_end instead of due_date)
            $overdueWorkOrders = $db->table('work_orders')
                ->where('planned_end <', date('Y-m-d H:i:s'))
                ->whereNotIn('status', ['completed', 'closed', 'cancelled'])
                ->countAllResults();
            
            // Get completed today count
            $completedToday = $db->table('work_orders')
                ->whereIn('status', ['completed', 'closed'])
                ->where('DATE(actual_end)', date('Y-m-d'))
                ->countAllResults();
            
            // Calculate basic metrics (you can enhance these with real calculations)
            $avgMTBF = 168; // hours
            $avgMTTR = 4;   // hours
            $oee = 85;      // percentage
            $uptime = 99.2; // percentage
            
            $data = [
                'totalAssets' => $totalAssets,
                'activeWorkOrders' => $activeWorkOrders,
                'overdueWorkOrders' => $overdueWorkOrders,
                'completedToday' => $completedToday,
                'avgMTBF' => $avgMTBF,
                'avgMTTR' => $avgMTTR,
                'oee' => $oee,
                'uptime' => $uptime
            ];
            
            return $this->respond([
                'status' => 'success',
                'data' => $data
            ]);
            
        } catch (\Exception $e) {
            return $this->fail([
                'status' => 'error',
                'message' => 'Failed to fetch KPIs: ' . $e->getMessage()
            ]);
        }
    }
}