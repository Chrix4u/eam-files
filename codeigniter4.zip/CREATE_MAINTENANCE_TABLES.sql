-- Maintenance Request System Tables
-- Run this SQL directly in phpMyAdmin or MySQL command line

-- 1. Maintenance Requests Table
CREATE TABLE IF NOT EXISTS `maintenance_requests` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `request_number` VARCHAR(50) NOT NULL UNIQUE,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT NOT NULL,
    `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    `category` ENUM('breakdown', 'preventive', 'corrective', 'inspection', 'other') NOT NULL,
    `machine_id` INT(11) UNSIGNED NULL,
    `department_id` INT(11) UNSIGNED NOT NULL,
    `location` VARCHAR(255) NULL,
    `requested_by` INT(11) UNSIGNED NOT NULL,
    `requested_date` DATETIME NOT NULL,
    `required_date` DATE NULL,
    `status` ENUM('pending', 'approved', 'rejected', 'converted') DEFAULT 'pending',
    `approved_by` INT(11) UNSIGNED NULL,
    `approved_date` DATETIME NULL,
    `rejection_reason` TEXT NULL,
    `work_order_id` INT(11) UNSIGNED NULL,
    `attachments` JSON NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    `deleted_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2. Work Orders Table
CREATE TABLE IF NOT EXISTS `work_orders` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_number` VARCHAR(50) NOT NULL UNIQUE,
    `request_id` INT(11) UNSIGNED NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT NOT NULL,
    `priority` ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    `type` ENUM('breakdown', 'preventive', 'corrective', 'inspection', 'project') NOT NULL,
    `machine_id` INT(11) UNSIGNED NULL,
    `department_id` INT(11) UNSIGNED NOT NULL,
    `assigned_to` INT(11) UNSIGNED NULL,
    `assigned_by` INT(11) UNSIGNED NOT NULL,
    `assigned_date` DATETIME NULL,
    `planned_start` DATETIME NULL,
    `planned_end` DATETIME NULL,
    `actual_start` DATETIME NULL,
    `actual_end` DATETIME NULL,
    `estimated_hours` DECIMAL(10,2) NULL,
    `actual_hours` DECIMAL(10,2) NULL,
    `status` ENUM('draft', 'assigned', 'acknowledged', 'in_progress', 'on_hold', 'completed', 'inspected', 'closed', 'cancelled') DEFAULT 'draft',
    `completion_notes` TEXT NULL,
    `inspection_by` INT(11) UNSIGNED NULL,
    `inspection_date` DATETIME NULL,
    `inspection_notes` TEXT NULL,
    `inspection_status` ENUM('passed', 'failed', 'pending') NULL,
    `closed_by` INT(11) UNSIGNED NULL,
    `closed_date` DATETIME NULL,
    `created_by` INT(11) UNSIGNED NOT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    `deleted_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 3. Work Order Activities Table
CREATE TABLE IF NOT EXISTS `work_order_activities` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `activity_type` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `performed_by` INT(11) UNSIGNED NOT NULL,
    `activity_date` DATETIME NOT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_id` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 4. Maintenance Notifications Table
CREATE TABLE IF NOT EXISTS `maintenance_notifications` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `reference_type` VARCHAR(50) NULL,
    `reference_id` INT(11) NULL,
    `is_read` BOOLEAN DEFAULT FALSE,
    `read_at` DATETIME NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 5. System Modules Table
CREATE TABLE IF NOT EXISTS `system_modules` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `module_name` VARCHAR(100) NOT NULL UNIQUE,
    `display_name` VARCHAR(255) NOT NULL,
    `description` TEXT NULL,
    `is_enabled` BOOLEAN DEFAULT TRUE,
    `requires_subscription` BOOLEAN DEFAULT FALSE,
    `subscription_tier` ENUM('basic', 'professional', 'enterprise') NULL,
    `settings` JSON NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Success message
SELECT 'Maintenance System Tables Created Successfully!' AS Status;
