<?php
/**
 * Module Extraction Script
 * Reorganizes controllers into proper module structure
 */

$baseDir = 'C:\\wamp64\\www\\factorymanager\\app\\Controllers\\Api\\V1\\Modules';

// Define module extractions
$extractions = [
    'IOT' => [
        'from' => 'MRMP',
        'files' => [
            'IoTController.php',
            'IoTDataController.php',
            'IoTRulesController.php',
            'PredictiveController.php'
        ]
    ],
    'DIGITAL_TWIN' => [
        'from' => ['Core', 'ASSET'],
        'files' => [
            'Core/DigitalTwinController.php',
            'ASSET/Model3DController.php',
            'ASSET/ModelViewerController.php',
            'ASSET/ModelUploadController.php',
            'ASSET/HotspotController.php'
        ]
    ],
    'MOBILE' => [
        'from' => 'Core',
        'files' => [
            'MobileController.php'
        ]
    ],
    'REPORTS' => [
        'from' => ['Core', 'RWOP', 'MPMP', 'IMS'],
        'files' => [
            'Core/ReportsController.php',
            'Core/AnalyticsController.php',
            'RWOP/WorkOrderReportsController.php',
            'MPMP/ProductionReportsController.php',
            'IMS/StockReportsController.php'
        ]
    ]
];

$moved = 0;
$errors = 0;

foreach ($extractions as $newModule => $config) {
    $newModuleDir = $baseDir . DIRECTORY_SEPARATOR . $newModule;
    
    // Create new module directory
    if (!is_dir($newModuleDir)) {
        mkdir($newModuleDir, 0755, true);
        echo "✓ Created directory: $newModule\n";
    }
    
    // Move files
    foreach ($config['files'] as $file) {
        $sourcePath = $baseDir . DIRECTORY_SEPARATOR . $file;
        $fileName = basename($file);
        $destPath = $newModuleDir . DIRECTORY_SEPARATOR . $fileName;
        
        if (file_exists($sourcePath)) {
            // Read and update namespace
            $content = file_get_contents($sourcePath);
            $oldNamespace = 'namespace App\\Controllers\\Api\\V1\\Modules\\' . dirname($file) . ';';
            $newNamespace = 'namespace App\\Controllers\\Api\\V1\\Modules\\' . $newModule . ';';
            
            // Handle files without subdirectory
            if (dirname($file) === '.') {
                $parts = explode('/', $file);
                $oldNamespace = 'namespace App\\Controllers\\Api\\V1\\Modules\\' . $parts[0] . ';';
            }
            
            $content = str_replace($oldNamespace, $newNamespace, $content);
            
            // Write to new location
            if (file_put_contents($destPath, $content)) {
                echo "✓ Moved: $file → $newModule/$fileName\n";
                $moved++;
                
                // Keep original file as backup (will delete after verification)
                rename($sourcePath, $sourcePath . '.backup');
            } else {
                echo "✗ Failed to move: $file\n";
                $errors++;
            }
        } else {
            echo "⊘ File not found: $file\n";
        }
    }
}

echo "\n=== Summary ===\n";
echo "Moved: $moved files\n";
echo "Errors: $errors files\n";
echo "\nNew module directories created:\n";
echo "- IOT (4 controllers)\n";
echo "- DIGITAL_TWIN (5 controllers)\n";
echo "- MOBILE (1 controller)\n";
echo "- REPORTS (5 controllers)\n";
echo "\nTotal: 15 controllers reorganized\n";
