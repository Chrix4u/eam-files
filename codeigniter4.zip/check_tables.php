<?php

require_once __DIR__ . '/vendor/autoload.php';

$db = \Config\Database::connect();

echo "Checking for tables with 'spare' in the name:\n";
echo "================================================\n\n";

$tables = $db->listTables();

$spareRelated = [];
foreach ($tables as $table) {
    if (stripos($table, 'spare') !== false) {
        $spareRelated[] = $table;
    }
}

if (empty($spareRelated)) {
    echo "❌ No tables found with 'spare' in the name\n\n";
} else {
    echo "✅ Found tables:\n";
    foreach ($spareRelated as $table) {
        echo "   - {$table}\n";
    }
    echo "\n";
}

echo "All tables in database:\n";
echo "================================================\n";
foreach ($tables as $table) {
    echo "- {$table}\n";
}
