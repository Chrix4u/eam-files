CREATE TABLE IF NOT EXISTS material_requests (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    request_number VARCHAR(50) UNIQUE,
    work_order_id INT(11) NULL,
    requested_by INT(11) UNSIGNED,
    department VARCHAR(100) NULL,
    request_type ENUM('maintenance','production','emergency','project') DEFAULT 'maintenance',
    priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
    status ENUM('draft','pending','approved','partially_issued','issued','rejected','cancelled') DEFAULT 'pending',
    requested_date DATETIME NULL,
    required_date DATETIME NULL,
    approved_by INT(11) NULL,
    approved_date DATETIME NULL,
    issued_by INT(11) NULL,
    issued_date DATETIME NULL,
    rejection_reason TEXT NULL,
    notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    PRIMARY KEY(id),
    KEY(request_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS material_request_items (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    request_id INT(11) UNSIGNED,
    inventory_item_id INT(11) UNSIGNED,
    quantity_requested DECIMAL(15,2) DEFAULT 1,
    quantity_approved DECIMAL(15,2) NULL,
    quantity_issued DECIMAL(15,2) DEFAULT 0,
    unit_cost DECIMAL(10,2) NULL,
    total_cost DECIMAL(10,2) NULL,
    purpose VARCHAR(255) NULL,
    notes TEXT NULL,
    created_at DATETIME NULL,
    PRIMARY KEY(id),
    KEY(request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS stock_transactions (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    transaction_number VARCHAR(50) UNIQUE,
    inventory_item_id INT(11) UNSIGNED,
    transaction_type ENUM('purchase','issue','return','adjustment','transfer') DEFAULT 'issue',
    quantity DECIMAL(15,2),
    unit_cost DECIMAL(10,2) NULL,
    total_cost DECIMAL(10,2) NULL,
    reference_type VARCHAR(50) NULL,
    reference_id INT(11) NULL,
    from_location VARCHAR(255) NULL,
    to_location VARCHAR(255) NULL,
    performed_by INT(11) UNSIGNED,
    notes TEXT NULL,
    transaction_date DATETIME NULL,
    created_at DATETIME NULL,
    PRIMARY KEY(id),
    KEY(transaction_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS asset_inventory_links (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    inventory_item_id INT(11) UNSIGNED,
    asset_type ENUM('machine','assembly','part') DEFAULT 'machine',
    asset_id INT(11) UNSIGNED,
    pm_code VARCHAR(50) NULL,
    pm_name VARCHAR(255) NULL,
    quantity_per_maintenance DECIMAL(15,2) DEFAULT 1,
    is_critical_spare TINYINT(1) DEFAULT 0,
    created_at DATETIME NULL,
    PRIMARY KEY(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
