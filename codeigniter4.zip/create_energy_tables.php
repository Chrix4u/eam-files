<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS energy_consumption (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    consumption_kwh DECIMAL(10,2) NOT NULL,
    cost DECIMAL(10,2) NOT NULL,
    rate_per_kwh DECIMAL(10,4) DEFAULT 0.12,
    peak_demand_kw DECIMAL(10,2) NULL,
    power_factor DECIMAL(5,2) NULL,
    timestamp DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_asset (asset_id),
    INDEX idx_timestamp (timestamp)
)";

if ($db->query($sql)) {
    echo "✓ Table 'energy_consumption' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql2 = "CREATE TABLE IF NOT EXISTS energy_targets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NULL,
    department_id INT NULL,
    target_kwh DECIMAL(10,2) NOT NULL,
    target_cost DECIMAL(10,2) NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($db->query($sql2)) {
    echo "✓ Table 'energy_targets' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

for ($i = 0; $i < 100; $i++) {
    $assetId = rand(1, 5);
    $consumption = rand(50, 500) / 10;
    $cost = $consumption * 0.12;
    $timestamp = date('Y-m-d H:i:s', strtotime("-$i hours"));
    
    $stmt = $db->prepare("INSERT INTO energy_consumption (asset_id, consumption_kwh, cost, timestamp) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("idds", $assetId, $consumption, $cost, $timestamp);
    $stmt->execute();
}

echo "✓ Inserted 100 sample energy records\n";

$db->close();
?>
