USE factory_manager;

-- Alter work_orders table to add enterprise features
ALTER TABLE `work_orders`
ADD COLUMN `sla_id` INT(11) UNSIGNED NULL AFTER `assigned_group_id`,
ADD COLUMN `response_due` DATETIME NULL AFTER `sla_breached_at`,
ADD COLUMN `resolution_due` DATETIME NULL AFTER `response_due`,
ADD COLUMN `total_labor_hours` DECIMAL(10,2) NULL AFTER `actual_hours`,
ADD COLUMN `total_material_cost` DECIMAL(10,2) NULL AFTER `total_cost`,
ADD COLUMN `downtime_hours` DECIMAL(10,2) NULL AFTER `total_material_cost`;

-- Alter maintenance_requests table to add enterprise features
ALTER TABLE `maintenance_requests`
ADD COLUMN `sla_id` INT(11) UNSIGNED NULL AFTER `department_id`,
ADD COLUMN `response_due` DATETIME NULL AFTER `required_date`,
ADD COLUMN `reviewed_by` INT(11) UNSIGNED NULL AFTER `approved_by`,
ADD COLUMN `reviewed_date` DATETIME NULL AFTER `reviewed_by`;

-- Create new enterprise tables
CREATE TABLE IF NOT EXISTS `labor_logs` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `technician_id` INT(11) UNSIGNED NOT NULL,
    `start_time` DATETIME NOT NULL,
    `end_time` DATETIME NULL,
    `duration_hours` DECIMAL(10,2) NULL,
    `labor_type` ENUM('regular', 'overtime', 'emergency') DEFAULT 'regular',
    `notes` TEXT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_id` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `work_order_materials` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `spare_part_id` INT(11) UNSIGNED NULL,
    `part_name` VARCHAR(255) NOT NULL,
    `quantity` DECIMAL(10,2) NOT NULL,
    `unit_cost` DECIMAL(10,2) NULL,
    `total_cost` DECIMAL(10,2) NULL,
    `issued_by` INT(11) UNSIGNED NOT NULL,
    `issued_at` DATETIME NOT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_id` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `failure_codes` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `code` VARCHAR(50) NOT NULL UNIQUE,
    `description` VARCHAR(255) NOT NULL,
    `category` ENUM('mechanical', 'electrical', 'hydraulic', 'pneumatic', 'software', 'other') NOT NULL,
    `severity` ENUM('minor', 'moderate', 'major', 'critical') NOT NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `work_order_failures` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `failure_code_id` INT(11) UNSIGNED NOT NULL,
    `failure_description` TEXT NOT NULL,
    `root_cause` TEXT NULL,
    `remedy_action` TEXT NULL,
    `recorded_by` INT(11) UNSIGNED NOT NULL,
    `recorded_at` DATETIME NOT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_id` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sla_definitions` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(100) NOT NULL,
    `priority` ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    `response_time_hours` INT(11) NOT NULL,
    `resolution_time_hours` INT(11) NOT NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `maintenance_attachments` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `entity_type` ENUM('maintenance_request', 'work_order') NOT NULL,
    `entity_id` INT(11) UNSIGNED NOT NULL,
    `file_name` VARCHAR(255) NOT NULL,
    `file_path` VARCHAR(500) NOT NULL,
    `file_type` VARCHAR(50) NOT NULL,
    `file_size` INT(11) NOT NULL,
    `uploaded_by` INT(11) UNSIGNED NOT NULL,
    `uploaded_at` DATETIME NOT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `entity_type_id` (`entity_type`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `maintenance_comments` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `entity_type` ENUM('maintenance_request', 'work_order') NOT NULL,
    `entity_id` INT(11) UNSIGNED NOT NULL,
    `comment` TEXT NOT NULL,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `entity_type_id` (`entity_type`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed data
INSERT IGNORE INTO `sla_definitions` (`name`, `priority`, `response_time_hours`, `resolution_time_hours`, `is_active`) VALUES
('Critical Priority SLA', 'critical', 1, 4, TRUE),
('High Priority SLA', 'high', 2, 8, TRUE),
('Medium Priority SLA', 'medium', 4, 24, TRUE),
('Low Priority SLA', 'low', 8, 72, TRUE);

INSERT IGNORE INTO `failure_codes` (`code`, `description`, `category`, `severity`, `is_active`) VALUES
('MECH-001', 'Bearing failure', 'mechanical', 'major', TRUE),
('MECH-002', 'Belt breakage', 'mechanical', 'moderate', TRUE),
('ELEC-001', 'Motor burnout', 'electrical', 'critical', TRUE),
('ELEC-002', 'Wiring fault', 'electrical', 'major', TRUE),
('HYD-001', 'Hydraulic leak', 'hydraulic', 'major', TRUE),
('PNEU-001', 'Air pressure loss', 'pneumatic', 'moderate', TRUE),
('SOFT-001', 'PLC error', 'software', 'major', TRUE);

SELECT 'Tables Enhanced Successfully!' AS Status;
