<?php

require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "=== ADDING ENTERPRISE FEATURES TO PRODUCTION SURVEYS ===\n\n";

// 1. SAFETY & COMPLIANCE
echo "1. Adding Safety & Compliance fields...\n";
$fields = [
    "safety_incident TINYINT(1) DEFAULT 0",
    "safety_incident_type ENUM('near_miss', 'injury', 'spill', 'equipment_damage', 'other') NULL",
    "safety_notes TEXT NULL",
    "ppe_compliant TINYINT(1) DEFAULT 1",
    "loto_verified TINYINT(1) DEFAULT 0",
    "environmental_incident TINYINT(1) DEFAULT 0"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 2. QUALITY CONTROL
echo "\n2. Adding Quality Control fields...\n";
$fields = [
    "first_article_pass TINYINT(1) NULL",
    "quality_hold TINYINT(1) DEFAULT 0",
    "scrap_quantity INT DEFAULT 0",
    "scrap_reason VARCHAR(255) NULL",
    "rework_quantity INT DEFAULT 0",
    "batch_number VARCHAR(100) NULL",
    "lot_number VARCHAR(100) NULL",
    "customer_complaint_ref VARCHAR(100) NULL"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 3. TOOL & CONSUMABLE TRACKING
echo "\n3. Adding Tool & Consumable fields...\n";
$fields = [
    "tools_changed JSON NULL",
    "consumables_used JSON NULL",
    "tool_life_alerts JSON NULL",
    "cost_per_unit DECIMAL(10,2) DEFAULT 0"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 4. OPERATOR SKILL & CERTIFICATION
echo "\n4. Adding Operator Skill fields...\n";
$fields = [
    "operator_certification VARCHAR(100) NULL",
    "skill_level ENUM('trainee', 'competent', 'expert') DEFAULT 'competent'",
    "certification_expiry DATE NULL",
    "supervisor_override TINYINT(1) DEFAULT 0",
    "multi_operator_handoff TINYINT(1) DEFAULT 0"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 5. ENERGY & UTILITIES
echo "\n5. Adding Energy & Utilities fields...\n";
$fields = [
    "power_consumption_kwh DECIMAL(10,2) DEFAULT 0",
    "compressed_air_m3 DECIMAL(10,2) DEFAULT 0",
    "water_consumption_liters DECIMAL(10,2) DEFAULT 0",
    "gas_consumption_m3 DECIMAL(10,2) DEFAULT 0",
    "carbon_footprint_kg DECIMAL(10,2) DEFAULT 0",
    "energy_cost DECIMAL(10,2) DEFAULT 0"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 6. CHANGEOVER & SETUP
echo "\n6. Adding Changeover & Setup fields...\n";
$fields = [
    "setup_start_time TIME NULL",
    "setup_end_time TIME NULL",
    "changeover_duration_minutes INT DEFAULT 0",
    "previous_job VARCHAR(100) NULL",
    "next_job VARCHAR(100) NULL",
    "setup_approved_by INT NULL",
    "tooling_changeover_notes TEXT NULL"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 7. PERFORMANCE TARGETS
echo "\n7. Adding Performance Target fields...\n";
$fields = [
    "target_units INT DEFAULT 0",
    "target_cycle_time_seconds INT DEFAULT 0",
    "actual_cycle_time_seconds INT DEFAULT 0",
    "efficiency_percent DECIMAL(5,2) DEFAULT 0",
    "variance_percent DECIMAL(5,2) DEFAULT 0",
    "bonus_eligible TINYINT(1) DEFAULT 0"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

// 8. SHIFT HANDOVER
echo "\n8. Creating Shift Handover table...\n";
$sql = "CREATE TABLE IF NOT EXISTS shift_handovers (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    handover_notes TEXT NULL,
    issues_reported TEXT NULL,
    pending_tasks TEXT NULL,
    machine_condition TEXT NULL,
    special_instructions TEXT NULL,
    next_shift_actions TEXT NULL,
    acknowledged_by INT UNSIGNED NULL,
    acknowledged_at DATETIME NULL,
    created_at DATETIME NULL,
    KEY idx_survey_id (survey_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->query($sql)) {
    echo "  ✓ shift_handovers table created\n";
}

// 9. REAL-TIME ALERTS
echo "\n9. Creating Alert Configuration table...\n";
$sql = "CREATE TABLE IF NOT EXISTS survey_alert_rules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    alert_type ENUM('defects', 'downtime', 'production', 'quality', 'safety') NOT NULL,
    threshold_value DECIMAL(10,2) NOT NULL,
    comparison ENUM('greater_than', 'less_than', 'equals') DEFAULT 'greater_than',
    notification_method ENUM('email', 'sms', 'system', 'all') DEFAULT 'system',
    recipients JSON NULL,
    active TINYINT(1) DEFAULT 1,
    created_at DATETIME NULL,
    KEY idx_alert_type (alert_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->query($sql)) {
    echo "  ✓ survey_alert_rules table created\n";
}

$sql = "CREATE TABLE IF NOT EXISTS survey_alerts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    survey_id INT UNSIGNED NOT NULL,
    rule_id INT UNSIGNED NOT NULL,
    alert_message TEXT NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    acknowledged TINYINT(1) DEFAULT 0,
    acknowledged_by INT UNSIGNED NULL,
    acknowledged_at DATETIME NULL,
    created_at DATETIME NULL,
    KEY idx_survey_id (survey_id),
    KEY idx_acknowledged (acknowledged)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->query($sql)) {
    echo "  ✓ survey_alerts table created\n";
}

// 10. MOBILE/OFFLINE SUPPORT
echo "\n10. Adding Mobile/Offline fields...\n";
$fields = [
    "offline_created TINYINT(1) DEFAULT 0",
    "sync_status ENUM('synced', 'pending', 'conflict') DEFAULT 'synced'",
    "device_id VARCHAR(100) NULL",
    "gps_latitude DECIMAL(10,8) NULL",
    "gps_longitude DECIMAL(11,8) NULL",
    "photo_attachments JSON NULL",
    "voice_notes JSON NULL"
];
foreach ($fields as $field) {
    if ($db->query("ALTER TABLE production_surveys ADD COLUMN $field")) {
        echo "  ✓ Added: " . explode(' ', $field)[0] . "\n";
    }
}

echo "\n✅ ALL ENTERPRISE FEATURES ADDED SUCCESSFULLY!\n";
echo "\nSummary:\n";
echo "- Safety & Compliance: 6 fields\n";
echo "- Quality Control: 8 fields\n";
echo "- Tool & Consumable: 4 fields\n";
echo "- Operator Skill: 5 fields\n";
echo "- Energy & Utilities: 6 fields\n";
echo "- Changeover & Setup: 7 fields\n";
echo "- Performance Targets: 6 fields\n";
echo "- Shift Handover: 1 table\n";
echo "- Real-time Alerts: 2 tables\n";
echo "- Mobile/Offline: 7 fields\n";
echo "\nTotal: 49 new fields + 3 new tables\n";

$db->close();
