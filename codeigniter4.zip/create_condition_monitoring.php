<?php

require 'vendor/autoload.php';

$db = \Config\Database::connect();

// Create condition_readings table
$db->query("
CREATE TABLE IF NOT EXISTS condition_readings (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT(11) UNSIGNED NOT NULL,
    reading_type ENUM('vibration', 'temperature', 'oil', 'ultrasonic', 'thermography') NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    threshold_min DECIMAL(10,2) NULL,
    threshold_max DECIMAL(10,2) NULL,
    status ENUM('normal', 'warning', 'critical') DEFAULT 'normal',
    notes TEXT NULL,
    recorded_by INT(11) UNSIGNED NOT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_asset (asset_id),
    INDEX idx_type (reading_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Create condition_alerts table
$db->query("
CREATE TABLE IF NOT EXISTS condition_alerts (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    reading_id INT(11) UNSIGNED NOT NULL,
    asset_id INT(11) UNSIGNED NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    message TEXT NOT NULL,
    acknowledged TINYINT(1) DEFAULT 0,
    acknowledged_by INT(11) UNSIGNED NULL,
    acknowledged_at DATETIME NULL,
    created_at DATETIME NULL,
    INDEX idx_asset (asset_id),
    INDEX idx_severity (severity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Create monitoring_thresholds table
$db->query("
CREATE TABLE IF NOT EXISTS monitoring_thresholds (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT(11) UNSIGNED NOT NULL,
    reading_type VARCHAR(50) NOT NULL,
    warning_min DECIMAL(10,2) NULL,
    warning_max DECIMAL(10,2) NULL,
    critical_min DECIMAL(10,2) NULL,
    critical_max DECIMAL(10,2) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_asset_type (asset_id, reading_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

echo "✅ Condition monitoring tables created successfully!\n";

// Insert sample data
$db->query("
INSERT INTO condition_readings (asset_id, reading_type, value, unit, status, recorded_by, created_at) VALUES
(1, 'vibration', 4.2, 'mm/s', 'normal', 1, NOW()),
(2, 'vibration', 8.5, 'mm/s', 'warning', 1, NOW()),
(3, 'vibration', 12.3, 'mm/s', 'critical', 1, NOW()),
(1, 'temperature', 85, '°C', 'normal', 1, NOW()),
(2, 'temperature', 92, '°C', 'warning', 1, NOW()),
(3, 'temperature', 105, '°C', 'critical', 1, NOW())
");

echo "✅ Sample data inserted!\n";
