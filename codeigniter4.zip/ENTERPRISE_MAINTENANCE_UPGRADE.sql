-- ============================================
-- ENTERPRISE MAINTENANCE MODULE UPGRADE v3.0
-- Multi-Technician Teams, Job Planning, SLA Tracking
-- ============================================

-- 1. TEAM ASSIGNMENT
CREATE TABLE IF NOT EXISTS work_order_team_members (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    role ENUM('team_lead', 'assistant', 'specialist') NOT NULL,
    assigned_date DATETIME NOT NULL,
    assigned_by INT UNSIGNED NOT NULL,
    accepted_date DATETIME NULL,
    declined_date DATETIME NULL,
    status ENUM('assigned', 'accepted', 'declined', 'working', 'completed') DEFAULT 'assigned',
    labor_hours DECIMAL(10,2) DEFAULT 0.00,
    notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_wo_tech (work_order_id, technician_id),
    INDEX idx_role (role),
    INDEX idx_status (status),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. ASSISTANCE REQUESTS
CREATE TABLE IF NOT EXISTS work_order_assistance_requests (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    requested_by INT UNSIGNED NOT NULL,
    requested_at DATETIME NOT NULL,
    skill_required VARCHAR(100) NULL,
    reason TEXT NOT NULL,
    urgency ENUM('low', 'medium', 'high') DEFAULT 'medium',
    status ENUM('pending', 'approved', 'rejected', 'fulfilled', 'cancelled') DEFAULT 'pending',
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    assigned_technician_id INT UNSIGNED NULL,
    fulfilled_at DATETIME NULL,
    rejection_reason TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_status (status),
    INDEX idx_urgency (urgency),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. JOB PLANNING
CREATE TABLE IF NOT EXISTS work_order_job_plans (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    plan_name VARCHAR(255) NULL,
    estimated_duration INT NULL COMMENT 'minutes',
    required_skills JSON NULL,
    required_tools JSON NULL,
    required_parts JSON NULL,
    safety_requirements TEXT NULL,
    step_by_step_instructions TEXT NULL,
    permits_required JSON NULL,
    special_instructions TEXT NULL,
    created_by INT UNSIGNED NOT NULL,
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_status (status),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. RESOURCE RESERVATIONS
CREATE TABLE IF NOT EXISTS work_order_resource_reservations (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    resource_type ENUM('part', 'tool', 'equipment') NOT NULL,
    resource_id INT UNSIGNED NOT NULL,
    quantity INT NOT NULL,
    reserved_by INT UNSIGNED NOT NULL,
    reserved_at DATETIME NOT NULL,
    released_at DATETIME NULL,
    status ENUM('reserved', 'issued', 'returned', 'consumed') DEFAULT 'reserved',
    notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_resource (resource_type, resource_id),
    INDEX idx_status (status),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. STATUS HISTORY
CREATE TABLE IF NOT EXISTS work_order_status_history (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(50) NULL,
    to_status VARCHAR(50) NOT NULL,
    changed_by INT UNSIGNED NOT NULL,
    changed_at DATETIME NOT NULL,
    reason TEXT NULL,
    INDEX idx_wo_status (work_order_id, changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. SLA DEFINITIONS
CREATE TABLE IF NOT EXISTS sla_definitions (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL,
    order_type ENUM('corrective', 'preventive', 'predictive', 'emergency') NOT NULL,
    response_time_hours INT NOT NULL,
    resolution_time_hours INT NOT NULL,
    escalation_level_1_hours INT NULL,
    escalation_level_2_hours INT NULL,
    escalation_level_3_hours INT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_priority_type (priority, order_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. SLA TRACKING
CREATE TABLE IF NOT EXISTS work_order_sla_tracking (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    sla_definition_id INT UNSIGNED NOT NULL,
    target_response_time DATETIME NOT NULL,
    actual_response_time DATETIME NULL,
    target_resolution_time DATETIME NOT NULL,
    actual_resolution_time DATETIME NULL,
    response_breached BOOLEAN DEFAULT FALSE,
    resolution_breached BOOLEAN DEFAULT FALSE,
    response_breach_duration INT NULL,
    resolution_breach_duration INT NULL,
    current_escalation_level INT DEFAULT 0,
    escalated_to INT UNSIGNED NULL,
    escalated_at DATETIME NULL,
    escalation_notes TEXT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_breached (response_breached, resolution_breached),
    INDEX idx_escalation (current_escalation_level),
    INDEX idx_wo_id (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. SHUTDOWN EVENTS
CREATE TABLE IF NOT EXISTS shutdown_events (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(255) NOT NULL,
    event_type ENUM('planned_shutdown', 'turnaround', 'overhaul') NOT NULL,
    facility_id INT UNSIGNED NULL,
    planned_start_date DATE NOT NULL,
    planned_end_date DATE NOT NULL,
    actual_start_date DATE NULL,
    actual_end_date DATE NULL,
    status ENUM('planning', 'approved', 'in_progress', 'completed', 'cancelled') DEFAULT 'planning',
    budget DECIMAL(15,2) NULL,
    actual_cost DECIMAL(15,2) NULL,
    coordinator_id INT UNSIGNED NOT NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_status (status),
    INDEX idx_dates (planned_start_date, planned_end_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. SHUTDOWN WORK ORDERS
CREATE TABLE IF NOT EXISTS shutdown_work_orders (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    shutdown_event_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NOT NULL,
    sequence_order INT NULL,
    critical_path BOOLEAN DEFAULT FALSE,
    dependencies JSON NULL,
    created_at DATETIME NULL,
    INDEX idx_shutdown (shutdown_event_id, sequence_order),
    INDEX idx_critical (critical_path)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. PREDICTIVE MAINTENANCE
CREATE TABLE IF NOT EXISTS predictive_maintenance_inspections (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    asset_id INT UNSIGNED NOT NULL,
    inspection_type ENUM('vibration', 'temperature', 'oil_analysis', 'visual', 'ultrasonic') NOT NULL,
    reading_value DECIMAL(10,2) NULL,
    threshold_warning DECIMAL(10,2) NULL,
    threshold_critical DECIMAL(10,2) NULL,
    status ENUM('normal', 'warning', 'critical') NOT NULL,
    inspector_id INT UNSIGNED NOT NULL,
    inspection_date DATETIME NOT NULL,
    next_inspection_date DATE NULL,
    notes TEXT NULL,
    work_order_generated BOOLEAN DEFAULT FALSE,
    work_order_id INT UNSIGNED NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_status (status),
    INDEX idx_next_inspection (next_inspection_date),
    INDEX idx_asset (asset_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. PM METER TRIGGERS
CREATE TABLE IF NOT EXISTS pm_meter_triggers (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    pm_schedule_id INT UNSIGNED NOT NULL,
    meter_id INT UNSIGNED NOT NULL,
    trigger_value INT NOT NULL,
    last_reading INT NULL,
    last_wo_generated_at DATETIME NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_active (active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. INSERT DEFAULT SLA DEFINITIONS
INSERT IGNORE INTO sla_definitions (name, priority, order_type, response_time_hours, resolution_time_hours, escalation_level_1_hours, escalation_level_2_hours, escalation_level_3_hours) VALUES
('Urgent Corrective', 'urgent', 'corrective', 1, 4, 2, 3, 4),
('High Corrective', 'high', 'corrective', 2, 8, 4, 6, 8),
('Medium Corrective', 'medium', 'corrective', 4, 24, 12, 18, 24),
('Low Corrective', 'low', 'corrective', 8, 48, 24, 36, 48),
('Urgent Emergency', 'urgent', 'emergency', 1, 2, 1, 1, 2),
('High Emergency', 'high', 'emergency', 1, 4, 2, 3, 4),
('Medium Preventive', 'medium', 'preventive', 24, 72, 48, 60, 72),
('Low Preventive', 'low', 'preventive', 48, 168, 96, 132, 168);

-- VERIFICATION
SELECT 'Enterprise Maintenance Module v3.0 Upgrade Complete!' AS Status;
SELECT COUNT(*) AS 'Tables Created' FROM information_schema.tables 
WHERE table_schema = DATABASE() 
AND table_name IN (
    'work_order_team_members',
    'work_order_assistance_requests',
    'work_order_job_plans',
    'work_order_resource_reservations',
    'work_order_status_history',
    'sla_definitions',
    'work_order_sla_tracking',
    'shutdown_events',
    'shutdown_work_orders',
    'predictive_maintenance_inspections',
    'pm_meter_triggers'
);
