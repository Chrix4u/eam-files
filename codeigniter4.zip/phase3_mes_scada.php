<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_mes_integration (
    integration_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT NOT NULL,
    mes_system VARCHAR(100) NOT NULL,
    data_source VARCHAR(255) NOT NULL,
    field_mappings JSON NOT NULL,
    sync_status ENUM('pending', 'synced', 'failed') DEFAULT 'pending',
    synced_data JSON,
    last_sync_at TIMESTAMP NULL,
    error_message TEXT NULL,
    INDEX idx_survey_mes (survey_id),
    INDEX idx_sync_status (sync_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$fields = [
    "mes_integrated BOOLEAN DEFAULT FALSE",
    "mes_data_source VARCHAR(255) NULL",
    "auto_populate_enabled BOOLEAN DEFAULT FALSE"
];
foreach ($fields as $field) {
    $db->query("ALTER TABLE production_surveys ADD COLUMN $field");
}

echo "✅ MES/SCADA Integration table created\n";
$db->close();
