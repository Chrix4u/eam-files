<?php

require 'vendor/autoload.php';

// Load CodeIgniter
$pathsConfig = 'app/Config/Paths.php';
require realpath($pathsConfig) ?: $pathsConfig;

$paths = new Config\Paths();
$bootstrap = rtrim($paths->systemDirectory, '\\/ ') . '/bootstrap.php';
$app = require realpath($bootstrap) ?: $bootstrap;

$app->initialize();

$db = \Config\Database::connect();

echo "=== MIGRATING TO UNIFIED ASSET SCHEMA ===\n\n";

// Step 1: Backup existing tables
echo "Step 1: Creating backup tables...\n";
$db->query("CREATE TABLE IF NOT EXISTS assets_backup AS SELECT * FROM assets");
$db->query("CREATE TABLE IF NOT EXISTS machines_backup AS SELECT * FROM machines");
$db->query("CREATE TABLE IF NOT EXISTS assemblies_backup AS SELECT * FROM assemblies");
$db->query("CREATE TABLE IF NOT EXISTS parts_backup AS SELECT * FROM parts");
echo "✓ Backup complete\n\n";

// Step 2: Migrate machines
echo "Step 2: Migrating machines...\n";
$machines = $db->query("SELECT * FROM machines")->getResultArray();
$count = 0;

foreach ($machines as $machine) {
    $data = [
        'asset_code' => $machine['machine_code'] ?? 'M-' . $machine['id'],
        'asset_name' => $machine['machine_name'] ?? $machine['name'],
        'asset_type' => 'machine',
        'parent_id' => null,
        'hierarchy_level' => 0,
        'hierarchy_path' => '/',
        'manufacturer' => $machine['manufacturer'] ?? null,
        'model_number' => $machine['model'] ?? null,
        'serial_number' => $machine['serial_number'] ?? null,
        'status' => $machine['status'] ?? 'active',
        'criticality' => $machine['criticality'] ?? 'medium',
        'location_id' => $machine['location_id'] ?? null,
        'created_at' => $machine['created_at'] ?? date('Y-m-d H:i:s'),
        'updated_at' => $machine['updated_at'] ?? date('Y-m-d H:i:s'),
    ];
    
    $db->table('assets_unified')->insert($data);
    $newId = $db->insertID();
    
    // Insert into closure table (self-reference)
    $db->table('asset_closure')->insert([
        'ancestor_id' => $newId,
        'descendant_id' => $newId,
        'depth' => 0
    ]);
    
    // Store mapping for later
    $db->query("INSERT INTO asset_migration_map (old_table, old_id, new_id) VALUES ('machines', ?, ?)", [$machine['id'], $newId]);
    
    $count++;
}
echo "✓ Migrated $count machines\n\n";

// Step 3: Migrate assemblies
echo "Step 3: Migrating assemblies...\n";
$assemblies = $db->query("SELECT * FROM assemblies")->getResultArray();
$count = 0;

foreach ($assemblies as $assembly) {
    // Find parent machine
    $parentId = null;
    if (!empty($assembly['equipment_id'])) {
        $parent = $db->query("SELECT new_id FROM asset_migration_map WHERE old_table='machines' AND old_id=?", [$assembly['equipment_id']])->getRow();
        $parentId = $parent->new_id ?? null;
    }
    
    $parentPath = '/';
    $parentLevel = 0;
    if ($parentId) {
        $parentAsset = $db->query("SELECT hierarchy_path, hierarchy_level FROM assets_unified WHERE id=?", [$parentId])->getRow();
        $parentPath = $parentAsset->hierarchy_path . $parentId . '/';
        $parentLevel = $parentAsset->hierarchy_level + 1;
    }
    
    $data = [
        'asset_code' => $assembly['assembly_code'] ?? 'A-' . $assembly['id'],
        'asset_name' => $assembly['assembly_name'] ?? $assembly['name'],
        'asset_type' => 'assembly',
        'parent_id' => $parentId,
        'hierarchy_level' => $parentLevel,
        'hierarchy_path' => $parentPath,
        'status' => $assembly['status'] ?? 'active',
        'criticality' => $assembly['criticality'] ?? 'medium',
        'created_at' => $assembly['created_at'] ?? date('Y-m-d H:i:s'),
        'updated_at' => $assembly['updated_at'] ?? date('Y-m-d H:i:s'),
    ];
    
    $db->table('assets_unified')->insert($data);
    $newId = $db->insertID();
    
    // Update closure table
    $db->table('asset_closure')->insert([
        'ancestor_id' => $newId,
        'descendant_id' => $newId,
        'depth' => 0
    ]);
    
    if ($parentId) {
        $db->query("
            INSERT INTO asset_closure (ancestor_id, descendant_id, depth)
            SELECT ancestor_id, ?, depth + 1
            FROM asset_closure
            WHERE descendant_id = ?
        ", [$newId, $parentId]);
    }
    
    $db->query("INSERT INTO asset_migration_map (old_table, old_id, new_id) VALUES ('assemblies', ?, ?)", [$assembly['id'], $newId]);
    
    $count++;
}
echo "✓ Migrated $count assemblies\n\n";

// Step 4: Migrate parts
echo "Step 4: Migrating parts...\n";
$parts = $db->query("SELECT * FROM parts")->getResultArray();
$count = 0;

foreach ($parts as $part) {
    // Find parent assembly
    $parentId = null;
    if (!empty($part['component_id'])) {
        $parent = $db->query("SELECT new_id FROM asset_migration_map WHERE old_table='assemblies' AND old_id=?", [$part['component_id']])->getRow();
        $parentId = $parent->new_id ?? null;
    }
    
    $parentPath = '/';
    $parentLevel = 0;
    if ($parentId) {
        $parentAsset = $db->query("SELECT hierarchy_path, hierarchy_level FROM assets_unified WHERE id=?", [$parentId])->getRow();
        $parentPath = $parentAsset->hierarchy_path . $parentId . '/';
        $parentLevel = $parentAsset->hierarchy_level + 1;
    }
    
    $data = [
        'asset_code' => $part['part_code'] ?? 'P-' . $part['id'],
        'asset_name' => $part['part_name'] ?? $part['name'],
        'asset_type' => 'part',
        'parent_id' => $parentId,
        'hierarchy_level' => $parentLevel,
        'hierarchy_path' => $parentPath,
        'manufacturer' => $part['manufacturer'] ?? null,
        'model_number' => $part['part_number'] ?? null,
        'status' => $part['status'] ?? 'active',
        'criticality' => $part['criticality'] ?? 'medium',
        'created_at' => $part['created_at'] ?? date('Y-m-d H:i:s'),
        'updated_at' => $part['updated_at'] ?? date('Y-m-d H:i:s'),
    ];
    
    $db->table('assets_unified')->insert($data);
    $newId = $db->insertID();
    
    // Update closure table
    $db->table('asset_closure')->insert([
        'ancestor_id' => $newId,
        'descendant_id' => $newId,
        'depth' => 0
    ]);
    
    if ($parentId) {
        $db->query("
            INSERT INTO asset_closure (ancestor_id, descendant_id, depth)
            SELECT ancestor_id, ?, depth + 1
            FROM asset_closure
            WHERE descendant_id = ?
        ", [$newId, $parentId]);
    }
    
    $db->query("INSERT INTO asset_migration_map (old_table, old_id, new_id) VALUES ('parts', ?, ?)", [$part['id'], $newId]);
    
    $count++;
}
echo "✓ Migrated $count parts\n\n";

// Step 5: Verify migration
echo "Step 5: Verifying migration...\n";
$totalAssets = $db->query("SELECT COUNT(*) as count FROM assets_unified")->getRow()->count;
$totalClosure = $db->query("SELECT COUNT(*) as count FROM asset_closure")->getRow()->count;
echo "✓ Total assets migrated: $totalAssets\n";
echo "✓ Total closure entries: $totalClosure\n\n";

// Step 6: Refresh materialized view
echo "Step 6: Refreshing materialized views...\n";
$db->query("CALL refresh_asset_health_summary()");
echo "✓ Materialized views refreshed\n\n";

echo "=== MIGRATION COMPLETE ===\n";
echo "\nNext steps:\n";
echo "1. Verify data in assets_unified table\n";
echo "2. Test hierarchy queries\n";
echo "3. Update frontend to use new API endpoints\n";
echo "4. Once verified, you can drop old tables (machines, assemblies, parts)\n";
