<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

echo "Making title column nullable...\n";

$mysqli->query("ALTER TABLE maintenance_requests MODIFY title VARCHAR(255) NULL");
echo "Title column is now nullable!\n";

$mysqli->close();
echo "\nMigration completed!\n";
