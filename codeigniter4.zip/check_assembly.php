<?php
$pdo = new PDO('mysql:host=localhost;dbname=factory_manager;charset=utf8mb4', 'root', 'myjesus4mE');
$stmt = $pdo->prepare('SELECT * FROM assemblies WHERE id = ?');
$stmt->execute([7]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);
if ($result) {
    echo 'Assembly 7 exists: ' . $result['assembly_name'] . "\n";
    print_r($result);
} else {
    echo "Assembly 7 does not exist\n";
    echo "Available assemblies:\n";
    $stmt = $pdo->query('SELECT id, assembly_name FROM assemblies LIMIT 5');
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo 'ID: ' . $row['id'] . ' - ' . $row['assembly_name'] . "\n";
    }
}
?>