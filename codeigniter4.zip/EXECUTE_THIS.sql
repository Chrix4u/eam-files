-- ========================================
-- MATERIALIZED VIEW SETUP
-- Execute this in MySQL Workbench or phpMyAdmin
-- ========================================

-- 1. Create materialized view table
CREATE TABLE IF NOT EXISTS mv_asset_health_summary (
    asset_id BIGINT UNSIGNED PRIMARY KEY,
    asset_name VARCHAR(255),
    asset_type VARCHAR(50),
    status VARCHAR(50),
    health_score DECIMAL(5,2),
    open_work_orders INT DEFAULT 0,
    overdue_work_orders INT DEFAULT 0,
    last_maintenance_date DATE,
    next_maintenance_date DATE,
    mtbf_hours DECIMAL(10,2),
    mttr_hours DECIMAL(10,2),
    oee_percent DECIMAL(5,2),
    total_downtime_hours DECIMAL(10,2) DEFAULT 0,
    maintenance_cost_ytd DECIMAL(15,2) DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_health (health_score),
    INDEX idx_status (status),
    INDEX idx_type (asset_type)
) ENGINE=InnoDB;

-- 2. Create refresh procedure
DROP PROCEDURE IF EXISTS refresh_asset_health_summary;

DELIMITER $$
CREATE PROCEDURE refresh_asset_health_summary()
BEGIN
    TRUNCATE TABLE mv_asset_health_summary;
    
    INSERT INTO mv_asset_health_summary
    SELECT 
        a.id,
        a.asset_name,
        a.asset_type,
        a.status,
        a.health_score,
        COUNT(DISTINCT wo.id) as open_work_orders,
        COUNT(DISTINCT CASE WHEN wo.due_date < CURDATE() THEN wo.id END) as overdue_work_orders,
        MAX(wo.completed_at) as last_maintenance_date,
        MIN(CASE WHEN wo.status = 'scheduled' THEN wo.scheduled_date END) as next_maintenance_date,
        a.mtbf_hours,
        a.mttr_hours,
        a.oee_percent,
        COALESCE(SUM(de.duration_hours), 0) as total_downtime_hours,
        COALESCE(SUM(wo.actual_cost), 0) as maintenance_cost_ytd,
        NOW()
    FROM assets_unified a
    LEFT JOIN work_orders wo ON a.id = wo.asset_id
    LEFT JOIN downtime_events de ON a.id = de.asset_id AND YEAR(de.start_time) = YEAR(CURDATE())
    GROUP BY a.id;
END$$
DELIMITER ;

-- 3. Create auto-refresh event
DROP EVENT IF EXISTS refresh_asset_health;

CREATE EVENT refresh_asset_health
ON SCHEDULE EVERY 5 MINUTE
DO CALL refresh_asset_health_summary();

-- 4. Initial population
CALL refresh_asset_health_summary();

-- 5. Verify installation
SELECT 'Table created' AS step, COUNT(*) AS count FROM mv_asset_health_summary
UNION ALL
SELECT 'Procedure exists', COUNT(*) FROM information_schema.ROUTINES WHERE ROUTINE_NAME = 'refresh_asset_health_summary'
UNION ALL
SELECT 'Event exists', COUNT(*) FROM information_schema.EVENTS WHERE EVENT_NAME = 'refresh_asset_health';

-- Done! Now test the API:
-- curl http://localhost/factorymanager/public/index.php/api/v1/eam/asset-health-summary
