<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert sample IoT devices
$devices = [
    ['DEV-001', 1, 'vibration_sensor'],
    ['DEV-002', 1, 'temperature_sensor'],
    ['DEV-003', 2, 'vibration_sensor'],
    ['DEV-004', 3, 'pressure_sensor']
];

foreach ($devices as $device) {
    $conn->query("INSERT IGNORE INTO iot_devices (device_id, asset_id, device_type, status, created_at) 
                  VALUES ('{$device[0]}', {$device[1]}, '{$device[2]}', 'active', NOW())");
}

// Insert sample IoT metrics (last 24 hours)
for ($i = 0; $i < 100; $i++) {
    $timestamp = date('Y-m-d H:i:s', strtotime("-{$i} minutes"));
    $vibration = rand(30, 90) / 10;
    $temperature = rand(60, 95);
    $pressure = rand(100, 160);
    
    $conn->query("INSERT INTO iot_metrics (device_id, asset_id, metric_type, value, timestamp) 
                  VALUES ('DEV-001', 1, 'vibration', $vibration, '$timestamp')");
    $conn->query("INSERT INTO iot_metrics (device_id, asset_id, metric_type, value, timestamp) 
                  VALUES ('DEV-002', 1, 'temperature', $temperature, '$timestamp')");
    $conn->query("INSERT INTO iot_metrics (device_id, asset_id, metric_type, value, timestamp) 
                  VALUES ('DEV-004', 3, 'pressure', $pressure, '$timestamp')");
}

// Insert sample alerts
$alerts = [
    [1, 'vibration', 8.5, 8.0, 'critical'],
    [1, 'temperature', 92, 90, 'critical'],
    [2, 'vibration', 6.2, 5.0, 'warning'],
    [3, 'pressure', 155, 150, 'warning']
];

foreach ($alerts as $alert) {
    $conn->query("INSERT INTO iot_alerts (asset_id, metric_type, value, threshold, severity, acknowledged, created_at) 
                  VALUES ({$alert[0]}, '{$alert[1]}', {$alert[2]}, {$alert[3]}, '{$alert[4]}', 0, NOW())");
}

// Insert sample ERP sync logs
$syncs = [
    ['assets', 'success', 'Synced 15 assets from ERP'],
    ['work_orders', 'success', 'Synced 8 work orders to ERP'],
    ['inventory', 'success', 'Synced 42 inventory items'],
    ['assets', 'failed', 'Connection timeout to ERP']
];

foreach ($syncs as $sync) {
    $conn->query("INSERT INTO erp_sync_log (entity_type, status, message, created_at) 
                  VALUES ('{$sync[0]}', '{$sync[1]}', '{$sync[2]}', NOW())");
}

$conn->close();
echo "Sample IoT and ERP data inserted successfully!\n";
