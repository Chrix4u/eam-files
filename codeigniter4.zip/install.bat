@echo off
echo ========================================
echo ENTERPRISE MAINTENANCE v3.0 INSTALLER
echo ========================================
echo.

echo Step 1: Creating tables...
c:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager < install_tables.sql
if %errorlevel% neq 0 (
    echo ERROR: Failed to create tables!
    pause
    exit /b 1
)
echo SUCCESS: Tables created!
echo.

echo Step 2: Inserting SLA definitions...
c:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager < install_sla_data.sql
if %errorlevel% neq 0 (
    echo ERROR: Failed to insert SLA data!
    pause
    exit /b 1
)
echo SUCCESS: SLA definitions inserted!
echo.

echo ========================================
echo INSTALLATION COMPLETE!
echo ========================================
echo.
echo Next steps:
echo 1. Run: php spark cache:clear
echo 2. Test: php spark serve
echo.
pause
