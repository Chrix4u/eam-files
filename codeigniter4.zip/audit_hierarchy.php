<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $hierarchyTables = ['facilities', 'facility_areas', 'production_lines', 'departments', 
                        'assets_unified', 'machines', 'asset_nodes'];
    
    echo "=== ENTERPRISE MULTI-PLANT HIERARCHY AUDIT ===\n\n";
    
    foreach ($hierarchyTables as $table) {
        echo "TABLE: $table\n";
        echo str_repeat("-", 80) . "\n";
        
        $stmt = $pdo->query("DESCRIBE $table");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($columns as $col) {
            $key = $col['Key'] ? " [{$col['Key']}]" : "";
            $null = $col['Null'] === 'YES' ? 'NULL' : 'NOT NULL';
            echo sprintf("  %-30s %-20s %-10s%s\n", 
                $col['Field'], $col['Type'], $null, $key);
        }
        
        // Check for plant-related columns
        $plantCols = ['plant_id', 'plant_code', 'plant_name', 'facility_id', 'area_id', 'line_id'];
        $found = array_filter($columns, fn($c) => in_array($c['Field'], $plantCols));
        
        if ($found) {
            echo "\n  ✓ Plant-related columns: " . implode(', ', array_column($found, 'Field')) . "\n";
        } else {
            echo "\n  ✗ No plant-related columns found\n";
        }
        
        // Sample data count
        $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
        echo "  Records: $count\n";
        
        echo "\n";
    }
    
    // Check work_orders
    echo "TABLE: work_orders\n";
    echo str_repeat("-", 80) . "\n";
    $stmt = $pdo->query("DESCRIBE work_orders");
    $woCols = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $plantRelated = array_filter($woCols, fn($c) => 
        in_array($c['Field'], ['plant_id', 'facility_id', 'area_id', 'asset_id']));
    
    foreach ($plantRelated as $col) {
        echo sprintf("  %-30s %-20s\n", $col['Field'], $col['Type']);
    }
    
    if (!$plantRelated) {
        echo "  ✗ No plant isolation columns\n";
    }
    
    echo "\n";
    
    // Check users
    echo "TABLE: users\n";
    echo str_repeat("-", 80) . "\n";
    $stmt = $pdo->query("DESCRIBE users");
    $userCols = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $userPlant = array_filter($userCols, fn($c) => 
        in_array($c['Field'], ['plant_id', 'default_plant_id', 'facility_id']));
    
    foreach ($userPlant as $col) {
        echo sprintf("  %-30s %-20s\n", $col['Field'], $col['Type']);
    }
    
    if (!$userPlant) {
        echo "  ✗ No plant assignment columns\n";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
