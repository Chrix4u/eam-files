<?php
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "=== WORK ORDER #8 DATA ===\n\n";

$result = $conn->query("SELECT * FROM work_orders WHERE id = 8");
if ($result && $result->num_rows > 0) {
    $wo = $result->fetch_assoc();
    echo "ID: " . $wo['id'] . "\n";
    echo "Title: " . ($wo['title'] ?? 'NULL') . "\n";
    echo "Asset ID: " . ($wo['asset_id'] ?? 'NULL') . "\n";
    echo "Equipment Name: " . ($wo['equipment_name'] ?? 'NULL') . "\n";
    echo "Location: " . ($wo['location'] ?? 'NULL') . "\n";
    echo "Department ID: " . ($wo['department_id'] ?? 'NULL') . "\n";
    echo "\n";
    
    if ($wo['asset_id']) {
        echo "=== MACHINE DATA ===\n";
        $machineResult = $conn->query("SELECT * FROM machines WHERE id = " . $wo['asset_id']);
        if ($machineResult && $machineResult->num_rows > 0) {
            $machine = $machineResult->fetch_assoc();
            echo "Machine Name: " . ($machine['machine_name'] ?? 'NULL') . "\n";
            echo "Location: " . ($machine['location'] ?? 'NULL') . "\n";
        } else {
            echo "No machine found with ID: " . $wo['asset_id'] . "\n";
        }
    } else {
        echo "No asset_id set for this work order\n";
    }
} else {
    echo "Work order #8 not found\n";
}

$conn->close();
