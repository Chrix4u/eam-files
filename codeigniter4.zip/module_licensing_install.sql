-- Module Licensing System Tables (Updated for existing schema)

-- Rename existing system_modules to system_modules_old
RENAME TABLE IF EXISTS `system_modules` TO `system_modules_old`;

-- Create new system_modules table
CREATE TABLE `system_modules` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `module_code` VARCHAR(50) UNIQUE NOT NULL,
    `module_name` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `is_core` TINYINT(1) DEFAULT 0,
    `is_system_licensed` TINYINT(1) DEFAULT 0,
    `license_key` VARCHAR(255),
    `license_type` ENUM('perpetual', 'subscription', 'trial') DEFAULT 'subscription',
    `max_companies` INT DEFAULT NULL,
    `valid_from` DATE,
    `valid_until` DATE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_module_code` (`module_code`),
    INDEX `idx_licensed` (`is_system_licensed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create companies table if not exists
CREATE TABLE IF NOT EXISTS `companies` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `company_name` VARCHAR(100) NOT NULL,
    `company_code` VARCHAR(50) UNIQUE,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create company_module_licenses table
CREATE TABLE `company_module_licenses` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `company_id` INT NOT NULL,
    `module_code` VARCHAR(50) NOT NULL,
    `is_active` TINYINT(1) DEFAULT 0,
    `activated_by` INT,
    `activated_at` TIMESTAMP NULL,
    `deactivated_at` TIMESTAMP NULL,
    `valid_from` DATE,
    `valid_until` DATE,
    `grace_period_days` INT DEFAULT 30,
    `usage_limit` INT DEFAULT NULL,
    `usage_count` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_company_module` (`company_id`, `module_code`),
    INDEX `idx_company` (`company_id`),
    INDEX `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create module_usage_logs table
CREATE TABLE `module_usage_logs` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `company_id` INT NOT NULL,
    `user_id` INT NOT NULL,
    `module_code` VARCHAR(50) NOT NULL,
    `action` VARCHAR(50) NOT NULL,
    `access_granted` TINYINT(1) DEFAULT 0,
    `denial_reason` VARCHAR(255),
    `ip_address` VARCHAR(45),
    `user_agent` VARCHAR(255),
    `request_uri` VARCHAR(500),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_company_module` (`company_id`, `module_code`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert initial modules
INSERT INTO `system_modules` (`module_code`, `module_name`, `description`, `is_core`, `is_system_licensed`) VALUES
('CORE', 'Core EAM', 'Essential EAM functionality', 1, 1),
('ASSET', 'Asset Management', 'Complete asset lifecycle management', 0, 1),
('RWOP', 'Work Order Management', 'Work order creation and tracking', 0, 1),
('MRMP', 'Preventive Maintenance', 'Scheduled maintenance planning', 0, 1),
('IMS', 'Inventory Management', 'Spare parts and inventory control', 0, 1),
('MPMP', 'Production Management', 'Production planning and tracking', 0, 1),
('TRAC', 'Safety & Compliance', 'Safety and regulatory compliance', 0, 1),
('HRMS', 'HR Management', 'Human resource management', 0, 0),
('IOT', 'IoT & Predictive Maintenance', 'IoT sensors and predictive analytics', 0, 1),
('DIGITAL_TWIN', 'Digital Twin Analytics', '3D visualization and analytics', 0, 0),
('REPORTS', 'Advanced Reporting', 'Custom reports and analytics', 0, 1),
('MOBILE', 'Mobile Access', 'Mobile app access', 0, 0);

-- Insert default company if not exists
INSERT IGNORE INTO `companies` (`id`, `company_name`, `company_code`, `is_active`) VALUES
(1, 'Default Company', 'DEFAULT', 1);

-- Activate all licensed modules for default company
INSERT INTO `company_module_licenses` 
    (`company_id`, `module_code`, `is_active`, `activated_at`, `valid_from`, `valid_until`)
SELECT 
    1, 
    `module_code`, 
    1, 
    NOW(), 
    CURDATE(), 
    DATE_ADD(CURDATE(), INTERVAL 1 YEAR)
FROM `system_modules` 
WHERE `is_system_licensed` = 1;

-- Add foreign keys
ALTER TABLE `company_module_licenses`
    ADD CONSTRAINT `fk_company` FOREIGN KEY (`company_id`) REFERENCES `companies`(`id`) ON DELETE CASCADE,
    ADD CONSTRAINT `fk_module_code` FOREIGN KEY (`module_code`) REFERENCES `system_modules`(`module_code`) ON DELETE CASCADE;
