<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

echo "=== RBAC Table Structures ===\n\n";

$tables = ['permissions', 'roles', 'role_permissions', 'user_roles', 'audit_logs'];

foreach ($tables as $table) {
    echo "Table: $table\n";
    $result = $mysqli->query("DESCRIBE $table");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo "  • {$row['Field']} ({$row['Type']}) - " . (!empty($row['Null']) && $row['Null'] === 'YES' ? 'nullable' : 'NOT NULL') . "\n";
        }
    }
    echo "\n";
}

$mysqli->close();
?>
