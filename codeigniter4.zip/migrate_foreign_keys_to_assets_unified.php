<?php
/**
 * Migrate Foreign Keys from assets table to assets_unified table
 * Then safely drop the old assets table
 */

$db_host = 'localhost';
$db_user = 'root';
$db_pass = 'myjesus4mE';
$db_name = 'factory_manager';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "=== FOREIGN KEY MIGRATION TO assets_unified ===\n\n";

// Step 1: Find all foreign keys referencing assets table
echo "Step 1: Finding foreign key references to 'assets' table...\n";
$fk_query = "
    SELECT 
        TABLE_NAME,
        COLUMN_NAME,
        CONSTRAINT_NAME,
        REFERENCED_TABLE_NAME,
        REFERENCED_COLUMN_NAME
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE REFERENCED_TABLE_NAME = 'assets'
    AND TABLE_SCHEMA = '$db_name'
";

$result = $conn->query($fk_query);
$foreign_keys = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $foreign_keys[] = $row;
        echo "  - {$row['TABLE_NAME']}.{$row['COLUMN_NAME']} -> {$row['CONSTRAINT_NAME']}\n";
    }
} else {
    echo "  No foreign keys found referencing 'assets' table.\n";
}

echo "\nTotal foreign keys found: " . count($foreign_keys) . "\n\n";

// Step 2: Backup database
echo "Step 2: Creating backup...\n";
$backup_file = "backup_before_assets_migration_" . date('Y-m-d_H-i-s') . ".sql";
$backup_cmd = "\"C:\\wamp64\\bin\\mysql\\mysql8.0.31\\bin\\mysqldump.exe\" -u$db_user -p$db_pass $db_name > $backup_file";
exec($backup_cmd, $output, $return_var);
if ($return_var === 0) {
    echo "  ✓ Backup created: $backup_file\n\n";
} else {
    echo "  ⚠ Backup failed, but continuing...\n\n";
}

// Step 3: Drop foreign key constraints
echo "Step 3: Dropping foreign key constraints...\n";
foreach ($foreign_keys as $fk) {
    $table = $fk['TABLE_NAME'];
    $constraint = $fk['CONSTRAINT_NAME'];
    
    $drop_sql = "ALTER TABLE `$table` DROP FOREIGN KEY `$constraint`";
    if ($conn->query($drop_sql)) {
        echo "  ✓ Dropped: $table.$constraint\n";
    } else {
        echo "  ✗ Failed to drop $table.$constraint: " . $conn->error . "\n";
    }
}

echo "\n";

// Step 4: Recreate foreign keys pointing to assets_unified
echo "Step 4: Recreating foreign keys to point to assets_unified...\n";
foreach ($foreign_keys as $fk) {
    $table = $fk['TABLE_NAME'];
    $column = $fk['COLUMN_NAME'];
    $new_constraint = $fk['CONSTRAINT_NAME'] . '_unified';
    
    $add_sql = "ALTER TABLE `$table` 
                ADD CONSTRAINT `$new_constraint` 
                FOREIGN KEY (`$column`) 
                REFERENCES `assets_unified`(`id`) 
                ON DELETE CASCADE 
                ON UPDATE CASCADE";
    
    if ($conn->query($add_sql)) {
        echo "  ✓ Created: $table.$new_constraint -> assets_unified.id\n";
    } else {
        echo "  ⚠ Failed to create $table.$new_constraint: " . $conn->error . "\n";
    }
}

echo "\n";

// Step 5: Check for any remaining references in code
echo "Step 5: Checking table dependencies...\n";
$tables_with_asset_id = $conn->query("
    SELECT DISTINCT TABLE_NAME, COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = '$db_name'
    AND COLUMN_NAME = 'asset_id'
    ORDER BY TABLE_NAME
");

echo "  Tables with asset_id column:\n";
while ($row = $tables_with_asset_id->fetch_assoc()) {
    echo "    - {$row['TABLE_NAME']}.{$row['COLUMN_NAME']}\n";
}

echo "\n";

// Step 6: Verify data integrity
echo "Step 6: Verifying data integrity...\n";
$assets_count = $conn->query("SELECT COUNT(*) as cnt FROM assets")->fetch_assoc()['cnt'];
$assets_unified_count = $conn->query("SELECT COUNT(*) as cnt FROM assets_unified")->fetch_assoc()['cnt'];

echo "  - Old assets table: $assets_count records\n";
echo "  - New assets_unified table: $assets_unified_count records\n";

if ($assets_unified_count >= $assets_count) {
    echo "  ✓ Data migration verified\n\n";
} else {
    echo "  ⚠ WARNING: assets_unified has fewer records!\n\n";
    die("Stopping migration. Please investigate data discrepancy.\n");
}

// Step 7: Rename old assets table (don't delete yet)
echo "Step 7: Renaming old assets table to assets_deprecated...\n";
$rename_sql = "RENAME TABLE `assets` TO `assets_deprecated`";
if ($conn->query($rename_sql)) {
    echo "  ✓ Renamed: assets -> assets_deprecated\n";
    echo "  (Table preserved for safety. Delete manually after verification)\n\n";
} else {
    echo "  ✗ Failed to rename: " . $conn->error . "\n\n";
}

// Step 8: Summary
echo "=== MIGRATION COMPLETE ===\n\n";
echo "Summary:\n";
echo "  - Foreign keys migrated: " . count($foreign_keys) . "\n";
echo "  - Old table renamed: assets -> assets_deprecated\n";
echo "  - New table active: assets_unified ($assets_unified_count records)\n";
echo "  - Backup created: $backup_file\n\n";

echo "Next Steps:\n";
echo "  1. Test all features thoroughly\n";
echo "  2. Verify work orders, PM schedules, IoT devices work correctly\n";
echo "  3. After 1-2 weeks of testing, drop assets_deprecated:\n";
echo "     DROP TABLE assets_deprecated;\n\n";

echo "To rollback if needed:\n";
echo "  1. Restore from backup: $backup_file\n";
echo "  2. Or rename back: RENAME TABLE assets_deprecated TO assets;\n\n";

$conn->close();
?>
