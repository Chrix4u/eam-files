<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);

echo "=== Assets Unified ===\n";
$stmt = $pdo->query("SELECT id, asset_name, asset_type, status FROM assets_unified LIMIT 5");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));

echo "\n=== Users ===\n";
$stmt = $pdo->query("DESCRIBE users");
$columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
print_r($columns);

echo "\n=== Sample Users ===\n";
$stmt = $pdo->query("SELECT id, username, role, supervisor_id FROM users WHERE role IN ('operator', 'technician') LIMIT 5");
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
