<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');
if (!$db) die('Connection failed: ' . mysqli_connect_error());

// Get current columns
$result = mysqli_query($db, "DESCRIBE users");
$existingColumns = [];
while ($row = mysqli_fetch_assoc($result)) {
    $existingColumns[] = $row['Field'];
}

echo "Existing columns:\n";
print_r($existingColumns);
echo "\n\n";

// Required columns from the model
$requiredColumns = [
    'hire_date' => 'DATE',
    'trade' => 'VARCHAR(100)',
    'hourly_rate' => 'DECIMAL(10,2)',
    'bank_name' => 'VARCHAR(100)',
    'bank_branch' => 'VARCHAR(100)',
    'account_number' => 'VARCHAR(50)',
    'account_name' => 'VARCHAR(255)',
    'basic_salary' => 'DECIMAL(12,2)',
    'emergency_contact_1_name' => 'VARCHAR(255)',
    'emergency_contact_1_phone' => 'VARCHAR(20)',
    'emergency_contact_1_relationship' => 'VARCHAR(50)'
];

// Add missing columns
foreach ($requiredColumns as $column => $type) {
    if (!in_array($column, $existingColumns)) {
        $sql = "ALTER TABLE users ADD COLUMN $column $type";
        if (mysqli_query($db, $sql)) {
            echo "✅ Added column: $column\n";
        } else {
            echo "❌ Error adding $column: " . mysqli_error($db) . "\n";
        }
    } else {
        echo "⏭️  Column already exists: $column\n";
    }
}

mysqli_close($db);
