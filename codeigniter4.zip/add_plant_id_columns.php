<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();

try {
    // Add plant_id to production_targets
    $db->query("ALTER TABLE production_targets ADD COLUMN plant_id INT(11) UNSIGNED NULL AFTER id");
    echo "Added plant_id to production_targets\n";
} catch (\Exception $e) {
    echo "production_targets: " . $e->getMessage() . "\n";
}

try {
    // Add plant_id to pm_schedules
    $db->query("ALTER TABLE pm_schedules ADD COLUMN plant_id INT(11) UNSIGNED NULL AFTER id");
    echo "Added plant_id to pm_schedules\n";
} catch (\Exception $e) {
    echo "pm_schedules: " . $e->getMessage() . "\n";
}

// Update existing records
$db->query("UPDATE production_targets SET plant_id = 1 WHERE plant_id IS NULL");
$db->query("UPDATE pm_schedules SET plant_id = 1 WHERE plant_id IS NULL");

echo "Migration completed successfully!\n";
