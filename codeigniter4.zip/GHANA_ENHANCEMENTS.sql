-- ============================================
-- GHANA-SPECIFIC OPERATIONAL ENHANCEMENTS
-- Power/Internet Instability, Skills, Labor Types, Parts Constraints
-- ============================================

-- 1. TECHNICIAN SKILL MATRIX
CREATE TABLE IF NOT EXISTS technician_skills (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    technician_id INT UNSIGNED NOT NULL,
    skill_name VARCHAR(100) NOT NULL,
    proficiency_level ENUM('beginner', 'intermediate', 'advanced', 'expert') NOT NULL,
    certified BOOLEAN DEFAULT FALSE,
    certification_date DATE NULL,
    certification_expiry DATE NULL,
    years_experience DECIMAL(4,2) DEFAULT 0.00,
    verified_by INT UNSIGNED NULL,
    verified_at DATETIME NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_tech_skill (technician_id, skill_name),
    INDEX idx_skill (skill_name),
    INDEX idx_proficiency (proficiency_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. OFFLINE WORK ORDER SYNC
CREATE TABLE IF NOT EXISTS work_order_offline_queue (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    action_type ENUM('start', 'pause', 'resume', 'update', 'complete') NOT NULL,
    offline_data JSON NOT NULL,
    device_id VARCHAR(100) NULL,
    offline_timestamp DATETIME NOT NULL,
    synced BOOLEAN DEFAULT FALSE,
    synced_at DATETIME NULL,
    sync_error TEXT NULL,
    created_at DATETIME NULL,
    INDEX idx_sync_status (synced, offline_timestamp),
    INDEX idx_work_order (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. POWER/NETWORK INTERRUPTION LOG
CREATE TABLE IF NOT EXISTS work_order_interruptions (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    interruption_type ENUM('power_outage', 'network_loss', 'equipment_failure', 'other') NOT NULL,
    started_at DATETIME NOT NULL,
    ended_at DATETIME NULL,
    duration_minutes INT NULL,
    auto_detected BOOLEAN DEFAULT TRUE,
    technician_id INT UNSIGNED NULL,
    notes TEXT NULL,
    created_at DATETIME NULL,
    INDEX idx_work_order (work_order_id),
    INDEX idx_type (interruption_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. LABOR TYPES (Normal, Overtime, Weekend, Emergency)
CREATE TABLE IF NOT EXISTS work_order_labor_enhanced (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    technician_id INT UNSIGNED NOT NULL,
    labor_type ENUM('normal', 'overtime', 'weekend', 'holiday', 'emergency') NOT NULL DEFAULT 'normal',
    start_time DATETIME NOT NULL,
    end_time DATETIME NULL,
    hours_worked DECIMAL(10,2) DEFAULT 0.00,
    base_rate DECIMAL(10,2) NOT NULL,
    multiplier DECIMAL(4,2) DEFAULT 1.00,
    total_cost DECIMAL(10,2) DEFAULT 0.00,
    justification TEXT NULL COMMENT 'Required for overtime/emergency',
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    INDEX idx_work_order (work_order_id),
    INDEX idx_labor_type (labor_type),
    INDEX idx_approval (approved_by, approved_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. PART SUBSTITUTIONS & FABRICATIONS
CREATE TABLE IF NOT EXISTS work_order_part_substitutions (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    original_part_id INT UNSIGNED NOT NULL,
    substitute_part_id INT UNSIGNED NULL,
    is_fabricated BOOLEAN DEFAULT FALSE,
    fabrication_details TEXT NULL,
    reason ENUM('unavailable', 'cost_saving', 'upgrade', 'emergency') NOT NULL,
    quantity INT NOT NULL,
    cost_difference DECIMAL(10,2) DEFAULT 0.00,
    approved_by INT UNSIGNED NOT NULL,
    approved_at DATETIME NOT NULL,
    created_at DATETIME NULL,
    INDEX idx_work_order (work_order_id),
    INDEX idx_original_part (original_part_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. MAINTENANCE DELAYS (Part Unavailability)
CREATE TABLE IF NOT EXISTS work_order_delays (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    delay_type ENUM('parts_unavailable', 'technician_unavailable', 'tool_unavailable', 'approval_pending', 'other') NOT NULL,
    delay_start DATETIME NOT NULL,
    delay_end DATETIME NULL,
    duration_hours DECIMAL(10,2) NULL,
    part_id INT UNSIGNED NULL,
    expected_availability_date DATE NULL,
    impact ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    notes TEXT NULL,
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME NULL,
    INDEX idx_work_order (work_order_id),
    INDEX idx_delay_type (delay_type),
    INDEX idx_impact (impact)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. DEPARTMENTAL AUTHORITY & OVERRIDES
CREATE TABLE IF NOT EXISTS work_order_authority_overrides (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    override_type ENUM('cross_department_assignment', 'priority_change', 'cost_override', 'deadline_extension') NOT NULL,
    original_value VARCHAR(255) NULL,
    new_value VARCHAR(255) NULL,
    overridden_by INT UNSIGNED NOT NULL,
    override_reason TEXT NOT NULL,
    approved_by INT UNSIGNED NULL,
    approved_at DATETIME NULL,
    created_at DATETIME NULL,
    INDEX idx_work_order (work_order_id),
    INDEX idx_override_type (override_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. ENHANCED AUDIT TRAIL (Immutable)
CREATE TABLE IF NOT EXISTS work_order_audit_log (
    id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    work_order_id INT UNSIGNED NOT NULL,
    action_type ENUM('created', 'assigned', 'started', 'paused', 'resumed', 'completed', 'approved', 'rejected', 'closed', 'modified') NOT NULL,
    entity_type VARCHAR(50) NOT NULL COMMENT 'team, labor, parts, report, etc',
    entity_id INT UNSIGNED NULL,
    field_changed VARCHAR(100) NULL,
    old_value TEXT NULL,
    new_value TEXT NULL,
    changed_by INT UNSIGNED NOT NULL,
    changed_at DATETIME NOT NULL,
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    INDEX idx_work_order (work_order_id, changed_at),
    INDEX idx_action (action_type),
    INDEX idx_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. FAILURE ANALYSIS (Root Cause)
CREATE TABLE IF NOT EXISTS asset_failure_analysis (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    asset_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NOT NULL,
    failure_date DATETIME NOT NULL,
    failure_code_id INT UNSIGNED NULL,
    root_cause TEXT NOT NULL,
    contributing_factors JSON NULL,
    corrective_action TEXT NOT NULL,
    preventive_recommendation TEXT NULL,
    recurrence_risk ENUM('low', 'medium', 'high') NOT NULL,
    cost_impact DECIMAL(15,2) DEFAULT 0.00,
    downtime_hours DECIMAL(10,2) DEFAULT 0.00,
    analyzed_by INT UNSIGNED NOT NULL,
    analyzed_at DATETIME NOT NULL,
    created_at DATETIME NULL,
    INDEX idx_asset (asset_id, failure_date),
    INDEX idx_failure_code (failure_code_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. COST TREND TRACKING
CREATE TABLE IF NOT EXISTS maintenance_cost_trends (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    period_type ENUM('daily', 'weekly', 'monthly', 'quarterly', 'yearly') NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    asset_id INT UNSIGNED NULL,
    department_id INT UNSIGNED NULL,
    total_labor_cost DECIMAL(15,2) DEFAULT 0.00,
    total_parts_cost DECIMAL(15,2) DEFAULT 0.00,
    total_external_cost DECIMAL(15,2) DEFAULT 0.00,
    total_downtime_cost DECIMAL(15,2) DEFAULT 0.00,
    total_cost DECIMAL(15,2) DEFAULT 0.00,
    work_order_count INT DEFAULT 0,
    emergency_count INT DEFAULT 0,
    preventive_count INT DEFAULT 0,
    calculated_at DATETIME NOT NULL,
    UNIQUE KEY unique_period (period_type, period_start, asset_id, department_id),
    INDEX idx_period (period_start, period_end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. DOWNTIME CAUSE ANALYSIS
CREATE TABLE IF NOT EXISTS downtime_cause_analysis (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    asset_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NULL,
    downtime_start DATETIME NOT NULL,
    downtime_end DATETIME NULL,
    duration_hours DECIMAL(10,2) NULL,
    primary_cause ENUM('mechanical_failure', 'electrical_failure', 'operator_error', 'maintenance_delay', 'parts_unavailable', 'power_outage', 'other') NOT NULL,
    secondary_causes JSON NULL,
    production_loss_units DECIMAL(15,2) NULL,
    revenue_loss DECIMAL(15,2) NULL,
    preventable BOOLEAN DEFAULT FALSE,
    created_at DATETIME NULL,
    INDEX idx_asset (asset_id, downtime_start),
    INDEX idx_cause (primary_cause)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. LABOR RATE CONFIGURATION (Ghana-specific)
CREATE TABLE IF NOT EXISTS labor_rate_config (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    labor_type ENUM('normal', 'overtime', 'weekend', 'holiday', 'emergency') NOT NULL,
    base_multiplier DECIMAL(4,2) NOT NULL DEFAULT 1.00,
    description VARCHAR(255) NULL,
    effective_from DATE NOT NULL,
    effective_to DATE NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY unique_labor_type_date (labor_type, effective_from)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. INSERT DEFAULT LABOR RATES (Ghana Standard)
INSERT INTO labor_rate_config (labor_type, base_multiplier, description, effective_from) VALUES
('normal', 1.00, 'Regular working hours (Mon-Fri, 8am-5pm)', CURDATE()),
('overtime', 1.50, 'After hours and extended shifts', CURDATE()),
('weekend', 2.00, 'Saturday and Sunday work', CURDATE()),
('holiday', 2.50, 'Public holidays', CURDATE()),
('emergency', 2.00, 'Emergency callouts', CURDATE());

-- 14. SKILL REQUIREMENTS LOOKUP
CREATE TABLE IF NOT EXISTS skill_categories (
    id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NULL,
    active BOOLEAN DEFAULT TRUE,
    created_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO skill_categories (category_name, description) VALUES
('Mechanical', 'Mechanical maintenance and repair'),
('Electrical', 'Electrical systems and wiring'),
('Hydraulic', 'Hydraulic systems'),
('Pneumatic', 'Pneumatic systems'),
('Welding', 'Welding and fabrication'),
('Instrumentation', 'Instrumentation and controls'),
('HVAC', 'Heating, ventilation, air conditioning'),
('Plumbing', 'Plumbing and piping'),
('Electronics', 'Electronic systems and PCB repair'),
('PLC Programming', 'Programmable Logic Controllers');

-- 15. WORK ORDER CLOSURE LOCK (Prevent tampering)
ALTER TABLE maintenance_orders 
ADD COLUMN locked BOOLEAN DEFAULT FALSE,
ADD COLUMN locked_at DATETIME NULL,
ADD COLUMN locked_by INT UNSIGNED NULL;

-- VERIFICATION
SELECT 'Ghana-Specific Enhancements Complete!' AS Status;
SELECT COUNT(*) AS 'New Tables' FROM information_schema.tables 
WHERE table_schema = DATABASE() 
AND table_name IN (
    'technician_skills',
    'work_order_offline_queue',
    'work_order_interruptions',
    'work_order_labor_enhanced',
    'work_order_part_substitutions',
    'work_order_delays',
    'work_order_authority_overrides',
    'work_order_audit_log',
    'asset_failure_analysis',
    'maintenance_cost_trends',
    'downtime_cause_analysis',
    'labor_rate_config',
    'skill_categories'
);
