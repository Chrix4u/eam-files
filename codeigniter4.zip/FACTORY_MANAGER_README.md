# Factory Machine Maintenance Management System

A comprehensive, industry-ready factory machine maintenance management system built with CodeIgniter 4, TailwindCSS, and Flowbite components.

## 🚀 Features

### Core Functionality
- **Equipment Management**: Complete CRUD operations for factory machines and equipment
- **Maintenance Scheduling**: Preventive, corrective, emergency, and inspection maintenance
- **Work Order Management**: Create, assign, and track maintenance work orders
- **User Management**: Role-based access control (Admin, Manager, Technician, Operator)
- **Real-time Dashboard**: Comprehensive analytics and KPI monitoring
- **3D Model Support**: Upload and view 3D models of equipment
- **Parts Inventory**: Track spare parts and maintenance supplies
- **Assembly Management**: Manage equipment assemblies and components

### Advanced Features
- **Maintenance Analytics**: Performance metrics and reporting
- **Priority Management**: Critical, High, Medium, Low priority levels
- **Status Tracking**: Real-time equipment and maintenance status
- **Overdue Alerts**: Automatic identification of overdue maintenance
- **Cost Tracking**: Labor hours, parts cost, and total maintenance costs
- **Document Management**: Attach manuals, images, and maintenance records
- **Mobile Responsive**: Works seamlessly on all devices

## 🛠 Technology Stack

- **Backend**: CodeIgniter 4.6.3 (PHP 8.1+)
- **Frontend**: TailwindCSS 4.x + Flowbite Components
- **Database**: MySQL 8.0+
- **JavaScript**: Vanilla JS + Chart.js for analytics
- **Icons**: Font Awesome 6.0
- **Build Tools**: PostCSS + Autoprefixer

## 📋 System Requirements

- PHP 8.1 or higher
- MySQL 8.0 or higher
- Composer 2.x
- Node.js 16+ and NPM
- Web server (Apache/Nginx)

### Required PHP Extensions
- intl
- mbstring
- mysqlnd
- libcurl
- json (enabled by default)

## 🚀 Installation & Setup

### 1. Clone and Install Dependencies

```bash
# Clone the repository
git clone <repository-url> factorymanager
cd factorymanager

# Install PHP dependencies
composer install

# Install Node.js dependencies
npm install
```

### 2. Database Configuration

1. Create a MySQL database named `factory_manager`
2. Copy `env` to `.env` and configure database settings:

```env
CI_ENVIRONMENT = development

database.default.hostname = localhost
database.default.database = factory_manager
database.default.username = root
database.default.password = your_password
database.default.DBDriver = MySQLi
database.default.port = 3306
```

### 3. Run Database Migrations

```bash
# Run all migrations to create tables
php spark migrate

# Seed sample data (optional)
php spark db:seed FactoryDataSeeder
```

### 4. Build Frontend Assets

```bash
# Build TailwindCSS
npm run build

# Or watch for changes during development
npm run watch
```

### 5. Set Permissions

```bash
# Make writable directories writable
chmod -R 755 writable/
```

### 6. Start Development Server

```bash
# Start CodeIgniter development server
php spark serve

# Or configure your web server to point to the public/ directory
```

## 👤 Default Login Credentials

After running migrations, you can login with:

- **Email**: admin@gtp.com.gh
- **Password**: admin123
- **Role**: Administrator

## 🏗 System Architecture

### Database Schema

#### Core Tables
- `users` - System users with role-based access
- `equipment_categories` - Equipment categorization
- `equipment` - Main equipment/machine records
- `assemblies` - Equipment assemblies and sub-components
- `parts` - Spare parts and components
- `maintenance_logs` - All maintenance activities
- `work_orders` - Maintenance work orders and requests

#### Key Relationships
- Equipment → Categories (Many-to-One)
- Equipment → Assemblies (One-to-Many)
- Assemblies → Parts (One-to-Many)
- Equipment → Maintenance Logs (One-to-Many)
- Equipment → Work Orders (One-to-Many)
- Users → Maintenance Logs (One-to-Many)

### Application Structure

```
app/
├── Controllers/
│   ├── Auth.php              # Authentication
│   ├── Admin.php             # Admin dashboard
│   ├── Machine.php           # Equipment management
│   ├── Maintenance.php       # Maintenance operations
│   ├── Assembly.php          # Assembly management
│   └── Parts.php             # Parts management
├── Models/
│   ├── UserModel.php
│   ├── EquipmentModel.php
│   ├── MaintenanceLogModel.php
│   ├── WorkOrderModel.php
│   └── ...
├── Views/
│   ├── auth/                 # Login/Register pages
│   ├── admin/                # Admin dashboard
│   ├── maintenance/          # Maintenance views
│   ├── layouts/              # Layout templates
│   └── ...
└── Database/
    ├── Migrations/           # Database schema
    └── Seeds/                # Sample data
```

## 🔧 Configuration

### Environment Variables

Key configuration options in `.env`:

```env
# Application
app.baseURL = 'http://localhost:8080'
app.forceGlobalSecureRequests = false

# Database
database.default.hostname = localhost
database.default.database = factory_manager
database.default.username = root
database.default.password = your_password

# Session
session.driver = 'CodeIgniter\Session\Handlers\FileHandler'
session.savePath = null

# Security
encryption.key = your-32-character-secret-key
```

### Web Server Configuration

#### Apache (.htaccess included)
The system includes proper `.htaccess` files for Apache.

#### Nginx
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /path/to/factorymanager/public;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

## 📊 Key Features Explained

### 1. Equipment Management
- Complete equipment lifecycle tracking
- 3D model support for visual reference
- Specifications and documentation storage
- Status monitoring (Operational, Maintenance, Repair, Offline)
- Criticality levels for priority management

### 2. Maintenance Scheduling
- **Preventive**: Scheduled regular maintenance
- **Corrective**: Repair-based maintenance
- **Emergency**: Urgent maintenance requirements
- **Inspection**: Regular equipment inspections

### 3. Work Order System
- Automated work order numbering
- Assignment to technicians
- Progress tracking and completion
- Cost tracking (labor + parts)
- Due date management

### 4. Dashboard Analytics
- Equipment status overview
- Maintenance completion metrics
- Overdue maintenance alerts
- Cost analysis and trends
- Performance KPIs

### 5. User Roles & Permissions
- **Admin**: Full system access
- **Manager**: Equipment and maintenance oversight
- **Technician**: Maintenance execution
- **Operator**: Basic equipment monitoring

## 🔒 Security Features

- Password hashing with PHP's password_hash()
- CSRF protection on all forms
- SQL injection prevention with query builder
- XSS protection with output escaping
- Session-based authentication
- Role-based access control
- Input validation and sanitization

## 🚀 Production Deployment

### 1. Server Requirements
- PHP 8.1+ with required extensions
- MySQL 8.0+ or MariaDB 10.6+
- SSL certificate for HTTPS
- Sufficient disk space for file uploads

### 2. Security Hardening
```env
CI_ENVIRONMENT = production
app.forceGlobalSecureRequests = true
```

### 3. Performance Optimization
- Enable OPcache
- Configure proper caching headers
- Optimize database queries
- Use CDN for static assets
- Enable gzip compression

### 4. Backup Strategy
- Regular database backups
- File system backups (uploads, logs)
- Automated backup verification
- Disaster recovery procedures

## 📈 Monitoring & Maintenance

### System Health Checks
- Database connectivity
- File system permissions
- Log file monitoring
- Performance metrics
- Security audit logs

### Regular Maintenance
- Database optimization
- Log file rotation
- Security updates
- Performance monitoring
- Backup verification

## 🤝 Support & Documentation

### Getting Help
- Check the CodeIgniter 4 documentation
- Review system logs in `writable/logs/`
- Enable debug mode for development
- Use browser developer tools for frontend issues

### Common Issues
1. **Database Connection**: Check credentials and server status
2. **File Permissions**: Ensure writable/ directory is writable
3. **Missing Dependencies**: Run `composer install` and `npm install`
4. **CSS Not Loading**: Run `npm run build` to compile TailwindCSS

## 📝 License

This project is proprietary software developed for industrial factory maintenance management.

## 🔄 Version History

- **v1.0.0** - Initial release with core functionality
- Complete equipment management system
- Maintenance scheduling and tracking
- Work order management
- User authentication and authorization
- Responsive dashboard with analytics

---

**Built with ❤️ for Industrial Excellence**