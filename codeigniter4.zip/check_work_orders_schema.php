<?php

// Check work_orders table schema
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔍 Checking work_orders Table Schema\n";
    echo "====================================\n\n";
    
    // Check table structure
    $stmt = $pdo->query("DESCRIBE work_orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Table Structure:\n";
    foreach ($columns as $column) {
        echo "  {$column['Field']} - {$column['Type']} - {$column['Null']} - {$column['Default']}\n";
    }
    
    // Check current data count
    $stmt = $pdo->query("SELECT COUNT(*) FROM work_orders");
    $count = $stmt->fetchColumn();
    echo "\nCurrent record count: $count\n";
    
    if ($count > 0) {
        echo "\nSample records:\n";
        $stmt = $pdo->query("SELECT id, work_order_number, title, status, created_at FROM work_orders LIMIT 3");
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($records as $record) {
            echo "  ID: {$record['id']}, Number: {$record['work_order_number']}, Title: {$record['title']}, Status: {$record['status']}\n";
        }
    }
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}