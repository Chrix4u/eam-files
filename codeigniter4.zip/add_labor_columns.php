<?php
// Simple script to add columns to labor_logs table
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$queries = [
    "ALTER TABLE `labor_logs` ADD COLUMN `clock_in` DATETIME NULL AFTER `technician_id`",
    "ALTER TABLE `labor_logs` ADD COLUMN `clock_out` DATETIME NULL AFTER `clock_in`",
    "ALTER TABLE `labor_logs` ADD COLUMN `break_minutes` INT(11) DEFAULT 0 AFTER `clock_out`",
    "ALTER TABLE `labor_logs` ADD COLUMN `actual_hours` DECIMAL(10,2) NULL AFTER `break_minutes`",
    "ALTER TABLE `labor_logs` ADD COLUMN `work_type` VARCHAR(50) NULL AFTER `actual_hours`",
    "ALTER TABLE `labor_logs` ADD COLUMN `activity_description` TEXT NULL AFTER `work_type`"
];

foreach ($queries as $query) {
    if ($conn->query($query) === TRUE) {
        echo "✓ Executed: " . substr($query, 0, 60) . "...\n";
    } else {
        if (strpos($conn->error, 'Duplicate column') !== false) {
            echo "- Column already exists, skipping...\n";
        } else {
            echo "✗ Error: " . $conn->error . "\n";
        }
    }
}

$conn->close();
echo "\n✓ Labor logs table updated successfully!\n";
