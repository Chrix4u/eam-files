# AWS Quick Start - 15 Minutes

## Prerequisites
- AWS Account
- AWS CLI configured
- GitHub repository

## Step 1: One-Command Infrastructure Setup (5 min)

```bash
# Run this script to create all AWS resources
./scripts/aws-setup.sh
```

Or manually:

```bash
# 1. Create ECR Repository
aws ecr create-repository --repository-name factorymanager-api

# 2. Create ECS Cluster
aws ecs create-cluster --cluster-name factorymanager-cluster

# 3. Create RDS Database
aws rds create-db-instance \
  --db-instance-identifier factorymanager-db \
  --db-instance-class db.t3.micro \
  --engine mysql \
  --master-username admin \
  --master-user-password ChangeMe123! \
  --allocated-storage 20 \
  --backup-retention-period 7

# 4. Store secrets
aws secretsmanager create-secret --name factorymanager/db-password --secret-string "ChangeMe123!"
aws secretsmanager create-secret --name factorymanager/jwt-secret --secret-string "your-jwt-secret-key"
```

## Step 2: Setup GitHub Secrets (2 min)

1. Go to: `https://github.com/YOUR_USERNAME/factorymanager/settings/secrets/actions`
2. Add:
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`

## Step 3: Deploy (5 min)

```bash
git add .
git commit -m "Initial AWS deployment"
git push origin main
```

GitHub Actions will automatically:
1. Build Docker image
2. Push to ECR
3. Deploy to ECS
4. Run migrations

## Step 4: Verify (3 min)

```bash
# Get ALB DNS
aws elbv2 describe-load-balancers --names factorymanager-alb --query 'LoadBalancers[0].DNSName'

# Test API
curl http://YOUR-ALB-DNS/api/v1/health
```

## Done! 🎉

Your API is now running on AWS with:
- ✅ Auto-scaling
- ✅ Load balancing
- ✅ Automated backups
- ✅ CI/CD pipeline

## Costs
~$80/month for production-ready setup

## Next Steps
- Add custom domain (Route 53)
- Enable HTTPS (ACM certificate)
- Setup monitoring (CloudWatch)
- Configure auto-scaling rules
