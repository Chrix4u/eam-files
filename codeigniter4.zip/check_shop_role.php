<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();
$users = $db->query("SELECT id, username, role FROM users WHERE role LIKE '%shop%' OR role LIKE '%attendant%'")->getResultArray();

echo "Shop Attendant Users:\n";
foreach ($users as $user) {
    echo "ID: {$user['id']}, Username: {$user['username']}, Role: {$user['role']}\n";
}
