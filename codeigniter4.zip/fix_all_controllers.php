<?php
// Fix all controllers with proper structure

$controllersToFix = [
    'EamFacilitiesController.php' => [
        'model' => 'FacilitiesModel',
        'validation' => [
            'facility_code' => 'required|max_length[50]|is_unique[facilities.facility_code]',
            'facility_name' => 'required|max_length[255]',
            'status' => 'required|in_list[active,inactive]'
        ]
    ],
    'DepartmentsController.php' => [
        'model' => 'DepartmentsModel',
        'validation' => [
            'department_code' => 'required|max_length[50]|is_unique[departments.department_code]',
            'department_name' => 'required|max_length[255]',
            'status' => 'required|in_list[active,inactive]'
        ]
    ],
    'AssignmentsController.php' => [
        'model' => 'WorkOrderAssignmentsModel',
        'validation' => [
            'work_order_id' => 'required|integer',
            'assigned_to_user_id' => 'required|integer',
            'assigned_date' => 'required|valid_date',
            'assignment_status' => 'required|in_list[assigned,in_progress,completed]'
        ]
    ],
    'DocumentsController.php' => [
        'model' => 'DocumentsModel',
        'validation' => [
            'title' => 'required|max_length[255]',
            'category' => 'required',
            'file_name' => 'required|max_length[255]',
            'status' => 'required|in_list[draft,pending_approval,approved,archived]'
        ]
    ],
    'SchedulerController.php' => [
        'model' => 'ProductionSchedulesModel',
        'validation' => [
            'schedule_code' => 'required|max_length[50]|is_unique[production_schedules.schedule_code]',
            'schedule_name' => 'required|max_length[255]',
            'planned_start_date' => 'required|valid_date',
            'planned_end_date' => 'required|valid_date',
            'status' => 'required|in_list[planned,in_progress,completed,cancelled]'
        ]
    ],
    'ShiftsController.php' => [
        'model' => 'ShiftsModel',
        'validation' => [
            'name' => 'required|max_length[50]',
            'start_time' => 'required',
            'end_time' => 'required',
            'is_active' => 'in_list[yes,no]'
        ]
    ],
    'ShiftHandoverController.php' => [
        'model' => 'ShiftHandoversModel',
        'validation' => [
            'survey_id' => 'required|integer',
            'status' => 'in_list[draft,submitted,acknowledged,completed]'
        ]
    ],
    'QualityController.php' => [
        'model' => 'QualityInspectionsModel',
        'validation' => [
            'inspection_number' => 'required|max_length[50]|is_unique[quality_inspections.inspection_number]',
            'inspection_type' => 'required|in_list[incoming,in_process,final,audit]',
            'inspection_date' => 'required|valid_date',
            'result' => 'required|in_list[pass,fail,pending]'
        ]
    ],
    'EnergyController.php' => [
        'model' => 'EnergyConsumptionModel',
        'validation' => [
            'asset_id' => 'required|integer',
            'consumption_kwh' => 'required|decimal',
            'timestamp' => 'required|valid_date'
        ]
    ],
    'EmployeeShiftsController.php' => [
        'model' => 'EmployeeRosterModel',
        'validation' => [
            'employee_id' => 'required|integer',
            'roster_date' => 'required|valid_date',
            'status' => 'required|in_list[scheduled,completed,absent]'
        ]
    ],
    'InventoryForecastController.php' => [
        'model' => 'InventoryForecastsModel',
        'validation' => [
            'item_code' => 'required|max_length[100]',
            'forecast_date' => 'required|valid_date'
        ]
    ]
];

$controllerPath = 'C:/wamp64/www/factorymanager/app/Controllers/Api/V1/';
$fixed = 0;
$errors = 0;

foreach ($controllersToFix as $controllerFile => $config) {
    $filePath = $controllerPath . $controllerFile;
    
    if (!file_exists($filePath)) {
        echo "❌ Not found: $controllerFile\n";
        $errors++;
        continue;
    }
    
    $content = file_get_contents($filePath);
    
    // Check if it already has proper structure
    if (strpos($content, 'protected $model') !== false && strpos($content, 'protected $validationRules') !== false) {
        echo "✅ Already fixed: $controllerFile\n";
        $fixed++;
        continue;
    }
    
    // Add model property if missing
    if (strpos($content, 'protected $model') === false) {
        // Find the class declaration
        if (preg_match('/class\s+\w+\s+extends\s+BaseController\s*{/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            $insertPos = $matches[0][1] + strlen($matches[0][0]);
            $modelProperty = "\n    protected \$model;\n";
            $content = substr_replace($content, $modelProperty, $insertPos, 0);
        }
    }
    
    // Add validation rules if missing
    if (strpos($content, 'protected $validationRules') === false) {
        $validationRulesStr = "    protected \$validationRules = [\n";
        foreach ($config['validation'] as $field => $rule) {
            $validationRulesStr .= "        '$field' => '$rule',\n";
        }
        $validationRulesStr .= "    ];\n\n";
        
        // Insert after model property
        if (preg_match('/protected\s+\$model;/', $content, $matches, PREG_OFFSET_CAPTURE)) {
            $insertPos = $matches[0][1] + strlen($matches[0][0]);
            $content = substr_replace($content, "\n" . $validationRulesStr, $insertPos, 0);
        }
    }
    
    // Add model initialization in constructor if missing
    if (strpos($content, "this->model = new") === false) {
        $constructorCode = "\n    public function __construct()\n    {\n        parent::__construct();\n        \$this->model = new \\App\\Models\\{$config['model']}();\n    }\n";
        
        // Insert after validation rules
        if (preg_match('/protected\s+\$validationRules\s*=\s*\[.*?\];/s', $content, $matches, PREG_OFFSET_CAPTURE)) {
            $insertPos = $matches[0][1] + strlen($matches[0][0]);
            $content = substr_replace($content, $constructorCode, $insertPos, 0);
        }
    }
    
    // Save the fixed controller
    if (file_put_contents($filePath, $content)) {
        echo "✅ Fixed: $controllerFile\n";
        $fixed++;
    } else {
        echo "❌ Failed to write: $controllerFile\n";
        $errors++;
    }
}

echo "\n========================================\n";
echo "CONTROLLERS FIXED: $fixed/" . count($controllersToFix) . "\n";
echo "ERRORS: $errors\n";
echo "========================================\n";
?>
