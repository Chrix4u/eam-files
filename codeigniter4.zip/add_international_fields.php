<?php
// Add international fields to facilities and company_settings tables

$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "🔄 Adding international fields...\n\n";
    
    // Update facilities table
    echo "📍 Updating facilities table...\n";
    $queries = [
        "ALTER TABLE facilities ADD COLUMN timezone VARCHAR(50) DEFAULT 'UTC' AFTER country_code",
        "ALTER TABLE facilities ADD COLUMN latitude DECIMAL(10,8) NULL AFTER timezone",
        "ALTER TABLE facilities ADD COLUMN longitude DECIMAL(11,8) NULL AFTER latitude",
        "ALTER TABLE facilities MODIFY COLUMN location VARCHAR(255) NULL"
    ];
    foreach ($queries as $query) {
        try { $pdo->exec($query); } catch (PDOException $e) { if (strpos($e->getMessage(), 'Duplicate column') === false) throw $e; }
    }
    echo "✅ Facilities table updated\n\n";
    
    // Update company_settings table
    echo "🏢 Updating company_settings table...\n";
    $queries = [
        "ALTER TABLE company_settings ADD COLUMN country_code CHAR(2) NULL AFTER website",
        "ALTER TABLE company_settings ADD COLUMN language_code CHAR(2) DEFAULT 'en' AFTER country_code",
        "ALTER TABLE company_settings ADD COLUMN currency_code CHAR(3) DEFAULT 'USD' AFTER language_code",
        "ALTER TABLE company_settings ADD COLUMN timezone VARCHAR(50) DEFAULT 'UTC' AFTER currency_code",
        "ALTER TABLE company_settings ADD COLUMN tax_id VARCHAR(50) NULL AFTER timezone"
    ];
    foreach ($queries as $query) {
        try { $pdo->exec($query); } catch (PDOException $e) { if (strpos($e->getMessage(), 'Duplicate column') === false) throw $e; }
    }
    echo "✅ Company settings table updated\n\n";
    
    echo "✅ All international fields added successfully!\n";
    
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
