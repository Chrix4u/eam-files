-- Check existing users
SELECT id, username, email, role, status FROM users LIMIT 5;

-- Update or create admin
UPDATE users 
SET password = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
    email = 'admin@factory.com',
    username = 'admin',
    role = 'admin',
    status = 'active'
WHERE id = (SELECT id FROM (SELECT id FROM users ORDER BY id LIMIT 1) AS temp);

-- Verify
SELECT id, username, email, role, status FROM users WHERE username = 'admin';
