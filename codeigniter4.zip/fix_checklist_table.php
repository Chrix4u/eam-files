<?php

// Fix work_order_checklist_items table structure
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔧 Fixing work_order_checklist_items table\n";
    echo "==========================================\n\n";
    
    // Check current structure
    $stmt = $pdo->query("DESCRIBE work_order_checklist_items");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Current columns:\n";
    foreach ($columns as $column) {
        echo "  {$column['Field']} - {$column['Type']}\n";
    }
    
    // Check if item_id column exists
    $hasItemId = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'item_id') {
            $hasItemId = true;
            break;
        }
    }
    
    if (!$hasItemId) {
        echo "\n❌ item_id column missing, adding it...\n";
        $pdo->exec("ALTER TABLE work_order_checklist_items ADD COLUMN item_id INT NOT NULL AFTER work_order_id");
        echo "✅ item_id column added\n";
    } else {
        echo "\n✅ item_id column exists\n";
    }
    
    // Check if value column exists
    $hasValue = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'value') {
            $hasValue = true;
            break;
        }
    }
    
    if (!$hasValue) {
        echo "❌ value column missing, adding it...\n";
        $pdo->exec("ALTER TABLE work_order_checklist_items ADD COLUMN value TEXT AFTER item_id");
        echo "✅ value column added\n";
    } else {
        echo "✅ value column exists\n";
    }
    
    echo "\n✅ Table structure fixed\n";
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}