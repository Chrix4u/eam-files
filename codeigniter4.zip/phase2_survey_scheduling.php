<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_schedules (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,
    schedule_name VARCHAR(255) NOT NULL,
    template_id INT,
    machine_id INT,
    shift_id INT,
    frequency ENUM('daily', 'weekly', 'monthly', 'per_shift', 'custom') NOT NULL,
    frequency_value INT DEFAULT 1,
    start_date DATE NOT NULL,
    end_date DATE NULL,
    auto_create BOOLEAN DEFAULT TRUE,
    auto_assign_user_id INT,
    reminder_hours INT DEFAULT 2,
    is_active BOOLEAN DEFAULT TRUE,
    last_generated_at TIMESTAMP NULL,
    next_generation_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_schedule_active (is_active),
    INDEX idx_next_gen (next_generation_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$sql = "CREATE TABLE IF NOT EXISTS survey_reminders (
    reminder_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT NOT NULL,
    user_id INT NOT NULL,
    reminder_type ENUM('overdue', 'due_soon', 'scheduled') NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    INDEX idx_survey_reminder (survey_id),
    INDEX idx_user_reminder (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$db->query("ALTER TABLE production_surveys ADD COLUMN schedule_id INT NULL, ADD COLUMN is_scheduled BOOLEAN DEFAULT FALSE, ADD INDEX idx_schedule (schedule_id)");

echo "✅ Survey Scheduling tables created\n";
$db->close();
