<?php
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$database`");
    $pdo->exec("USE `$database`");
    
    // Machines table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `machines` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `asset_name` VARCHAR(255) NOT NULL,
        `asset_code` VARCHAR(50) UNIQUE,
        `asset_type` VARCHAR(100) DEFAULT 'equipment',
        `machine_name` VARCHAR(255) NOT NULL,
        `machine_code` VARCHAR(50),
        `machine_category` VARCHAR(100),
        `model` VARCHAR(100),
        `manufacturer` VARCHAR(100),
        `serial_number` VARCHAR(100),
        `plant_location` VARCHAR(255),
        `department` VARCHAR(100),
        `description` TEXT,
        `operation_type` VARCHAR(50) DEFAULT 'continuous',
        `purchase_date` DATE,
        `installation_date` DATE,
        `warranty_expiry` DATE,
        `machine_photo` VARCHAR(500),
        `status` ENUM('active','inactive','out_of_service') DEFAULT 'active',
        `rated_power` VARCHAR(50),
        `voltage` VARCHAR(50),
        `capacity` VARCHAR(100),
        `cycle_time` VARCHAR(50),
        `speed_throughput` VARCHAR(100),
        `criticality` ENUM('low','medium','high','critical') DEFAULT 'medium',
        `maintenance_strategy` VARCHAR(50) DEFAULT 'time-based',
        `warranty_alerts` ENUM('yes','no') DEFAULT 'no',
        `default_technician_group` VARCHAR(100),
        `pm_frequency` INT,
        `usage_unit` VARCHAR(50) DEFAULT 'hours',
        `location` VARCHAR(255),
        `created_by` INT UNSIGNED,
        `updated_by` INT UNSIGNED,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_asset_code` (`asset_code`),
        INDEX `idx_status` (`status`)
    ) ENGINE=InnoDB");
    
    // Update assemblies table to ensure all required fields exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS `assemblies` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `machine_id` INT UNSIGNED NOT NULL,
        `assembly_name` VARCHAR(255) NOT NULL,
        `assembly_code` VARCHAR(50),
        `assembly_category` VARCHAR(100),
        `description` TEXT,
        `criticality` ENUM('low','medium','high','critical') DEFAULT 'medium',
        `status` ENUM('active','inactive') DEFAULT 'active',
        `assembly_image` VARCHAR(500),
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_machine` (`machine_id`)
    ) ENGINE=InnoDB");
    
    // Update parts table to ensure all required fields exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS `parts` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `machine_id` INT UNSIGNED,
        `assembly_id` INT UNSIGNED,
        `parent_part_id` INT UNSIGNED,
        `part_name` VARCHAR(255) NOT NULL,
        `part_number` VARCHAR(100),
        `part_code` VARCHAR(50),
        `part_category` VARCHAR(100),
        `manufacturer` VARCHAR(100),
        `material` VARCHAR(100),
        `dimensions` VARCHAR(100),
        `expected_lifespan` VARCHAR(100),
        `spare_availability` ENUM('yes','no') DEFAULT 'no',
        `current_stock_qty` INT DEFAULT 0,
        `safety_notes` TEXT,
        `failure_modes` TEXT,
        `status` ENUM('active','inactive','obsolete') DEFAULT 'active',
        `part_image` VARCHAR(500),
        `unit_cost` DECIMAL(10,2),
        `description` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_machine` (`machine_id`),
        INDEX `idx_assembly` (`assembly_id`),
        INDEX `idx_parent` (`parent_part_id`)
    ) ENGINE=InnoDB");
    
    // BOM entries table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `bom_entries` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `machine_id` INT UNSIGNED NOT NULL,
        `assembly_id` INT UNSIGNED,
        `part_id` INT UNSIGNED,
        `qty` DECIMAL(10,2) NOT NULL,
        `unit` VARCHAR(20),
        `reference_location` VARCHAR(255),
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_machine` (`machine_id`)
    ) ENGINE=InnoDB");
    
    // Part media table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `part_media` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `part_id` INT UNSIGNED NOT NULL,
        `media_type` ENUM('image','diagram','3d_model','document') NOT NULL,
        `file_path` VARCHAR(500) NOT NULL,
        `thumbnail_path` VARCHAR(500),
        `hotspot_data` JSON,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_part` (`part_id`)
    ) ENGINE=InnoDB");
    
    // Meters table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `meters` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `asset_node_type` VARCHAR(50) NOT NULL,
        `asset_node_id` INT UNSIGNED NOT NULL,
        `meter_type` VARCHAR(50) NOT NULL,
        `unit` VARCHAR(20),
        `value` DECIMAL(15,2) DEFAULT 0,
        `last_read_at` TIMESTAMP,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_asset_node` (`asset_node_type`, `asset_node_id`)
    ) ENGINE=InnoDB");
    
    // Asset history table
    $pdo->exec("CREATE TABLE IF NOT EXISTS `asset_history` (
        `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `asset_type` VARCHAR(50) NOT NULL,
        `asset_id` INT UNSIGNED NOT NULL,
        `action` VARCHAR(50) NOT NULL,
        `user_id` INT UNSIGNED,
        `changes` JSON,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_asset` (`asset_type`, `asset_id`)
    ) ENGINE=InnoDB");
    
    echo "✅ All Asset Management tables created successfully!\n";
    echo "\nTables created:\n";
    echo "- machines\n";
    echo "- bom_entries\n";
    echo "- part_media\n";
    echo "- meters\n";
    echo "- asset_history\n";
    echo "\nNote: assemblies and parts tables already exist in the database\n";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
