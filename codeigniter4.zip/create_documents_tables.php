<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category ENUM('Manual', 'SOP', 'Drawing', 'Certificate', 'Report', 'Policy') NOT NULL,
    version VARCHAR(20) DEFAULT '1.0',
    status ENUM('draft', 'pending_approval', 'approved', 'archived') DEFAULT 'draft',
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    asset_id INT NULL,
    uploaded_by INT NOT NULL,
    approved_by INT NULL,
    approved_at DATETIME NULL,
    tags JSON NULL,
    metadata JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_asset (asset_id),
    FULLTEXT idx_search (title)
)";

if ($db->query($sql)) {
    echo "✓ Table 'documents' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql2 = "CREATE TABLE IF NOT EXISTS document_versions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT NOT NULL,
    version VARCHAR(20) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    uploaded_by INT NOT NULL,
    change_notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
)";

if ($db->query($sql2)) {
    echo "✓ Table 'document_versions' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql3 = "CREATE TABLE IF NOT EXISTS document_approvals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT NOT NULL,
    approver_id INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    comments TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
)";

if ($db->query($sql3)) {
    echo "✓ Table 'document_approvals' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$samples = [
    ['CNC Machine Manual', 'Manual', '1.0', 'approved', 'cnc_manual.pdf', '/uploads/cnc_manual.pdf', 2048000, 'application/pdf', 1, 1],
    ['Safety SOP', 'SOP', '2.1', 'approved', 'safety_sop.pdf', '/uploads/safety_sop.pdf', 1024000, 'application/pdf', null, 1],
    ['Equipment Drawing', 'Drawing', '1.0', 'draft', 'equipment.dwg', '/uploads/equipment.dwg', 512000, 'application/dwg', 2, 1]
];

foreach ($samples as $s) {
    $stmt = $db->prepare("INSERT INTO documents (title, category, version, status, file_name, file_path, file_size, file_type, asset_id, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssisii", $s[0], $s[1], $s[2], $s[3], $s[4], $s[5], $s[6], $s[7], $s[8], $s[9]);
    $stmt->execute();
}

echo "✓ Inserted 3 sample documents\n";

$db->close();
?>
