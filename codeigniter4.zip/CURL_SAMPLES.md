# 🚀 API TESTING - cURL SAMPLES

## MODULE 2: Work Execution

### Start Execution
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/work-executions/start \
  -H "Content-Type: application/json" \
  -d '{"work_order_id": 1, "technician_id": 5}'
```

### Pause Execution
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/work-executions/1/pause \
  -H "Content-Type: application/json" \
  -d '{"reason": "Waiting for parts"}'
```

### Complete Execution
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/work-executions/1/complete \
  -H "Content-Type: application/json" \
  -d '{
    "findings": "Replaced bearing",
    "parts_used": [{"part_id": 10, "quantity": 2}],
    "quality_check_passed": true
  }'
```

## MODULE 3: Operator Checklist

### Create Template
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/checklists/templates \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Daily Machine Check",
    "machine_type": "CNC",
    "items": [
      {"key": "oil_level", "label": "Check Oil Level", "type": "boolean", "weight": 1},
      {"key": "temperature", "label": "Temperature Reading", "type": "number", "weight": 2}
    ],
    "pass_threshold": 80,
    "created_by": 1
  }'
```

### Create Checklist Entry
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/checklists \
  -H "Content-Type: application/json" \
  -d '{
    "template_id": 1,
    "machine_id": 5,
    "operator_id": 3,
    "date": "2025-01-21",
    "shift": "Day",
    "items": [
      {"key": "oil_level", "value": true, "weight": 1},
      {"key": "temperature", "value": 75, "weight": 2}
    ]
  }'
```

## MODULE 4: Shift Handover

### Create Handover
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/shift/handovers \
  -H "Content-Type: application/json" \
  -d '{
    "machine_id": 5,
    "from_operator_id": 3,
    "from_shift": "Day",
    "to_shift": "Night",
    "date": "2025-01-21",
    "summary": "Machine running smoothly. Produced 500 units.",
    "produced_qty": 500,
    "target_qty": 480,
    "open_issues": [{"issue": "Minor vibration", "priority": "low"}],
    "material_remaining": [{"material": "Steel", "quantity": 100}]
  }'
```

### Accept Handover
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/shift/handovers/1/accept \
  -H "Content-Type: application/json" \
  -d '{"user_id": 4}'
```

### Reject Handover
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/shift/handovers/1/reject \
  -H "Content-Type: application/json" \
  -d '{"reason": "Incomplete information"}'
```

## MODULE 5: Risk Assessment

### Create Assessment
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/risk/assessments \
  -H "Content-Type: application/json" \
  -d '{
    "machine_id": 5,
    "assessed_by": 2,
    "assessment_date": "2025-01-21",
    "task_description": "Replace hydraulic pump",
    "task_type": "Corrective",
    "hazard_list": [
      {"hazard": "High pressure fluid", "severity": 4, "likelihood": 3},
      {"hazard": "Heavy lifting", "severity": 3, "likelihood": 2}
    ],
    "ppe_required": ["Safety glasses", "Gloves", "Steel-toe boots"],
    "permits_required": ["LOTO", "Hot Work"]
  }'
```

### Add Control Measure
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/risk/assessments/1/measures \
  -H "Content-Type: application/json" \
  -d '{
    "measure_text": "Install pressure relief valve",
    "measure_type": "Engineering",
    "owner": 5,
    "due_date": "2025-02-01",
    "priority": "High"
  }'
```

### Approve Assessment
```bash
curl -X POST http://localhost/factorymanager/public/api/v1/risk/assessments/1/approve \
  -H "Content-Type: application/json" \
  -d '{"user_id": 1}'
```

## Testing All Endpoints

### Get All Records
```bash
# Work Executions
curl http://localhost/factorymanager/public/api/v1/work-executions

# Checklists
curl http://localhost/factorymanager/public/api/v1/checklists

# Shift Handovers
curl http://localhost/factorymanager/public/api/v1/shift/handovers

# Risk Assessments
curl http://localhost/factorymanager/public/api/v1/risk/assessments
```

### Get Single Record
```bash
curl http://localhost/factorymanager/public/api/v1/work-executions/1
curl http://localhost/factorymanager/public/api/v1/checklists/1
curl http://localhost/factorymanager/public/api/v1/shift/handovers/1
curl http://localhost/factorymanager/public/api/v1/risk/assessments/1
```
