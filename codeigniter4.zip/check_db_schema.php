<?php

// Check the PM schedules table schema and data
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔍 Checking PM Schedules Table Schema\n";
    echo "=====================================\n\n";
    
    // Check table structure
    $stmt = $pdo->query("DESCRIBE pm_schedules");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Table Structure:\n";
    foreach ($columns as $column) {
        echo "  {$column['Field']} - {$column['Type']} - {$column['Null']} - {$column['Default']}\n";
    }
    
    // Check current data
    echo "\nCurrent Data:\n";
    $stmt = $pdo->query("SELECT id, pm_rule_id, status, due_date, created_at FROM pm_schedules LIMIT 5");
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($schedules as $schedule) {
        echo "  ID: {$schedule['id']}, Rule ID: {$schedule['pm_rule_id']}, Status: {$schedule['status']}, Due: {$schedule['due_date']}\n";
    }
    
    // Check what statuses are available
    echo "\nAvailable Statuses:\n";
    $stmt = $pdo->query("SELECT DISTINCT status FROM pm_schedules");
    $statuses = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($statuses as $status) {
        echo "  - $status\n";
    }
    
    // Update one schedule to 'waiting' for testing
    echo "\n🔧 Updating schedule ID 1 to 'waiting' status for testing...\n";
    $stmt = $pdo->prepare("UPDATE pm_schedules SET status = 'waiting' WHERE id = 1");
    $result = $stmt->execute();
    
    if ($result) {
        echo "✅ Schedule ID 1 updated to 'waiting' status\n";
    } else {
        echo "❌ Failed to update schedule\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}