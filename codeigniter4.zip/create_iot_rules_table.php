<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS iot_alert_rules (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    metric_type VARCHAR(50) NOT NULL,
    warning_threshold DECIMAL(10,2) NOT NULL,
    critical_threshold DECIMAL(10,2) NOT NULL,
    action ENUM('alert','alert_and_email','alert_and_wo','shutdown') DEFAULT 'alert',
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME,
    updated_at DATETIME NULL,
    KEY asset_id (asset_id),
    KEY metric_type (metric_type),
    KEY is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql) === TRUE) {
    echo "iot_alert_rules table created successfully\n";
    
    // Insert sample rules
    $conn->query("INSERT INTO iot_alert_rules (asset_id, metric_type, warning_threshold, critical_threshold, action, is_active, created_at) 
                  VALUES (1, 'vibration', 5.0, 8.0, 'alert_and_wo', 1, NOW())");
    $conn->query("INSERT INTO iot_alert_rules (asset_id, metric_type, warning_threshold, critical_threshold, action, is_active, created_at) 
                  VALUES (1, 'temperature', 75, 90, 'alert_and_email', 1, NOW())");
    $conn->query("INSERT INTO iot_alert_rules (asset_id, metric_type, warning_threshold, critical_threshold, action, is_active, created_at) 
                  VALUES (2, 'pressure', 120, 150, 'alert', 1, NOW())");
    
    echo "Sample rules inserted\n";
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
