-- Maintenance Request Workflow Schema Update
-- Run this SQL script manually in phpMyAdmin or MySQL client

-- Add workflow columns to maintenance_requests table
ALTER TABLE maintenance_requests 
ADD COLUMN workflow_status ENUM('pending','supervisor_review','approved','rejected','assigned_to_planner','work_order_created','completed') DEFAULT 'pending' AFTER status,
ADD COLUMN supervisor_id INT UNSIGNED NULL AFTER workflow_status,
ADD COLUMN reviewed_by INT UNSIGNED NULL AFTER supervisor_id,
ADD COLUMN reviewed_at DATETIME NULL AFTER reviewed_by,
ADD COLUMN review_notes TEXT NULL AFTER reviewed_at,
ADD COLUMN assigned_planner_id INT UNSIGNED NULL AFTER review_notes,
ADD COLUMN planner_type ENUM('engineering','production') NULL AFTER assigned_planner_id,
ADD COLUMN work_order_id INT UNSIGNED NULL AFTER planner_type,
ADD COLUMN rejection_reason TEXT NULL AFTER work_order_id,
ADD COLUMN department_id INT UNSIGNED NULL AFTER rejection_reason;

-- Add indexes
ALTER TABLE maintenance_requests 
ADD INDEX idx_workflow_status (workflow_status),
ADD INDEX idx_supervisor (supervisor_id),
ADD INDEX idx_planner (assigned_planner_id),
ADD INDEX idx_department (department_id);

-- Create workflow history table
CREATE TABLE IF NOT EXISTS maintenance_request_workflow (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(50),
    to_status VARCHAR(50) NOT NULL,
    action_by INT UNSIGNED NOT NULL,
    action_type ENUM('created','reviewed','approved','rejected','assigned','converted','completed','commented') NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_action_by (action_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create notifications table if not exists
CREATE TABLE IF NOT EXISTS maintenance_notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    request_id INT UNSIGNED NULL,
    work_order_id INT UNSIGNED NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
