<?php
// Run OEE migration
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// OEE Metrics
$sql = "CREATE TABLE IF NOT EXISTS oee_metrics (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    shift_date DATE NOT NULL,
    shift_name VARCHAR(50) NOT NULL,
    planned_production_time INT COMMENT 'minutes',
    downtime_minutes INT DEFAULT 0,
    runtime_minutes INT DEFAULT 0,
    ideal_cycle_time DECIMAL(10,2) COMMENT 'seconds per unit',
    total_pieces INT DEFAULT 0,
    good_pieces INT DEFAULT 0,
    rejected_pieces INT DEFAULT 0,
    availability DECIMAL(5,2) COMMENT 'percentage',
    performance DECIMAL(5,2) COMMENT 'percentage',
    quality DECIMAL(5,2) COMMENT 'percentage',
    oee DECIMAL(5,2) COMMENT 'percentage',
    created_at DATETIME,
    updated_at DATETIME,
    INDEX idx_asset_date (asset_id, shift_date)
)";
$db->query($sql);

// Downtime Events
$sql = "CREATE TABLE IF NOT EXISTS oee_downtime_events (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    reason_code_id INT UNSIGNED NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME,
    duration_minutes INT DEFAULT 0,
    is_planned TINYINT(1) DEFAULT 0,
    notes TEXT,
    reported_by INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED,
    created_at DATETIME,
    INDEX idx_asset_time (asset_id, start_time)
)";
$db->query($sql);

// Downtime Reasons
$sql = "CREATE TABLE IF NOT EXISTS oee_downtime_reasons (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) UNIQUE NOT NULL,
    description VARCHAR(255) NOT NULL,
    category ENUM('mechanical','electrical','material','operator','quality','changeover','planned_maintenance','other') NOT NULL,
    is_planned TINYINT(1) DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME
)";
$db->query($sql);

// Production Counts
$sql = "CREATE TABLE IF NOT EXISTS oee_production_counts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED NOT NULL,
    timestamp DATETIME NOT NULL,
    good_count INT DEFAULT 0,
    reject_count INT DEFAULT 0,
    shift_name VARCHAR(50) NOT NULL,
    operator_id INT UNSIGNED,
    created_at DATETIME,
    INDEX idx_asset_time (asset_id, timestamp)
)";
$db->query($sql);

// Asset Targets
$sql = "CREATE TABLE IF NOT EXISTS oee_asset_targets (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    asset_id INT UNSIGNED UNIQUE NOT NULL,
    target_oee DECIMAL(5,2) DEFAULT 85.00,
    target_availability DECIMAL(5,2) DEFAULT 90.00,
    target_performance DECIMAL(5,2) DEFAULT 95.00,
    target_quality DECIMAL(5,2) DEFAULT 99.00,
    ideal_cycle_time DECIMAL(10,2) COMMENT 'seconds per unit',
    updated_at DATETIME
)";
$db->query($sql);

// Insert default downtime reasons
$reasons = [
    ['MECH-BRK', 'Mechanical Breakdown', 'mechanical', 0],
    ['ELEC-FAIL', 'Electrical Failure', 'electrical', 0],
    ['MAT-SHORT', 'Material Shortage', 'material', 0],
    ['QUAL-ISSUE', 'Quality Issue', 'quality', 0],
    ['CHANGEOVER', 'Product Changeover', 'changeover', 1],
    ['PM-SCHED', 'Scheduled Maintenance', 'planned_maintenance', 1],
    ['OP-ABSENT', 'Operator Absent', 'operator', 0],
    ['NO-ORDER', 'No Production Order', 'other', 1],
];

$stmt = $db->prepare("INSERT IGNORE INTO oee_downtime_reasons (code, description, category, is_planned, created_at) VALUES (?, ?, ?, ?, NOW())");
foreach ($reasons as $r) {
    $stmt->bind_param('sssi', $r[0], $r[1], $r[2], $r[3]);
    $stmt->execute();
}

echo "OEE tables created successfully!\n";
$db->close();
