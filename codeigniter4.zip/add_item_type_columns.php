<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

echo "Adding item_type and manual_item_description columns...\n";

// Add item_type column
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'item_type'");
if ($result->num_rows > 0) {
    echo "item_type column already exists!\n";
} else {
    $mysqli->query("ALTER TABLE maintenance_requests ADD COLUMN item_type ENUM('machine', 'manual') DEFAULT 'machine' AFTER part_id");
    echo "item_type column added successfully!\n";
}

// Add manual_item_description column
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'manual_item_description'");
if ($result->num_rows > 0) {
    echo "manual_item_description column already exists!\n";
} else {
    $mysqli->query("ALTER TABLE maintenance_requests ADD COLUMN manual_item_description TEXT NULL AFTER item_type");
    echo "manual_item_description column added successfully!\n";
}

$mysqli->close();
echo "\nMigration completed!\n";
