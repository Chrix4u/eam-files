<?php
// Create technician user
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if technician exists
$check = $conn->query("SELECT id FROM users WHERE username = 'technician' OR email = 'technician@factory.com'");

if ($check->num_rows > 0) {
    echo "✓ Technician user already exists\n";
    $user = $check->fetch_assoc();
    echo "  ID: " . $user['id'] . "\n";
    echo "  Username: technician\n";
    echo "  Password: technician123\n";
} else {
    // Create technician user
    $password = password_hash('technician123', PASSWORD_DEFAULT);
    $query = "INSERT INTO users (username, email, password, role, full_name, is_active, created_at) 
              VALUES ('technician', 'technician@factory.com', '$password', 'technician', 'John Technician', 1, NOW())";
    
    if ($conn->query($query) === TRUE) {
        echo "✓ Technician user created successfully!\n";
        echo "  Username: technician\n";
        echo "  Password: technician123\n";
        echo "  Email: technician@factory.com\n";
    } else {
        echo "✗ Error: " . $conn->error . "\n";
    }
}

// Also check/create other test users
$testUsers = [
    ['username' => 'operator', 'email' => 'operator@factory.com', 'role' => 'operator', 'name' => 'Jane Operator'],
    ['username' => 'supervisor', 'email' => 'supervisor@factory.com', 'role' => 'supervisor', 'name' => 'Bob Supervisor'],
    ['username' => 'planner', 'email' => 'planner@factory.com', 'role' => 'planner', 'name' => 'Alice Planner'],
];

echo "\n--- Other Test Users ---\n";
foreach ($testUsers as $testUser) {
    $check = $conn->query("SELECT id FROM users WHERE username = '{$testUser['username']}'");
    if ($check->num_rows > 0) {
        echo "✓ {$testUser['username']} exists\n";
    } else {
        $password = password_hash($testUser['username'] . '123', PASSWORD_DEFAULT);
        $query = "INSERT INTO users (username, email, password, role, full_name, is_active, created_at) 
                  VALUES ('{$testUser['username']}', '{$testUser['email']}', '$password', '{$testUser['role']}', '{$testUser['name']}', 1, NOW())";
        if ($conn->query($query) === TRUE) {
            echo "✓ {$testUser['username']} created (password: {$testUser['username']}123)\n";
        }
    }
}

$conn->close();
echo "\n✓ All test users ready!\n";
