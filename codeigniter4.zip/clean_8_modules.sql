-- Clean 8-Module Structure
-- Consolidates existing 10 modules into 8 logical modules

-- Step 1: Delete modules that will be consolidated
DELETE FROM system_modules WHERE module_name IN ('maintenance_requests', 'iot_monitoring', 'predictive_maintenance', 'mobile_app');

-- Step 2: Update remaining modules to represent the 8 core modules
UPDATE system_modules SET 
    module_name = 'rwop',
    display_name = 'Repair Work Order Program',
    description = 'Work orders, maintenance requests, team assignments, shift handover',
    code = 'rwop',
    version = '2.1.0',
    dependencies = '["ims","asset"]',
    ghana_features = '{"shift_handover":true,"union_notification":true,"team_leader_enforcement":true}',
    route_prefix = '/rwop',
    icon = 'wrench',
    display_order = 1
WHERE module_name = 'work_orders';

UPDATE system_modules SET
    module_name = 'mrmp',
    display_name = 'Machine Reliability Maintenance',
    description = 'PM schedules, IoT monitoring, predictive maintenance, calibration',
    code = 'mrmp',
    version = '1.0.0',
    dependencies = '["asset","ims"]',
    ghana_features = '{"season_adjustment":true,"generator_pm":true,"voltage_monitoring":true,"iot_integration":true}',
    route_prefix = '/mrmp',
    icon = 'cog',
    display_order = 2
WHERE module_name = 'preventive_maintenance';

UPDATE system_modules SET
    module_name = 'mpmp',
    display_name = 'Manufacturing Production Management',
    description = 'Production tracking, OEE, downtime, shift management',
    code = 'mpmp',
    version = '1.0.0',
    dependencies = '["asset"]',
    ghana_features = '{"shift_production":true,"power_outage_downtime":true,"union_break_compliance":true}',
    route_prefix = '/mpmp',
    icon = 'factory',
    display_order = 3
WHERE module_name = 'production_tracking';

UPDATE system_modules SET
    module_name = 'ims',
    display_name = 'Inventory Management System',
    description = 'Parts, stock, material requests, vendors, forex tracking',
    code = 'ims',
    version = '1.0.0',
    dependencies = '[]',
    ghana_features = '{"forex_tracking":true,"local_vs_imported":true,"customs_tracking":true,"dumsor_buffer":true}',
    route_prefix = '/ims',
    icon = 'box',
    display_order = 4
WHERE module_name = 'inventory';

UPDATE system_modules SET
    module_name = 'asset',
    display_name = 'Asset Management',
    description = 'Equipment, facilities, assemblies, BOM, asset hierarchy',
    code = 'asset',
    version = '1.0.0',
    dependencies = '[]',
    ghana_features = '{}',
    route_prefix = '/asset',
    icon = 'building',
    display_order = 5
WHERE module_name = 'asset_management';

UPDATE system_modules SET
    module_name = 'core',
    display_name = 'Core Platform Services',
    description = 'Auth, analytics, reports, audit logs, mobile app',
    code = 'core',
    version = '1.0.0',
    dependencies = '[]',
    ghana_features = '{"audit_logging":true,"rbac":true}',
    route_prefix = '/core',
    icon = 'shield',
    display_order = 6
WHERE module_name = 'analytics';

-- Step 3: Insert new HRMS and TRAC modules
INSERT INTO system_modules (module_name, display_name, description, is_enabled, subscription_tier, code, version, dependencies, ghana_features, route_prefix, icon, display_order)
VALUES 
('hrms', 'Human Resources Management', 'Users, shifts, training, skills, union tracking', 1, 'professional', 'hrms', '1.0.0', '[]', '{"union_tracking":true,"ssnit_calculation":true,"shift_allowance":true,"night_differential":true}', '/hrms', 'users', 7),
('trac', 'Tool & Rotating Asset Control', 'Tools, LOTO, permits-to-work, safety compliance', 1, 'professional', 'trac', '1.0.0', '["asset"]', '{"union_custody":true,"gsa_certification":true}', '/trac', 'tool', 8)
ON DUPLICATE KEY UPDATE updated_at = NOW();

-- Step 4: Verify final 8 modules
SELECT 
    module_name,
    display_name,
    code,
    route_prefix,
    is_enabled,
    subscription_tier,
    display_order
FROM system_modules
ORDER BY display_order;
