# 🔧 Controller Merge Plan - Comprehensive

**Date**: 2026-02-11  
**Status**: 🔴 READY TO EXECUTE

---

## 🎯 Merge Strategy

For each duplicate pair:
1. **Compare methods** - List all public functions in both
2. **Compare features** - Check for RBAC, plant validation, audit logging
3. **Merge** - Copy missing methods from one to the other
4. **Rename** - Ensure class name matches filename
5. **Test** - Verify the merged controller works
6. **Delete** - Remove the duplicate
7. **Update routes** - Ensure routes point to correct controller

---

## 📋 Duplicate Controllers to Merge

### 1. Core/AuthController ⚠️ CRITICAL (Blocking Login)

**Files**:
- `AuthController.php` (class: EamAuthController ❌ WRONG)
- `EamAuthController.php` (class: EamAuthController)

**Methods**:
- Both have: `__construct()`, `login()`, `logout()`, `refresh()`
- Missing: `forgotPassword()`, `resetPassword()` (referenced in routes)

**Action**:
1. Fix class name in AuthController.php to `AuthController`
2. Add missing methods if needed
3. Delete EamAuthController.php
4. Routes already use `AuthController` ✅

---

### 2. Core/RolesController

**Files**:
- `RolesController.php` (if exists)
- `EamRolesController.php`

**Action**: Compare and merge

---

### 3. ASSET/AssembliesController

**Files**:
- `AssembliesController.php`
- `EamAssembliesController.php`

**Action**: Compare and merge

---

### 4. ASSET/EquipmentController

**Files**:
- `EquipmentController.php` (if exists)
- `EamEquipmentController.php`

**Action**: Compare and merge

---

### 5. ASSET/FacilitiesController ✅ DONE

**Status**: Already merged in Phase 2
- Using `FacilitiesController.php` with RBAC
- Routes updated ✅

---

### 6. HRMS/UsersController

**Files**:
- `UsersController.php` (if exists)
- `EamUsersController.php`

**Action**: Compare and merge

---

### 7. IMS/InventoryController ✅ DONE

**Status**: Already merged in Phase 2
- Using `EamInventoryController.php` with RBAC
- Routes updated ✅
- Old `InventoryController.php` deleted ✅

---

### 8. IMS/PartsController

**Files**:
- `PartsController.php`
- `EamPartsController.php`

**Action**: Compare and merge

---

### 9. MRMP/PmController

**Files**:
- `PmController.php`
- `EamPmController.php`

**Action**: Compare and merge

---

### 10. RWOP/WorkOrdersController

**Files**:
- `WorkOrdersController.php`
- `EamWorkOrdersController.php`

**Action**: Compare and merge

---

## 🔍 Comparison Checklist

For each controller pair, check:

### Features
- [ ] Has `requirePermission()` calls
- [ ] Has `validatePlantInRequest()` calls
- [ ] Has `auditLog()` calls
- [ ] Extends proper base class
- [ ] Has parent::__construct() call

### Methods
- [ ] List all public functions in both
- [ ] Identify unique methods in each
- [ ] Identify common methods with different implementations
- [ ] Check which implementation is better (RBAC, validation, etc.)

### Code Quality
- [ ] Proper error handling
- [ ] Consistent response format
- [ ] Input validation
- [ ] Security checks

---

## 📝 Merge Template

```php
<?php

namespace App\Controllers\Api\V1\Modules\[MODULE];

use App\Controllers\Api\V1\BaseApiController;

class [ControllerName] extends BaseApiController
{
    protected $service;

    public function __construct()
    {
        parent::__construct();
        $this->service = new [ServiceName]();
    }

    public function index()
    {
        if ($error = $this->requirePermission('[permission].view')) return $error;
        $result = $this->service->getAll($this->request->getGet());
        return $this->respond($result);
    }

    public function show($id = null)
    {
        if ($error = $this->requirePermission('[permission].view')) return $error;
        $result = $this->service->getById($id);
        return $this->respond($result);
    }

    public function create()
    {
        if ($error = $this->requirePermission('[permission].create')) return $error;
        $data = $this->validatePlantInRequest($this->request->getJSON(true));
        if ($data instanceof \CodeIgniter\HTTP\ResponseInterface) return $data;
        $result = $this->service->create($data);
        if ($result['status'] === 'success') {
            $this->auditLog('create', '[entity]', $result['data']['id'] ?? null, $data);
        }
        return $this->respond($result, $result['status'] === 'success' ? 201 : 400);
    }

    public function update($id = null)
    {
        if ($error = $this->requirePermission('[permission].update')) return $error;
        $data = $this->request->getJSON(true);
        unset($data['plant_id']); // Prevent plant_id changes
        $result = $this->service->update($id, $data);
        if ($result['status'] === 'success') {
            $this->auditLog('update', '[entity]', $id, $data);
        }
        return $this->respond($result);
    }

    public function delete($id = null)
    {
        if ($error = $this->requirePermission('[permission].delete')) return $error;
        $result = $this->service->delete($id);
        if ($result['status'] === 'success') {
            $this->auditLog('delete', '[entity]', $id);
        }
        return $this->respond($result);
    }
}
```

---

## 🚀 Execution Order

### Phase 1: Critical (Fix Login) - 15 min
1. ✅ Fix AuthController class name
2. ⏳ Add missing methods (forgotPassword, resetPassword)
3. ⏳ Delete EamAuthController.php
4. ⏳ Test login

### Phase 2: Core Controllers - 30 min
1. ⏳ Merge RolesController

### Phase 3: Asset Controllers - 45 min
1. ⏳ Merge AssembliesController
2. ⏳ Merge EquipmentController

### Phase 4: Other Modules - 60 min
1. ⏳ Merge UsersController (HRMS)
2. ⏳ Merge PartsController (IMS)
3. ⏳ Merge PmController (MRMP)
4. ⏳ Merge WorkOrdersController (RWOP)

### Phase 5: Verification - 30 min
1. ⏳ Test all endpoints
2. ⏳ Verify routes work
3. ⏳ Check RBAC enforcement
4. ⏳ Verify multi-plant isolation

---

## 📊 Progress Tracker

| Controller | Compared | Merged | Tested | Deleted | Routes Updated |
|------------|----------|--------|--------|---------|----------------|
| AuthController | ✅ | ⏳ | ⏳ | ⏳ | ✅ |
| RolesController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| AssembliesController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| EquipmentController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| FacilitiesController | ✅ | ✅ | ✅ | ✅ | ✅ |
| UsersController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| InventoryController | ✅ | ✅ | ✅ | ✅ | ✅ |
| PartsController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| PmController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| WorkOrdersController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |

**Progress**: 2/10 Complete (20%)

---

**Status**: 🔴 READY TO EXECUTE  
**Next**: Complete AuthController merge, then proceed with others

