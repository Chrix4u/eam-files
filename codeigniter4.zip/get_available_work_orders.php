<?php

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

$pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
$stmt = $pdo->query("SELECT id, wo_number, title, status FROM work_orders WHERE status != 'completed' ORDER BY id DESC LIMIT 5");
$workOrders = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Available work orders:\n";
foreach ($workOrders as $wo) {
    echo "ID: {$wo['id']}, Number: {$wo['wo_number']}, Status: {$wo['status']}\n";
}

if (!empty($workOrders)) {
    $firstId = $workOrders[0]['id'];
    echo "\n✅ Use work order ID: $firstId\n";
    echo "curl -X POST \"http://localhost/factorymanager/public/index.php/api/v1/work-orders/$firstId/complete\" \\\n";
    echo "  -H \"Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE3NjMzNzQ3ODUsImV4cCI6MTc2MzM3ODM4NSwiZGF0YSI6eyJpZCI6IjEiLCJ1c2VybmFtZSI6ImFkbWluIiwicm9sZSI6ImFkbWluIn19.V9UAKej85tJMDwRvwXcySLOvv4P9q91jpH6kggV3sLI\" \\\n";
    echo "  -H \"Content-Type: application/json\" \\\n";
    echo "  -d '{\"actual_hours\":1.5,\"checklist\":[{\"item_id\":1,\"value\":\"yes\"},{\"item_id\":2,\"value\":\"ok\"}]}'\n";
}