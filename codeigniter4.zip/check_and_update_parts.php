<?php

$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Checking parts table...\n\n";

// Get all parts
$result = $conn->query("SELECT id, part_name, part_number, spare_availability FROM parts LIMIT 10");

echo "Sample Parts:\n";
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
while ($row = $result->fetch_assoc()) {
    echo sprintf("ID: %d | %-30s | %s | Spare: %s\n", 
        $row['id'], 
        $row['part_name'], 
        $row['part_number'],
        $row['spare_availability']
    );
}

// Count by spare_availability
echo "\n\nCounts:\n";
$counts = $conn->query("
    SELECT spare_availability, COUNT(*) as cnt 
    FROM parts 
    GROUP BY spare_availability
");

while ($row = $counts->fetch_assoc()) {
    echo "spare_availability = '{$row['spare_availability']}': {$row['cnt']} parts\n";
}

// Update all parts to spare_availability='yes'
echo "\n\nUpdating all parts to spare_availability='yes'...\n";
$conn->query("UPDATE parts SET spare_availability = 'yes' WHERE spare_availability = 'no' OR spare_availability IS NULL");
$affected = $conn->affected_rows;
echo "✅ Updated {$affected} parts\n";

$conn->close();
