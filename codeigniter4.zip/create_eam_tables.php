<?php

// Database configuration - update these values as needed
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

// Alternative configurations you can try:
// $password = ''; // No password
// $password = 'password'; // Common default
// $password = 'mysql'; // Another common default

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Check existing tables
    echo "🔍 Checking existing tables...\n";
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        echo "Found table: $table\n";
    }

    // Create assets/equipment table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS assets (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            asset_code VARCHAR(50) NOT NULL UNIQUE,
            name VARCHAR(255) NOT NULL,
            description TEXT,
            category VARCHAR(100),
            location VARCHAR(255),
            status ENUM('active', 'inactive', 'maintenance', 'retired') DEFAULT 'active',
            purchase_date DATE,
            purchase_cost DECIMAL(12,2),
            manufacturer VARCHAR(255),
            model VARCHAR(255),
            serial_number VARCHAR(255),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");

    // Create work_orders table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS work_orders (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            wo_number VARCHAR(50) NOT NULL UNIQUE,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            asset_id INT UNSIGNED,
            priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
            status ENUM('draft', 'assigned', 'in_progress', 'completed', 'closed', 'cancelled') DEFAULT 'draft',
            type ENUM('corrective', 'preventive', 'predictive', 'emergency') DEFAULT 'corrective',
            assigned_to INT UNSIGNED,
            requested_by INT UNSIGNED,
            due_date DATE,
            started_at DATETIME,
            completed_at DATETIME,
            estimated_hours DECIMAL(8,2),
            actual_hours DECIMAL(8,2),
            cost DECIMAL(12,2),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE SET NULL
        )
    ");

    // Create users table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(255) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            first_name VARCHAR(100),
            last_name VARCHAR(100),
            role ENUM('admin', 'manager', 'supervisor', 'technician', 'operator', 'planner', 'shop_attendant') DEFAULT 'technician',
            status ENUM('active', 'inactive') DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");

    // Insert sample data
    $pdo->exec("
        INSERT IGNORE INTO assets (asset_code, name, description, category, location, status) VALUES
        ('A-001', 'Compressor Unit 1', 'Main air compressor for production line', 'Compressor', 'Production Floor A', 'active'),
        ('A-002', 'Conveyor Belt System', 'Primary conveyor system', 'Conveyor', 'Production Floor A', 'active'),
        ('A-003', 'Packaging Machine', 'Automated packaging equipment', 'Packaging', 'Packaging Area', 'active'),
        ('A-004', 'Quality Control Scanner', 'Automated quality inspection', 'QC Equipment', 'QC Lab', 'active'),
        ('A-005', 'Hydraulic Press', 'Heavy duty hydraulic press', 'Press', 'Manufacturing', 'maintenance')
    ");

    $pdo->exec("
        INSERT IGNORE INTO users (username, email, password, first_name, last_name, role) VALUES
        ('admin', 'admin@factory.com', '$2y$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'User', 'admin'),
        ('john.doe', 'john@factory.com', '$2y$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John', 'Doe', 'technician'),
        ('jane.smith', 'jane@factory.com', '$2y$10\$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane', 'Smith', 'supervisor')
    ");

    $pdo->exec("
        INSERT IGNORE INTO work_orders (wo_number, title, description, asset_id, priority, status, type, due_date) VALUES
        ('WO-001', 'Compressor Maintenance', 'Routine maintenance for compressor unit', 1, 'medium', 'assigned', 'preventive', DATE_ADD(CURDATE(), INTERVAL 7 DAY)),
        ('WO-002', 'Conveyor Belt Repair', 'Fix belt alignment issue', 2, 'high', 'in_progress', 'corrective', DATE_ADD(CURDATE(), INTERVAL 2 DAY)),
        ('WO-003', 'Packaging Machine Calibration', 'Calibrate packaging machine sensors', 3, 'low', 'completed', 'preventive', CURDATE()),
        ('WO-004', 'Overdue Maintenance', 'Critical maintenance task', 1, 'critical', 'assigned', 'corrective', DATE_SUB(CURDATE(), INTERVAL 2 DAY))
    ");

    echo "✅ EAM tables created successfully!\n";
    echo "✅ Sample data inserted\n";
    echo "📊 Assets: 5 records\n";
    echo "📋 Work Orders: 4 records\n";
    echo "👥 Users: 3 records\n";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}