# EAM API Module Structure

## Complete Folder Structure

```
app/
├── Controllers/Api/V1/
│   ├── AuthController.php
│   ├── UsersController.php
│   ├── RolesController.php
│   ├── FacilitiesController.php
│   ├── SystemsController.php
│   ├── EquipmentController.php
│   ├── AssembliesController.php
│   ├── ComponentsController.php
│   ├── PartsController.php
│   ├── AssetsController.php
│   ├── MetersController.php
│   ├── MeterReadingsController.php
│   ├── PmRulesController.php
│   ├── PmSchedulesController.php
│   ├── WorkOrdersController.php
│   ├── WorkOrderTasksController.php
│   ├── WorkOrderMaterialsController.php
│   ├── InventoryController.php
│   ├── StockTransactionsController.php
│   ├── ProductionController.php
│   └── NotificationsController.php
│
├── Services/
│   ├── AuthService.php
│   ├── UserService.php
│   ├── RoleService.php
│   ├── AssetHierarchyService.php
│   ├── AssetService.php
│   ├── MeterService.php
│   ├── PmService.php
│   ├── WorkOrderService.php
│   ├── InventoryService.php
│   ├── ProductionService.php
│   └── NotificationService.php
│
└── Repositories/
    ├── UserRepository.php
    ├── RoleRepository.php
    ├── FacilityRepository.php
    ├── SystemRepository.php
    ├── EquipmentRepository.php
    ├── AssemblyRepository.php
    ├── ComponentRepository.php
    ├── PartRepository.php
    ├── AssetRepository.php
    ├── MeterRepository.php
    ├── PmRepository.php
    ├── WorkOrderRepository.php
    ├── InventoryRepository.php
    ├── ProductionRepository.php
    └── NotificationRepository.php
```

## API Routes Structure

```
/api/v1/
├── /auth
│   ├── POST /login
│   ├── POST /logout
│   └── POST /refresh
│
├── /users
│   ├── GET /users
│   ├── GET /users/{id}
│   ├── POST /users
│   ├── PUT /users/{id}
│   ├── DELETE /users/{id}
│   └── POST /users/{id}/assign-role
│
├── /roles
│   ├── GET /roles
│   ├── GET /roles/{id}
│   ├── POST /roles
│   ├── PUT /roles/{id}
│   ├── DELETE /roles/{id}
│   └── POST /roles/{id}/permissions
│
├── /facilities
│   ├── GET /facilities
│   ├── GET /facilities/{id}
│   ├── POST /facilities
│   ├── PUT /facilities/{id}
│   └── DELETE /facilities/{id}
│
├── /systems
│   ├── GET /systems
│   ├── GET /systems/{id}
│   ├── POST /systems
│   ├── PUT /systems/{id}
│   └── DELETE /systems/{id}
│
├── /equipment
│   ├── GET /equipment
│   ├── GET /equipment/{id}
│   ├── POST /equipment
│   ├── PUT /equipment/{id}
│   └── DELETE /equipment/{id}
│
├── /assemblies
│   ├── GET /assemblies
│   ├── GET /assemblies/{id}
│   ├── POST /assemblies
│   ├── PUT /assemblies/{id}
│   └── DELETE /assemblies/{id}
│
├── /components
│   ├── GET /components
│   ├── GET /components/{id}
│   ├── POST /components
│   ├── PUT /components/{id}
│   └── DELETE /components/{id}
│
├── /parts
│   ├── GET /parts
│   ├── GET /parts/{id}
│   ├── POST /parts
│   ├── PUT /parts/{id}
│   └── DELETE /parts/{id}
│
├── /assets
│   ├── GET /assets
│   ├── GET /assets/{id}
│   ├── GET /assets/tree
│   ├── GET /assets/{id}/children
│   └── GET /assets/{id}/hierarchy
│
├── /meters
│   ├── GET /meters
│   ├── GET /meters/{id}
│   ├── POST /meters
│   ├── PUT /meters/{id}
│   └── DELETE /meters/{id}
│
├── /meter-readings
│   ├── GET /meter-readings
│   ├── POST /meter-readings
│   └── GET /meters/{id}/readings
│
├── /pm-rules
│   ├── GET /pm-rules
│   ├── GET /pm-rules/{id}
│   ├── POST /pm-rules
│   ├── PUT /pm-rules/{id}
│   └── DELETE /pm-rules/{id}
│
├── /pm-schedules
│   ├── GET /pm-schedules
│   ├── GET /pm-schedules/{id}
│   ├── POST /pm-schedules/generate
│   └── GET /pm-schedules/overdue
│
├── /work-orders
│   ├── GET /work-orders
│   ├── GET /work-orders/{id}
│   ├── POST /work-orders
│   ├── PUT /work-orders/{id}
│   ├── DELETE /work-orders/{id}
│   ├── POST /work-orders/{id}/assign
│   ├── POST /work-orders/{id}/start
│   ├── POST /work-orders/{id}/complete
│   └── POST /work-orders/{id}/cancel
│
├── /work-order-tasks
│   ├── GET /work-orders/{id}/tasks
│   ├── POST /work-orders/{id}/tasks
│   ├── PUT /work-order-tasks/{id}
│   └── DELETE /work-order-tasks/{id}
│
├── /work-order-materials
│   ├── GET /work-orders/{id}/materials
│   ├── POST /work-orders/{id}/materials
│   └── DELETE /work-order-materials/{id}
│
├── /inventory
│   ├── GET /inventory
│   ├── GET /inventory/{id}
│   ├── POST /inventory
│   ├── PUT /inventory/{id}
│   ├── DELETE /inventory/{id}
│   └── GET /inventory/low-stock
│
├── /stock-transactions
│   ├── GET /stock-transactions
│   ├── POST /stock-transactions/stock-in
│   ├── POST /stock-transactions/stock-out
│   └── POST /stock-transactions/adjust
│
├── /production
│   ├── GET /production/summary
│   ├── GET /production/equipment/{id}
│   └── POST /production/record
│
└── /notifications
    ├── GET /notifications
    ├── GET /notifications/unread
    ├── PUT /notifications/{id}/read
    └── DELETE /notifications/{id}
```

## Standard JSON Response Format

### Success Response
```json
{
  "status": 200,
  "message": "Success",
  "data": {}
}
```

### Error Response
```json
{
  "status": 400,
  "message": "Error message",
  "errors": {}
}
```

### Paginated Response
```json
{
  "status": 200,
  "message": "Success",
  "data": [],
  "pagination": {
    "total": 100,
    "page": 1,
    "per_page": 20,
    "total_pages": 5
  }
}
```

## Example Responses by Module

### Auth Module
```json
// POST /api/v1/auth/login
{
  "status": 200,
  "message": "Login successful",
  "data": {
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "expires_in": 3600,
    "user": {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "role": "Admin"
    }
  }
}
```

### Asset Hierarchy
```json
// GET /api/v1/assets/tree
{
  "status": 200,
  "message": "Success",
  "data": [
    {
      "id": 1,
      "type": "facility",
      "name": "Plant A",
      "children": [
        {
          "id": 1,
          "type": "system",
          "name": "Production Line 1",
          "children": [
            {
              "id": 1,
              "type": "equipment",
              "name": "CNC Machine",
              "status": "operational"
            }
          ]
        }
      ]
    }
  ]
}
```

### Work Orders
```json
// GET /api/v1/work-orders
{
  "status": 200,
  "message": "Success",
  "data": [
    {
      "id": 1,
      "wo_number": "WO-2025-001",
      "equipment_id": 5,
      "equipment_name": "CNC Machine",
      "wo_type": "preventive",
      "priority": "high",
      "status": "assigned",
      "assigned_to": 3,
      "assigned_to_name": "John Doe",
      "scheduled_date": "2025-11-15",
      "created_at": "2025-11-14 10:00:00"
    }
  ],
  "pagination": {
    "total": 50,
    "page": 1,
    "per_page": 20,
    "total_pages": 3
  }
}
```

### Inventory
```json
// GET /api/v1/inventory
{
  "status": 200,
  "message": "Success",
  "data": [
    {
      "id": 1,
      "item_code": "PART-001",
      "item_name": "Bearing 6205",
      "category": "Mechanical",
      "quantity": 150,
      "unit": "pcs",
      "min_stock": 50,
      "max_stock": 200,
      "unit_price": 25.50,
      "status": "in_stock"
    }
  ]
}
```

### PM Schedules
```json
// GET /api/v1/pm-schedules
{
  "status": 200,
  "message": "Success",
  "data": [
    {
      "id": 1,
      "equipment_id": 5,
      "equipment_name": "CNC Machine",
      "pm_rule_id": 2,
      "pm_type": "time_based",
      "frequency_days": 30,
      "last_completed": "2025-10-15",
      "next_due": "2025-11-14",
      "status": "overdue",
      "work_order_id": null
    }
  ]
}
```

### Notifications
```json
// GET /api/v1/notifications/unread
{
  "status": 200,
  "message": "Success",
  "data": [
    {
      "id": 1,
      "type": "pm_overdue",
      "title": "PM Overdue",
      "message": "PM for CNC Machine is overdue",
      "data": {
        "equipment_id": 5,
        "pm_schedule_id": 1
      },
      "is_read": false,
      "created_at": "2025-11-14 08:00:00"
    }
  ]
}
```
