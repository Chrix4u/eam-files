-- =====================================================
-- GRADE A+ MAINTENANCE REQUEST SYSTEM - DATABASE FIXES
-- =====================================================

USE factory_manager;

-- Drop existing triggers and procedures
DROP TRIGGER IF EXISTS trg_maintenance_request_sla_insert;
DROP PROCEDURE IF EXISTS sp_calculate_sla;

-- Create workflow history table
CREATE TABLE IF NOT EXISTS maintenance_request_workflow (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(50),
    to_status VARCHAR(50) NOT NULL,
    action_by INT UNSIGNED NOT NULL,
    action_type ENUM('created','reviewed','approved','rejected','assigned','converted','completed','commented') NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_action_by (action_by),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create notifications table
CREATE TABLE IF NOT EXISTS maintenance_notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    request_id INT UNSIGNED NULL,
    work_order_id INT UNSIGNED NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    INDEX idx_user_read (user_id, is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create attachments table
CREATE TABLE IF NOT EXISTS maintenance_attachments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(100),
    file_size INT UNSIGNED,
    uploaded_by INT UNSIGNED NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create comments table
CREATE TABLE IF NOT EXISTS maintenance_comments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create SLA configuration table
CREATE TABLE IF NOT EXISTS maintenance_sla_config (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    priority ENUM('low','medium','high','urgent') NOT NULL UNIQUE,
    response_time_hours INT NOT NULL,
    resolution_time_hours INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default SLA configurations
INSERT IGNORE INTO maintenance_sla_config (priority, response_time_hours, resolution_time_hours) VALUES
('urgent', 1, 4),
('high', 4, 24),
('medium', 8, 72),
('low', 24, 168);

-- Create work_orders table
CREATE TABLE IF NOT EXISTS work_orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
    status ENUM('open','in_progress','on_hold','completed','cancelled') DEFAULT 'open',
    work_type ENUM('corrective','preventive','predictive','inspection') DEFAULT 'corrective',
    machine_id INT UNSIGNED NULL,
    assembly_id INT UNSIGNED NULL,
    part_id INT UNSIGNED NULL,
    location VARCHAR(255),
    assigned_to INT UNSIGNED NULL,
    scheduled_date DATETIME NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    estimated_hours DECIMAL(10,2),
    actual_hours DECIMAL(10,2),
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_assigned_to (assigned_to),
    INDEX idx_scheduled_date (scheduled_date),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add SLA columns to maintenance_requests if they don't exist
SET @query = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = 'factory_manager' 
     AND TABLE_NAME = 'maintenance_requests' 
     AND COLUMN_NAME = 'sla_due_date') = 0,
    'ALTER TABLE maintenance_requests ADD COLUMN sla_due_date DATETIME NULL',
    'SELECT "sla_due_date already exists"'
));
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @query = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = 'factory_manager' 
     AND TABLE_NAME = 'maintenance_requests' 
     AND COLUMN_NAME = 'sla_status') = 0,
    'ALTER TABLE maintenance_requests ADD COLUMN sla_status ENUM("on_time","at_risk","overdue") DEFAULT "on_time"',
    'SELECT "sla_status already exists"'
));
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @query = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = 'factory_manager' 
     AND TABLE_NAME = 'maintenance_requests' 
     AND COLUMN_NAME = 'response_time') = 0,
    'ALTER TABLE maintenance_requests ADD COLUMN response_time INT NULL',
    'SELECT "response_time already exists"'
));
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @query = (SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS 
     WHERE TABLE_SCHEMA = 'factory_manager' 
     AND TABLE_NAME = 'maintenance_requests' 
     AND COLUMN_NAME = 'resolution_time') = 0,
    'ALTER TABLE maintenance_requests ADD COLUMN resolution_time INT NULL',
    'SELECT "resolution_time already exists"'
));
PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Create stored procedure to calculate SLA
DELIMITER //
CREATE PROCEDURE sp_calculate_sla(IN p_request_id INT)
BEGIN
    DECLARE v_priority VARCHAR(20);
    DECLARE v_resolution_hours INT;
    DECLARE v_created_at DATETIME;
    
    SELECT priority, created_at INTO v_priority, v_created_at
    FROM maintenance_requests
    WHERE id = p_request_id;
    
    SELECT resolution_time_hours INTO v_resolution_hours
    FROM maintenance_sla_config
    WHERE priority = v_priority;
    
    UPDATE maintenance_requests
    SET sla_due_date = DATE_ADD(v_created_at, INTERVAL v_resolution_hours HOUR)
    WHERE id = p_request_id;
END //
DELIMITER ;

-- Create trigger to auto-calculate SLA on insert
DELIMITER //
CREATE TRIGGER trg_maintenance_request_sla_insert
AFTER INSERT ON maintenance_requests
FOR EACH ROW
BEGIN
    DECLARE v_resolution_hours INT;
    
    SELECT resolution_time_hours INTO v_resolution_hours
    FROM maintenance_sla_config
    WHERE priority = NEW.priority;
    
    UPDATE maintenance_requests
    SET sla_due_date = DATE_ADD(NEW.created_at, INTERVAL v_resolution_hours HOUR)
    WHERE id = NEW.id;
END //
DELIMITER ;

-- Update existing requests with SLA
UPDATE maintenance_requests mr
JOIN maintenance_sla_config sla ON sla.priority = mr.priority
SET mr.sla_due_date = DATE_ADD(mr.created_at, INTERVAL sla.resolution_time_hours HOUR)
WHERE mr.sla_due_date IS NULL;

SELECT '✅ Grade A+ Database Setup Complete!' as Status;
