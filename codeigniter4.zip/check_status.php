<?php
$db = new PDO('mysql:host=localhost;dbname=factory_manager', 'root', 'myjesus4mE');
$result = $db->query("SELECT DISTINCT status FROM assets_unified ORDER BY status");
echo "Asset Status Values:\n";
foreach ($result as $row) {
    echo "- " . $row['status'] . "\n";
}

echo "\nAsset Count by Status:\n";
$result = $db->query("SELECT status, COUNT(*) as count FROM assets_unified GROUP BY status ORDER BY status");
foreach ($result as $row) {
    echo "- " . $row['status'] . ": " . $row['count'] . "\n";
}
