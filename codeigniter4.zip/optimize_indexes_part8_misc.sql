-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 8: MISCELLANEOUS
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- CLASS_ROUTINE TABLE
ALTER TABLE `class_routine` ADD INDEX IF NOT EXISTS `idx_class_section_routine` (`class_id`, `section_id`);
ALTER TABLE `class_routine` ADD INDEX IF NOT EXISTS `idx_subject_routine` (`subject_id`);
ALTER TABLE `class_routine` ADD INDEX IF NOT EXISTS `idx_day` (`day`(20));
ALTER TABLE `class_routine` ADD INDEX IF NOT EXISTS `idx_year_term_routine` (`year`(50), `term`(50));

-- DORMITORY TABLE
ALTER TABLE `dormitory` ADD INDEX IF NOT EXISTS `idx_dormitory_name` (`name`(100));

-- TRANSPORT TABLE
ALTER TABLE `transport` ADD INDEX IF NOT EXISTS `idx_route_name` (`route_name`(100));

-- HOLIDAY TABLE
ALTER TABLE `holiday` ADD INDEX IF NOT EXISTS `idx_year_holiday` (`year`);
ALTER TABLE `holiday` ADD INDEX IF NOT EXISTS `idx_dates_holiday` (`from_date`, `to_date`);

-- TERMS TABLE
ALTER TABLE `terms` ADD INDEX IF NOT EXISTS `idx_year_term_terms` (`year`(50), `term`(50));

-- SEMS TABLE
ALTER TABLE `sems` ADD INDEX IF NOT EXISTS `idx_year_sem` (`year`(50), `sem`(50));

-- SETTINGS TABLE
ALTER TABLE `settings` ADD INDEX IF NOT EXISTS `idx_type_settings` (`type`(100));

-- FRONTEND_EVENTS TABLE
ALTER TABLE `frontend_events` ADD INDEX IF NOT EXISTS `idx_timestamp_events` (`timestamp`);
ALTER TABLE `frontend_events` ADD INDEX IF NOT EXISTS `idx_status_events` (`status`);

-- FRONTEND_GALLERY TABLE
ALTER TABLE `frontend_gallery` ADD INDEX IF NOT EXISTS `idx_date_gallery` (`date_added`);
ALTER TABLE `frontend_gallery` ADD INDEX IF NOT EXISTS `idx_show_gallery` (`show_on_website`);

-- FRONTEND_GALLERY_IMAGE TABLE
ALTER TABLE `frontend_gallery_image` ADD INDEX IF NOT EXISTS `idx_gallery_image` (`frontend_gallery_id`);

-- FRONTEND_NEWS TABLE
ALTER TABLE `frontend_news` ADD INDEX IF NOT EXISTS `idx_date_news` (`date_added`);

-- FRONTEND_GENERAL_SETTINGS TABLE
ALTER TABLE `frontend_general_settings` ADD INDEX IF NOT EXISTS `idx_type_frontend` (`type`);

-- CI_SESSIONS TABLE
ALTER TABLE `ci_sessions` ADD INDEX IF NOT EXISTS `idx_ip_address` (`ip_address`);

-- VISITOR_TRACKER TABLE
ALTER TABLE `visitor_tracker` ADD INDEX IF NOT EXISTS `idx_ip_visitor` (`ip`);
ALTER TABLE `visitor_tracker` ADD INDEX IF NOT EXISTS `idx_date_visitor` (`date`);

-- USER_PERMISSION TABLE
ALTER TABLE `user_permission` ADD INDEX IF NOT EXISTS `idx_user_type_perm` (`user_type`(50));
ALTER TABLE `user_permission` ADD INDEX IF NOT EXISTS `idx_user_level` (`user_level`);
ALTER TABLE `user_permission` ADD INDEX IF NOT EXISTS `idx_perm_status` (`permission_status`);

-- TO-DO_LIST TABLE
ALTER TABLE `to-do_list` ADD INDEX IF NOT EXISTS `idx_user_todo` (`user_id`);
ALTER TABLE `to-do_list` ADD INDEX IF NOT EXISTS `idx_date_todo` (`date`);
ALTER TABLE `to-do_list` ADD INDEX IF NOT EXISTS `idx_value_todo` (`value`);

-- BLOOD_GROUP TABLE
ALTER TABLE `blood_group` ADD INDEX IF NOT EXISTS `idx_blood_group` (`blood_group`);

-- RELIGION TABLE
ALTER TABLE `religion` ADD INDEX IF NOT EXISTS `idx_religion` (`religion`);

-- SUBJECT_CATEGORY_CRECHE TABLE
ALTER TABLE `subject_category_creche` ADD INDEX IF NOT EXISTS `idx_year_term_creche` (`year`(50), `term`(50));

-- SUBJECT_CRECHE TABLE
ALTER TABLE `subject_creche` ADD INDEX IF NOT EXISTS `idx_class_teacher_creche` (`class_id`, `teacher_id`);
ALTER TABLE `subject_creche` ADD INDEX IF NOT EXISTS `idx_category_creche` (`category_id`);
ALTER TABLE `subject_creche` ADD INDEX IF NOT EXISTS `idx_year_term_subj_creche` (`year`(50), `term`(50));

-- GRADE_2 TABLE
ALTER TABLE `grade_2` ADD INDEX IF NOT EXISTS `idx_mark_range_2` (`mark_from`, `mark_upto`);

-- RAW_SCORE_GRADE TABLE
ALTER TABLE `raw_score_grade` ADD INDEX IF NOT EXISTS `idx_mark_range_raw` (`mark_from`, `mark_upto`);

-- GRADE_CRECHE TABLE
ALTER TABLE `grade_creche` ADD INDEX IF NOT EXISTS `idx_abbrev` (`abbrev`(20));

-- EXAM_CATEGORY TABLE
ALTER TABLE `exam_category` ADD INDEX IF NOT EXISTS `idx_category_name` (`category_name`(100));

-- AGGREGATION_OLD TABLE
ALTER TABLE `aggregation_old` ADD INDEX IF NOT EXISTS `idx_student_exam_old` (`student_id`, `exam_id`, `class_id`, `section_id`);
ALTER TABLE `aggregation_old` ADD INDEX IF NOT EXISTS `idx_year_term_old` (`year`(50), `term`(50), `sem`(50));

-- FLUTTER_USER TABLE
ALTER TABLE `flutter_user` ADD INDEX IF NOT EXISTS `idx_flutter_email` (`flutter_email`(100));
ALTER TABLE `flutter_user` ADD INDEX IF NOT EXISTS `idx_flutter_phone` (`flutter_phone`(50));

-- EMPLOYEE_FILE TABLE
ALTER TABLE `employee_file` ADD INDEX IF NOT EXISTS `idx_emp_file` (`em_id`);

-- OWNER TABLE
ALTER TABLE `owner` ADD INDEX IF NOT EXISTS `idx_owner_name` (`owner_name`);

-- BILL_ITEM TABLE
ALTER TABLE `bill_item` ADD INDEX IF NOT EXISTS `idx_bill_title` (`title`);

COMMIT;
