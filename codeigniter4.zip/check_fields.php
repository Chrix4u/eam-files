<?php
$pdo = new PDO('mysql:host=localhost;dbname=factory_manager;charset=utf8mb4', 'root', 'myjesus4mE');
echo "=== MACHINES TABLE ===\n";
$stmt = $pdo->query('DESCRIBE machines');
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo $row['Field'] . "\n";
}
echo "\n=== ASSEMBLIES TABLE ===\n";
$stmt = $pdo->query('DESCRIBE assemblies');
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo $row['Field'] . "\n";
}
echo "\n=== PARTS TABLE ===\n";
$stmt = $pdo->query('DESCRIBE parts');
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo $row['Field'] . "\n";
}
?>