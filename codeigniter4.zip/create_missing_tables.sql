-- Create only missing tables
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS facilities (
  id INT(11) NOT NULL AUTO_INCREMENT,
  facility_code VARCHAR(50) NOT NULL UNIQUE,
  facility_name VARCHAR(255) NOT NULL,
  facility_type ENUM('plant','warehouse','office','distribution_center','service_center') DEFAULT 'plant',
  address_line1 VARCHAR(255),
  city VARCHAR(100),
  country_code CHAR(2),
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS departments (
  id INT(11) NOT NULL AUTO_INCREMENT,
  department_code VARCHAR(50) NOT NULL UNIQUE,
  department_name VARCHAR(255) NOT NULL,
  facility_id INT(11),
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS work_order_assignments (
  id INT(11) NOT NULL AUTO_INCREMENT,
  work_order_id INT(11) NOT NULL,
  assigned_to_user_id INT(11),
  assigned_date DATETIME NOT NULL,
  estimated_hours DECIMAL(8,2),
  actual_hours DECIMAL(8,2),
  assignment_status ENUM('assigned','in_progress','completed') DEFAULT 'assigned',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS production_schedules (
  id INT(11) NOT NULL AUTO_INCREMENT,
  schedule_code VARCHAR(50) NOT NULL UNIQUE,
  schedule_name VARCHAR(255) NOT NULL,
  planned_start_date DATETIME NOT NULL,
  planned_end_date DATETIME NOT NULL,
  status ENUM('planned','in_progress','completed','cancelled') DEFAULT 'planned',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS quality_inspections (
  id INT(11) NOT NULL AUTO_INCREMENT,
  inspection_number VARCHAR(50) NOT NULL UNIQUE,
  inspection_type ENUM('incoming','in_process','final','audit') DEFAULT 'in_process',
  inspection_date DATETIME NOT NULL,
  result ENUM('pass','fail','pending') DEFAULT 'pending',
  status ENUM('open','closed') DEFAULT 'open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS employee_roster (
  id INT(11) NOT NULL AUTO_INCREMENT,
  employee_id INT(11) NOT NULL,
  shift_id INT(11),
  roster_date DATE NOT NULL,
  status ENUM('scheduled','completed','absent') DEFAULT 'scheduled',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_forecasts (
  id INT(11) NOT NULL AUTO_INCREMENT,
  item_code VARCHAR(100) NOT NULL,
  forecast_date DATE NOT NULL,
  forecasted_demand DECIMAL(15,3),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;
SELECT 'Missing tables created!' AS status;
