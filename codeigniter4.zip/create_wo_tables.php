<?php

$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS mobile_sync_batches;
DROP TABLE IF EXISTS work_order_logs;
DROP TABLE IF EXISTS work_order_comments;
DROP TABLE IF EXISTS work_order_attachments;
DROP TABLE IF EXISTS work_order_materials;
DROP TABLE IF EXISTS work_order_checklist_items;
DROP TABLE IF EXISTS work_order_tasks;
DROP TABLE IF EXISTS work_order_types_meta;
DROP TABLE IF EXISTS work_orders;

CREATE TABLE work_orders (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    wo_number VARCHAR(50) UNIQUE NOT NULL,
    type ENUM('breakdown', 'corrective', 'inspection', 'lubrication', 'emergency', 'safety', 'improvement') NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    asset_id INT(11) UNSIGNED NULL,
    related_pm_id INT(11) UNSIGNED NULL,
    requestor_id INT(11) UNSIGNED NOT NULL,
    planner_id INT(11) UNSIGNED NULL,
    assigned_user_id INT(11) UNSIGNED NULL,
    assigned_group_id INT(11) UNSIGNED NULL,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    status ENUM('requested', 'approved', 'planned', 'assigned', 'in_progress', 'waiting_parts', 'on_hold', 'completed', 'closed', 'cancelled') DEFAULT 'requested',
    estimated_hours DECIMAL(10,2) NULL,
    actual_hours DECIMAL(10,2) NULL,
    planned_start DATETIME NULL,
    planned_end DATETIME NULL,
    actual_start DATETIME NULL,
    actual_end DATETIME NULL,
    sla_hours INT(11) NULL,
    sla_started_at DATETIME NULL,
    sla_breached_at DATETIME NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    KEY idx_type_status (type, status),
    KEY idx_asset (asset_id),
    KEY idx_assigned (assigned_user_id),
    KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_types_meta (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_type VARCHAR(50) UNIQUE NOT NULL,
    default_checklist_template_id INT(11) UNSIGNED NULL,
    default_required_tools JSON NULL,
    default_required_spares JSON NULL,
    default_priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    default_sla_hours INT(11) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_tasks (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    task_order INT(11) DEFAULT 0,
    description TEXT NOT NULL,
    is_completed TINYINT(1) DEFAULT 0,
    completed_by INT(11) UNSIGNED NULL,
    completed_at DATETIME NULL,
    created_at DATETIME NULL,
    KEY idx_wo (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_checklist_items (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    item_order INT(11) DEFAULT 0,
    item_type ENUM('text', 'yesno', 'numeric', 'passfail', 'photo', 'signature') DEFAULT 'text',
    description TEXT NOT NULL,
    response_value TEXT NULL,
    is_completed TINYINT(1) DEFAULT 0,
    completed_by INT(11) UNSIGNED NULL,
    completed_at DATETIME NULL,
    created_at DATETIME NULL,
    KEY idx_wo (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_materials (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    inventory_item_id INT(11) UNSIGNED NOT NULL,
    quantity_required DECIMAL(10,2) NOT NULL,
    quantity_reserved DECIMAL(10,2) DEFAULT 0,
    quantity_issued DECIMAL(10,2) DEFAULT 0,
    status ENUM('pending', 'reserved', 'issued', 'returned') DEFAULT 'pending',
    issued_by INT(11) UNSIGNED NULL,
    issued_at DATETIME NULL,
    created_at DATETIME NULL,
    KEY idx_wo (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_attachments (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size INT(11) NOT NULL,
    uploaded_by INT(11) UNSIGNED NOT NULL,
    created_at DATETIME NULL,
    KEY idx_wo (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_comments (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    user_id INT(11) UNSIGNED NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME NULL,
    KEY idx_wo (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE work_order_logs (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    user_id INT(11) UNSIGNED NOT NULL,
    action VARCHAR(100) NOT NULL,
    details JSON NULL,
    created_at DATETIME NULL,
    KEY idx_wo (work_order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE mobile_sync_batches (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    batch_id VARCHAR(100) UNIQUE NOT NULL,
    user_id INT(11) UNSIGNED NOT NULL,
    operations JSON NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
    result_mapping JSON NULL,
    error_message TEXT NULL,
    created_at DATETIME NULL,
    processed_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
";

if ($conn->multi_query($sql)) {
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->next_result());
    echo "Work order tables created successfully!\n";
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
