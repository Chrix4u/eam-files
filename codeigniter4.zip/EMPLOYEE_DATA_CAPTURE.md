# Employee Data Capture - Complete Guide

## 📊 Database Table: `users`

### All Employee Fields Available:

```sql
-- Core Identity
id                      INT PRIMARY KEY
username               VARCHAR(100)
email                  VARCHAR(255)
password               VARCHAR(255)
full_name              VARCHAR(255)
employee_number        VARCHAR(50)

-- Contact Information
phone                  VARCHAR(20)
mobile                 VARCHAR(20)
address                TEXT
city                   VARCHAR(100)
state                  VARCHAR(100)
postal_code            VARCHAR(20)
country                VARCHAR(100)

-- Employment Details
role                   ENUM('admin','manager','supervisor','technician','senior_technician','operator','planner','shop_attendant')
department_id          INT (FK to departments)
supervisor_id          INT (FK to users)
trade                  VARCHAR(100)
employee_type          VARCHAR(50) (permanent, contract, temporary)
hire_date              DATE
termination_date       DATE
status                 ENUM('active','inactive','suspended')

-- Professional Details
job_title              VARCHAR(100)
qualification          VARCHAR(255)
certification          TEXT
experience_years       INT
hourly_rate            DECIMAL(10,2)
salary                 DECIMAL(12,2)

-- System Fields
is_active              TINYINT(1)
last_login             DATETIME
created_at             DATETIME
updated_at             DATETIME
created_by             INT
updated_by             INT

-- Additional Fields
profile_photo          VARCHAR(255)
emergency_contact      VARCHAR(255)
emergency_phone        VARCHAR(20)
notes                  TEXT
```

---

## 📝 Complete Employee Data Capture

### API Endpoint: `POST /api/v1/eam/users`

```json
{
  "username": "jdoe",
  "email": "john.doe@company.com",
  "password": "SecurePass123",
  "full_name": "John Doe",
  "employee_number": "EMP-2024-001",
  
  "phone": "+233-24-123-4567",
  "mobile": "+233-50-987-6543",
  "address": "123 Main Street, Accra",
  "city": "Accra",
  "state": "Greater Accra",
  "postal_code": "GA-123",
  "country": "Ghana",
  
  "role": "technician",
  "department_id": 5,
  "supervisor_id": 10,
  "trade": "Electrical",
  "employee_type": "permanent",
  "hire_date": "2024-01-15",
  "status": "active",
  
  "job_title": "Senior Electrical Technician",
  "qualification": "HND Electrical Engineering",
  "certification": "Licensed Electrician, Safety Certified",
  "experience_years": 8,
  "hourly_rate": 50.00,
  "salary": 8000.00,
  
  "emergency_contact": "Jane Doe (Wife)",
  "emergency_phone": "+233-24-555-1234",
  "notes": "Specialized in high voltage systems"
}
```

---

## 🗄️ Where Data is Stored

### Primary Table: `users`
**Location**: Database `factorymanager`, table `users`

All employee data is saved in the `users` table with these relationships:

1. **Department Link**: `department_id` → `departments.id`
2. **Supervisor Link**: `supervisor_id` → `users.id`
3. **Trades/Skills**: `user_skills` table (many-to-many)
4. **Groups**: `technician_group_members` table

---

## 🔗 Related Tables

### 1. departments
```sql
id, department_name, department_code, supervisor_id
```

### 2. skills (trades)
```sql
id, skill_name, skill_code, description
```

### 3. user_skills (employee trades)
```sql
id, user_id, skill_id, created_at
```

### 4. technician_groups
```sql
id, group_name, group_code, group_leader_id, department_id
```

### 5. technician_group_members
```sql
id, group_id, technician_id, role, joined_at
```

---

## 📋 Frontend Form Fields

### Basic Information
- Full Name ✅
- Employee Number ✅
- Email ✅
- Username ✅
- Password ✅

### Contact Details
- Phone ✅
- Mobile ✅
- Address ✅
- City ✅
- State ✅
- Postal Code ✅
- Country ✅

### Employment
- Role (dropdown) ✅
- Department (dropdown) ✅
- Supervisor (dropdown) ✅
- Employee Type ✅
- Hire Date ✅
- Status ✅

### Professional
- Job Title ✅
- Qualification ✅
- Certifications ✅
- Experience Years ✅
- Hourly Rate ✅
- Salary ✅

### Emergency
- Emergency Contact ✅
- Emergency Phone ✅

### Additional
- Trades/Skills (multi-select) ✅
- Groups (multi-select) ✅
- Notes ✅

---

## 🎯 Example: Complete Employee Creation

```typescript
// Frontend form submission
const createEmployee = async (formData) => {
  const response = await fetch('/api/v1/eam/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      // Basic
      full_name: formData.fullName,
      employee_number: formData.employeeNumber,
      email: formData.email,
      username: formData.username,
      password: formData.password,
      
      // Contact
      phone: formData.phone,
      mobile: formData.mobile,
      address: formData.address,
      city: formData.city,
      state: formData.state,
      postal_code: formData.postalCode,
      country: formData.country,
      
      // Employment
      role: formData.role,
      department_id: formData.departmentId,
      supervisor_id: formData.supervisorId,
      employee_type: formData.employeeType,
      hire_date: formData.hireDate,
      status: 'active',
      
      // Professional
      job_title: formData.jobTitle,
      qualification: formData.qualification,
      certification: formData.certification,
      experience_years: formData.experienceYears,
      hourly_rate: formData.hourlyRate,
      salary: formData.salary,
      
      // Emergency
      emergency_contact: formData.emergencyContact,
      emergency_phone: formData.emergencyPhone,
      
      // Notes
      notes: formData.notes
    })
  });
  
  const result = await response.json();
  
  // Then assign trades
  if (formData.tradeIds && formData.tradeIds.length > 0) {
    await fetch(`/api/v1/eam/trades/assign/${result.data.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ skill_ids: formData.tradeIds })
    });
  }
  
  return result;
};
```

---

## ✅ Summary

**Where Employee Data is Saved**: 
- Main table: `users` in `factorymanager` database
- Trades: `user_skills` table (links to `skills`)
- Groups: `technician_group_members` table

**What Can Be Captured**:
- ✅ 30+ employee fields
- ✅ Full contact information
- ✅ Employment details
- ✅ Professional qualifications
- ✅ Emergency contacts
- ✅ Multiple trades/skills
- ✅ Group memberships
- ✅ Department & supervisor assignment

**API Endpoints Ready**:
- `POST /api/v1/eam/users` - Create employee
- `PUT /api/v1/eam/users/{id}` - Update employee
- `GET /api/v1/eam/users/{id}` - Get full employee data
- `POST /api/v1/eam/trades/assign/{userId}` - Assign trades

All data is properly stored and can be retrieved with full relationships!
