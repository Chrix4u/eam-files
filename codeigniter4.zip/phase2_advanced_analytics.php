<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_analytics_cache (
    cache_id INT AUTO_INCREMENT PRIMARY KEY,
    metric_type VARCHAR(100) NOT NULL,
    dimension VARCHAR(100),
    time_period VARCHAR(50),
    metric_data JSON NOT NULL,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    INDEX idx_metric_type (metric_type),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$sql = "CREATE TABLE IF NOT EXISTS survey_anomalies (
    anomaly_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT NOT NULL,
    anomaly_type VARCHAR(100) NOT NULL,
    field_name VARCHAR(100),
    expected_value DECIMAL(12,2),
    actual_value DECIMAL(12,2),
    deviation_percent DECIMAL(5,2),
    severity ENUM('low', 'medium', 'high') DEFAULT 'medium',
    ml_confidence DECIMAL(5,4),
    detected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_by INT NULL,
    acknowledged_at TIMESTAMP NULL,
    INDEX idx_survey_anomaly (survey_id),
    INDEX idx_detected (detected_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

echo "✅ Advanced Analytics tables created\n";
$db->close();
