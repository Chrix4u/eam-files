# AWS Deployment Guide - Factory Manager EAM API

## Architecture Overview

```
GitHub → GitHub Actions → AWS ECR → AWS ECS Fargate → Application Load Balancer
                                    ↓
                              AWS RDS MySQL
                                    ↓
                          Automated Backups (Snapshots)
```

---

## Prerequisites

1. AWS Account
2. AWS CLI installed and configured
3. GitHub repository
4. Domain name (optional)

---

## Step 1: Setup AWS Infrastructure

### 1.1 Create VPC and Subnets
```bash
# Create VPC
aws ec2 create-vpc --cidr-block 10.0.0.0/16 --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=factorymanager-vpc}]'

# Create Public Subnets (2 for ALB)
aws ec2 create-subnet --vpc-id vpc-xxx --cidr-block 10.0.1.0/24 --availability-zone us-east-1a
aws ec2 create-subnet --vpc-id vpc-xxx --cidr-block 10.0.2.0/24 --availability-zone us-east-1b

# Create Private Subnets (2 for ECS)
aws ec2 create-subnet --vpc-id vpc-xxx --cidr-block 10.0.3.0/24 --availability-zone us-east-1a
aws ec2 create-subnet --vpc-id vpc-xxx --cidr-block 10.0.4.0/24 --availability-zone us-east-1b
```

### 1.2 Create RDS MySQL Database
```bash
aws rds create-db-instance \
  --db-instance-identifier factorymanager-db \
  --db-instance-class db.t3.micro \
  --engine mysql \
  --engine-version 8.0 \
  --master-username admin \
  --master-user-password YOUR_PASSWORD \
  --allocated-storage 20 \
  --vpc-security-group-ids sg-xxx \
  --db-subnet-group-name factorymanager-subnet-group \
  --backup-retention-period 7 \
  --preferred-backup-window "03:00-04:00" \
  --preferred-maintenance-window "mon:04:00-mon:05:00" \
  --enable-cloudwatch-logs-exports '["error","general","slowquery"]' \
  --storage-encrypted \
  --publicly-accessible false
```

### 1.3 Enable Automated RDS Backups
```bash
# Modify DB instance for automated backups
aws rds modify-db-instance \
  --db-instance-identifier factorymanager-db \
  --backup-retention-period 7 \
  --preferred-backup-window "03:00-04:00" \
  --apply-immediately

# Create manual snapshot
aws rds create-db-snapshot \
  --db-instance-identifier factorymanager-db \
  --db-snapshot-identifier factorymanager-snapshot-$(date +%Y%m%d)
```

### 1.4 Create ECR Repository
```bash
aws ecr create-repository \
  --repository-name factorymanager-api \
  --image-scanning-configuration scanOnPush=true \
  --encryption-configuration encryptionType=AES256
```

### 1.5 Create ECS Cluster
```bash
aws ecs create-cluster \
  --cluster-name factorymanager-cluster \
  --capacity-providers FARGATE FARGATE_SPOT \
  --default-capacity-provider-strategy capacityProvider=FARGATE,weight=1
```

### 1.6 Create Application Load Balancer
```bash
# Create ALB
aws elbv2 create-load-balancer \
  --name factorymanager-alb \
  --subnets subnet-xxx subnet-yyy \
  --security-groups sg-xxx \
  --scheme internet-facing \
  --type application

# Create Target Group
aws elbv2 create-target-group \
  --name factorymanager-tg \
  --protocol HTTP \
  --port 80 \
  --vpc-id vpc-xxx \
  --target-type ip \
  --health-check-path /api/v1/health \
  --health-check-interval-seconds 30

# Create Listener
aws elbv2 create-listener \
  --load-balancer-arn arn:aws:elasticloadbalancing:... \
  --protocol HTTP \
  --port 80 \
  --default-actions Type=forward,TargetGroupArn=arn:aws:elasticloadbalancing:...
```

---

## Step 2: Setup AWS Secrets Manager

### 2.1 Store Database Credentials
```bash
aws secretsmanager create-secret \
  --name factorymanager/db-host \
  --secret-string "factorymanager-db.xxx.us-east-1.rds.amazonaws.com"

aws secretsmanager create-secret \
  --name factorymanager/db-name \
  --secret-string "factory_manager"

aws secretsmanager create-secret \
  --name factorymanager/db-user \
  --secret-string "admin"

aws secretsmanager create-secret \
  --name factorymanager/db-password \
  --secret-string "YOUR_DB_PASSWORD"

aws secretsmanager create-secret \
  --name factorymanager/jwt-secret \
  --secret-string "YOUR_JWT_SECRET_KEY"
```

---

## Step 3: Create IAM Roles

### 3.1 ECS Task Execution Role
```bash
# Create trust policy
cat > trust-policy.json <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {"Service": "ecs-tasks.amazonaws.com"},
    "Action": "sts:AssumeRole"
  }]
}
EOF

# Create role
aws iam create-role \
  --role-name ecsTaskExecutionRole \
  --assume-role-policy-document file://trust-policy.json

# Attach policies
aws iam attach-role-policy \
  --role-name ecsTaskExecutionRole \
  --policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy

aws iam attach-role-policy \
  --role-name ecsTaskExecutionRole \
  --policy-arn arn:aws:iam::aws:policy/SecretsManagerReadWrite
```

### 3.2 ECS Task Role
```bash
aws iam create-role \
  --role-name ecsTaskRole \
  --assume-role-policy-document file://trust-policy.json

# Attach custom policies for S3, SES, etc. if needed
```

---

## Step 4: Register Task Definition

```bash
aws ecs register-task-definition --cli-input-json file://task-definition.json
```

---

## Step 5: Create ECS Service

```bash
aws ecs create-service \
  --cluster factorymanager-cluster \
  --service-name factorymanager-service \
  --task-definition factorymanager-task \
  --desired-count 2 \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx,subnet-yyy],securityGroups=[sg-xxx],assignPublicIp=DISABLED}" \
  --load-balancers "targetGroupArn=arn:aws:elasticloadbalancing:...,containerName=factorymanager-api,containerPort=80" \
  --health-check-grace-period-seconds 60
```

---

## Step 6: Setup GitHub Secrets

Add these secrets to your GitHub repository:

1. Go to: Settings → Secrets and variables → Actions
2. Add secrets:
   - `AWS_ACCESS_KEY_ID`
   - `AWS_SECRET_ACCESS_KEY`

---

## Step 7: Deploy

```bash
# Push to main branch
git add .
git commit -m "Deploy to AWS"
git push origin main

# GitHub Actions will automatically:
# 1. Build Docker image
# 2. Push to ECR
# 3. Update ECS service
# 4. Run migrations
```

---

## RDS Backup Configuration

### Automated Backups
```bash
# Backups are automatically enabled with:
# - Retention period: 7 days
# - Backup window: 03:00-04:00 UTC
# - Maintenance window: Monday 04:00-05:00 UTC
```

### Manual Snapshots
```bash
# Create snapshot
aws rds create-db-snapshot \
  --db-instance-identifier factorymanager-db \
  --db-snapshot-identifier factorymanager-manual-$(date +%Y%m%d-%H%M)

# List snapshots
aws rds describe-db-snapshots \
  --db-instance-identifier factorymanager-db

# Restore from snapshot
aws rds restore-db-instance-from-db-snapshot \
  --db-instance-identifier factorymanager-db-restored \
  --db-snapshot-identifier factorymanager-snapshot-20251114
```

### Automated Snapshot Lifecycle (AWS Backup)
```bash
# Create backup plan
aws backup create-backup-plan --cli-input-json '{
  "BackupPlan": {
    "BackupPlanName": "factorymanager-backup-plan",
    "Rules": [{
      "RuleName": "DailyBackups",
      "TargetBackupVaultName": "Default",
      "ScheduleExpression": "cron(0 3 * * ? *)",
      "StartWindowMinutes": 60,
      "CompletionWindowMinutes": 120,
      "Lifecycle": {
        "DeleteAfterDays": 30
      }
    }]
  }
}'

# Assign resources to backup plan
aws backup create-backup-selection --cli-input-json '{
  "BackupPlanId": "backup-plan-id",
  "BackupSelection": {
    "SelectionName": "factorymanager-db-selection",
    "IamRoleArn": "arn:aws:iam::ACCOUNT_ID:role/service-role/AWSBackupDefaultServiceRole",
    "Resources": [
      "arn:aws:rds:us-east-1:ACCOUNT_ID:db:factorymanager-db"
    ]
  }
}'
```

---

## Monitoring & Logging

### CloudWatch Logs
```bash
# Create log group
aws logs create-log-group --log-group-name /ecs/factorymanager

# View logs
aws logs tail /ecs/factorymanager --follow
```

### CloudWatch Alarms
```bash
# CPU Utilization Alarm
aws cloudwatch put-metric-alarm \
  --alarm-name factorymanager-high-cpu \
  --alarm-description "Alert when CPU exceeds 80%" \
  --metric-name CPUUtilization \
  --namespace AWS/ECS \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2

# Database Connection Alarm
aws cloudwatch put-metric-alarm \
  --alarm-name factorymanager-db-connections \
  --metric-name DatabaseConnections \
  --namespace AWS/RDS \
  --statistic Average \
  --period 300 \
  --threshold 80 \
  --comparison-operator GreaterThanThreshold
```

---

## Scaling Configuration

### Auto Scaling
```bash
# Register scalable target
aws application-autoscaling register-scalable-target \
  --service-namespace ecs \
  --resource-id service/factorymanager-cluster/factorymanager-service \
  --scalable-dimension ecs:service:DesiredCount \
  --min-capacity 2 \
  --max-capacity 10

# Create scaling policy
aws application-autoscaling put-scaling-policy \
  --service-namespace ecs \
  --resource-id service/factorymanager-cluster/factorymanager-service \
  --scalable-dimension ecs:service:DesiredCount \
  --policy-name cpu-scaling-policy \
  --policy-type TargetTrackingScaling \
  --target-tracking-scaling-policy-configuration '{
    "TargetValue": 70.0,
    "PredefinedMetricSpecification": {
      "PredefinedMetricType": "ECSServiceAverageCPUUtilization"
    },
    "ScaleInCooldown": 300,
    "ScaleOutCooldown": 60
  }'
```

---

## Cost Optimization

1. **Use Fargate Spot** for non-critical workloads (50-70% savings)
2. **RDS Reserved Instances** for production (up to 60% savings)
3. **S3 Lifecycle Policies** for log archival
4. **CloudWatch Log Retention** (7-30 days)

---

## Security Checklist

- ✅ Database in private subnet
- ✅ Secrets in AWS Secrets Manager
- ✅ IAM roles with least privilege
- ✅ Security groups properly configured
- ✅ SSL/TLS enabled (use ACM certificate)
- ✅ Automated backups enabled
- ✅ CloudWatch logging enabled
- ✅ Container image scanning enabled

---

## Useful Commands

```bash
# View ECS service status
aws ecs describe-services --cluster factorymanager-cluster --services factorymanager-service

# View running tasks
aws ecs list-tasks --cluster factorymanager-cluster --service-name factorymanager-service

# Force new deployment
aws ecs update-service --cluster factorymanager-cluster --service factorymanager-service --force-new-deployment

# View ALB health
aws elbv2 describe-target-health --target-group-arn arn:aws:elasticloadbalancing:...

# Run migrations manually
aws ecs run-task \
  --cluster factorymanager-cluster \
  --task-definition factorymanager-task \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx],assignPublicIp=ENABLED}" \
  --overrides '{"containerOverrides":[{"name":"factorymanager-api","command":["php","spark","migrate"]}]}'
```

---

## Estimated Monthly Costs

- **ECS Fargate** (2 tasks, 0.5 vCPU, 1GB): ~$30
- **RDS MySQL** (db.t3.micro): ~$15
- **Application Load Balancer**: ~$20
- **Data Transfer**: ~$10
- **CloudWatch Logs**: ~$5
- **Total**: ~$80/month

---

## Support & Troubleshooting

### Common Issues

1. **Task fails to start**: Check CloudWatch logs
2. **Health check failing**: Verify `/api/v1/health` endpoint
3. **Database connection error**: Check security groups and secrets
4. **502 Bad Gateway**: Check target group health

### Debug Commands
```bash
# Get task logs
aws logs tail /ecs/factorymanager --follow

# Describe task
aws ecs describe-tasks --cluster factorymanager-cluster --tasks task-id

# Check service events
aws ecs describe-services --cluster factorymanager-cluster --services factorymanager-service --query 'services[0].events'
```
