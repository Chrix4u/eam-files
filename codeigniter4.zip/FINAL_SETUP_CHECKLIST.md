# 🎯 Final Setup Checklist - Factory Manager EAM

## ✅ Complete This Checklist

### 1. Database Setup
- [ ] Open phpMyAdmin: `http://localhost/phpmyadmin`
- [ ] Select database: `factorymanager`
- [ ] Run SQL from: `ADD_DESCRIPTION_COLUMN.sql`
  ```sql
  ALTER TABLE `departments` 
  ADD COLUMN `description` TEXT NULL AFTER `department_name`;
  ```
- [ ] Verify column added successfully

### 2. Apache Configuration
- [ ] Open WAMP tray icon
- [ ] Click: **Apache → Apache modules**
- [ ] Enable: ☑ **headers_module**
- [ ] Enable: ☑ **rewrite_module** (should already be enabled)
- [ ] Click: **Restart All Services**
- [ ] Wait for WAMP to turn green

### 3. Next.js Configuration
- [ ] Stop Next.js dev server (Ctrl+C)
- [ ] Verify `.env.local` has:
  ```
  NEXT_PUBLIC_API_URL=http://localhost/factorymanager/public/api/v1/eam
  ```
- [ ] Start Next.js: `npm run dev`
- [ ] Wait for "Ready on http://localhost:3000"

### 4. Test CORS
- [ ] Open browser: `http://localhost:3000`
- [ ] Open DevTools (F12)
- [ ] Go to Console tab
- [ ] Run test:
  ```javascript
  fetch('http://localhost/factorymanager/public/api/v1/eam/departments')
    .then(r => r.json())
    .then(d => console.log('✅ CORS Works:', d))
    .catch(e => console.error('❌ Failed:', e));
  ```
- [ ] Should see: `✅ CORS Works: {status: "success", ...}`

### 5. Test Department Creation
- [ ] Go to: `http://localhost:3000/admin/departments`
- [ ] Click: **"+ Add Department"**
- [ ] Fill in:
  - Department Name: `Test Department`
  - Description: `This is a test`
  - Supervisor: (select one or leave as None)
- [ ] Click: **"Create"**
- [ ] Should see: ✅ Success toast
- [ ] Department should appear in list

### 6. Verify Network Requests
- [ ] Open DevTools → Network tab
- [ ] Clear network log
- [ ] Try creating another department
- [ ] Check for:
  - [ ] OPTIONS request → Status: **200 OK**
  - [ ] POST request → Status: **200 OK** or **201 Created**
  - [ ] Response headers include: `Access-Control-Allow-Origin: http://localhost:3000`

---

## 🔧 Troubleshooting

### Issue: CORS still failing

**Solution 1:** Hard refresh browser
```
Windows: Ctrl + Shift + R
Mac: Cmd + Shift + R
```

**Solution 2:** Check Apache error log
```
Location: C:\wamp64\logs\apache_error.log
Look for: mod_headers errors
```

**Solution 3:** Verify mod_headers
```
1. Create: C:\wamp64\www\test.php
2. Add: <?php phpinfo(); ?>
3. Visit: http://localhost/test.php
4. Search for: "Loaded Modules"
5. Find: mod_headers
```

**Solution 4:** Restart everything
```
1. Stop WAMP
2. Close all browsers
3. Start WAMP
4. Wait for green icon
5. Start Next.js
6. Open browser
7. Test again
```

### Issue: Department creation fails

**Check 1:** Database column exists
```sql
DESCRIBE departments;
-- Should show 'description' column
```

**Check 2:** Backend logs
```
Location: C:\wamp64\www\factorymanager\writable\logs\
Check latest log file for errors
```

**Check 3:** Browser console
```
F12 → Console tab
Look for error messages
```

---

## ✅ Success Indicators

All should be TRUE:

- ✅ WAMP icon is GREEN
- ✅ Next.js shows "Ready on http://localhost:3000"
- ✅ No CORS errors in browser console
- ✅ OPTIONS requests return 200 OK
- ✅ Department creation works
- ✅ Success toast appears
- ✅ New department appears in list
- ✅ No errors in Apache log
- ✅ No errors in CodeIgniter log

---

## 📁 Files Reference

### Backend Files
```
c:\wamp64\www\factorymanager\
├── app/
│   ├── Filters/
│   │   └── CORS.php ✅ NEW
│   ├── Config/
│   │   └── Filters.php ✅ UPDATED
│   └── Controllers/Api/V1/
│       └── DepartmentsController.php ✅ EXISTS
├── public/
│   └── .htaccess ✅ UPDATED
└── ADD_DESCRIPTION_COLUMN.sql ✅ RUN THIS
```

### Frontend Files
```
c:\devs\factorymanager\
├── .env.local ✅ UPDATED
├── src/
│   ├── lib/
│   │   └── api.ts ✅ UPDATED
│   └── app/admin/departments/
│       └── page.tsx ✅ UPDATED
└── test-cors.html ✅ TEST FILE
```

---

## 🎉 You're Ready!

Once all checkboxes are ✅, your system is fully configured and ready to use!

**What's Working:**
- ✅ CORS fully configured
- ✅ Department creation functional
- ✅ All API endpoints accessible
- ✅ No more CORS errors
- ✅ Clean URLs (no index.php)
- ✅ Authorization headers working

**Next Steps:**
1. Complete this checklist
2. Test department creation
3. Continue building your EAM system
4. Refer to documentation as needed

---

**Need Help?**
- Read: `CORS_QUICK_START.md`
- Read: `CORS_SETUP_INSTRUCTIONS.md`
- Read: `CORS_COMPLETE_SOLUTION.md`

**Status:** Ready to Deploy ✅
