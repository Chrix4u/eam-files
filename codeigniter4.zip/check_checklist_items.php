<?php

// Check if checklist items were saved
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔍 Checking Work Order Checklist Items\n";
    echo "======================================\n\n";
    
    // Check if table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'work_order_checklist_items'");
    if ($stmt->rowCount() > 0) {
        echo "✅ work_order_checklist_items table exists\n";
        
        // Check recent checklist items
        $stmt = $pdo->query("SELECT * FROM work_order_checklist_items ORDER BY completed_at DESC LIMIT 5");
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($items)) {
            echo "Recent checklist items:\n";
            foreach ($items as $item) {
                echo "  WO ID: {$item['work_order_id']}, Item ID: {$item['item_id']}, Value: {$item['value']}, Completed: {$item['completed_at']}\n";
            }
        } else {
            echo "❌ No checklist items found\n";
        }
    } else {
        echo "❌ work_order_checklist_items table does not exist\n";
        echo "Creating table...\n";
        
        $sql = "CREATE TABLE work_order_checklist_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            work_order_id INT NOT NULL,
            item_id INT NOT NULL,
            value TEXT,
            completed_by INT,
            completed_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_work_order (work_order_id)
        )";
        
        $pdo->exec($sql);
        echo "✅ Table created successfully\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}