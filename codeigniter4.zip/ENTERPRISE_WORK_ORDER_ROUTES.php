<?php

/**
 * Enterprise Work Order Module Routes
 * Add these routes to app/Config/RoutesEam.php
 */

// Work Order Team Management
$routes->group('api/v1/eam/work-orders/(:num)', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    // Team Management
    $routes->get('team', 'WorkOrderTeamController::getTeamMembers/$1');
    $routes->post('team', 'WorkOrderTeamController::addTeamMember/$1');
    $routes->delete('team/(:num)', 'WorkOrderTeamController::removeTeamMember/$1/$2');
    
    // Time Tracking
    $routes->post('time-log', 'WorkOrderTeamController::logTime/$1');
    $routes->get('time-logs/(:num)', 'WorkOrderTeamController::getTimeLogs/$1/$2');
    
    // Timeline
    $routes->get('timeline', 'WorkOrderAnalyticsController::timeline/$1');
});

// Assistance Requests
$routes->group('api/v1/eam/assistance-requests', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    $routes->get('/', 'AssistanceRequestController::index');
    $routes->get('pending', 'AssistanceRequestController::getPending');
    $routes->post('/', 'AssistanceRequestController::create');
    $routes->post('(:num)/approve', 'AssistanceRequestController::approve/$1');
    $routes->post('(:num)/reject', 'AssistanceRequestController::reject/$1');
});

// Technician Groups
$routes->group('api/v1/eam/technician-groups', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    $routes->get('/', 'TechnicianGroupController::index');
    $routes->get('(:num)', 'TechnicianGroupController::show/$1');
    $routes->post('/', 'TechnicianGroupController::create');
    $routes->put('(:num)', 'TechnicianGroupController::update/$1');
    $routes->post('(:num)/members', 'TechnicianGroupController::addMember/$1');
    $routes->delete('(:num)/members/(:num)', 'TechnicianGroupController::removeMember/$1/$2');
});

// Analytics & Reports
$routes->group('api/v1/eam/analytics', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    $routes->get('performance', 'WorkOrderAnalyticsController::performance');
    $routes->get('technician-productivity', 'WorkOrderAnalyticsController::technicianProductivity');
    $routes->get('material-consumption', 'WorkOrderAnalyticsController::materialConsumption');
    $routes->get('failure-analysis', 'WorkOrderAnalyticsController::failureAnalysis');
    $routes->get('dashboard-kpis', 'WorkOrderAnalyticsController::dashboardKPIs');
});
