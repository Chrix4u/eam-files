<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS scheduled_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_type VARCHAR(100) NOT NULL,
    frequency ENUM('daily', 'weekly', 'monthly') NOT NULL,
    format ENUM('pdf', 'excel', 'csv') DEFAULT 'pdf',
    recipients JSON NOT NULL,
    filters JSON NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_run DATETIME NULL,
    next_run DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($db->query($sql)) {
    echo "✓ Table 'scheduled_reports' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql2 = "CREATE TABLE IF NOT EXISTS custom_reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    query_config JSON NOT NULL,
    created_by INT NOT NULL,
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($db->query($sql2)) {
    echo "✓ Table 'custom_reports' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$db->close();
?>
