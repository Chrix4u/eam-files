-- Work Order Templates
CREATE TABLE IF NOT EXISTS `work_order_templates` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `template_name` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `type` ENUM('breakdown', 'preventive', 'corrective', 'inspection', 'project') DEFAULT 'preventive',
  `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  `estimated_hours` DECIMAL(10,2) NULL,
  `instructions` TEXT NULL,
  `safety_notes` TEXT NULL,
  `checklist` JSON NULL,
  `required_parts` JSON NULL,
  `created_by` INT(11) UNSIGNED NOT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Recurring Work Orders
CREATE TABLE IF NOT EXISTS `recurring_work_orders` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `template_id` INT(11) UNSIGNED NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `machine_id` INT(11) UNSIGNED NULL,
  `department_id` INT(11) UNSIGNED NOT NULL,
  `assigned_to` INT(11) UNSIGNED NULL,
  `frequency` ENUM('daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'semiannual', 'annual') DEFAULT 'monthly',
  `start_date` DATE NOT NULL,
  `end_date` DATE NULL,
  `next_due_date` DATE NOT NULL,
  `last_generated` DATETIME NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  `type` ENUM('breakdown', 'preventive', 'corrective', 'inspection', 'project') DEFAULT 'preventive',
  `estimated_hours` DECIMAL(10,2) NULL,
  `created_by` INT(11) UNSIGNED NOT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `next_due_date` (`next_due_date`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add columns to work_orders if not exists
ALTER TABLE `work_orders` 
ADD COLUMN IF NOT EXISTS `template_id` INT(11) UNSIGNED NULL AFTER `id`,
ADD COLUMN IF NOT EXISTS `recurring_id` INT(11) UNSIGNED NULL AFTER `template_id`;
