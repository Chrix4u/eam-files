-- =====================================================
-- GRADE A+ MAINTENANCE REQUEST SYSTEM - SIMPLE FIXES
-- =====================================================

USE factory_manager;

-- Drop existing triggers and procedures
DROP TRIGGER IF EXISTS trg_maintenance_request_sla_insert;
DROP PROCEDURE IF EXISTS sp_calculate_sla;

-- Create workflow history table
CREATE TABLE IF NOT EXISTS maintenance_request_workflow (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(50),
    to_status VARCHAR(50) NOT NULL,
    action_by INT UNSIGNED NOT NULL,
    action_type ENUM('created','reviewed','approved','rejected','assigned','converted','completed','commented') NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_action_by (action_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create notifications table
CREATE TABLE IF NOT EXISTS maintenance_notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    request_id INT UNSIGNED NULL,
    work_order_id INT UNSIGNED NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    INDEX idx_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create attachments table
CREATE TABLE IF NOT EXISTS maintenance_attachments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(100),
    file_size INT UNSIGNED,
    uploaded_by INT UNSIGNED NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create comments table
CREATE TABLE IF NOT EXISTS maintenance_comments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create SLA configuration table
CREATE TABLE IF NOT EXISTS maintenance_sla_config (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    priority ENUM('low','medium','high','urgent') NOT NULL UNIQUE,
    response_time_hours INT NOT NULL,
    resolution_time_hours INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert default SLA configurations
INSERT IGNORE INTO maintenance_sla_config (priority, response_time_hours, resolution_time_hours) VALUES
('urgent', 1, 4),
('high', 4, 24),
('medium', 8, 72),
('low', 24, 168);

-- Create work_orders table
CREATE TABLE IF NOT EXISTS work_orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
    status ENUM('open','in_progress','on_hold','completed','cancelled') DEFAULT 'open',
    work_type ENUM('corrective','preventive','predictive','inspection') DEFAULT 'corrective',
    machine_id INT UNSIGNED NULL,
    assembly_id INT UNSIGNED NULL,
    part_id INT UNSIGNED NULL,
    location VARCHAR(255),
    assigned_to INT UNSIGNED NULL,
    scheduled_date DATETIME NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    estimated_hours DECIMAL(10,2),
    actual_hours DECIMAL(10,2),
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_assigned_to (assigned_to)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SELECT '✅ Grade A+ Database Tables Created!' as Status;
