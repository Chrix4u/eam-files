<?php
/**
 * Work Order Management Module - Database Schema
 * Creates all required tables for the Work Order Management system
 */

require __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$host = $_ENV['database_default_hostname'] ?? 'localhost';
$database = $_ENV['database_default_database'] ?? 'factory_manager';
$username = $_ENV['database_default_username'] ?? 'root';
$password = $_ENV['database_default_password'] ?? '';

try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to MySQL server\n";
    
    // Create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$database` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$database`");
    
    echo "Using database: $database\n";
    
    // Work Orders Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `work_orders` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `wo_number` VARCHAR(50) UNIQUE NOT NULL,
            `title` VARCHAR(255) NOT NULL,
            `description` TEXT,
            `asset_id` INT UNSIGNED,
            `related_pm_id` INT UNSIGNED,
            `requestor_id` INT UNSIGNED,
            `planner_id` INT UNSIGNED,
            `assigned_user_id` INT UNSIGNED,
            `assigned_group_id` INT UNSIGNED,
            `priority` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
            `status` ENUM('requested', 'approved', 'planned', 'assigned', 'in_progress', 'waiting_parts', 'on_hold', 'completed', 'closed', 'cancelled') DEFAULT 'requested',
            `type` ENUM('breakdown', 'corrective', 'inspection', 'lubrication', 'emergency', 'safety', 'improvement', 'preventive') NOT NULL,
            `estimated_hours` DECIMAL(10,2),
            `actual_hours` DECIMAL(10,2),
            `planned_start` DATETIME,
            `planned_end` DATETIME,
            `actual_start` DATETIME,
            `actual_end` DATETIME,
            `sla_hours` DECIMAL(10,2),
            `sla_started_at` DATETIME,
            `sla_breached_at` DATETIME,
            `version` INT UNSIGNED DEFAULT 0,
            `total_cost` DECIMAL(12,2) DEFAULT 0,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_wo_number` (`wo_number`),
            INDEX `idx_asset_id` (`asset_id`),
            INDEX `idx_status` (`status`),
            INDEX `idx_assigned_user` (`assigned_user_id`),
            INDEX `idx_priority` (`priority`),
            INDEX `idx_type` (`type`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ work_orders table created\n";
    
    // Work Order Materials Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `work_order_materials` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `work_order_id` INT UNSIGNED NOT NULL,
            `inventory_item_id` INT UNSIGNED NOT NULL,
            `quantity_required` DECIMAL(10,2) NOT NULL,
            `quantity_reserved` DECIMAL(10,2) DEFAULT 0,
            `quantity_issued` DECIMAL(10,2) DEFAULT 0,
            `unit_cost` DECIMAL(10,2),
            `status` ENUM('required', 'reserved', 'issued', 'returned') DEFAULT 'required',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_work_order` (`work_order_id`),
            INDEX `idx_inventory_item` (`inventory_item_id`),
            FOREIGN KEY (`work_order_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ work_order_materials table created\n";
    
    // Work Order Attachments Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `work_order_attachments` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `work_order_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED,
            `filename` VARCHAR(255) NOT NULL,
            `original_name` VARCHAR(255) NOT NULL,
            `file_path` VARCHAR(500) NOT NULL,
            `file_size` INT UNSIGNED,
            `mime_type` VARCHAR(100),
            `thumbnail_path` VARCHAR(500),
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_work_order` (`work_order_id`),
            FOREIGN KEY (`work_order_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ work_order_attachments table created\n";
    
    // Work Order Logs Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `work_order_logs` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `work_order_id` INT UNSIGNED NOT NULL,
            `user_id` INT UNSIGNED,
            `action` VARCHAR(50) NOT NULL,
            `old_status` VARCHAR(50),
            `new_status` VARCHAR(50),
            `notes` TEXT,
            `details` JSON,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_work_order` (`work_order_id`),
            INDEX `idx_action` (`action`),
            FOREIGN KEY (`work_order_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ work_order_logs table created\n";
    
    // Inventory Items Table (if not exists)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `inventory_items` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `item_code` VARCHAR(50) UNIQUE NOT NULL,
            `item_name` VARCHAR(255) NOT NULL,
            `description` TEXT,
            `category` VARCHAR(100),
            `unit_of_measure` VARCHAR(20),
            `unit_cost` DECIMAL(10,2),
            `quantity_on_hand` DECIMAL(10,2) DEFAULT 0,
            `quantity_reserved` DECIMAL(10,2) DEFAULT 0,
            `reorder_point` DECIMAL(10,2),
            `reorder_quantity` DECIMAL(10,2),
            `location` VARCHAR(100),
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_item_code` (`item_code`),
            INDEX `idx_category` (`category`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ inventory_items table created\n";
    
    // Stock Transactions Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `stock_transactions` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `inventory_item_id` INT UNSIGNED NOT NULL,
            `transaction_type` ENUM('receipt', 'issue', 'return', 'adjustment', 'reserve', 'release') NOT NULL,
            `quantity` DECIMAL(10,2) NOT NULL,
            `reference` VARCHAR(100),
            `notes` TEXT,
            `user_id` INT UNSIGNED,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_inventory_item` (`inventory_item_id`),
            INDEX `idx_transaction_type` (`transaction_type`),
            FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ stock_transactions table created\n";
    
    // Assets Table (if not exists)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `assets` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `asset_code` VARCHAR(50) UNIQUE NOT NULL,
            `asset_name` VARCHAR(255) NOT NULL,
            `description` TEXT,
            `asset_type` VARCHAR(100),
            `location` VARCHAR(255),
            `status` ENUM('active', 'inactive', 'maintenance', 'retired') DEFAULT 'active',
            `criticality` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_asset_code` (`asset_code`),
            INDEX `idx_status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ assets table created\n";
    
    // Technicians/Users Table (if not exists)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `users` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `username` VARCHAR(100) UNIQUE NOT NULL,
            `email` VARCHAR(255) UNIQUE,
            `password` VARCHAR(255) NOT NULL,
            `full_name` VARCHAR(255),
            `role` VARCHAR(50),
            `is_active` TINYINT(1) DEFAULT 1,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX `idx_username` (`username`),
            INDEX `idx_role` (`role`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ users table created\n";
    
    // Work Order Checklist Items Table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS `work_order_checklist_items` (
            `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            `work_order_id` INT UNSIGNED NOT NULL,
            `item_id` INT UNSIGNED,
            `description` VARCHAR(255),
            `value` TEXT,
            `completed_by` INT UNSIGNED,
            `completed_at` TIMESTAMP,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX `idx_work_order` (`work_order_id`),
            FOREIGN KEY (`work_order_id`) REFERENCES `work_orders`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    ");
    echo "✓ work_order_checklist_items table created\n";
    
    echo "\n✅ All Work Order Management tables created successfully!\n";
    
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
