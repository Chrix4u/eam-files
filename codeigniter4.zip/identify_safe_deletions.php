<?php
/**
 * Identify safe-to-delete duplicate controllers
 * Only marks files that are truly redundant
 */

echo "=== IDENTIFYING SAFE DELETIONS ===\n\n";

$duplicates = [
    // These are TRUE duplicates (same functionality, different location)
    'SAFE_TO_DELETE' => [
        'app/Controllers/Api/V1/AssetsController.php' => 'Replaced by Asset/AssetsUnifiedController.php',
        'app/Controllers/Api/V1/AssetUnifiedController.php' => 'Replaced by Asset/AssetsUnifiedController.php',
        'app/Controllers/Api/V1/AssetTreeController.php' => 'Replaced by Asset/TreeController.php',
        'app/Controllers/Api/V1/AssetHierarchyController.php' => 'Replaced by Asset/HierarchyController.php',
    ],
    
    // These should be KEPT (different purposes)
    'KEEP' => [
        'app/Controllers/Api/V1/Asset/AssetsUnifiedController.php' => 'PRIMARY - Uses unified schema',
        'app/Controllers/Api/V1/Asset/MachinesController.php' => 'Handles detailed machine data',
        'app/Controllers/Api/V1/MachineController.php' => 'Legacy API support',
        'app/Controllers/Api/V1/BaseApiController.php' => 'Base class for all controllers',
    ]
];

echo "SAFE TO DELETE:\n";
foreach ($duplicates['SAFE_TO_DELETE'] as $file => $reason) {
    $fullPath = "c:\\wamp64\\www\\factorymanager\\$file";
    $exists = file_exists($fullPath) ? '✓ EXISTS' : '✗ NOT FOUND';
    echo "  $exists - $file\n";
    echo "    Reason: $reason\n\n";
}

echo "\nKEEP (DO NOT DELETE):\n";
foreach ($duplicates['KEEP'] as $file => $reason) {
    echo "  ✓ $file\n";
    echo "    Reason: $reason\n\n";
}

echo "\n=== RECOMMENDATION ===\n";
echo "Delete 4 duplicate controllers that are truly redundant.\n";
echo "Keep all others for backward compatibility and different use cases.\n\n";

echo "Run delete_duplicate_controllers.php to proceed with deletion.\n";
?>
