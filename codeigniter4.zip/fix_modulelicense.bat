@echo off
echo Removing modulelicense filter from route files...

cd c:\wamp64\www\factorymanager\app\Config\Routes

for %%f in (ASSET.php DIGITAL_TWIN.php HRMS.php IMS.php IOT.php MOBILE.php MPMP.php MRMP.php REPORTS.php RWOP.php TRAC.php) do (
    echo Processing %%f...
    powershell -Command "(Get-Content '%%f') -replace ', ''modulelicense''', '' | Set-Content '%%f'"
    powershell -Command "(Get-Content '%%f') -replace '''modulelicense'', ', '' | Set-Content '%%f'"
    powershell -Command "(Get-Content '%%f') -replace '\|modulelicense', '' | Set-Content '%%f'"
)

echo Done!
pause
