<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();

echo "Checking database tables...\n\n";

$requiredTables = [
    'assets',
    'work_orders',
    'users',
    'iot_alerts',
    'machines',
    'assemblies',
    'parts'
];

$existingTables = $db->listTables();

echo "Existing tables: " . count($existingTables) . "\n";
foreach ($existingTables as $table) {
    echo "  ✓ $table\n";
}

echo "\nMissing required tables:\n";
$missing = array_diff($requiredTables, $existingTables);
if (empty($missing)) {
    echo "  None - all required tables exist!\n";
} else {
    foreach ($missing as $table) {
        echo "  ✗ $table\n";
    }
}
