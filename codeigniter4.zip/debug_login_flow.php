<?php
// Bootstrap CodeIgniter
define('FCPATH', __DIR__ . '/public/');
require_once __DIR__ . '/vendor/autoload.php';

$app = \Config\Services::codeigniter();
$app->initialize();

echo "=== COMPLETE LOGIN FLOW DEBUG ===\n\n";

// Test 1: Database Connection
echo "1. Testing Database Connection...\n";
$db = \Config\Database::connect();
if ($db->connID) {
    echo "✓ Database connected\n\n";
} else {
    echo "✗ Database connection failed\n";
    exit(1);
}

// Test 2: Check Users Table
echo "2. Checking users table...\n";
$users = $db->table('users')->select('id, username, email, role')->get()->getResultArray();
echo "Found " . count($users) . " users:\n";
foreach ($users as $user) {
    echo "  - {$user['username']} ({$user['email']}) - Role: {$user['role']}\n";
}
echo "\n";

// Test 3: Test operator1 password
echo "3. Testing operator1 password...\n";
$operator = $db->table('users')->where('username', 'operator1')->get()->getRowArray();
if ($operator) {
    $testPassword = 'password';
    $verified = password_verify($testPassword, $operator['password']);
    echo "Password hash: " . substr($operator['password'], 0, 30) . "...\n";
    echo "Test password: '$testPassword'\n";
    echo "Verification: " . ($verified ? "✓ PASS" : "✗ FAIL") . "\n\n";
} else {
    echo "✗ operator1 not found\n\n";
}

// Test 4: Simulate Login Request
echo "4. Simulating login request...\n";
$loginData = [
    'username' => 'operator1',
    'password' => 'password'
];

$authService = new \App\Services\EamAuthService();
$result = $authService->login($loginData);

echo "Login result:\n";
echo json_encode($result, JSON_PRETTY_PRINT) . "\n\n";

// Test 5: Test JWT Token
if ($result['status'] === 'success' && isset($result['data']['tokens']['access_token'])) {
    echo "5. Testing JWT Token...\n";
    $token = $result['data']['tokens']['access_token'];
    echo "Token (first 50 chars): " . substr($token, 0, 50) . "...\n";
    
    try {
        $parts = explode('.', $token);
        if (count($parts) === 3) {
            $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);
            echo "Token payload:\n";
            echo json_encode($payload, JSON_PRETTY_PRINT) . "\n";
            echo "✓ Token is valid JWT format\n\n";
        }
    } catch (Exception $e) {
        echo "✗ Token decode failed: " . $e->getMessage() . "\n\n";
    }
    
    // Test 6: Test actual HTTP request
    echo "6. Testing actual HTTP login request...\n";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://localhost/factorymanager/public/index.php/api/v1/eam/auth/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($loginData));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP Code: $httpCode\n";
    echo "Response: " . substr($response, 0, 300) . "\n";
} else {
    echo "✗ Login failed, cannot test token\n";
}

echo "\n=== DEBUG COMPLETE ===\n";
