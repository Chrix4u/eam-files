# Factory Manager - REST API Restructure Plan

## New Folder Structure

```
factorymanager/
├── app/
│   ├── Config/
│   │   ├── Routes.php (API routes only)
│   │   └── JWT.php (JWT configuration)
│   │
│   ├── Controllers/
│   │   └── Api/
│   │       └── V1/
│   │           ├── AuthController.php
│   │           ├── AssetsController.php
│   │           ├── AssetHierarchyController.php
│   │           ├── PreventiveMaintenanceController.php
│   │           ├── WorkOrdersController.php
│   │           ├── InventoryController.php
│   │           ├── ProductionController.php
│   │           ├── NotificationsController.php
│   │           └── UsersController.php
│   │
│   ├── Services/
│   │   ├── AuthService.php
│   │   ├── AssetService.php
│   │   ├── AssetHierarchyService.php
│   │   ├── PreventiveMaintenanceService.php
│   │   ├── WorkOrderService.php
│   │   ├── InventoryService.php
│   │   ├── ProductionService.php
│   │   ├── NotificationService.php
│   │   └── UserService.php
│   │
│   ├── Repositories/
│   │   ├── AssetRepository.php
│   │   ├── EquipmentRepository.php
│   │   ├── AssemblyRepository.php
│   │   ├── PartRepository.php
│   │   ├── PmScheduleRepository.php
│   │   ├── WorkOrderRepository.php
│   │   ├── InventoryRepository.php
│   │   ├── ProductionRepository.php
│   │   ├── NotificationRepository.php
│   │   └── UserRepository.php
│   │
│   ├── Filters/
│   │   ├── JWTAuthFilter.php
│   │   ├── CorsFilter.php
│   │   └── RateLimitFilter.php
│   │
│   ├── Libraries/
│   │   ├── JWT/
│   │   │   ├── JWTHandler.php
│   │   │   └── TokenBlacklist.php
│   │   ├── ApiResponse.php
│   │   └── Pagination.php
│   │
│   ├── Traits/
│   │   ├── ApiResponseTrait.php
│   │   └── PaginationTrait.php
│   │
│   ├── Validation/
│   │   ├── AssetRules.php
│   │   ├── WorkOrderRules.php
│   │   └── UserRules.php
│   │
│   └── Database/
│       └── Migrations/ (existing)
│
├── public/
│   └── index.php (API entry point only)
│
└── tests/
    └── Api/
        └── V1/
            ├── AuthTest.php
            ├── AssetsTest.php
            └── WorkOrdersTest.php
```

## Module Breakdown

### 1. Auth Module
- POST /api/v1/auth/login
- POST /api/v1/auth/register
- POST /api/v1/auth/refresh
- POST /api/v1/auth/logout
- GET /api/v1/auth/me

### 2. Assets Module
- GET /api/v1/assets (list with pagination, search, sort)
- GET /api/v1/assets/{id}
- POST /api/v1/assets
- PUT /api/v1/assets/{id}
- DELETE /api/v1/assets/{id}
- GET /api/v1/assets/{id}/maintenance-history

### 3. AssetHierarchy Module
- GET /api/v1/equipment
- GET /api/v1/equipment/{id}/assemblies
- GET /api/v1/assemblies/{id}/parts
- POST /api/v1/equipment/{id}/assemblies
- POST /api/v1/assemblies/{id}/parts

### 4. PreventiveMaintenance Module
- GET /api/v1/pm/schedules
- POST /api/v1/pm/schedules
- GET /api/v1/pm/schedules/{id}
- PUT /api/v1/pm/schedules/{id}
- GET /api/v1/pm/tasks
- POST /api/v1/pm/generate-work-orders

### 5. WorkOrders Module
- GET /api/v1/work-orders
- POST /api/v1/work-orders
- GET /api/v1/work-orders/{id}
- PUT /api/v1/work-orders/{id}
- PATCH /api/v1/work-orders/{id}/status
- POST /api/v1/work-orders/{id}/complete

### 6. Inventory Module
- GET /api/v1/inventory/parts
- GET /api/v1/inventory/parts/{id}
- POST /api/v1/inventory/parts
- PUT /api/v1/inventory/parts/{id}
- PATCH /api/v1/inventory/parts/{id}/stock
- GET /api/v1/inventory/low-stock

### 7. Production Module
- GET /api/v1/production/surveys
- POST /api/v1/production/surveys
- GET /api/v1/production/reports
- GET /api/v1/production/equipment/{id}/performance

### 8. Notifications Module
- GET /api/v1/notifications
- PATCH /api/v1/notifications/{id}/read
- DELETE /api/v1/notifications/{id}
- GET /api/v1/notifications/unread-count

### 9. Users & Roles Module
- GET /api/v1/users
- GET /api/v1/users/{id}
- POST /api/v1/users
- PUT /api/v1/users/{id}
- DELETE /api/v1/users/{id}
- GET /api/v1/roles
- POST /api/v1/roles

## Implementation Steps

1. Install JWT library: `composer require firebase/php-jwt`
2. Create new folder structure
3. Implement base classes (ApiResponse, Pagination, JWT)
4. Create repositories for data access
5. Create services for business logic
6. Create API controllers
7. Configure routes with versioning
8. Add JWT authentication filter
9. Remove all view files
10. Update documentation

## Response Format Standard

```json
{
  "success": true,
  "message": "Operation successful",
  "data": {},
  "meta": {
    "pagination": {
      "current_page": 1,
      "per_page": 20,
      "total": 100,
      "total_pages": 5
    }
  }
}
```

## Error Response Format

```json
{
  "success": false,
  "message": "Error message",
  "errors": {
    "field": ["Validation error"]
  },
  "code": 400
}
```
