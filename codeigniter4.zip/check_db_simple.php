<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "✓ Database connected\n\n";

$result = mysqli_query($db, "SHOW TABLES");
$tables = [];
while ($row = mysqli_fetch_array($result)) {
    $tables[] = $row[0];
}

echo "Existing tables (" . count($tables) . "):\n";
foreach ($tables as $table) {
    echo "  ✓ $table\n";
}

$required = ['assets', 'work_orders', 'users', 'machines', 'assemblies', 'parts'];
$missing = array_diff($required, $tables);

if (!empty($missing)) {
    echo "\nMissing tables:\n";
    foreach ($missing as $table) {
        echo "  ✗ $table\n";
    }
}

mysqli_close($db);
