<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_workflow_rules (
    rule_id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(255) NOT NULL,
    rule_type ENUM('auto_assign', 'auto_escalate', 'auto_approve', 'conditional_routing') NOT NULL,
    conditions JSON NOT NULL,
    actions JSON NOT NULL,
    priority INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rule_type (rule_type, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$sql = "CREATE TABLE IF NOT EXISTS survey_workflow_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT NOT NULL,
    rule_id INT,
    action_type VARCHAR(100) NOT NULL,
    from_status VARCHAR(50),
    to_status VARCHAR(50),
    from_user_id INT,
    to_user_id INT,
    automated BOOLEAN DEFAULT FALSE,
    metadata JSON,
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_survey_workflow (survey_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$fields = [
    "auto_assigned BOOLEAN DEFAULT FALSE",
    "escalation_level INT DEFAULT 0",
    "escalated_at TIMESTAMP NULL"
];
foreach ($fields as $field) {
    $db->query("ALTER TABLE production_surveys ADD COLUMN $field");
}

echo "✅ Workflow Automation tables created\n";
$db->close();
