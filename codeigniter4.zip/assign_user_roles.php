<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

echo "=== Assigning User Roles ===\n\n";

// 1. Get all users
echo "1. Fetching existing users...\n";
$users = [];
$result = $mysqli->query("SELECT id, email FROM users WHERE status = 'active' LIMIT 50");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
echo "   Found " . count($users) . " active users\n\n";

// 2. Get default role (technician)
echo "2. Getting default role...\n";
$roleResult = $mysqli->query("SELECT id FROM roles WHERE role_code = 'technician'");
if (!$roleResult || $roleResult->num_rows === 0) {
    die("   ✗ Technician role not found!\n");
}
$roleRow = $roleResult->fetch_assoc();
$technicianRoleId = $roleRow['id'];
echo "   ✓ Technician role ID: $technicianRoleId\n\n";

// 3. Assign technician role to all users
echo "3. Assigning default role to users...\n";
$assignCount = 0;
$existingCount = 0;

foreach ($users as $user) {
    $userId = $user['id'];
    
    // Check if user already has a role
    $check = $mysqli->query("SELECT id FROM user_roles WHERE user_id = $userId");
    if ($check && $check->num_rows > 0) {
        $existingCount++;
        continue;
    }
    
    // Assign technician role
    $sql = "INSERT INTO user_roles (user_id, role_id, assigned_at) VALUES ($userId, $technicianRoleId, NOW())";
    if ($mysqli->query($sql)) {
        $assignCount++;
        echo "   ✓ User {$user['email']} assigned to technician role\n";
    } else {
        echo "   ✗ Failed to assign role to user {$user['email']} - " . $mysqli->error . "\n";
    }
}

echo "\n=== Assignment Complete ===\n";
echo "New assignments: $assignCount\n";
echo "Already assigned: $existingCount\n";

// 4. Verify assignments
echo "\n4. Verifying role assignments...\n";
$summary = $mysqli->query("
    SELECT r.role_code, COUNT(ur.id) as user_count
    FROM roles r
    LEFT JOIN user_roles ur ON r.id = ur.role_id
    GROUP BY r.id, r.role_code
    ORDER BY r.id
");

if ($summary) {
    while ($row = $summary->fetch_assoc()) {
        echo "   • {$row['role_code']}: {$row['user_count']} users assigned\n";
    }
}

$mysqli->close();
?>
