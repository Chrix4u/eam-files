<?php
/**
 * Standalone Database Audit Script
 */

$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "=== DATABASE AUDIT: factory_manager ===\n\n";
    
    // Get all tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "Total Tables: " . count($tables) . "\n\n";
    
    $auditData = [];
    $companyTables = [];
    $plantTables = [];
    
    foreach ($tables as $table) {
        $stmt = $pdo->query("DESCRIBE `$table`");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $auditData[$table] = [
            'columns' => $columns,
            'column_count' => count($columns)
        ];
        
        echo "Table: $table (" . count($columns) . " columns)\n";
        foreach ($columns as $col) {
            echo "  - {$col['Field']} ({$col['Type']}) {$col['Null']}\n";
            
            if (stripos($col['Field'], 'company') !== false) {
                $companyTables[$table][] = $col['Field'];
            }
            if (stripos($col['Field'], 'plant') !== false) {
                $plantTables[$table][] = $col['Field'];
            }
        }
        echo "\n";
    }
    
    // Save to JSON
    file_put_contents('database_audit.json', json_encode($auditData, JSON_PRETTY_PRINT));
    
    echo "\n=== TABLES WITH COMPANY_ID ===\n";
    foreach ($companyTables as $table => $cols) {
        echo "$table -> " . implode(', ', $cols) . "\n";
    }
    
    echo "\n=== TABLES WITH PLANT_ID ===\n";
    foreach ($plantTables as $table => $cols) {
        echo "$table -> " . implode(', ', $cols) . "\n";
    }
    
    echo "\n=== TABLES WITHOUT PLANT_ID (May need it) ===\n";
    $needsPlantId = [];
    foreach ($auditData as $table => $data) {
        $hasPlantId = false;
        foreach ($data['columns'] as $col) {
            if (stripos($col['Field'], 'plant') !== false) {
                $hasPlantId = true;
                break;
            }
        }
        if (!$hasPlantId && !in_array($table, ['migrations', 'modules', 'module_activation_logs', 'plants', 'user_plant_access'])) {
            $needsPlantId[] = $table;
        }
    }
    foreach ($needsPlantId as $table) {
        echo "  - $table\n";
    }
    
    echo "\nAudit complete! Data saved to database_audit.json\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
