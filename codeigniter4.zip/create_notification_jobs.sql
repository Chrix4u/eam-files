-- Create notification_jobs table manually
CREATE TABLE IF NOT EXISTS `notification_jobs` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) UNSIGNED NOT NULL,
    `channel` ENUM('in_app', 'email', 'sms') NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `data` JSON NOT NULL,
    `status` ENUM('pending', 'processing', 'completed', 'failed') NOT NULL DEFAULT 'pending',
    `attempts` INT(3) NOT NULL DEFAULT 0,
    `error` TEXT NULL,
    `created_at` DATETIME NULL,
    `processed_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `status_created_at` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verify table created
SELECT 'notification_jobs table created successfully' as status;
DESCRIBE notification_jobs;
