<?php

$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS company_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(100),
    website VARCHAR(255),
    logo VARCHAR(255),
    created_at DATETIME,
    updated_at DATETIME
)";

if ($conn->query($sql) === TRUE) {
    echo "Table company_settings created successfully\n";
    
    $insert = "INSERT INTO company_settings (company_name, created_at) VALUES ('GTP', NOW())";
    if ($conn->query($insert) === TRUE) {
        echo "Default company data inserted\n";
    }
} else {
    echo "Error: " . $conn->error . "\n";
}

$conn->close();
