<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_translations (
    translation_id INT AUTO_INCREMENT PRIMARY KEY,
    entity_type ENUM('template', 'field', 'instruction', 'alert') NOT NULL,
    entity_id INT NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    language_code VARCHAR(10) NOT NULL,
    translated_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_translation (entity_type, entity_id, field_name, language_code),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_language (language_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$db->query("ALTER TABLE production_surveys ADD COLUMN language_code VARCHAR(10) DEFAULT 'en'");

echo "✅ Multi-language table created\n";
$db->close();
