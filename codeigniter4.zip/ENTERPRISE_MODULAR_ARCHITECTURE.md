# Enterprise Modular EAM System Architecture

**Version**: 3.0.0  
**Architecture Type**: Modular Monolith with Microservices-Ready Design  
**Status**: Production-Grade Blueprint

---

## 1. SYSTEM OVERVIEW

### 1.1 Architecture Philosophy
- **Modular Monolith**: Single deployment, independent modules
- **Domain-Driven Design (DDD)**: Business logic organized by domain
- **Clean Architecture**: Dependency inversion, testability
- **API-First**: Backend as service layer for any frontend

### 1.2 Core Modules
1. **Core Platform** - Authentication, RBAC, Audit, Notifications
2. **RWOP** - Repair Work Order Program
3. **MRMP** - Machine Reliability Maintenance Program  
4. **MPMP** - Manufacturing Production Management Program
5. **IMS** - Inventory Management System
6. **HRMS** - Human Resources Management System

---

## 2. BACKEND ARCHITECTURE (CodeIgniter 4)

### 2.1 Folder Structure

```
app/
├── Core/                           # Core Platform Layer
│   ├── Authentication/
│   │   ├── Controllers/
│   │   │   └── AuthController.php
│   │   ├── Services/
│   │   │   ├── AuthService.php
│   │   │   └── JWTService.php
│   │   ├── Middleware/
│   │   │   └── AuthMiddleware.php
│   │   └── Models/
│   │       └── UserModel.php
│   │
│   ├── Authorization/
│   │   ├── Services/
│   │   │   ├── RBACService.php
│   │   │   └── PermissionService.php
│   │   ├── Middleware/
│   │   │   └── PermissionMiddleware.php
│   │   └── Models/
│   │       ├── RoleModel.php
│   │       └── PermissionModel.php
│   │
│   ├── AuditLog/
│   │   ├── Services/
│   │   │   └── AuditService.php
│   │   ├── Middleware/
│   │   │   └── AuditMiddleware.php
│   │   └── Models/
│   │       └── AuditLogModel.php
│   │
│   ├── Notification/
│   │   ├── Services/
│   │   │   ├── NotificationService.php
│   │   │   ├── EmailService.php
│   │   │   └── SMSService.php
│   │   └── Models/
│   │       └── NotificationModel.php
│   │
│   ├── FileManagement/
│   │   ├── Services/
│   │   │   └── FileService.php
│   │   └── Models/
│   │       └── FileModel.php
│   │
│   ├── ModuleManager/
│   │   ├── Services/
│   │   │   └── ModuleService.php
│   │   ├── Controllers/
│   │   │   └── ModuleController.php
│   │   ├── Middleware/
│   │   │   └── ModuleAccessMiddleware.php
│   │   └── Models/
│   │       └── ModuleModel.php
│   │
│   └── Settings/
│       ├── Services/
│       │   └── SettingsService.php
│       └── Models/
│           └── SettingModel.php
│
├── Modules/                        # Business Modules
│   ├── RWOP/                       # Repair Work Order Program
│   │   ├── Controllers/
│   │   │   ├── WorkOrderController.php
│   │   │   ├── MaintenanceRequestController.php
│   │   │   └── WorkOrderCompletionController.php
│   │   ├── Services/
│   │   │   ├── WorkOrderService.php
│   │   │   ├── RequestWorkflowService.php
│   │   │   └── CompletionService.php
│   │   ├── Models/
│   │   │   ├── WorkOrderModel.php
│   │   │   ├── MaintenanceRequestModel.php
│   │   │   └── CompletionReportModel.php
│   │   ├── Events/
│   │   │   ├── WorkOrderCreated.php
│   │   │   └── WorkOrderCompleted.php
│   │   ├── Config/
│   │   │   └── RWOPConfig.php
│   │   └── Database/
│   │       └── Migrations/
│   │
│   ├── MRMP/                       # Machine Reliability Maintenance
│   │   ├── Controllers/
│   │   │   ├── PMScheduleController.php
│   │   │   ├── CalibrationController.php
│   │   │   └── ReliabilityController.php
│   │   ├── Services/
│   │   │   ├── PMService.php
│   │   │   ├── CalibrationService.php
│   │   │   └── ReliabilityAnalysisService.php
│   │   ├── Models/
│   │   │   ├── PMScheduleModel.php
│   │   │   └── CalibrationModel.php
│   │   └── Database/
│   │       └── Migrations/
│   │
│   ├── MPMP/                       # Manufacturing Production Management
│   │   ├── Controllers/
│   │   │   ├── ProductionOrderController.php
│   │   │   ├── OEEController.php
│   │   │   └── DowntimeController.php
│   │   ├── Services/
│   │   │   ├── ProductionService.php
│   │   │   ├── OEECalculationService.php
│   │   │   └── DowntimeAnalysisService.php
│   │   ├── Models/
│   │   │   ├── ProductionOrderModel.php
│   │   │   └── OEEModel.php
│   │   └── Database/
│   │       └── Migrations/
│   │
│   ├── IMS/                        # Inventory Management System
│   │   ├── Controllers/
│   │   │   ├── InventoryController.php
│   │   │   ├── MaterialRequestController.php
│   │   │   └── StockController.php
│   │   ├── Services/
│   │   │   ├── InventoryService.php
│   │   │   ├── StockMovementService.php
│   │   │   └── ReorderService.php
│   │   ├── Models/
│   │   │   ├── PartModel.php
│   │   │   └── StockMovementModel.php
│   │   └── Database/
│   │       └── Migrations/
│   │
│   └── HRMS/                       # Human Resources Management
│       ├── Controllers/
│       │   ├── EmployeeController.php
│       │   ├── TrainingController.php
│       │   └── SkillController.php
│       ├── Services/
│       │   ├── EmployeeService.php
│       │   └── TrainingService.php
│       ├── Models/
│       │   ├── EmployeeModel.php
│       │   └── TrainingModel.php
│       └── Database/
│           └── Migrations/
│
├── Shared/                         # Shared Utilities
│   ├── Traits/
│   │   ├── HasAuditLog.php
│   │   ├── HasWorkflow.php
│   │   └── HasApproval.php
│   ├── Helpers/
│   │   ├── DateHelper.php
│   │   └── ValidationHelper.php
│   └── Exceptions/
│       ├── ModuleDisabledException.php
│       └── UnauthorizedException.php
│
└── Config/
    ├── Routes/
    │   ├── Core.php
    │   ├── RWOP.php
    │   ├── MRMP.php
    │   ├── MPMP.php
    │   ├── IMS.php
    │   └── HRMS.php
    └── Modules.php                 # Module registry
```

---

## 3. FRONTEND ARCHITECTURE (Next.js)

### 3.1 Folder Structure

```
src/
├── core/                           # Core Platform
│   ├── auth/
│   │   ├── components/
│   │   ├── hooks/
│   │   └── services/
│   ├── rbac/
│   ├── notifications/
│   └── settings/
│
├── modules/                        # Business Modules
│   ├── rwop/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── hooks/
│   │   ├── services/
│   │   └── types/
│   ├── mrmp/
│   ├── mpmp/
│   ├── ims/
│   └── hrms/
│
├── shared/                         # Shared Components
│   ├── components/
│   ├── hooks/
│   ├── utils/
│   └── types/
│
├── app/                            # Next.js App Router
│   ├── (auth)/
│   ├── (dashboard)/
│   ├── rwop/
│   ├── mrmp/
│   ├── mpmp/
│   ├── ims/
│   └── hrms/
│
└── lib/
    ├── api.ts
    ├── moduleRegistry.ts
    └── permissions.ts
```

---

## 4. DATABASE SCHEMA

### 4.1 Core Platform Tables

```sql
-- Module Management
CREATE TABLE system_modules (
    id VARCHAR(36) PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_enabled BOOLEAN DEFAULT TRUE,
    version VARCHAR(20),
    dependencies JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- RBAC
CREATE TABLE roles (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    module_code VARCHAR(50),
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE permissions (
    id VARCHAR(36) PRIMARY KEY,
    module_code VARCHAR(50) NOT NULL,
    resource VARCHAR(100) NOT NULL,
    action VARCHAR(50) NOT NULL,
    description TEXT,
    UNIQUE KEY (module_code, resource, action)
);

CREATE TABLE role_permissions (
    role_id VARCHAR(36),
    permission_id VARCHAR(36),
    PRIMARY KEY (role_id, permission_id),
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
);

CREATE TABLE user_roles (
    user_id VARCHAR(36),
    role_id VARCHAR(36),
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
);

-- Audit Logs
CREATE TABLE audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    module_code VARCHAR(50) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id VARCHAR(36) NOT NULL,
    action VARCHAR(50) NOT NULL,
    user_id VARCHAR(36),
    changes JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_module (module_code),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_user (user_id),
    INDEX idx_created (created_at)
);
```

### 4.2 Module Prefixing Strategy

Each module uses table prefixes:
- **RWOP**: `rwop_*` (work_orders, maintenance_requests)
- **MRMP**: `mrmp_*` (pm_schedules, calibrations)
- **MPMP**: `mpmp_*` (production_orders, oee_data)
- **IMS**: `ims_*` (parts, stock_movements)
- **HRMS**: `hrms_*` (employees, training_records)

---

## 5. API VERSIONING STRATEGY

### 5.1 URL Structure
```
/api/v1/{module}/{resource}
/api/v2/{module}/{resource}
```

### 5.2 Examples
```
GET  /api/v1/rwop/work-orders
POST /api/v1/rwop/work-orders
GET  /api/v1/mrmp/pm-schedules
GET  /api/v1/ims/parts
```

### 5.3 Version Management
- **v1**: Current production
- **v2**: New features (parallel deployment)
- Deprecation notices in headers
- Sunset dates for old versions

---

## 6. MODULE MANAGEMENT SYSTEM

### 6.1 Module Configuration

```php
// app/Config/Modules.php
return [
    'rwop' => [
        'name' => 'Repair Work Order Program',
        'enabled' => true,
        'version' => '1.0.0',
        'dependencies' => ['ims'],
        'routes' => 'Config/Routes/RWOP.php',
        'permissions' => [
            'rwop.work_orders.view',
            'rwop.work_orders.create',
            'rwop.work_orders.update',
            'rwop.work_orders.delete',
        ]
    ],
    'mrmp' => [
        'name' => 'Machine Reliability Maintenance Program',
        'enabled' => true,
        'version' => '1.0.0',
        'dependencies' => ['rwop'],
        'routes' => 'Config/Routes/MRMP.php',
    ],
    // ... other modules
];
```

### 6.2 Module Service

```php
// app/Core/ModuleManager/Services/ModuleService.php
namespace App\Core\ModuleManager\Services;

class ModuleService
{
    public function isEnabled(string $moduleCode): bool
    {
        $module = $this->moduleModel->where('code', $moduleCode)->first();
        return $module && $module['is_enabled'];
    }

    public function enable(string $moduleCode): bool
    {
        // Check dependencies
        // Enable module
        // Register routes
        // Clear cache
    }

    public function disable(string $moduleCode): bool
    {
        // Check dependents
        // Disable module
        // Unregister routes
        // Clear cache
    }

    public function checkDependencies(string $moduleCode): array
    {
        // Return missing dependencies
    }
}
```

### 6.3 Module Access Middleware

```php
// app/Core/ModuleManager/Middleware/ModuleAccessMiddleware.php
namespace App\Core\ModuleManager\Middleware;

class ModuleAccessMiddleware implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $moduleCode = $arguments[0] ?? null;
        
        if (!$this->moduleService->isEnabled($moduleCode)) {
            return Services::response()
                ->setJSON([
                    'status' => 'error',
                    'message' => 'Module is disabled'
                ])
                ->setStatusCode(403);
        }
    }
}
```

---

## 7. INTER-MODULE COMMUNICATION

### 7.1 Service Layer Pattern

```php
// Modules communicate via services, NOT direct database access

// RWOP needs inventory data
namespace App\Modules\RWOP\Services;

use App\Modules\IMS\Services\InventoryService;

class WorkOrderService
{
    protected $inventoryService;

    public function __construct()
    {
        $this->inventoryService = new InventoryService();
    }

    public function checkMaterialAvailability(string $workOrderId): array
    {
        $materials = $this->getRequiredMaterials($workOrderId);
        return $this->inventoryService->checkAvailability($materials);
    }
}
```

### 7.2 Event-Driven Communication

```php
// app/Modules/RWOP/Events/WorkOrderCompleted.php
namespace App\Modules\RWOP\Events;

class WorkOrderCompleted
{
    public $workOrderId;
    public $materialsUsed;

    public function __construct($workOrderId, $materialsUsed)
    {
        $this->workOrderId = $workOrderId;
        $this->materialsUsed = $materialsUsed;
    }
}

// Listener in IMS module
namespace App\Modules\IMS\Listeners;

class UpdateInventoryOnWorkOrderCompletion
{
    public function handle(WorkOrderCompleted $event)
    {
        // Update inventory based on materials used
    }
}
```

---

## 8. IMPLEMENTATION ROADMAP

### Phase 1: Core Platform (Week 1-2)
- [ ] Create folder structure
- [ ] Implement ModuleService
- [ ] Implement RBAC system
- [ ] Implement AuditService
- [ ] Create module registry

### Phase 2: Module Extraction (Week 3-4)
- [ ] Extract RWOP module
- [ ] Extract MRMP module
- [ ] Extract MPMP module
- [ ] Extract IMS module
- [ ] Extract HRMS module

### Phase 3: Integration (Week 5)
- [ ] Implement inter-module services
- [ ] Implement event system
- [ ] Update all routes
- [ ] Update frontend module structure

### Phase 4: Testing & Documentation (Week 6)
- [ ] Module enable/disable testing
- [ ] Permission testing
- [ ] API documentation
- [ ] Deployment guide

---

## 9. MIGRATION STRATEGY

### 9.1 Backward Compatibility
- Keep old routes active during migration
- Use route aliases
- Gradual frontend migration

### 9.2 Database Migration
```sql
-- Add module_code to existing tables
ALTER TABLE work_orders ADD COLUMN module_code VARCHAR(50) DEFAULT 'rwop';
ALTER TABLE pm_schedules ADD COLUMN module_code VARCHAR(50) DEFAULT 'mrmp';
```

---

## 10. PRODUCTION CHECKLIST

- [ ] All modules have independent tests
- [ ] Module enable/disable works correctly
- [ ] RBAC enforced on all endpoints
- [ ] Audit logs capture all actions
- [ ] API versioning implemented
- [ ] Documentation complete
- [ ] Performance benchmarks met
- [ ] Security audit passed
- [ ] Backup/restore procedures tested
- [ ] Monitoring and alerting configured

---

**This architecture transforms your system into an enterprise-grade, modular EAM platform ready for industrial production use.**
