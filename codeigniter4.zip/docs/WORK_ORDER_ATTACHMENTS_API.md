# Work Order Attachments & Checklist API

## Features

### 1. PM Order Number
- Format: `EAM-{YYYY}{4-digit-seq}`
- Example: `EAM-20250001`, `EAM-20250002`
- Auto-generated for PM-based work orders
- Unique per work order
- Resets sequence each year

### 2. Checklist JSON Schema
```json
[
  {
    "id": "item-1",
    "text": "Check oil level",
    "required": true,
    "type": "text",
    "value": null,
    "completed_at": null,
    "completed_by": null
  },
  {
    "id": "item-2",
    "text": "Take photo of equipment",
    "required": true,
    "type": "photo",
    "value": null,
    "completed_at": null,
    "completed_by": null
  },
  {
    "id": "item-3",
    "text": "Measure vibration level",
    "required": false,
    "type": "measurement",
    "value": null,
    "completed_at": null,
    "completed_by": null
  }
]
```

**Field Definitions:**
- `id`: Unique identifier for checklist item
- `text`: Description of task
- `required`: Boolean - must be completed before WO completion
- `type`: `text` | `photo` | `measurement`
- `value`: Completed value (text, attachment_id, or measurement)
- `completed_at`: ISO datetime when completed
- `completed_by`: User ID who completed

### 3. File Attachments
- Supported types: JPEG, PNG, PDF, MP4
- Max size: 10MB
- Storage: `writable/uploads/work_orders/`
- Linked to work order or specific checklist item

---

## API Endpoints

### Upload Attachment

**POST** `/api/v1/eam/work-orders/{id}/attachments`

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: multipart/form-data
```

**Body (form-data):**
```
file: <binary file>
task_item_id: item-2 (optional - links to checklist item)
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "attachment_id": 1,
    "filename": "equipment_photo.jpg",
    "filepath": "WO123_1699876543_abc123.jpg"
  },
  "message": "File uploaded successfully"
}
```

**cURL Example:**
```bash
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/work-orders/123/attachments \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc..." \
  -F "file=@/path/to/photo.jpg" \
  -F "task_item_id=item-2"
```

---

### Get Work Order Attachments

**GET** `/api/v1/eam/work-orders/{id}/attachments`

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "work_order_id": 123,
      "task_item_id": "item-2",
      "filename": "equipment_photo.jpg",
      "filepath": "WO123_1699876543_abc123.jpg",
      "file_type": "image/jpeg",
      "file_size": 245678,
      "uploaded_by": 5,
      "uploaded_at": "2025-01-15 10:30:00"
    }
  ],
  "message": "Attachments retrieved successfully"
}
```

---

### Download Attachment

**GET** `/api/v1/eam/attachments/{id}/download`

**Response:** Binary file with appropriate headers

**cURL Example:**
```bash
curl -X GET \
  http://localhost/factorymanager/public/index.php/api/v1/eam/attachments/1/download \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc..." \
  -o downloaded_file.jpg
```

---

### Delete Attachment

**DELETE** `/api/v1/eam/attachments/{id}`

**Response:**
```json
{
  "status": "success",
  "message": "Attachment deleted successfully"
}
```

---

## PM Rule with Default Checklist

### Create PM Rule with Checklist

**POST** `/api/v1/eam/pm-rules`

**Request Body:**
```json
{
  "rule_name": "Monthly Equipment Inspection",
  "asset_id": 1,
  "trigger_type": "time",
  "frequency_value": 30,
  "frequency_unit": "days",
  "is_active": 1,
  "default_checklist": [
    {
      "id": "item-1",
      "text": "Check oil level",
      "required": true,
      "type": "text",
      "value": null,
      "completed_at": null,
      "completed_by": null
    },
    {
      "id": "item-2",
      "text": "Take photo of equipment condition",
      "required": true,
      "type": "photo",
      "value": null,
      "completed_at": null,
      "completed_by": null
    },
    {
      "id": "item-3",
      "text": "Measure vibration (mm/s)",
      "required": false,
      "type": "measurement",
      "value": null,
      "completed_at": null,
      "completed_by": null
    }
  ]
}
```

When a work order is created from this PM rule, the checklist is automatically copied to the work order.

---

## Complete Workflow Example

### 1. Create PM Rule with Checklist
```bash
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/pm-rules \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "rule_name": "Monthly Inspection",
    "asset_id": 1,
    "trigger_type": "time",
    "frequency_value": 30,
    "frequency_unit": "days",
    "is_active": 1,
    "default_checklist": [
      {
        "id": "item-1",
        "text": "Check oil level",
        "required": true,
        "type": "text"
      },
      {
        "id": "item-2",
        "text": "Take equipment photo",
        "required": true,
        "type": "photo"
      }
    ]
  }'
```

### 2. PM Scheduler Creates Work Order
```bash
php spark eam:schedule-run
```

Work order created with:
- `pm_order_number`: `EAM-20250001`
- `checklist`: Copied from PM rule

### 3. Technician Uploads Photo for Checklist Item
```bash
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/work-orders/123/attachments \
  -H "Authorization: Bearer <token>" \
  -F "file=@equipment_photo.jpg" \
  -F "task_item_id=item-2"
```

Response:
```json
{
  "status": "success",
  "data": {
    "attachment_id": 1,
    "filename": "equipment_photo.jpg",
    "filepath": "WO123_1699876543_abc123.jpg"
  }
}
```

### 4. Update Checklist Item with Attachment
```bash
curl -X PUT \
  http://localhost/factorymanager/public/index.php/api/v1/eam/work-orders/123 \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "checklist": [
      {
        "id": "item-1",
        "text": "Check oil level",
        "required": true,
        "type": "text",
        "value": "Oil level OK",
        "completed_at": "2025-01-15T10:25:00",
        "completed_by": 5
      },
      {
        "id": "item-2",
        "text": "Take equipment photo",
        "required": true,
        "type": "photo",
        "value": "1",
        "completed_at": "2025-01-15T10:30:00",
        "completed_by": 5
      }
    ]
  }'
```

### 5. Complete Work Order
```bash
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/work-orders/123/complete \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "completion_notes": "All checks completed successfully",
    "labor_hours": 1.5
  }'
```

---

## Database Schema

### work_orders Table (Enhanced)
```sql
ALTER TABLE work_orders 
ADD COLUMN pm_order_number VARCHAR(50) UNIQUE AFTER id,
ADD COLUMN checklist JSON AFTER description;
```

### work_order_attachments Table
```sql
CREATE TABLE work_order_attachments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  work_order_id INT UNSIGNED NOT NULL,
  task_item_id VARCHAR(50) NULL,
  filename VARCHAR(255) NOT NULL,
  filepath VARCHAR(500) NOT NULL,
  file_type VARCHAR(50) NOT NULL,
  file_size INT NOT NULL,
  uploaded_by INT UNSIGNED NOT NULL,
  uploaded_at DATETIME NOT NULL,
  FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE
);
```

### pm_rules Table (Enhanced)
```sql
ALTER TABLE pm_rules 
ADD COLUMN default_checklist JSON AFTER meter_threshold;
```

---

## Frontend Integration Example

### React/Next.js Upload Component
```typescript
const uploadPhoto = async (workOrderId: number, file: File, taskItemId: string) => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('task_item_id', taskItemId);

  const response = await fetch(
    `${API_URL}/work-orders/${workOrderId}/attachments`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`
      },
      body: formData
    }
  );

  return response.json();
};

// Usage
const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0];
  if (!file) return;

  const result = await uploadPhoto(123, file, 'item-2');
  console.log('Uploaded:', result.data.attachment_id);
};
```

---

## Validation Rules

### File Upload
- Max size: 10MB
- Allowed types: JPEG, PNG, PDF, MP4
- Filename sanitization: Auto-generated unique name
- Storage path: `writable/uploads/work_orders/`

### Checklist
- Required items must be completed before WO completion
- Photo type items must have attachment
- Measurement type items must have numeric value
- Text type items must have non-empty value

---

## Security Considerations

1. **File Upload Security**
   - Validate file type and size
   - Generate unique filenames
   - Store outside web root
   - Scan for malware (recommended)

2. **Access Control**
   - Only assigned technician can upload
   - Only work order participants can download
   - Admin can delete attachments

3. **Storage Management**
   - Implement file retention policy
   - Archive old attachments
   - Monitor disk usage

---

## Testing

### Test Upload
```bash
# Create test image
echo "test" > test.jpg

# Upload
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/work-orders/1/attachments \
  -H "Authorization: Bearer <token>" \
  -F "file=@test.jpg" \
  -F "task_item_id=item-1"
```

### Test Download
```bash
curl -X GET \
  http://localhost/factorymanager/public/index.php/api/v1/eam/attachments/1/download \
  -H "Authorization: Bearer <token>" \
  -o downloaded.jpg
```

---

## Error Handling

### Common Errors

**File too large:**
```json
{
  "status": "error",
  "message": "File too large (max 10MB)"
}
```

**Invalid file type:**
```json
{
  "status": "error",
  "message": "Invalid file type"
}
```

**Attachment not found:**
```json
{
  "status": "error",
  "message": "Attachment not found"
}
```

---

**Files Created:**
- Migration: `2025-11-15-000003_AddWorkOrderEnhancements.php`
- Model: `WorkOrderAttachmentModel.php`
- Service: `WorkOrderAttachmentService.php`
- Controller: `WorkOrderAttachmentsController.php`
- Routes: Updated `RoutesEam.php`
- Documentation: This file
