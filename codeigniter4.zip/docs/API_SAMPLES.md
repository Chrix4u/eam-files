# EAM API Samples - Machine, Assembly, Part Forms

## 1. Machine API

### Create Machine
**Endpoint:** `POST /api/v1/eam/machines`

**Request (multipart/form-data):**
```json
{
  "machine_name": "CNC Milling Machine",
  "machine_code": "MCH-000001",
  "machine_category": "production",
  "model": "XYZ-5000",
  "manufacturer": "Haas Automation",
  "serial_number": "SN123456789",
  "plant_location": "Plant A - Building 2",
  "department": "production",
  "description": "High-precision CNC milling machine for metal parts",
  "operation_type": "automated",
  "purchase_date": "2023-01-15",
  "installation_date": "2023-02-01",
  "warranty_expiry": "2026-02-01",
  "status": "active",
  "rated_power": "75 kW",
  "voltage": "380V",
  "capacity": "1000 units/hr",
  "cycle_time": "3.6",
  "speed_throughput": "120 m/min",
  "criticality": "high",
  "maintenance_strategy": "condition-based",
  "warranty_alerts": "yes",
  "default_technician_group": "Mechanical Team A",
  "pm_frequency": "30",
  "usage_unit": "hours",
  "machine_photo": "<file>"
}
```

**Response (201 Created):**
```json
{
  "status": "success",
  "message": "Machine created successfully",
  "data": {
    "id": 1,
    "machine_code": "MCH-000001"
  }
}
```

**Validation Errors (400 Bad Request):**
```json
{
  "status": "error",
  "messages": {
    "machine_name": "Machine name is required",
    "machine_category": "Machine category is required",
    "plant_location": "Plant location is required"
  }
}
```

### Get All Machines
**Endpoint:** `GET /api/v1/eam/machines`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "machine_name": "CNC Milling Machine",
      "machine_code": "MCH-000001",
      "machine_category": "production",
      "status": "active",
      "criticality": "high",
      "plant_location": "Plant A - Building 2",
      "department": "production",
      "created_at": "2024-01-15 10:30:00"
    }
  ]
}
```

### Get Machine by ID
**Endpoint:** `GET /api/v1/eam/machines/1`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "machine_name": "CNC Milling Machine",
    "machine_code": "MCH-000001",
    "machine_category": "production",
    "model": "XYZ-5000",
    "manufacturer": "Haas Automation",
    "serial_number": "SN123456789",
    "plant_location": "Plant A - Building 2",
    "department": "production",
    "description": "High-precision CNC milling machine for metal parts",
    "operation_type": "automated",
    "purchase_date": "2023-01-15",
    "installation_date": "2023-02-01",
    "warranty_expiry": "2026-02-01",
    "machine_photo": "uploads/machines/abc123.jpg",
    "status": "active",
    "rated_power": "75 kW",
    "voltage": "380V",
    "capacity": "1000 units/hr",
    "cycle_time": "3.6",
    "speed_throughput": "120 m/min",
    "criticality": "high",
    "maintenance_strategy": "condition-based",
    "warranty_alerts": "yes",
    "default_technician_group": "Mechanical Team A",
    "pm_frequency": 30,
    "usage_unit": "hours",
    "created_at": "2024-01-15 10:30:00",
    "updated_at": "2024-01-15 10:30:00"
  }
}
```

---

## 2. Assembly API

### Create Assembly
**Endpoint:** `POST /api/v1/eam/assemblies`

**Request (multipart/form-data):**
```json
{
  "machine_id": 1,
  "assembly_name": "Spindle Assembly",
  "assembly_code": "ASM-0001",
  "assembly_category": "mechanical",
  "description": "Main spindle assembly with bearings and motor mount",
  "criticality": "high",
  "assembly_image": "<file>"
}
```

**Response (201 Created):**
```json
{
  "status": "success",
  "message": "Assembly created successfully",
  "data": {
    "id": 1,
    "assembly_code": "ASM-0001"
  }
}
```

### Get All Assemblies
**Endpoint:** `GET /api/v1/eam/assemblies`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "machine_id": 1,
      "machine_name": "CNC Milling Machine",
      "machine_code": "MCH-000001",
      "assembly_name": "Spindle Assembly",
      "assembly_code": "ASM-0001",
      "assembly_category": "mechanical",
      "criticality": "high",
      "created_at": "2024-01-15 11:00:00"
    }
  ]
}
```

### Get Assembly by ID
**Endpoint:** `GET /api/v1/eam/assemblies/1`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "machine_id": 1,
    "machine_name": "CNC Milling Machine",
    "machine_code": "MCH-000001",
    "assembly_name": "Spindle Assembly",
    "assembly_code": "ASM-0001",
    "assembly_category": "mechanical",
    "description": "Main spindle assembly with bearings and motor mount",
    "criticality": "high",
    "assembly_image": "uploads/assemblies/def456.jpg",
    "created_at": "2024-01-15 11:00:00",
    "updated_at": "2024-01-15 11:00:00"
  }
}
```

---

## 3. Part API

### Create Part
**Endpoint:** `POST /api/v1/eam/parts`

**Request (multipart/form-data):**
```json
{
  "machine_id": 1,
  "assembly_id": 1,
  "parent_part_id": null,
  "part_name": "Spindle Bearing",
  "part_code": "PRT-0001",
  "part_category": "bearing",
  "manufacturer": "SKF",
  "material": "Stainless Steel",
  "dimensions": "50mm x 30mm x 20mm",
  "expected_lifespan": "5000 hours",
  "spare_availability": "yes",
  "current_stock_qty": 10,
  "safety_notes": "Wear protective gloves when handling. Avoid direct contact with lubricants.",
  "failure_modes": "Common failures: excessive vibration, overheating, noise. Symptoms: grinding sound, increased temperature, reduced precision.",
  "part_image": "<file>"
}
```

**Response (201 Created):**
```json
{
  "status": "success",
  "message": "Part created successfully",
  "data": {
    "id": 1,
    "part_code": "PRT-0001"
  }
}
```

### Get All Parts
**Endpoint:** `GET /api/v1/eam/parts`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "machine_id": 1,
      "machine_name": "CNC Milling Machine",
      "assembly_id": 1,
      "assembly_name": "Spindle Assembly",
      "parent_part_id": null,
      "parent_part_name": null,
      "part_name": "Spindle Bearing",
      "part_code": "PRT-0001",
      "part_category": "bearing",
      "manufacturer": "SKF",
      "spare_availability": "yes",
      "current_stock_qty": 10,
      "created_at": "2024-01-15 11:30:00"
    }
  ]
}
```

### Get Nested Parts (Hierarchical)
**Endpoint:** `GET /api/v1/eam/parts/nested/1`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "part_name": "Spindle Bearing",
      "part_code": "PRT-0001",
      "part_category": "bearing",
      "children": [
        {
          "id": 2,
          "part_name": "Inner Race",
          "part_code": "PRT-0002",
          "part_category": "bearing",
          "children": []
        },
        {
          "id": 3,
          "part_name": "Outer Race",
          "part_code": "PRT-0003",
          "part_category": "bearing",
          "children": []
        }
      ]
    }
  ]
}
```

### Get Part by ID
**Endpoint:** `GET /api/v1/eam/parts/1`

**Response (200 OK):**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "machine_id": 1,
    "machine_name": "CNC Milling Machine",
    "assembly_id": 1,
    "assembly_name": "Spindle Assembly",
    "parent_part_id": null,
    "parent_part_name": null,
    "part_name": "Spindle Bearing",
    "part_code": "PRT-0001",
    "part_category": "bearing",
    "manufacturer": "SKF",
    "material": "Stainless Steel",
    "dimensions": "50mm x 30mm x 20mm",
    "expected_lifespan": "5000 hours",
    "spare_availability": "yes",
    "current_stock_qty": 10,
    "part_image": "uploads/parts/ghi789.jpg",
    "safety_notes": "Wear protective gloves when handling. Avoid direct contact with lubricants.",
    "failure_modes": "Common failures: excessive vibration, overheating, noise. Symptoms: grinding sound, increased temperature, reduced precision.",
    "created_at": "2024-01-15 11:30:00",
    "updated_at": "2024-01-15 11:30:00"
  }
}
```

---

## Auto-Code Generation

### Machine Code
- **Format:** `MCH-XXXXXX` (6 digits)
- **Example:** `MCH-000001`, `MCH-000002`
- **Logic:** Auto-increments from last machine ID

### Assembly Code
- **Format:** `ASM-XXXX` (4 digits)
- **Example:** `ASM-0001`, `ASM-0002`
- **Logic:** Auto-increments per machine

### Part Code
- **Format:** `PRT-XXXX` (4 digits)
- **Example:** `PRT-0001`, `PRT-0002`
- **Logic:** Auto-increments per assembly

---

## Error Responses

### 400 Bad Request (Validation Error)
```json
{
  "status": "error",
  "messages": {
    "field_name": "Error message"
  }
}
```

### 404 Not Found
```json
{
  "status": "error",
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "status": "error",
  "message": "Internal server error"
}
```
