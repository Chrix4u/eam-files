# PM Scheduler Cron Setup

## Command Usage

### Basic Run
```bash
php spark eam:schedule-run
```

### With Options
```bash
# Look ahead 60 days
php spark eam:schedule-run --days=60

# Force regeneration of existing schedules
php spark eam:schedule-run --force

# Combined
php spark eam:schedule-run --days=60 --force
```

---

## Cron Configuration

### Linux/Unix Crontab

Edit crontab:
```bash
crontab -e
```

Add this line to run daily at 01:00 AM:
```cron
0 1 * * * cd /var/www/factorymanager && /usr/bin/php spark eam:schedule-run >> /var/log/eam-scheduler.log 2>&1
```

### Alternative Times

Run every day at 6:00 AM:
```cron
0 6 * * * cd /var/www/factorymanager && /usr/bin/php spark eam:schedule-run
```

Run twice daily (01:00 and 13:00):
```cron
0 1,13 * * * cd /var/www/factorymanager && /usr/bin/php spark eam:schedule-run
```

Run every Monday at 08:00:
```cron
0 8 * * 1 cd /var/www/factorymanager && /usr/bin/php spark eam:schedule-run
```

### Windows Task Scheduler

1. Open Task Scheduler
2. Create Basic Task
3. Set Trigger: Daily at 01:00
4. Set Action: Start a program
   - Program: `C:\php\php.exe`
   - Arguments: `spark eam:schedule-run`
   - Start in: `C:\wamp64\www\factorymanager`

---

## Environment Variables

Add to `.env` file:

```env
# PM Scheduler Configuration
PM_WEBHOOK_URL=https://your-webhook-url.com/notifications
PM_LOOKAHEAD_DAYS=30
PM_AUTO_CREATE_WO=true
```

---

## SQL Queries Used

### 1. Get Active PM Rules
```sql
SELECT * 
FROM pm_rules 
WHERE is_active = 1 
ORDER BY priority DESC, id ASC;
```

### 2. Find Existing Schedule
```sql
SELECT * 
FROM pm_schedules 
WHERE pm_rule_id = ? 
  AND scheduled_date = ? 
LIMIT 1;
```

### 3. Get Current Meter Reading (Usage-Based)
```sql
SELECT m.current_reading 
FROM meters m 
WHERE m.equipment_id = ? 
LIMIT 1;
```

**Alternative with Latest Reading:**
```sql
SELECT mr.reading_value 
FROM meter_readings mr
WHERE mr.meter_id = (
    SELECT id FROM meters WHERE equipment_id = ? LIMIT 1
)
ORDER BY mr.reading_date DESC 
LIMIT 1;
```

### 4. Calculate Usage Delta
```sql
SELECT 
    m.id as meter_id,
    m.current_reading,
    ps.meter_reading_at_completion as last_pm_reading,
    (m.current_reading - COALESCE(ps.meter_reading_at_completion, 0)) as usage_since_last_pm
FROM meters m
LEFT JOIN pm_schedules ps ON ps.equipment_id = m.equipment_id 
    AND ps.status = 'completed'
    AND ps.pm_rule_id = ?
WHERE m.equipment_id = ?
ORDER BY ps.completed_date DESC
LIMIT 1;
```

### 5. Mark Schedule as Overdue
```sql
UPDATE pm_schedules 
SET status = 'overdue', 
    escalation_level = escalation_level + 1,
    escalated_at = NOW()
WHERE id = ?;
```

### 6. Create Notification for Planners/Supervisors
```sql
INSERT INTO notifications (type, title, message, user_id, work_order_id, pm_schedule_id, is_read, created_at)
SELECT 
    'overdue' as type,
    'PM Schedule Overdue' as title,
    CONCAT('PM schedule for ', e.name, ' is overdue') as message,
    u.id as user_id,
    NULL as work_order_id,
    ? as pm_schedule_id,
    0 as is_read,
    NOW() as created_at
FROM users u
JOIN roles r ON u.role_id = r.id
CROSS JOIN equipment e
WHERE r.name IN ('planner', 'supervisor', 'admin')
  AND e.id = ?;
```

### 7. Get Overdue Schedules
```sql
SELECT 
    ps.*,
    pr.name as rule_name,
    e.name as equipment_name,
    e.code as equipment_code
FROM pm_schedules ps
JOIN pm_rules pr ON ps.pm_rule_id = pr.id
JOIN equipment e ON ps.equipment_id = e.id
WHERE ps.status IN ('waiting', 'overdue')
  AND ps.scheduled_date < CURDATE()
  AND ps.work_order_id IS NULL;
```

### 8. Get Usage-Based Due Schedules
```sql
SELECT 
    ps.*,
    pr.name as rule_name,
    e.name as equipment_name,
    m.current_reading,
    ps.next_due_usage
FROM pm_schedules ps
JOIN pm_rules pr ON ps.pm_rule_id = pr.id
JOIN equipment e ON ps.equipment_id = e.id
JOIN meters m ON m.equipment_id = e.id
WHERE ps.status = 'waiting'
  AND pr.frequency_type = 'meter'
  AND m.current_reading >= ps.next_due_usage
  AND ps.work_order_id IS NULL;
```

---

## Testing Locally

### Test 1: Dry Run (Check Active Rules)
```bash
php spark eam:schedule-run
```

Expected output:
```
Starting PM Schedule Generation...

Step 1: Fetching active PM rules...
Found 5 active PM rules

Processing Rule #1: Monthly Inspection
  ✓ Schedule created (ID: 123)
  ✓ Work Order auto-created (ID: 456)

Processing Rule #2: Quarterly Maintenance
  → Schedule already exists (ID: 124)

═══════════════════════════════════════
Summary:
  PM Rules Processed: 5
  Schedules Created: 3
  Work Orders Created: 2
  Schedules Marked Overdue: 1
═══════════════════════════════════════

PM Schedule Generation Completed Successfully!
```

### Test 2: Force Regeneration
```bash
php spark eam:schedule-run --force
```

### Test 3: Extended Lookahead
```bash
php spark eam:schedule-run --days=90
```

### Test 4: Check Database Results
```sql
-- Check created schedules
SELECT * FROM pm_schedules 
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
ORDER BY id DESC;

-- Check created work orders
SELECT * FROM work_orders 
WHERE pm_schedule_id IS NOT NULL 
  AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
ORDER BY id DESC;

-- Check notifications
SELECT * FROM notifications 
WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
ORDER BY id DESC;
```

---

## Status Flow

```
PM Rule (active)
    ↓
[Evaluate] → Calculate next_due_date / next_due_usage
    ↓
PM Schedule (waiting)
    ↓
[Check Due] → Is today >= scheduled_date OR current_usage >= next_due_usage?
    ↓ YES
Work Order (generated) → PM Schedule (status = 'generated')
    ↓
[Technician Completes]
    ↓
PM Schedule (status = 'completed')
    ↓
[Next Cycle] → New PM Schedule created
```

### Status Definitions

- **waiting**: Schedule created, waiting for due date/usage
- **generated**: Work order created from schedule
- **overdue**: Past due date and no work order created
- **completed**: Work order completed, PM done
- **cancelled**: Schedule cancelled (rule deactivated)

---

## Troubleshooting

### Issue: No schedules created
**Check:**
1. Are there active PM rules? `SELECT * FROM pm_rules WHERE is_active = 1`
2. Do rules have valid frequency values? `frequency_value > 0`
3. Check command output for errors

### Issue: Work orders not auto-created
**Check:**
1. Is scheduled_date <= today? `SELECT * FROM pm_schedules WHERE scheduled_date <= CURDATE() AND work_order_id IS NULL`
2. For meter-based: Is current_reading >= next_due_usage?
3. Check `shouldGenerateWorkOrder()` logic

### Issue: Notifications not sent
**Check:**
1. Do users have planner/supervisor/admin roles?
2. Is notifications table created?
3. Check webhook URL in .env

### Issue: Duplicate schedules
**Solution:** Use `--force` flag carefully, it regenerates existing schedules

---

## Monitoring

### Check Last Run
```bash
tail -f /var/log/eam-scheduler.log
```

### Database Monitoring Queries

**Overdue Schedules:**
```sql
SELECT COUNT(*) as overdue_count 
FROM pm_schedules 
WHERE status = 'overdue';
```

**Pending Work Orders:**
```sql
SELECT COUNT(*) as pending_wo 
FROM work_orders 
WHERE status = 'open' 
  AND pm_schedule_id IS NOT NULL;
```

**Today's Generated Schedules:**
```sql
SELECT COUNT(*) as today_schedules 
FROM pm_schedules 
WHERE DATE(created_at) = CURDATE();
```

---

## Performance Optimization

For large datasets (1000+ PM rules):

1. **Add Indexes:**
```sql
CREATE INDEX idx_pm_rules_active ON pm_rules(is_active, priority);
CREATE INDEX idx_pm_schedules_status_date ON pm_schedules(status, scheduled_date);
CREATE INDEX idx_meters_equipment ON meters(equipment_id, current_reading);
```

2. **Batch Processing:**
Modify command to process rules in batches of 100

3. **Queue Jobs:**
Use CodeIgniter Queue library for async processing

---

## Webhook Payload Example

```json
{
  "title": "Work Order Generated",
  "message": "Work order #456 created for PM on Chiller Unit 1 (CHILL-01)",
  "work_order_id": 456,
  "timestamp": "2024-01-15 01:00:00"
}
```

Integrate with Slack, Teams, or custom notification service.
