# Factory Manager EAM API Manifest

## Base URL
```
http://localhost/factorymanager/public/index.php/api/v1/eam
```

## Authentication
All endpoints except `/auth/login` and `/auth/refresh` require JWT Bearer token in Authorization header:
```
Authorization: Bearer <access_token>
```

---

## 📁 Controllers Created/Updated

### New Controllers
1. **DepartmentsController** - CRUD for departments
2. **ShiftsController** - CRUD for shifts
3. **EmployeeShiftsController** - Assign employees to shifts
4. **SubPartsController** - CRUD for sub-parts
5. **ProductionRunsController** - Production runs and surveys
6. **ReportsController** - PM, WO, inventory reports
7. **AssetHierarchyController** - Nested hierarchy retrieval

### Updated Controllers
1. **EamPmController** - Added `generateSchedule()` method
2. **EamInventoryController** - Added `consume()` method
3. **EamWorkOrdersController** - Added `issueMaterials()` method

---

## 🔐 Authentication Endpoints

### POST /auth/login
**Description**: User login  
**Auth Required**: No  
**Request Body**:
```json
{
  "username": "admin",
  "password": "admin123"
}
```
**Response**:
```json
{
  "status": "success",
  "data": {
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "user": {
      "id": 1,
      "username": "admin",
      "email": "admin@factory.com",
      "role_id": 1
    }
  }
}
```

### POST /auth/refresh
**Description**: Refresh access token  
**Auth Required**: No  
**Request Body**:
```json
{
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

### POST /auth/logout
**Description**: User logout  
**Auth Required**: Yes

---

## 👥 Users & Roles

### GET /users
**Query Params**: `role_id`, `department_id`

### POST /users
**Request Body**:
```json
{
  "username": "jdoe",
  "email": "jdoe@factory.com",
  "password": "password123",
  "role_id": 3,
  "department_id": 2,
  "first_name": "John",
  "last_name": "Doe"
}
```

### GET /users/{id}
### PUT /users/{id}
### DELETE /users/{id}

### GET /roles
### POST /roles
**Request Body**:
```json
{
  "name": "Technician",
  "description": "Maintenance technician role"
}
```

---

## 🏢 Departments & Shifts

### GET /departments
### POST /departments
**Request Body**:
```json
{
  "name": "Maintenance",
  "code": "MAINT",
  "manager_id": 5
}
```

### GET /departments/{id}
### PUT /departments/{id}
### DELETE /departments/{id}

### GET /shifts
### POST /shifts
**Request Body**:
```json
{
  "name": "Morning Shift",
  "start_time": "08:00:00",
  "end_time": "16:00:00"
}
```

### GET /shifts/{id}
### PUT /shifts/{id}
### DELETE /shifts/{id}

### GET /employee-shifts
**Query Params**: `user_id`, `shift_id`

### POST /employee-shifts
**Request Body**:
```json
{
  "user_id": 10,
  "shift_id": 1,
  "effective_date": "2024-01-15"
}
```

### DELETE /employee-shifts/{id}

---

## 🏭 Asset Hierarchy

### GET /facilities
### POST /facilities
**Request Body**:
```json
{
  "name": "Main Plant",
  "code": "PLANT-01",
  "location": "Building A"
}
```

### GET /facilities/{id}
### PUT /facilities/{id}
### DELETE /facilities/{id}

### GET /systems
**Query Params**: `facility_id`

### POST /systems
**Request Body**:
```json
{
  "name": "HVAC System",
  "code": "HVAC-01",
  "facility_id": 1
}
```

### GET /systems/{id}
### PUT /systems/{id}
### DELETE /systems/{id}

### GET /equipment
**Query Params**: `system_id`

### POST /equipment
**Request Body**:
```json
{
  "name": "Chiller Unit 1",
  "code": "CHILL-01",
  "system_id": 1,
  "model_path": "/models/chiller.glb"
}
```

### GET /equipment/{id}
### PUT /equipment/{id}
### DELETE /equipment/{id}

### GET /assemblies
**Query Params**: `equipment_id`

### POST /assemblies
**Request Body**:
```json
{
  "name": "Compressor Assembly",
  "code": "COMP-ASM-01",
  "equipment_id": 1
}
```

### GET /assemblies/{id}
### PUT /assemblies/{id}
### DELETE /assemblies/{id}

### GET /components
**Query Params**: `assembly_id`

### POST /components
**Request Body**:
```json
{
  "name": "Motor Component",
  "code": "MOTOR-01",
  "assembly_id": 1
}
```

### GET /components/{id}
### PUT /components/{id}
### DELETE /components/{id}

### GET /parts
**Query Params**: `component_id`

### POST /parts
**Request Body**:
```json
{
  "name": "Bearing",
  "code": "BRG-001",
  "component_id": 1
}
```

### GET /parts/{id}
### PUT /parts/{id}
### DELETE /parts/{id}

### GET /sub-parts
**Query Params**: `part_id`

### POST /sub-parts
**Request Body**:
```json
{
  "name": "Seal",
  "code": "SEAL-001",
  "part_id": 1
}
```

### GET /sub-parts/{id}
### PUT /sub-parts/{id}
### DELETE /sub-parts/{id}

### GET /assets/hierarchy
**Description**: Returns nested JSON tree of entire asset hierarchy  
**Query Params**: `facility_id` (optional)  
**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Main Plant",
      "systems": [
        {
          "id": 1,
          "name": "HVAC System",
          "equipment": [
            {
              "id": 1,
              "name": "Chiller Unit 1",
              "assemblies": [...]
            }
          ]
        }
      ]
    }
  ]
}
```

---

## 📊 Meters & Readings

### GET /meters
**Query Params**: `equipment_id`

### POST /meters
**Request Body**:
```json
{
  "name": "Operating Hours",
  "equipment_id": 1,
  "unit": "hours"
}
```

### GET /meters/{id}
### PUT /meters/{id}
### DELETE /meters/{id}

### POST /meters/{id}/readings
**Request Body**:
```json
{
  "reading_value": 1250.5,
  "reading_date": "2024-01-15T10:30:00"
}
```

---

## 🔧 Preventive Maintenance

### GET /pm-rules
**Query Params**: `equipment_id`

### POST /pm-rules
**Request Body**:
```json
{
  "name": "Monthly Inspection",
  "equipment_id": 1,
  "frequency_type": "time",
  "frequency_value": 30,
  "frequency_unit": "days"
}
```

### PUT /pm-rules/{id}

### POST /pm-rules/{id}/generate-schedule
**Description**: Generates next PM schedule based on rule

### GET /pm-schedules
**Query Params**: `status` (due/overdue/completed/all), `equipment_id`  
**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "pm_rule_id": 1,
      "equipment_id": 1,
      "scheduled_date": "2024-02-01",
      "status": "due"
    }
  ]
}
```

### POST /pm-schedules/generate
**Description**: Bulk generate schedules

---

## 📋 Work Orders

### GET /work-orders
**Query Params**: `status`, `assigned_to`

### POST /work-orders
**Request Body**:
```json
{
  "title": "Replace bearing on Chiller 1",
  "description": "Bearing showing signs of wear",
  "equipment_id": 1,
  "pm_schedule_id": 5,
  "priority": "high",
  "work_type": "preventive"
}
```

### GET /work-orders/{id}
**Response**:
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "title": "Replace bearing",
    "equipment_id": 1,
    "assigned_to": 10,
    "status": "in_progress",
    "priority": "high",
    "materials": [...],
    "tasks": [...]
  }
}
```

### PUT /work-orders/{id}

### POST /work-orders/{id}/assign
**Request Body**:
```json
{
  "assigned_to": 10
}
```

### POST /work-orders/{id}/complete
**Request Body**:
```json
{
  "completion_notes": "Bearing replaced successfully. Tested operation.",
  "labor_hours": 2.5
}
```

### POST /work-orders/{id}/materials/issue
**Request Body**:
```json
{
  "inventory_item_id": 15,
  "quantity": 2
}
```

### DELETE /work-orders/{id}

---

## 📦 Inventory

### GET /inventory
**Query Params**: `part_id`, `low_stock` (boolean)

### POST /inventory
**Request Body**:
```json
{
  "part_number": "BRG-6205",
  "description": "Deep groove ball bearing",
  "quantity": 50,
  "unit_cost": 12.50,
  "reorder_point": 10
}
```

### GET /inventory/{id}
### PUT /inventory/{id}
### DELETE /inventory/{id}

### POST /inventory/stock-in
**Request Body**:
```json
{
  "inventory_item_id": 15,
  "quantity": 100,
  "transaction_type": "purchase"
}
```

### POST /inventory/stock-out
**Request Body**:
```json
{
  "inventory_item_id": 15,
  "quantity": 5,
  "work_order_id": 10
}
```

### POST /inventory/{id}/reserve
**Request Body**:
```json
{
  "quantity": 2,
  "work_order_id": 10
}
```

### POST /inventory/{id}/consume
**Request Body**:
```json
{
  "quantity": 2,
  "work_order_id": 10
}
```

---

## 🏭 Production

### GET /production-runs

### POST /production-runs
**Request Body**:
```json
{
  "batch_no": "BATCH-2024-001",
  "product_id": 5,
  "asset_id": 1,
  "start_time": "2024-01-15T08:00:00"
}
```

### GET /production-runs/{id}

### GET /production-runs/{id}/surveys
**Description**: Get all surveys for a production run

### POST /production-runs/{id}/surveys
**Description**: Create production survey (copy path in CI project)  
**Request Body**:
```json
{
  "survey_data": {
    "temperature": 75.5,
    "pressure": 120,
    "quality_score": 95
  }
}
```

---

## 📈 Reports

### GET /reports/pm-history
**Query Params**: `asset_id`, `equipment_id`, `start_date`, `end_date`  
**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "equipment_id": 1,
      "scheduled_date": "2024-01-15",
      "completed_date": "2024-01-15",
      "status": "completed"
    }
  ]
}
```

### GET /reports/wo-history
**Query Params**: `asset_id`, `equipment_id`

### GET /reports/inventory-movements
**Query Params**: `part_id`, `item_id`  
**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "inventory_item_id": 15,
      "transaction_type": "stock_out",
      "quantity": 2,
      "transaction_date": "2024-01-15",
      "work_order_id": 10
    }
  ]
}
```

### GET /reports/asset-utilization
**Query Params**: `start_date`, `end_date`

### GET /reports/maintenance-costs
**Query Params**: `start_date`, `end_date`

---

## 📄 Files Created

### Controllers
- `app/Controllers/Api/V1/DepartmentsController.php`
- `app/Controllers/Api/V1/ShiftsController.php`
- `app/Controllers/Api/V1/EmployeeShiftsController.php`
- `app/Controllers/Api/V1/SubPartsController.php`
- `app/Controllers/Api/V1/ProductionRunsController.php`
- `app/Controllers/Api/V1/ReportsController.php`
- `app/Controllers/Api/V1/AssetHierarchyController.php`

### Routes
- `app/Config/RoutesEam.php` (updated with 50+ new routes)

### Documentation
- `docs/openapi.yaml` (OpenAPI 3.0 specification)
- `docs/API_MANIFEST.md` (this file)

---

## 🔑 Response Format

All endpoints follow this standard format:

**Success Response**:
```json
{
  "status": "success",
  "data": { ... },
  "message": "Operation completed successfully"
}
```

**Error Response**:
```json
{
  "status": "error",
  "message": "Error description",
  "errors": { ... }
}
```

---

## 🚀 Testing

View OpenAPI documentation:
```bash
# Install Swagger UI or use online editor
https://editor.swagger.io/
# Upload docs/openapi.yaml
```

Test endpoints with cURL:
```bash
# Login
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Get facilities (with token)
curl -X GET http://localhost/factorymanager/public/index.php/api/v1/eam/facilities \
  -H "Authorization: Bearer <access_token>"
```

---

## 📊 Endpoint Summary

| Category | Endpoints | Auth Required |
|----------|-----------|---------------|
| Authentication | 3 | Partial |
| Users & Roles | 9 | Yes |
| Departments | 5 | Yes |
| Shifts | 8 | Yes |
| Asset Hierarchy | 36 | Yes |
| Meters | 6 | Yes |
| PM Rules & Schedules | 5 | Yes |
| Work Orders | 9 | Yes |
| Inventory | 10 | Yes |
| Production | 5 | Yes |
| Reports | 5 | Yes |
| **TOTAL** | **101** | - |
