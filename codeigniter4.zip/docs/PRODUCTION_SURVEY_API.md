# Production Survey API

## Overview
Production surveys capture quality, performance, and inspection data during production runs. Each survey is stored in the database and a timestamped JSON copy is saved to the filesystem.

---

## Create Production Survey

**POST** `/api/v1/eam/production-runs/{id}/surveys`

**Authorization:** Inspector, Supervisor, Manager, or Admin role required

**Headers:**
```
Authorization: Bearer <access_token>
Content-Type: application/json
```

**Request Body:**
```json
{
  "inspector_name": "John Doe",
  "inspection_date": "2025-01-15",
  "quality_metrics": {
    "temperature": 75.5,
    "pressure": 120,
    "humidity": 45
  },
  "defects": [
    {
      "type": "surface_scratch",
      "severity": "minor",
      "location": "top_panel"
    }
  ],
  "pass_fail": "pass",
  "notes": "All parameters within acceptable range",
  "photos": [
    "attachment_id_123",
    "attachment_id_124"
  ]
}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "survey_id": 1,
    "production_run_id": 5,
    "file_path": "production_surveys/5/2025-01-15_143022.json",
    "full_path": "C:\\wamp64\\www\\factorymanager\\writable\\production_surveys\\5\\2025-01-15_143022.json",
    "timestamp": "2025-01-15_143022"
  },
  "message": "Production survey created successfully"
}
```

---

## Get Production Run Surveys

**GET** `/api/v1/eam/production-runs/{id}/surveys`

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "production_run_id": 5,
      "survey_data": "{...}",
      "copy_in_ci_project_path": "production_surveys/5/2025-01-15_143022.json",
      "surveyed_by": 3,
      "surveyed_at": "2025-01-15 14:30:22",
      "created_at": "2025-01-15 14:30:22"
    }
  ],
  "message": "Surveys retrieved successfully"
}
```

---

## Sample Survey Payloads

### Quality Inspection Survey
```json
{
  "survey_type": "quality_inspection",
  "inspector_name": "Jane Smith",
  "inspection_date": "2025-01-15",
  "batch_no": "BATCH-2025-001",
  "product_name": "Widget A",
  "measurements": {
    "length_mm": 150.2,
    "width_mm": 75.1,
    "height_mm": 25.0,
    "weight_g": 245.5
  },
  "visual_inspection": {
    "surface_finish": "excellent",
    "color_match": "pass",
    "packaging": "intact"
  },
  "defects_found": 0,
  "sample_size": 50,
  "pass_count": 50,
  "fail_count": 0,
  "pass_rate": 100,
  "overall_result": "pass",
  "notes": "Batch meets all quality standards",
  "next_action": "approve_for_shipment"
}
```

### Performance Test Survey
```json
{
  "survey_type": "performance_test",
  "tester_name": "Mike Johnson",
  "test_date": "2025-01-15",
  "test_duration_minutes": 120,
  "equipment_id": 1,
  "operating_conditions": {
    "ambient_temp_c": 22,
    "humidity_percent": 45,
    "voltage_v": 220
  },
  "performance_metrics": {
    "output_rate_units_per_hour": 500,
    "energy_consumption_kwh": 15.5,
    "efficiency_percent": 92.5,
    "downtime_minutes": 5
  },
  "anomalies": [],
  "overall_performance": "excellent",
  "recommendations": "Continue current operating parameters"
}
```

### Safety Inspection Survey
```json
{
  "survey_type": "safety_inspection",
  "inspector_name": "Sarah Williams",
  "inspection_date": "2025-01-15",
  "area": "Production Line A",
  "checklist": [
    {
      "item": "Emergency stop buttons functional",
      "status": "pass",
      "notes": "All 5 buttons tested and working"
    },
    {
      "item": "Safety guards in place",
      "status": "pass",
      "notes": "All guards secured"
    },
    {
      "item": "Fire extinguishers accessible",
      "status": "pass",
      "notes": "4 extinguishers, all within date"
    },
    {
      "item": "PPE compliance",
      "status": "pass",
      "notes": "All workers wearing required PPE"
    }
  ],
  "hazards_identified": 0,
  "corrective_actions": [],
  "overall_rating": "safe",
  "next_inspection_date": "2025-02-15"
}
```

---

## File Storage Structure

```
writable/
└── production_surveys/
    ├── 1/
    │   ├── 2025-01-15_143022.json
    │   ├── 2025-01-15_160045.json
    │   └── 2025-01-16_091530.json
    ├── 2/
    │   └── 2025-01-15_145500.json
    └── 3/
        └── 2025-01-16_083000.json
```

**Naming Convention:** `{YYYY-MM-DD}_{HHmmss}.json`

---

## Database Schema

### production_surveys Table
```sql
CREATE TABLE production_surveys (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  production_run_id INT UNSIGNED NOT NULL,
  survey_data JSON NOT NULL,
  copy_in_ci_project_path VARCHAR(500),
  surveyed_by INT UNSIGNED NOT NULL,
  surveyed_at DATETIME NOT NULL,
  created_at DATETIME,
  FOREIGN KEY (production_run_id) REFERENCES production_runs(id) ON DELETE CASCADE,
  FOREIGN KEY (surveyed_by) REFERENCES users(id)
);
```

---

## Role-Based Access Control

**Allowed Roles:**
- Inspector
- Supervisor
- Manager
- Admin

**Validation:**
```sql
SELECT u.id, r.name as role_name
FROM users u
JOIN roles r ON u.role_id = r.id
WHERE u.id = ?
AND r.name IN ('inspector', 'supervisor', 'manager', 'admin')
```

---

## Error Responses

### Production Run Not Found
```json
{
  "status": "error",
  "message": "Production run not found"
}
```

### Unauthorized Role
```json
{
  "status": "error",
  "message": "Unauthorized: Inspector or Supervisor role required"
}
```

### Invalid Survey Data
```json
{
  "status": "error",
  "message": "Survey data is required"
}
```

### File Save Failed
```json
{
  "status": "error",
  "message": "Failed to save survey file"
}
```

---

## Complete Workflow Example

### 1. Create Production Run
```bash
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/production-runs \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "batch_no": "BATCH-2025-001",
    "product_id": 1,
    "asset_id": 1,
    "start_time": "2025-01-15 08:00:00"
  }'
```

Response:
```json
{
  "status": "success",
  "data": {
    "id": 5
  }
}
```

### 2. Create Survey for Production Run
```bash
curl -X POST \
  http://localhost/factorymanager/public/index.php/api/v1/eam/production-runs/5/surveys \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "survey_type": "quality_inspection",
    "inspector_name": "John Doe",
    "inspection_date": "2025-01-15",
    "measurements": {
      "temperature": 75.5,
      "pressure": 120
    },
    "pass_fail": "pass",
    "notes": "All parameters OK"
  }'
```

Response:
```json
{
  "status": "success",
  "data": {
    "survey_id": 1,
    "production_run_id": 5,
    "file_path": "production_surveys/5/2025-01-15_143022.json",
    "timestamp": "2025-01-15_143022"
  },
  "message": "Production survey created successfully"
}
```

### 3. Verify File Created
```bash
# Check file exists
ls writable/production_surveys/5/

# View file content
cat writable/production_surveys/5/2025-01-15_143022.json
```

Output:
```json
{
  "survey_type": "quality_inspection",
  "inspector_name": "John Doe",
  "inspection_date": "2025-01-15",
  "measurements": {
    "temperature": 75.5,
    "pressure": 120
  },
  "pass_fail": "pass",
  "notes": "All parameters OK"
}
```

### 4. Get All Surveys for Run
```bash
curl -X GET \
  http://localhost/factorymanager/public/index.php/api/v1/eam/production-runs/5/surveys \
  -H "Authorization: Bearer <token>"
```

---

## Integration with Work Orders

Link production surveys to work orders for traceability:

```json
{
  "survey_type": "post_maintenance_inspection",
  "work_order_id": 123,
  "production_run_id": 5,
  "inspector_name": "Jane Smith",
  "equipment_status": "operational",
  "test_results": {
    "vibration_test": "pass",
    "temperature_test": "pass",
    "pressure_test": "pass"
  },
  "certification": "Equipment certified for production"
}
```

---

## Best Practices

1. **Consistent Schema:** Use consistent field names across survey types
2. **Timestamps:** Always include inspection/test dates
3. **Traceability:** Link to work orders, equipment, and batches
4. **Photos:** Reference attachment IDs for visual evidence
5. **Signatures:** Include inspector names or digital signatures
6. **Validation:** Validate measurements against specifications
7. **Archival:** Keep JSON files for audit trail

---

## Testing

### Test Survey Creation
```bash
# Create test production run
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/production-runs \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"batch_no":"TEST-001","product_id":1,"asset_id":1}'

# Create test survey
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/production-runs/1/surveys \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"test":"data","result":"pass"}'

# Verify file created
dir writable\production_surveys\1\
```

---

**Files Created:**
- Service: `ProductionSurveyService.php`
- Model: `ProductionSurveyModel.php`
- Model: `ProductionRunModel.php`
- Controller: Updated `ProductionRunsController.php`
- Documentation: This file
