# Shift Assignment Setup Guide

## 1. Run Migrations

```bash
cd C:\wamp64\www\factorymanager
php spark migrate
```

This will:
- Add `department_id` to users table
- Update employee_shifts schema (user_id, department_id, start_date, end_date)
- Create foreign keys and indexes

## 2. Update User Records

Set department_id for supervisors and users:

```sql
-- Example: Assign users to departments
UPDATE users SET department_id = 1 WHERE id IN (5, 8, 12);
UPDATE users SET department_id = 2 WHERE id IN (15, 20, 22);
UPDATE users SET department_id = 3 WHERE id IN (25, 28);

-- Verify
SELECT id, username, role, department_id FROM users;
```

## 3. Create Shifts

```bash
POST http://localhost/factorymanager/public/api/v1/eam/shifts
Authorization: Bearer <token>
Content-Type: application/json

{
  "shift_name": "Morning Shift",
  "start_time": "08:00:00",
  "end_time": "16:00:00",
  "is_active": true
}
```

Create 3 shifts:
- Morning: 08:00-16:00
- Afternoon: 16:00-00:00
- Night: 00:00-08:00

## 4. Assign Users to Shifts

### Option A: Single Assignment (API)
```bash
POST http://localhost/factorymanager/public/api/v1/eam/employee-shifts
Authorization: Bearer <admin_or_supervisor_token>
Content-Type: application/json

{
  "user_id": 5,
  "shift_id": 1,
  "department_id": 2,
  "start_date": "2024-01-01",
  "end_date": "2024-12-31"
}
```

### Option B: Bulk Import (CSV)
```bash
POST http://localhost/factorymanager/public/api/v1/eam/employee-shifts/bulk-import
Authorization: Bearer <admin_or_supervisor_token>
Content-Type: multipart/form-data

file: shift_roster_sample.csv
```

## 5. View Department Roster

```bash
GET http://localhost/factorymanager/public/api/v1/eam/departments/2/roster?date=2024-01-15
Authorization: Bearer <token>
```

## 6. Test Authorization

### Admin (can assign anywhere)
```bash
# Login as admin
POST http://localhost/factorymanager/public/api/v1/eam/auth/login
{
  "username": "admin",
  "password": "admin123"
}

# Assign in any department
POST /api/v1/eam/employee-shifts
{
  "user_id": 5,
  "shift_id": 1,
  "department_id": 2,  # Any department works
  "start_date": "2024-01-01"
}
```

### Supervisor (own department only)
```bash
# Login as supervisor (department_id = 2)
POST /api/v1/eam/auth/login
{
  "username": "supervisor1",
  "password": "password"
}

# Assign in own department - SUCCESS
POST /api/v1/eam/employee-shifts
{
  "user_id": 5,
  "shift_id": 1,
  "department_id": 2,  # Supervisor's department
  "start_date": "2024-01-01"
}

# Assign in other department - FAIL (401)
POST /api/v1/eam/employee-shifts
{
  "user_id": 10,
  "shift_id": 1,
  "department_id": 3,  # Different department
  "start_date": "2024-01-01"
}
```

## Troubleshooting

### Issue: "Unauthorized" error
**Solution:** Ensure user has `role = 'admin'` or `role = 'supervisor'` with matching `department_id`

```sql
-- Check user role and department
SELECT id, username, role, department_id FROM users WHERE id = <user_id>;

-- Update if needed
UPDATE users SET role = 'supervisor', department_id = 2 WHERE id = <user_id>;
```

### Issue: "User already has shift assignment"
**Solution:** Check for overlapping dates

```sql
-- View existing assignments
SELECT * FROM employee_shifts WHERE user_id = <user_id>;

-- Delete conflicting assignment
DELETE FROM employee_shifts WHERE id = <assignment_id>;
```

### Issue: JWT token missing role/department_id
**Solution:** Re-login to get updated token with new payload structure

```bash
POST /api/v1/eam/auth/login
{
  "username": "your_username",
  "password": "your_password"
}
```

## Quick Test Script

```bash
# 1. Login
curl -X POST http://localhost/factorymanager/public/api/v1/eam/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'

# Save token from response
TOKEN="<your_token>"

# 2. Create shift
curl -X POST http://localhost/factorymanager/public/api/v1/eam/shifts \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"shift_name":"Morning","start_time":"08:00:00","end_time":"16:00:00"}'

# 3. Assign user
curl -X POST http://localhost/factorymanager/public/api/v1/eam/employee-shifts \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"user_id":5,"shift_id":1,"department_id":2,"start_date":"2024-01-01"}'

# 4. View roster
curl -X GET "http://localhost/factorymanager/public/api/v1/eam/departments/2/roster?date=2024-01-15" \
  -H "Authorization: Bearer $TOKEN"
```
