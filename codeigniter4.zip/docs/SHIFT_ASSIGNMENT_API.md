# Shift Assignment API Documentation

## Overview
Shift assignment system with role-based authorization and bulk import capabilities.

## Authorization Rules
- **Admin**: Can assign shifts in any department
- **Supervisor**: Can only assign shifts in their own department
- **Other roles**: Cannot assign shifts

---

## Endpoints

### 1. Create Shift
**POST** `/api/v1/eam/shifts`

Create a new shift definition.

**Request Body:**
```json
{
  "shift_name": "Morning Shift",
  "start_time": "08:00:00",
  "end_time": "16:00:00",
  "is_active": true
}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "id": 1
  },
  "message": "Shift created successfully"
}
```

---

### 2. Assign User to Shift
**POST** `/api/v1/eam/employee-shifts`

Assign a user to a shift with date range.

**Authorization:** Admin or department supervisor only

**Request Body:**
```json
{
  "user_id": 5,
  "shift_id": 1,
  "department_id": 2,
  "start_date": "2024-01-01",
  "end_date": "2024-12-31"
}
```

**Notes:**
- `end_date` is optional (null = indefinite assignment)
- System validates no overlapping assignments
- Only admin or department supervisor can assign

**Response:**
```json
{
  "status": "success",
  "data": {
    "assignment_id": 15
  },
  "message": "User assigned to shift successfully"
}
```

**Error Responses:**
```json
{
  "status": "error",
  "message": "Unauthorized: Only admin or department supervisor can assign shifts"
}
```

```json
{
  "status": "error",
  "message": "User already has shift assignment in this period"
}
```

---

### 3. Get Department Roster
**GET** `/api/v1/eam/departments/{id}/roster?date=YYYY-MM-DD`

Get all users assigned to shifts in a department on a specific date.

**Query Parameters:**
- `date` (optional): Date in YYYY-MM-DD format (defaults to today)

**Example:**
```
GET /api/v1/eam/departments/2/roster?date=2024-01-15
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "department_id": 2,
    "date": "2024-01-15",
    "roster": [
      {
        "id": 15,
        "user_id": 5,
        "username": "john.doe",
        "first_name": "John",
        "last_name": "Doe",
        "email": "john.doe@factory.com",
        "shift_id": 1,
        "shift_name": "Morning Shift",
        "start_time": "08:00:00",
        "end_time": "16:00:00",
        "start_date": "2024-01-01",
        "end_date": "2024-12-31"
      },
      {
        "id": 16,
        "user_id": 8,
        "username": "jane.smith",
        "first_name": "Jane",
        "last_name": "Smith",
        "email": "jane.smith@factory.com",
        "shift_id": 2,
        "shift_name": "Afternoon Shift",
        "start_time": "16:00:00",
        "end_time": "00:00:00",
        "start_date": "2024-01-01",
        "end_date": null
      }
    ]
  },
  "message": "Department roster retrieved successfully"
}
```

---

### 4. Bulk Import Shift Roster
**POST** `/api/v1/eam/employee-shifts/bulk-import`

Import multiple shift assignments from CSV file.

**Authorization:** Admin or department supervisor (validates per row)

**Request:**
- Content-Type: `multipart/form-data`
- Field: `file` (CSV file)

**CSV Format:**
```csv
user_id,shift_id,department_id,start_date,end_date
5,1,2,2024-01-01,2024-12-31
8,2,2,2024-01-01,
12,1,3,2024-02-01,2024-06-30
15,3,2,2024-01-15,2024-03-15
```

**CSV Rules:**
- Header row required (exact column names)
- `end_date` can be empty for indefinite assignment
- Each row validated independently
- Authorization checked per department

**Response:**
```json
{
  "status": "success",
  "data": {
    "imported": 3,
    "errors": [
      "Row 3: Unauthorized: Only admin or department supervisor can assign shifts",
      "Row 5: User already has shift assignment in this period"
    ]
  },
  "message": "Imported 3 shift assignments with 2 errors"
}
```

---

### 5. List Employee Shifts
**GET** `/api/v1/eam/employee-shifts?user_id=5&shift_id=1`

Get all shift assignments with filters.

**Query Parameters:**
- `user_id` (optional): Filter by user
- `shift_id` (optional): Filter by shift

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 15,
      "user_id": 5,
      "shift_id": 1,
      "department_id": 2,
      "start_date": "2024-01-01",
      "end_date": "2024-12-31",
      "shift_name": "Morning Shift",
      "username": "john.doe",
      "first_name": "John",
      "last_name": "Doe"
    }
  ],
  "message": "Employee shifts retrieved successfully"
}
```

---

### 6. Delete Shift Assignment
**DELETE** `/api/v1/eam/employee-shifts/{id}`

Remove a shift assignment.

**Response:**
```json
{
  "status": "success",
  "message": "Employee shift assignment deleted successfully"
}
```

---

## Database Schema

### shifts table
```sql
id INT PRIMARY KEY AUTO_INCREMENT
shift_name VARCHAR(50)
start_time TIME
end_time TIME
is_active BOOLEAN DEFAULT 1
created_at TIMESTAMP
updated_at TIMESTAMP
```

### employee_shifts table
```sql
id INT PRIMARY KEY AUTO_INCREMENT
user_id INT (FK to users.id)
shift_id INT (FK to shifts.id)
department_id INT (FK to departments.id)
start_date DATE
end_date DATE (nullable)
created_at TIMESTAMP
updated_at TIMESTAMP
```

---

## Workflow Examples

### Example 1: Assign Morning Shift to Technician
```bash
# 1. Create shift (admin only)
POST /api/v1/eam/shifts
{
  "shift_name": "Morning Shift",
  "start_time": "08:00:00",
  "end_time": "16:00:00"
}

# 2. Assign user to shift (admin or supervisor)
POST /api/v1/eam/employee-shifts
{
  "user_id": 5,
  "shift_id": 1,
  "department_id": 2,
  "start_date": "2024-01-01",
  "end_date": "2024-12-31"
}

# 3. View department roster
GET /api/v1/eam/departments/2/roster?date=2024-01-15
```

### Example 2: Bulk Import Monthly Roster
```bash
# Prepare CSV file with assignments
# Upload via API
POST /api/v1/eam/employee-shifts/bulk-import
Content-Type: multipart/form-data
file: roster_january_2024.csv

# Response shows imported count and any errors
```

### Example 3: Supervisor Assigns in Own Department
```bash
# Supervisor (department_id=2) assigns user in their department
POST /api/v1/eam/employee-shifts
Authorization: Bearer <supervisor_token>
{
  "user_id": 8,
  "shift_id": 1,
  "department_id": 2,  # Must match supervisor's department
  "start_date": "2024-02-01"
}

# Attempting to assign in different department fails
POST /api/v1/eam/employee-shifts
{
  "user_id": 10,
  "shift_id": 1,
  "department_id": 3,  # Different department
  "start_date": "2024-02-01"
}
# Response: 401 Unauthorized
```

---

## Validation Rules

### Shift Creation
- `shift_name`: Required, 2-50 characters
- `start_time`: Required, valid time format (HH:MM:SS)
- `end_time`: Required, valid time format (HH:MM:SS)

### Shift Assignment
- `user_id`: Required, must exist in users table
- `shift_id`: Required, must exist in shifts table
- `department_id`: Required, must exist in departments table
- `start_date`: Required, valid date (YYYY-MM-DD)
- `end_date`: Optional, must be after start_date if provided
- No overlapping assignments for same user
- Authorization: admin or department supervisor only

---

## Error Codes

| Code | Message | Description |
|------|---------|-------------|
| 400 | Validation error | Invalid input data |
| 401 | Unauthorized | User lacks permission |
| 404 | Not found | Resource doesn't exist |
| 409 | Conflict | Overlapping assignment |
