<?php
$host = 'localhost';
$dbname = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$db = new mysqli($host, $user, $pass, $dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "╔══════════════════════════════════════════════════════════════╗\n";
echo "║  CONVERTING DATABASE TO utf8mb4_unicode_520_ci               ║\n";
echo "╚══════════════════════════════════════════════════════════════╝\n\n";

// Step 1: Convert database default collation
echo "📋 Step 1: Converting database default collation...\n";
$db->query("ALTER DATABASE {$dbname} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci");
echo "✅ Database default collation updated\n\n";

// Step 2: Get all tables
echo "📊 Step 2: Getting all tables...\n";
$result = $db->query("SHOW TABLES");
$tables = [];
while ($row = $result->fetch_array()) {
    $tables[] = $row[0];
}
echo "✅ Found " . count($tables) . " tables\n\n";

// Step 3: Convert each table
echo "🔄 Step 3: Converting tables...\n";
$converted = 0;
$failed = 0;

foreach ($tables as $table) {
    try {
        // Disable foreign key checks temporarily
        $db->query("SET FOREIGN_KEY_CHECKS=0");
        
        // Convert table
        $db->query("ALTER TABLE `{$table}` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci");
        
        // Re-enable foreign key checks
        $db->query("SET FOREIGN_KEY_CHECKS=1");
        
        echo "   ✅ {$table}\n";
        $converted++;
    } catch (Exception $e) {
        echo "   ❌ {$table} - " . $e->getMessage() . "\n";
        $failed++;
    }
}

echo "\n";
echo "╔══════════════════════════════════════════════════════════════╗\n";
echo "║  CONVERSION COMPLETE                                         ║\n";
echo "╠══════════════════════════════════════════════════════════════╣\n";
echo "║  Total tables: " . str_pad(count($tables), 42) . "║\n";
echo "║  Converted: " . str_pad($converted, 45) . "║\n";
echo "║  Failed: " . str_pad($failed, 48) . "║\n";
echo "║  Status: utf8mb4_unicode_520_ci                              ║\n";
echo "╚══════════════════════════════════════════════════════════════╝\n";

$db->close();
