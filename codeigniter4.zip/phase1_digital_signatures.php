<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

// Digital Signatures Table
$sql = "CREATE TABLE IF NOT EXISTS survey_signatures (
    signature_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT NOT NULL,
    user_id INT NOT NULL,
    signature_type ENUM('operator', 'supervisor', 'manager', 'quality') NOT NULL,
    signature_data TEXT NOT NULL,
    signature_method ENUM('drawn', 'typed', 'uploaded', 'biometric') DEFAULT 'drawn',
    ip_address VARCHAR(45),
    device_info VARCHAR(255),
    signed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_valid BOOLEAN DEFAULT TRUE,
    invalidated_at TIMESTAMP NULL,
    invalidated_by INT NULL,
    invalidation_reason TEXT NULL,
    INDEX idx_survey_sig (survey_id),
    INDEX idx_user_sig (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

// Add signature fields to production_surveys
$fields = [
    "requires_operator_signature BOOLEAN DEFAULT FALSE",
    "requires_supervisor_signature BOOLEAN DEFAULT FALSE",
    "operator_signed_at TIMESTAMP NULL",
    "supervisor_signed_at TIMESTAMP NULL",
    "signature_compliance_level ENUM('none', 'basic', 'fda_21cfr11') DEFAULT 'basic'"
];
foreach ($fields as $field) {
    $db->query("ALTER TABLE production_surveys ADD COLUMN $field");
}

echo "✅ Digital Signatures tables created\n";
$db->close();
