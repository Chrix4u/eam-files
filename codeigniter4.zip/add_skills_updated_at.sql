ALTER TABLE skills ADD COLUMN updated_at DATETIME NULL AFTER created_at;
