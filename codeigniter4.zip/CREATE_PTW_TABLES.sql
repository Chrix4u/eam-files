-- Permit to Work System - Run this SQL

CREATE TABLE IF NOT EXISTS `permits_to_work` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `permit_number` VARCHAR(50) UNIQUE NOT NULL,
    `permit_type` ENUM('hot_work','confined_space','electrical','height','excavation','cold_work') NOT NULL,
    `work_order_id` INT(11) UNSIGNED NULL,
    `location` VARCHAR(255) NOT NULL,
    `equipment_id` INT(11) UNSIGNED NULL,
    `work_description` TEXT NOT NULL,
    `hazards_identified` TEXT NOT NULL,
    `risk_level` ENUM('low','medium','high','critical') NOT NULL,
    `control_measures` TEXT NOT NULL,
    `ppe_required` TEXT NOT NULL,
    `emergency_procedures` TEXT NULL,
    `requested_by` INT(11) UNSIGNED NOT NULL,
    `supervisor_id` INT(11) UNSIGNED NULL,
    `safety_officer_id` INT(11) UNSIGNED NULL,
    `area_manager_id` INT(11) UNSIGNED NULL,
    `authorized_workers` JSON NULL,
    `valid_from` DATETIME NOT NULL,
    `valid_until` DATETIME NOT NULL,
    `extended` BOOLEAN DEFAULT FALSE,
    `work_started_at` DATETIME NULL,
    `work_completed_at` DATETIME NULL,
    `permit_closed_by` INT(11) UNSIGNED NULL,
    `permit_closed_at` DATETIME NULL,
    `pre_work_inspection` JSON NULL,
    `post_work_inspection` JSON NULL,
    `incidents_reported` TEXT NULL,
    `status` ENUM('draft','pending_approval','approved','active','suspended','completed','cancelled') DEFAULT 'draft',
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_permit_number` (`permit_number`),
    KEY `idx_status` (`status`),
    KEY `idx_valid_from` (`valid_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `permit_approvals` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `permit_id` INT(11) UNSIGNED NOT NULL,
    `approver_id` INT(11) UNSIGNED NOT NULL,
    `approval_level` ENUM('supervisor','safety_officer','area_manager','plant_manager') NOT NULL,
    `approved` BOOLEAN NULL,
    `comments` TEXT NULL,
    `approved_at` DATETIME NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_permit_id` (`permit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `permit_extensions` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `permit_id` INT(11) UNSIGNED NOT NULL,
    `extended_by` INT(11) UNSIGNED NOT NULL,
    `reason` TEXT NOT NULL,
    `previous_valid_until` DATETIME NOT NULL,
    `new_valid_until` DATETIME NOT NULL,
    `approved_by` INT(11) UNSIGNED NULL,
    `approved_at` DATETIME NULL,
    `created_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_permit_id` (`permit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `loto_procedures` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `equipment_id` INT(11) UNSIGNED NOT NULL,
    `procedure_name` VARCHAR(255) NOT NULL,
    `procedure_code` VARCHAR(50) UNIQUE NOT NULL,
    `energy_sources` JSON NOT NULL,
    `isolation_steps` TEXT NOT NULL,
    `verification_steps` TEXT NOT NULL,
    `restoration_steps` TEXT NOT NULL,
    `created_by` INT(11) UNSIGNED NOT NULL,
    `approved_by` INT(11) UNSIGNED NULL,
    `approved_at` DATETIME NULL,
    `active` BOOLEAN DEFAULT TRUE,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_equipment_id` (`equipment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `loto_applications` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `permit_id` INT(11) UNSIGNED NULL,
    `work_order_id` INT(11) UNSIGNED NULL,
    `equipment_id` INT(11) UNSIGNED NOT NULL,
    `procedure_id` INT(11) UNSIGNED NOT NULL,
    `applied_by` INT(11) UNSIGNED NOT NULL,
    `applied_at` DATETIME NOT NULL,
    `lock_numbers` JSON NOT NULL,
    `tag_numbers` JSON NOT NULL,
    `verified_by` INT(11) UNSIGNED NULL,
    `verified_at` DATETIME NULL,
    `zero_energy_confirmed` BOOLEAN DEFAULT FALSE,
    `verification_notes` TEXT NULL,
    `removed_by` INT(11) UNSIGNED NULL,
    `removed_at` DATETIME NULL,
    `equipment_tested` BOOLEAN DEFAULT FALSE,
    `removal_notes` TEXT NULL,
    `status` ENUM('applied','verified','active','removed') DEFAULT 'applied',
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_permit_work_order` (`permit_id`, `work_order_id`),
    KEY `idx_equipment_id` (`equipment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `loto_locks` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `lock_number` VARCHAR(50) UNIQUE NOT NULL,
    `lock_type` VARCHAR(50) NOT NULL,
    `assigned_to` INT(11) UNSIGNED NULL,
    `current_location` VARCHAR(255) NULL,
    `status` ENUM('available','in_use','damaged','lost') DEFAULT 'available',
    `last_inspection_date` DATE NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `idx_lock_number` (`lock_number`),
    KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add permit fields to work orders
ALTER TABLE maintenance_work_orders 
ADD COLUMN permit_required BOOLEAN DEFAULT FALSE AFTER status,
ADD COLUMN permit_id INT(11) UNSIGNED NULL AFTER permit_required,
ADD COLUMN loto_required BOOLEAN DEFAULT FALSE AFTER permit_id,
ADD COLUMN loto_id INT(11) UNSIGNED NULL AFTER loto_required;

-- Insert migration record
INSERT INTO `migrations` (`version`, `class`, `group`, `namespace`, `time`, `batch`) 
VALUES ('2025-01-28-000002', 'App\\Database\\Migrations\\CreatePermitToWorkSystem', 'default', 'App', UNIX_TIMESTAMP(), 
    (SELECT COALESCE(MAX(batch), 0) + 1 FROM (SELECT batch FROM migrations) AS temp));
