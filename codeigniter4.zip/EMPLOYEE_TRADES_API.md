# Employee & Trades Management API

## ✅ Endpoints Ready

### Employee/User Management

#### 1. List All Users
```http
GET /api/v1/eam/users
GET /api/v1/eam/users?role=technician
GET /api/v1/eam/users?department_id=5
```

**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "full_name": "John Doe",
      "email": "john@example.com",
      "role": "technician",
      "department_id": 5,
      "department_name": "Maintenance",
      "supervisor_id": 10,
      "supervisor_name": "Jane Smith",
      "trades": [
        {"skill_name": "Electrical", "skill_code": "ELEC"},
        {"skill_name": "Mechanical", "skill_code": "MECH"}
      ]
    }
  ]
}
```

#### 2. Get Single User
```http
GET /api/v1/eam/users/{id}
```

**Response includes**: user details, trades, groups

#### 3. Create User/Employee
```http
POST /api/v1/eam/users
Content-Type: application/json

{
  "full_name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "technician",
  "department_id": 5,
  "supervisor_id": 10,
  "employee_number": "EMP001",
  "phone": "+233123456789"
}
```

#### 4. Update User
```http
PUT /api/v1/eam/users/{id}
Content-Type: application/json

{
  "full_name": "John Doe Updated",
  "department_id": 6,
  "supervisor_id": 11
}
```

#### 5. Get Technicians Only
```http
GET /api/v1/eam/users/technicians/list
```

#### 6. Get Supervisors Only
```http
GET /api/v1/eam/users/supervisors/list
```

---

### Trades/Skills Management

#### 1. List All Trades
```http
GET /api/v1/eam/trades
```

**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "skill_name": "Electrical",
      "skill_code": "ELEC",
      "description": "Electrical maintenance and repairs"
    },
    {
      "id": 2,
      "skill_name": "Mechanical",
      "skill_code": "MECH",
      "description": "Mechanical maintenance"
    }
  ]
}
```

#### 2. Create Trade
```http
POST /api/v1/eam/trades
Content-Type: application/json

{
  "skill_name": "Welding",
  "skill_code": "WELD",
  "description": "Welding and fabrication"
}
```

#### 3. Update Trade
```http
PUT /api/v1/eam/trades/{id}
Content-Type: application/json

{
  "skill_name": "Advanced Welding",
  "description": "Advanced welding techniques"
}
```

#### 4. Delete Trade
```http
DELETE /api/v1/eam/trades/{id}
```

#### 5. Assign Trades to User
```http
POST /api/v1/eam/trades/assign/{userId}
Content-Type: application/json

{
  "skill_ids": [1, 2, 5]
}
```

#### 6. Get User's Trades
```http
GET /api/v1/eam/trades/user/{userId}
```

**Response**:
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "skill_name": "Electrical",
      "skill_code": "ELEC",
      "assigned_at": "2024-01-15 10:30:00"
    }
  ]
}
```

---

## Frontend Integration Examples

### Create Employee Form
```typescript
// Create new employee
const createEmployee = async (data) => {
  const response = await fetch('/api/v1/eam/users', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      full_name: data.name,
      email: data.email,
      password: data.password,
      role: data.role,
      department_id: data.departmentId,
      supervisor_id: data.supervisorId,
      employee_number: data.employeeNumber
    })
  });
  return response.json();
};
```

### Assign Trades to Technician
```typescript
// Assign trades
const assignTrades = async (userId, tradeIds) => {
  const response = await fetch(`/api/v1/eam/trades/assign/${userId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ skill_ids: tradeIds })
  });
  return response.json();
};
```

### Load Trades for Dropdown
```typescript
// Get all trades for selection
const loadTrades = async () => {
  const response = await fetch('/api/v1/eam/trades');
  const data = await response.json();
  return data.data; // Array of trades
};
```

### Load Technicians with Trades
```typescript
// Get technicians with their trades
const loadTechnicians = async () => {
  const response = await fetch('/api/v1/eam/users/technicians/list');
  const data = await response.json();
  return data.data; // Each has 'trades' array
};
```

---

## Database Tables

### users
- id, full_name, email, password
- role (admin, manager, supervisor, technician, operator, planner)
- department_id, supervisor_id
- employee_number, phone
- created_at, updated_at

### skills (trades)
- id, skill_name, skill_code
- description
- created_at, updated_at

### user_skills (assignments)
- id, user_id, skill_id
- created_at

---

## Status: ✅ READY TO USE

All endpoints are operational and tested. Frontend can now:
1. Create/edit employees
2. Assign departments and supervisors
3. Create/manage trades
4. Assign trades to technicians
5. View technicians with their trades
