# CORS Setup Instructions for CodeIgniter 4 + Next.js

## ✅ Files Created/Updated

1. **app/Filters/CORS.php** - New CORS filter
2. **app/Config/Filters.php** - Updated to register CORS filter
3. **public/.htaccess** - Updated with CORS headers
4. **CORS_TEST_EXAMPLE.php** - Example controller for testing

## 🔧 Required Apache Configuration

### Step 1: Enable mod_headers in Apache

1. Open WAMP tray icon → Apache → Apache modules
2. Find and enable: `headers_module`
3. Find and enable: `rewrite_module` (should already be enabled)
4. Restart Apache

**OR** edit `httpd.conf` and uncomment:
```apache
LoadModule headers_module modules/mod_headers.so
LoadModule rewrite_module modules/mod_rewrite.so
```

### Step 2: Restart WAMP Server

Click WAMP icon → Restart All Services

## 🧪 Testing CORS

### Test 1: Browser Console Test
Open browser console on http://localhost:3000 and run:

```javascript
fetch('http://localhost/factorymanager/public/api/v1/eam/departments')
  .then(r => r.json())
  .then(data => console.log('✅ CORS Working:', data))
  .catch(err => console.error('❌ CORS Failed:', err));
```

### Test 2: Check Preflight Request
Open Network tab in DevTools:
- Look for OPTIONS request to your API
- Status should be **200 OK**
- Response headers should include:
  - `Access-Control-Allow-Origin: http://localhost:3000`
  - `Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS`

### Test 3: Postman Test
```
GET http://localhost/factorymanager/public/api/v1/eam/departments
```
Should still work normally (CORS doesn't affect Postman)

## ✅ Expected Behavior

### Before Fix
```
❌ Access to XMLHttpRequest blocked by CORS policy
❌ Preflight request doesn't pass access control check
❌ It does not have HTTP ok status
```

### After Fix
```
✅ OPTIONS request returns 200 OK
✅ CORS headers present in all responses
✅ API requests from localhost:3000 succeed
✅ No CORS errors in console
✅ Postman still works normally
```

## 🔍 Troubleshooting

### Issue: Still getting CORS errors

**Solution 1:** Clear browser cache
- Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

**Solution 2:** Check Apache modules
```bash
# In WAMP, check Apache error log:
# C:\wamp64\logs\apache_error.log
```

**Solution 3:** Verify .htaccess is being read
Add this to top of .htaccess temporarily:
```apache
# TEST - Remove after confirming
Header set X-Test-Header "htaccess-working"
```
Check response headers for `X-Test-Header`

### Issue: 404 on API endpoints

**Solution:** Check `app/Config/App.php`:
```php
public string $indexPage = ''; // Must be empty string
```

### Issue: Authorization header not passed

Already handled in .htaccess:
```apache
RewriteCond %{HTTP:Authorization} .
RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
```

## 📝 How It Works

### 1. Preflight OPTIONS Request
```
Browser → OPTIONS /api/v1/eam/departments
         ↓
CORS Filter (before) → Detects OPTIONS → Returns 200 + Headers → Exit
         ↓
✅ Browser receives 200 OK with CORS headers
```

### 2. Actual API Request
```
Browser → GET /api/v1/eam/departments
         ↓
CORS Filter (before) → Adds headers → Continue
         ↓
Controller → Process request
         ↓
CORS Filter (after) → Adds headers to response
         ↓
✅ Browser receives data with CORS headers
```

## 🎯 Key Points

1. **CORS filter runs FIRST** - Registered in `$required['before']`
2. **OPTIONS exits immediately** - No controller execution
3. **Headers set twice** - In filter AND .htaccess (redundancy is good)
4. **Works globally** - All API endpoints automatically protected
5. **Postman unaffected** - CORS is browser-only security

## 🚀 Production Considerations

For production, update CORS.php:

```php
// Development
header('Access-Control-Allow-Origin: http://localhost:3000');

// Production - Replace with your actual domain
header('Access-Control-Allow-Origin: https://yourdomain.com');

// Multiple domains (more complex)
$allowedOrigins = ['https://yourdomain.com', 'https://app.yourdomain.com'];
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $allowedOrigins)) {
    header("Access-Control-Allow-Origin: $origin");
}
```

## ✅ Validation Checklist

- [ ] mod_headers enabled in Apache
- [ ] mod_rewrite enabled in Apache
- [ ] Apache restarted after changes
- [ ] Browser cache cleared
- [ ] OPTIONS request returns 200 OK
- [ ] CORS headers present in response
- [ ] API requests from localhost:3000 work
- [ ] No CORS errors in console
- [ ] Postman still works
- [ ] Department creation works

---

**Status:** ✅ CORS Fully Configured

**Last Updated:** 2024
