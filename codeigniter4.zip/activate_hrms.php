<?php
require 'vendor/autoload.php';

$db = \Config\Database::connect();

// Check company module activation
$result = $db->query("SELECT * FROM company_module_licenses WHERE module_code='HRMS'")->getResultArray();

if (empty($result)) {
    echo "HRMS not activated for company. Activating now...\n";
    $db->query("INSERT INTO company_module_licenses (company_id, module_code, is_active, activated_at) VALUES (1, 'HRMS', 1, NOW())");
    echo "HRMS activated for company!\n";
} else {
    echo "HRMS status: " . ($result[0]['is_active'] ? 'ACTIVE' : 'INACTIVE') . "\n";
    if (!$result[0]['is_active']) {
        $db->query("UPDATE company_module_licenses SET is_active=1, activated_at=NOW() WHERE module_code='HRMS'");
        echo "HRMS activated!\n";
    }
}
