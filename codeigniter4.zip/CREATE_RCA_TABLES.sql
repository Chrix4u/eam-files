-- Enterprise-Grade RCA, FMEA, RCM, Parts Optimization, and KPI Tables
-- Run this SQL directly in MySQL if migration fails

-- RCA 5 Whys Analysis
CREATE TABLE IF NOT EXISTS `rca_5whys` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id` INT(11) UNSIGNED NOT NULL,
  `problem_statement` TEXT NOT NULL,
  `why1` TEXT NULL,
  `why2` TEXT NULL,
  `why3` TEXT NULL,
  `why4` TEXT NULL,
  `why5` TEXT NULL,
  `root_cause` TEXT NULL,
  `created_by` INT(11) UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_asset_id` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- RCA Fishbone Analysis
CREATE TABLE IF NOT EXISTS `rca_fishbone` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id` INT(11) UNSIGNED NOT NULL,
  `problem_statement` TEXT NOT NULL,
  `people` JSON NULL,
  `process` JSON NULL,
  `equipment` JSON NULL,
  `materials` JSON NULL,
  `environment` JSON NULL,
  `management` JSON NULL,
  `created_by` INT(11) UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_asset_id` (`asset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Failure Modes (FMEA)
CREATE TABLE IF NOT EXISTS `failure_modes` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(50) NOT NULL UNIQUE,
  `name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `description` TEXT NULL,
  `severity` INT(2) NOT NULL,
  `occurrence` INT(2) NOT NULL,
  `detection` INT(2) NOT NULL,
  `rpn` INT(4) NOT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_code` (`code`),
  KEY `idx_rpn` (`rpn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- RCM Assessments
CREATE TABLE IF NOT EXISTS `rcm_assessments` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id` INT(11) UNSIGNED NOT NULL,
  `safety_score` INT(2) NOT NULL,
  `production_score` INT(2) NOT NULL,
  `quality_score` INT(2) NOT NULL,
  `environmental_score` INT(2) NOT NULL,
  `cost_score` INT(2) NOT NULL,
  `total_score` INT(3) NOT NULL,
  `criticality_level` ENUM('critical', 'high', 'medium', 'low') NOT NULL,
  `maintenance_strategy` ENUM('predictive', 'preventive', 'corrective') NOT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_asset_id` (`asset_id`),
  KEY `idx_criticality` (`criticality_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Parts Optimization
CREATE TABLE IF NOT EXISTS `parts_optimization` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `part_id` INT(11) UNSIGNED NOT NULL,
  `abc_class` ENUM('A', 'B', 'C') NOT NULL,
  `xyz_class` ENUM('X', 'Y', 'Z') NOT NULL,
  `annual_usage` INT(11) NOT NULL,
  `unit_cost` DECIMAL(10,2) NOT NULL,
  `annual_cost` DECIMAL(10,2) NOT NULL,
  `eoq` INT(11) NOT NULL,
  `rop` INT(11) NOT NULL,
  `current_stock` INT(11) NOT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_part_id` (`part_id`),
  KEY `idx_abc_class` (`abc_class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- KPI Snapshots
CREATE TABLE IF NOT EXISTS `kpi_snapshots` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `snapshot_date` DATE NOT NULL,
  `mtbf` DECIMAL(10,2) NOT NULL,
  `mttr` DECIMAL(10,2) NOT NULL,
  `oee` DECIMAL(5,2) NOT NULL,
  `pm_compliance` DECIMAL(5,2) NOT NULL,
  `reactive_ratio` DECIMAL(5,2) NOT NULL,
  `cost_per_asset` DECIMAL(10,2) NOT NULL,
  `schedule_compliance` DECIMAL(5,2) NOT NULL,
  `wrench_time` DECIMAL(5,2) NOT NULL,
  `created_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_snapshot_date` (`snapshot_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verify tables created
SELECT 'Tables created successfully!' as status;
SHOW TABLES LIKE 'rca_%';
SHOW TABLES LIKE 'failure_modes';
SHOW TABLES LIKE 'rcm_assessments';
SHOW TABLES LIKE 'parts_optimization';
SHOW TABLES LIKE 'kpi_snapshots';
