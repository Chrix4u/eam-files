<?php
$mysqli = new mysqli('localhost', 'factory_manager', 'myjesus4mE', 'factorymanager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

// Check if supervisor_id column exists
echo "=== CHECKING TABLE STRUCTURE ===\n";
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'supervisor_id'");
if ($result->num_rows > 0) {
    echo "supervisor_id column EXISTS\n";
} else {
    echo "supervisor_id column DOES NOT EXIST\n";
}

// Check users
echo "\n=== USERS TABLE ===\n";
$result = $mysqli->query("SELECT id, username, role, supervisor_id, department_id FROM users");
while ($row = $result->fetch_assoc()) {
    echo "ID: {$row['id']}, Username: {$row['username']}, Role: {$row['role']}, Supervisor: {$row['supervisor_id']}, Dept: {$row['department_id']}\n";
}

// Check maintenance requests
echo "\n=== MAINTENANCE REQUESTS ===\n";
$result = $mysqli->query("SELECT id, requested_by, supervisor_id, department_id, title FROM maintenance_requests");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']}, By: {$row['requested_by']}, Supervisor: " . ($row['supervisor_id'] ?? 'NULL') . ", Dept: " . ($row['department_id'] ?? 'NULL') . ", Title: {$row['title']}\n";
    }
} else {
    echo "Error: " . $mysqli->error . "\n";
}

$mysqli->close();
