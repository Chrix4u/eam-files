<?php
/**
 * Create Model Viewer Tables Directly
 * Run: php create_model_viewer_tables_direct.php
 */

// Load environment variables
if (file_exists('.env')) {
    $env = parse_ini_file('.env');
    foreach ($env as $key => $value) {
        $_ENV[$key] = $value;
    }
}

$host = $_ENV['database_default_hostname'] ?? 'localhost';
$database = $_ENV['database_default_database'] ?? 'factory_manager';
$username = $_ENV['database_default_username'] ?? 'root';
$password = $_ENV['database_default_password'] ?? 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Creating Model Viewer Tables...\n";
    
    // 1. Machine Models Table
    $sql = "
    CREATE TABLE IF NOT EXISTS machine_models (
        id CHAR(36) NOT NULL PRIMARY KEY,
        machine_id INT NOT NULL,
        model_type ENUM('glb', 'gltf', 'svg') NOT NULL,
        file_path VARCHAR(500) NOT NULL,
        optimized_file_path VARCHAR(500) NULL,
        file_size BIGINT NULL,
        thumbnail_path VARCHAR(500) NULL,
        version INT DEFAULT 1,
        uploader_id INT NOT NULL,
        status ENUM('uploaded', 'processing', 'processed', 'failed') DEFAULT 'uploaded',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_machine_id (machine_id),
        INDEX idx_model_type_status (model_type, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ";
    $pdo->exec($sql);
    echo "✓ machine_models table created\n";
    
    // 2. Model Layers Table
    $sql = "
    CREATE TABLE IF NOT EXISTS model_layers (
        id CHAR(36) NOT NULL PRIMARY KEY,
        model_id CHAR(36) NOT NULL,
        name VARCHAR(255) NOT NULL,
        order_index INT DEFAULT 0,
        visible_default BOOLEAN DEFAULT TRUE,
        metadata JSON NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_model_id (model_id),
        INDEX idx_model_order (model_id, order_index)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ";
    $pdo->exec($sql);
    echo "✓ model_layers table created\n";
    
    // 3. Model Hotspots Table
    $sql = "
    CREATE TABLE IF NOT EXISTS model_hotspots (
        id CHAR(36) NOT NULL PRIMARY KEY,
        model_id CHAR(36) NOT NULL,
        node_type ENUM('machine', 'assembly', 'part') NOT NULL,
        node_id INT NOT NULL,
        label VARCHAR(255) NOT NULL,
        shape ENUM('circle', 'rect', 'poly') DEFAULT 'circle',
        coords JSON NULL,
        mesh_name VARCHAR(255) NULL,
        world_coords JSON NULL,
        metadata JSON NULL,
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_model_id (model_id),
        INDEX idx_node_type_id (node_type, node_id),
        INDEX idx_mesh_name (mesh_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ";
    $pdo->exec($sql);
    echo "✓ model_hotspots table created\n";
    
    // 4. Part Geometry Table
    $sql = "
    CREATE TABLE IF NOT EXISTS part_geometry (
        id CHAR(36) NOT NULL PRIMARY KEY,
        part_id INT NOT NULL,
        model_id CHAR(36) NOT NULL,
        mesh_name VARCHAR(255) NULL,
        mapping_confidence FLOAT DEFAULT 0.0,
        metadata JSON NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_part_id (part_id),
        INDEX idx_model_id (model_id),
        INDEX idx_mesh_name (mesh_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ";
    $pdo->exec($sql);
    echo "✓ part_geometry table created\n";
    
    // 5. Model Processing Jobs Table
    $sql = "
    CREATE TABLE IF NOT EXISTS model_processing_jobs (
        id CHAR(36) NOT NULL PRIMARY KEY,
        model_id CHAR(36) NOT NULL,
        status ENUM('pending', 'running', 'success', 'failed') DEFAULT 'pending',
        logs TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_model_id (model_id),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ";
    $pdo->exec($sql);
    echo "✓ model_processing_jobs table created\n";
    
    // 6. Model Navigation History Table (optional)
    $sql = "
    CREATE TABLE IF NOT EXISTS model_navigation_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        model_id CHAR(36) NOT NULL,
        view_state JSON NULL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_model (user_id, model_id),
        INDEX idx_timestamp (timestamp)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
    ";
    $pdo->exec($sql);
    echo "✓ model_navigation_history table created\n";
    
    echo "\nAll Model Viewer tables created successfully!\n";
    echo "\nNext steps:\n";
    echo "1. Install Node.js dependencies: cd node-processing && npm install\n";
    echo "2. Start the processing service: pm2 start process-model.js\n";
    echo "3. Access the model upload page: /models/upload\n";
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>