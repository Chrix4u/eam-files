<?php
// Convert all MyISAM tables to InnoDB
$pdo = new PDO("mysql:host=localhost;dbname=factory_manager", "root", "myjesus4mE");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║         CONVERTING MyISAM TABLES TO InnoDB                 ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

try {
    // Get all MyISAM tables
    $stmt = $pdo->query("
        SELECT TABLE_NAME 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = 'factory_manager' 
        AND ENGINE = 'MyISAM'
    ");
    
    $myisamTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    if (count($myisamTables) == 0) {
        echo "✅ All tables are already using InnoDB!\n";
        exit(0);
    }
    
    echo "Found " . count($myisamTables) . " MyISAM tables to convert\n\n";
    
    $converted = 0;
    $failed = 0;
    
    foreach ($myisamTables as $table) {
        try {
            echo "Converting $table... ";
            $pdo->exec("ALTER TABLE `$table` ENGINE=InnoDB");
            echo "✅\n";
            $converted++;
        } catch (Exception $e) {
            echo "❌ " . $e->getMessage() . "\n";
            $failed++;
        }
    }
    
    echo "\n";
    echo "╔════════════════════════════════════════════════════════════╗\n";
    echo "║                  CONVERSION COMPLETE                       ║\n";
    echo "╚════════════════════════════════════════════════════════════╝\n\n";
    
    echo "✅ Converted: $converted tables\n";
    if ($failed > 0) {
        echo "❌ Failed: $failed tables\n";
    }
    
    // Verify
    echo "\nVerifying...\n";
    $stmt = $pdo->query("
        SELECT ENGINE, COUNT(*) as count 
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = 'factory_manager' 
        GROUP BY ENGINE
    ");
    
    $engines = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($engines as $engine) {
        echo "   {$engine['ENGINE']}: {$engine['count']} tables\n";
    }
    
    echo "\n✅ All tables now support foreign keys and transactions!\n";
    
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
