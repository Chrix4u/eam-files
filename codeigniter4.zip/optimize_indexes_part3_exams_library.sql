-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 3: ONLINE EXAMS & LIBRARY
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- ONLINE_EXAM TABLE
ALTER TABLE `online_exam` ADD INDEX IF NOT EXISTS `idx_class_section_online` (`class_id`, `section_id`, `subject_id`);
ALTER TABLE `online_exam` ADD INDEX IF NOT EXISTS `idx_year_term_online` (`running_year`(50), `term`(50), `sem`(50));
ALTER TABLE `online_exam` ADD INDEX IF NOT EXISTS `idx_status_online` (`status`(50));
ALTER TABLE `online_exam` ADD INDEX IF NOT EXISTS `idx_exam_date` (`exam_date`);
ALTER TABLE `online_exam` ADD INDEX IF NOT EXISTS `idx_code_online` (`code`);

-- ONLINE_EXAM_RESULT TABLE
ALTER TABLE `online_exam_result` ADD INDEX IF NOT EXISTS `idx_student_online_exam` (`student_id`, `online_exam_id`);
ALTER TABLE `online_exam_result` ADD INDEX IF NOT EXISTS `idx_status_result` (`status`(50));
ALTER TABLE `online_exam_result` ADD INDEX IF NOT EXISTS `idx_result` (`result`(50));

-- QUESTION_BANK TABLE
ALTER TABLE `question_bank` ADD INDEX IF NOT EXISTS `idx_online_exam_question` (`online_exam_id`);
ALTER TABLE `question_bank` ADD INDEX IF NOT EXISTS `idx_type_question` (`type`);

-- PORTFOLIO_ASSESSMENT TABLE
ALTER TABLE `portfolio_assessment` ADD INDEX IF NOT EXISTS `idx_student_exam_portfolio` (`student_id`, `exam_id`, `class_id`);
ALTER TABLE `portfolio_assessment` ADD INDEX IF NOT EXISTS `idx_subject_portfolio` (`subject_id`);
ALTER TABLE `portfolio_assessment` ADD INDEX IF NOT EXISTS `idx_year_term_portfolio` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `portfolio_assessment` ADD INDEX IF NOT EXISTS `idx_week` (`week`(50));
ALTER TABLE `portfolio_assessment` ADD INDEX IF NOT EXISTS `idx_section_portfolio` (`section_id`);

-- BOOK TABLE
ALTER TABLE `book` ADD INDEX IF NOT EXISTS `idx_class_book` (`class_id`(50));
ALTER TABLE `book` ADD INDEX IF NOT EXISTS `idx_status_book` (`status`(50));

-- BOOK_REQUEST TABLE
ALTER TABLE `book_request` ADD INDEX IF NOT EXISTS `idx_book_request` (`book_id`, `student_id`);
ALTER TABLE `book_request` ADD INDEX IF NOT EXISTS `idx_status_book_request` (`status`);
ALTER TABLE `book_request` ADD INDEX IF NOT EXISTS `idx_issue_dates` (`issue_start_date`(50), `issue_end_date`(50));

-- ACADEMIC_SYLLABUS TABLE
ALTER TABLE `academic_syllabus` ADD INDEX IF NOT EXISTS `idx_class_syllabus` (`class_id`);
ALTER TABLE `academic_syllabus` ADD INDEX IF NOT EXISTS `idx_subject_syllabus` (`subject_id`);
ALTER TABLE `academic_syllabus` ADD INDEX IF NOT EXISTS `idx_year_syllabus` (`year`(50));
ALTER TABLE `academic_syllabus` ADD INDEX IF NOT EXISTS `idx_uploader` (`uploader_id`, `uploader_type`(50));

-- DOCUMENT TABLE
ALTER TABLE `document` ADD INDEX IF NOT EXISTS `idx_class_document` (`class_id`(50));
ALTER TABLE `document` ADD INDEX IF NOT EXISTS `idx_teacher_document` (`teacher_id`);
ALTER TABLE `document` ADD INDEX IF NOT EXISTS `idx_subject_document` (`subject_id`);
ALTER TABLE `document` ADD INDEX IF NOT EXISTS `idx_timestamp_document` (`timestamp`(50));

-- QUESTION_PAPER TABLE
ALTER TABLE `question_paper` ADD INDEX IF NOT EXISTS `idx_class_exam_paper` (`class_id`, `exam_id`);
ALTER TABLE `question_paper` ADD INDEX IF NOT EXISTS `idx_teacher_paper` (`teacher_id`);

COMMIT;
