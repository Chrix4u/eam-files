<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

// Check if reviewed_by column exists
echo "=== CHECKING maintenance_requests COLUMNS ===\n";
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests");
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . " - " . $row['Type'] . "\n";
}

// Check if reviewed_by exists
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'reviewed_by'");
if ($result->num_rows > 0) {
    echo "\nreviewed_by column EXISTS\n";
} else {
    echo "\nreviewed_by column DOES NOT EXIST - NEED TO ADD IT\n";
    echo "Adding reviewed_by column...\n";
    $mysqli->query("ALTER TABLE maintenance_requests ADD COLUMN reviewed_by INT NULL AFTER supervisor_id");
    echo "Done!\n";
}

// Check if reviewed_at exists
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'reviewed_at'");
if ($result->num_rows > 0) {
    echo "reviewed_at column EXISTS\n";
} else {
    echo "reviewed_at column DOES NOT EXIST - NEED TO ADD IT\n";
    echo "Adding reviewed_at column...\n";
    $mysqli->query("ALTER TABLE maintenance_requests ADD COLUMN reviewed_at DATETIME NULL AFTER reviewed_by");
    echo "Done!\n";
}

// Check if rejection_reason exists
$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'rejection_reason'");
if ($result->num_rows > 0) {
    echo "rejection_reason column EXISTS\n";
} else {
    echo "rejection_reason column DOES NOT EXIST - NEED TO ADD IT\n";
    echo "Adding rejection_reason column...\n";
    $mysqli->query("ALTER TABLE maintenance_requests ADD COLUMN rejection_reason TEXT NULL AFTER reviewed_at");
    echo "Done!\n";
}

$mysqli->close();
