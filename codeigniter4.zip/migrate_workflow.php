<?php

// Direct database connection
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Updating maintenance_requests table...\n\n";

    // Update workflow_status enum
    echo "1. Updating workflow_status enum...\n";
    $pdo->exec("ALTER TABLE maintenance_requests 
        MODIFY COLUMN workflow_status ENUM(
          'pending',
          'supervisor_review',
          'approved',
          'rejected',
          'assigned_to_planner',
          'work_order_created',
          'in_progress',
          'technician_completed',
          'planner_confirmed',
          'satisfactory',
          'supervisor_rejected',
          'closed'
        ) DEFAULT 'pending'");
    echo "   ✓ Workflow status enum updated\n\n";

    // Get existing columns
    $stmt = $pdo->query("SHOW COLUMNS FROM maintenance_requests");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Add columns if they don't exist
    if (!in_array('technician_completed_by', $columns)) {
        echo "2. Adding technician_completed_by...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN technician_completed_by INT(11) UNSIGNED NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "2. technician_completed_by already exists\n\n";
    }
    
    if (!in_array('technician_completed_at', $columns)) {
        echo "3. Adding technician_completed_at...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN technician_completed_at DATETIME NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "3. technician_completed_at already exists\n\n";
    }
    
    if (!in_array('planner_confirmed_by', $columns)) {
        echo "4. Adding planner_confirmed_by...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN planner_confirmed_by INT(11) UNSIGNED NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "4. planner_confirmed_by already exists\n\n";
    }
    
    if (!in_array('planner_confirmed_at', $columns)) {
        echo "5. Adding planner_confirmed_at...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN planner_confirmed_at DATETIME NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "5. planner_confirmed_at already exists\n\n";
    }
    
    if (!in_array('supervisor_rejection_reason', $columns)) {
        echo "6. Adding supervisor_rejection_reason...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN supervisor_rejection_reason TEXT NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "6. supervisor_rejection_reason already exists\n\n";
    }
    
    if (!in_array('supervisor_rejected_by', $columns)) {
        echo "7. Adding supervisor_rejected_by...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN supervisor_rejected_by INT(11) UNSIGNED NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "7. supervisor_rejected_by already exists\n\n";
    }
    
    if (!in_array('supervisor_rejected_at', $columns)) {
        echo "8. Adding supervisor_rejected_at...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN supervisor_rejected_at DATETIME NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "8. supervisor_rejected_at already exists\n\n";
    }
    
    if (!in_array('satisfactory_checked_by', $columns)) {
        echo "9. Adding satisfactory_checked_by...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN satisfactory_checked_by INT(11) UNSIGNED NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "9. satisfactory_checked_by already exists\n\n";
    }
    
    if (!in_array('satisfactory_checked_at', $columns)) {
        echo "10. Adding satisfactory_checked_at...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN satisfactory_checked_at DATETIME NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "10. satisfactory_checked_at already exists\n\n";
    }
    
    if (!in_array('closed_by', $columns)) {
        echo "11. Adding closed_by...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN closed_by INT(11) UNSIGNED NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "11. closed_by already exists\n\n";
    }
    
    if (!in_array('closed_at', $columns)) {
        echo "12. Adding closed_at...\n";
        $pdo->exec("ALTER TABLE maintenance_requests ADD COLUMN closed_at DATETIME NULL");
        echo "   ✓ Added\n\n";
    } else {
        echo "12. closed_at already exists\n\n";
    }
    
    echo "\n✅ Migration completed successfully!\n";
    echo "\nYou can now use the new workflow:\n";
    echo "  - Technician completes → technician_completed\n";
    echo "  - Planner confirms → planner_confirmed\n";
    echo "  - Supervisor verifies → satisfactory/supervisor_rejected\n";
    echo "  - Planner closes/reschedules → closed/work_order_created\n\n";
    
} catch (PDOException $e) {
    echo "\n❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}
