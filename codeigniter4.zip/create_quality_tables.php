<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS non_conformances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nc_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    severity ENUM('minor', 'major', 'critical') NOT NULL,
    status ENUM('open', 'investigating', 'resolved', 'closed') DEFAULT 'open',
    asset_id INT NULL,
    root_cause TEXT NULL,
    corrective_action TEXT NULL,
    preventive_action TEXT NULL,
    reported_by INT NOT NULL,
    assigned_to INT NULL,
    resolved_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_severity (severity)
)";

if ($db->query($sql)) {
    echo "✓ Table 'non_conformances' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql2 = "CREATE TABLE IF NOT EXISTS inspection_checklists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    asset_type VARCHAR(100) NULL,
    frequency ENUM('daily', 'weekly', 'monthly', 'quarterly', 'annual') NOT NULL,
    checklist_items JSON NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($db->query($sql2)) {
    echo "✓ Table 'inspection_checklists' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql3 = "CREATE TABLE IF NOT EXISTS inspection_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    checklist_id INT NOT NULL,
    asset_id INT NOT NULL,
    inspector_id INT NOT NULL,
    results JSON NOT NULL,
    pass_fail ENUM('pass', 'fail', 'conditional') NOT NULL,
    notes TEXT NULL,
    inspection_date DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (checklist_id) REFERENCES inspection_checklists(id)
)";

if ($db->query($sql3)) {
    echo "✓ Table 'inspection_results' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql4 = "CREATE TABLE IF NOT EXISTS capa_actions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nc_id INT NOT NULL,
    action_type ENUM('corrective', 'preventive') NOT NULL,
    description TEXT NOT NULL,
    responsible_person INT NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('planned', 'in_progress', 'completed', 'verified') DEFAULT 'planned',
    completion_date DATE NULL,
    effectiveness_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (nc_id) REFERENCES non_conformances(id)
)";

if ($db->query($sql4)) {
    echo "✓ Table 'capa_actions' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$samples = [
    ['NC-2024-001', 'Oil leak on Pump 101', 'Oil leak detected during routine inspection', 'major', 'open', 1, 1],
    ['NC-2024-002', 'Vibration exceeds limits', 'Excessive vibration on motor bearing', 'critical', 'investigating', 2, 1],
    ['NC-2024-003', 'Missing safety guard', 'Safety guard not installed properly', 'major', 'resolved', 3, 1]
];

foreach ($samples as $s) {
    $stmt = $db->prepare("INSERT INTO non_conformances (nc_number, title, description, severity, status, asset_id, reported_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssiii", $s[0], $s[1], $s[2], $s[3], $s[4], $s[5], $s[6]);
    $stmt->execute();
}

echo "✓ Inserted 3 sample non-conformances\n";

$db->close();
?>
