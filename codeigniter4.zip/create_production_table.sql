CREATE TABLE IF NOT EXISTS `production` (
  `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `production_order` VARCHAR(100) NOT NULL,
  `product_name` VARCHAR(255) NOT NULL,
  `quantity` INT(11) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('planned', 'in-progress', 'completed') DEFAULT 'planned',
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
