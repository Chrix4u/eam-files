<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS purchase_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    part_id INT NOT NULL,
    quantity INT NOT NULL,
    unit_cost DECIMAL(10,2) NULL,
    total_cost DECIMAL(10,2) NULL,
    vendor_id INT NULL,
    status ENUM('pending', 'approved', 'ordered', 'received', 'cancelled') DEFAULT 'pending',
    expected_delivery DATE NULL,
    created_by INT NOT NULL,
    approved_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_part (part_id),
    INDEX idx_status (status)
)";

if ($db->query($sql)) {
    echo "✓ Table 'purchase_orders' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$tableCheck = $db->query("SHOW TABLES LIKE 'inventory'");
if ($tableCheck->num_rows > 0) {
    $columns = ['reorder_point' => 'INT DEFAULT 10', 'lead_time_days' => 'INT DEFAULT 7', 'abc_class' => "ENUM('A', 'B', 'C') DEFAULT 'C'"];

    foreach ($columns as $col => $def) {
        $check = $db->query("SHOW COLUMNS FROM inventory LIKE '$col'");
        if ($check->num_rows == 0) {
            $db->query("ALTER TABLE inventory ADD COLUMN $col $def");
            echo "✓ Added column $col to inventory\n";
        }
    }

    $db->query("UPDATE inventory SET reorder_point = 10 WHERE reorder_point IS NULL OR reorder_point = 0");
    $db->query("UPDATE inventory SET lead_time_days = 7 WHERE lead_time_days IS NULL OR lead_time_days = 0");
    echo "✓ Updated existing inventory records\n";
} else {
    echo "Note: inventory table doesn't exist yet\n";
}

echo "✓ Updated existing inventory records\n";

$db->close();
?>
