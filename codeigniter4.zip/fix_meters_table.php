<?php

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔧 Fixing Meters Table\n";
    echo "======================\n\n";

    // Check meters table structure
    $stmt = $pdo->query("DESCRIBE meters");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "Current columns: " . implode(', ', $columns) . "\n\n";
    
    // Add meters with correct column names
    $stmt = $pdo->query("SELECT * FROM meters LIMIT 1");
    $sample = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($sample) {
        echo "Sample meter structure:\n";
        foreach ($sample as $key => $value) {
            echo "  $key: $value\n";
        }
    }
    
    // Add meters using correct column names
    $meterData = [
        'meter_name' => 'Motor Runtime Hours',
        'meter_type' => 'runtime',
        'asset_id' => 1,
        'unit_of_measure' => 'hours',
        'is_active' => 1
    ];
    
    $columns = array_keys($meterData);
    $placeholders = ':' . implode(', :', $columns);
    $sql = "INSERT INTO meters (" . implode(', ', $columns) . ") VALUES ($placeholders)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($meterData);
    $meterId = $pdo->lastInsertId();
    
    echo "\n✅ Added meter ID: $meterId\n";
    
    // Add meter reading
    $pdo->prepare("INSERT INTO meter_readings (meter_id, reading_value, reading_date) VALUES (?, 1500, NOW())")
        ->execute([$meterId]);
    echo "✅ Added meter reading\n";
    
    // Add usage trigger
    $templateId = $pdo->query("SELECT id FROM pm_templates LIMIT 1")->fetchColumn();
    $pdo->prepare("INSERT INTO pm_triggers (pm_template_id, trigger_type, usage_meter_id, usage_threshold) VALUES (?, 'usage', ?, 2000)")
        ->execute([$templateId, $meterId]);
    echo "✅ Added usage trigger\n";
    
    // Verify
    $meters = $pdo->query("SELECT COUNT(*) FROM meters")->fetchColumn();
    $usageTriggers = $pdo->query("SELECT COUNT(*) FROM pm_triggers WHERE trigger_type = 'usage'")->fetchColumn();
    
    echo "\nVerification:\n";
    echo "  Meters: $meters\n";
    echo "  Usage Triggers: $usageTriggers\n";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}