-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 6: MESSAGING & NOTIFICATIONS
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- MESSAGE TABLE
ALTER TABLE `message` ADD INDEX IF NOT EXISTS `idx_thread_message` (`message_thread_code`(50));
ALTER TABLE `message` ADD INDEX IF NOT EXISTS `idx_sender_message` (`sender`(50));
ALTER TABLE `message` ADD INDEX IF NOT EXISTS `idx_timestamp_message` (`timestamp`(50));
ALTER TABLE `message` ADD INDEX IF NOT EXISTS `idx_read_status` (`read_status`);

-- MESSAGE_THREAD TABLE
ALTER TABLE `message_thread` ADD INDEX IF NOT EXISTS `idx_thread_code` (`message_thread_code`(50));
ALTER TABLE `message_thread` ADD INDEX IF NOT EXISTS `idx_sender_thread` (`sender`(50));
ALTER TABLE `message_thread` ADD INDEX IF NOT EXISTS `idx_receiver` (`reciever`(50));
ALTER TABLE `message_thread` ADD INDEX IF NOT EXISTS `idx_last_message` (`last_message_timestamp`(50));

-- GROUP_MESSAGE TABLE
ALTER TABLE `group_message` ADD INDEX IF NOT EXISTS `idx_group_thread` (`group_message_thread_code`(50));
ALTER TABLE `group_message` ADD INDEX IF NOT EXISTS `idx_sender_group` (`sender`(50));
ALTER TABLE `group_message` ADD INDEX IF NOT EXISTS `idx_timestamp_group` (`timestamp`(50));
ALTER TABLE `group_message` ADD INDEX IF NOT EXISTS `idx_read_status_group` (`read_status`);

-- GROUP_MESSAGE_THREAD TABLE
ALTER TABLE `group_message_thread` ADD INDEX IF NOT EXISTS `idx_group_code` (`group_message_thread_code`(50));
ALTER TABLE `group_message_thread` ADD INDEX IF NOT EXISTS `idx_last_message_group` (`last_message_timestamp`(50));
ALTER TABLE `group_message_thread` ADD INDEX IF NOT EXISTS `idx_created_timestamp` (`created_timestamp`(50));

-- GROUP_MESSAGE_OTHER TABLE
ALTER TABLE `group_message_other` ADD INDEX IF NOT EXISTS `idx_group_thread_other` (`group_message_thread`);

-- NOTICEBOARD TABLE
ALTER TABLE `noticeboard` ADD INDEX IF NOT EXISTS `idx_status_notice` (`status`);
ALTER TABLE `noticeboard` ADD INDEX IF NOT EXISTS `idx_show_website` (`show_on_website`);
ALTER TABLE `noticeboard` ADD INDEX IF NOT EXISTS `idx_create_timestamp` (`create_timestamp`(50));

-- NOTICE TABLE
ALTER TABLE `notice` ADD INDEX IF NOT EXISTS `idx_date_notice` (`date`);

-- PARENT TABLE
ALTER TABLE `parent` ADD INDEX IF NOT EXISTS `idx_email_parent` (`email`(100));
ALTER TABLE `parent` ADD INDEX IF NOT EXISTS `idx_phone_parent` (`phone`(50));
ALTER TABLE `parent` ADD INDEX IF NOT EXISTS `idx_active_parent` (`active_status`);

-- ADMIN TABLE
ALTER TABLE `admin` ADD INDEX IF NOT EXISTS `idx_email_admin` (`email`(100));
ALTER TABLE `admin` ADD INDEX IF NOT EXISTS `idx_level` (`level`(50));
ALTER TABLE `admin` ADD INDEX IF NOT EXISTS `idx_active_admin` (`active_status`);

-- ACCOUNTANT TABLE
ALTER TABLE `accountant` ADD INDEX IF NOT EXISTS `idx_email_accountant` (`email`(100));
ALTER TABLE `accountant` ADD INDEX IF NOT EXISTS `idx_active_accountant` (`active_status`);

-- LIBRARIAN TABLE
ALTER TABLE `librarian` ADD INDEX IF NOT EXISTS `idx_email_librarian` (`email`(100));
ALTER TABLE `librarian` ADD INDEX IF NOT EXISTS `idx_active_librarian` (`active_status`);

COMMIT;
