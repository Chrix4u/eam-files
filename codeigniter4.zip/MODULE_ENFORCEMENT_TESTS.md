# Module Enforcement Test Suite

## Test 1: Module Activation Check
```sql
-- Disable ASSET module
UPDATE modules SET is_active = 0 WHERE code = 'ASSET';

-- Try to access assets endpoint (should fail with 403)
-- GET /api/v1/eam/assets
-- Expected: {"success":false,"error":"Module not active","code":"MODULE_INACTIVE"}

-- Re-enable
UPDATE modules SET is_active = 1 WHERE code = 'ASSET';
```

## Test 2: Dependency Check
```sql
-- Try to enable RWOP without ASSET
UPDATE modules SET is_active = 0 WHERE code = 'ASSET';
-- POST /api/v1/modules/RWOP/enable
-- Expected: Fail with dependency error

UPDATE modules SET is_active = 1 WHERE code = 'ASSET';
```

## Test 3: Lock Prevention
```sql
-- Try to disable CORE (locked)
-- POST /api/v1/modules/CORE/disable
-- Expected: {"success":false,"error":"Module is locked"}
```

## Test 4: Dependent Check
```sql
-- Try to disable ASSET while RWOP is active
UPDATE modules SET is_active = 1 WHERE code IN ('ASSET', 'RWOP');
-- POST /api/v1/modules/ASSET/disable
-- Expected: Fail - RWOP depends on ASSET
```

## Test 5: Cache Verification
```sql
-- Enable/disable module and verify cache clears
SELECT * FROM modules WHERE code = 'REPORTS';
-- Toggle and verify API responds immediately
```

## Test 6: Audit Logging
```sql
-- Check logs after enable/disable
SELECT * FROM module_activation_logs ORDER BY created_at DESC LIMIT 10;
-- Verify action, user, IP logged
```

## Test 7: Multiple Dependencies
```sql
-- MPMP depends on ASSET and RWOP
UPDATE modules SET is_active = 0 WHERE code = 'RWOP';
-- POST /api/v1/modules/MPMP/enable
-- Expected: Fail - RWOP dependency not met
```

## Test 8: BaseApiController requireModule
```php
// In any controller
$this->requireModule('ASSET');
// Should block if ASSET inactive
```

## Test 9: Filter Enforcement
```
-- Disable IMS module
UPDATE modules SET is_active = 0 WHERE code = 'IMS';
-- GET /api/v1/eam/parts
-- Expected: 403 Module not active
```

## Test 10: Active Modules List
```
-- GET /api/v1/modules/active
-- Should only return is_active = 1 modules
```

---

## Run All Tests
```bash
mysql -u root -p factory_manager < module_enforcement_tests.sql
```
