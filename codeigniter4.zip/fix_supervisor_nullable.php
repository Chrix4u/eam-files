<?php

// Make supervisor_id nullable
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

echo "=== MAKING SUPERVISOR_ID NULLABLE ===\n\n";

// Modify supervisor_id to allow NULL
echo "Modifying supervisor_id column to allow NULL...\n";
$result = $mysqli->query("ALTER TABLE departments MODIFY COLUMN supervisor_id INT NULL");

if ($result) {
    echo "✅ supervisor_id is now nullable\n\n";
} else {
    echo "❌ Failed: " . $mysqli->error . "\n\n";
}

// Verify
echo "Verifying column definition...\n";
$result = $mysqli->query("SELECT COLUMN_NAME, IS_NULLABLE, COLUMN_TYPE 
    FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = 'factory_manager' 
    AND TABLE_NAME = 'departments' 
    AND COLUMN_NAME = 'supervisor_id'");

$row = $result->fetch_assoc();
echo "Column: " . $row['COLUMN_NAME'] . "\n";
echo "Type: " . $row['COLUMN_TYPE'] . "\n";
echo "Nullable: " . $row['IS_NULLABLE'] . "\n\n";

$mysqli->close();

echo "=== COMPLETED ===\n";
echo "✅ supervisor_id can now be NULL\n";
echo "✅ Supervisors can be assigned to departments later\n";
