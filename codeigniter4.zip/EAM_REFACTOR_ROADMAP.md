# EAM System Refactor Roadmap

## Phase 1: Cleanup & Stabilization (Week 1)

### 1.1 Remove UI Components
- [ ] Delete `app/Views/` folder
- [ ] Delete UI controllers: Admin.php, Analytics.php, Assembly.php, Auth.php, Machine.php, Maintenance.php, Parts.php, PMO.php, PMSystem.php, ProductionSurvey.php, Settings.php, Shifts.php, Users.php
- [ ] Delete dashboard controllers: Admin/, Manager/, Operator/, Planner/, Supervisor/
- [ ] Remove UI routes from Routes.php
- [ ] Keep only API routes (RoutesEam.php, RoutesRBAC.php)

### 1.2 Fix Critical Bugs
- [ ] Fix ResourceController method signatures (add `= null` defaults)
- [ ] Fix dynamic property warning in JWTAuthFilter (use setAttribute)
- [ ] Remove duplicate migration file (2025-11-14-000019_CreateEamRoles.php)
- [ ] Fix table name inconsistencies in seeders

### 1.3 Standardize API Responses
```php
// Create app/Helpers/api_response_helper.php
function apiSuccess($data, $message = 'Success', $code = 200)
function apiError($message, $code = 400, $errors = [])
function apiPaginated($data, $pagination)
```

---

## Phase 2: Complete Missing Endpoints (Week 2)

### 2.1 Meters API
- [ ] Create EamMetersController
- [ ] Create EamMeterService
- [ ] Create EamMeterRepository
- [ ] Endpoints: GET /meters, POST /meters, GET /meters/{id}, PUT /meters/{id}, DELETE /meters/{id}
- [ ] Endpoint: POST /meters/{id}/readings (record meter reading)

### 2.2 Vendors API
- [ ] Create EamVendorsController
- [ ] Create EamVendorService
- [ ] Create EamVendorRepository
- [ ] Full CRUD endpoints

### 2.3 Purchase Orders API
- [ ] Create EamPurchaseOrdersController
- [ ] Create EamPurchaseOrderService
- [ ] Create EamPurchaseOrderRepository
- [ ] Endpoints: CRUD + approve, receive, cancel

### 2.4 Asset Hierarchy API
- [ ] Complete AssetHierarchyController
- [ ] Add endpoint: GET /assets/tree (full hierarchy)
- [ ] Add endpoint: GET /assets/{id}/children
- [ ] Add endpoint: GET /assets/{id}/ancestors

---

## Phase 3: Validation & Error Handling (Week 3)

### 3.1 Request Validation
```php
// Create app/Validation/ rules
- FacilityValidation.php
- EquipmentValidation.php
- WorkOrderValidation.php
- InventoryValidation.php
```

### 3.2 Global Exception Handler
```php
// Create app/Exceptions/ApiExceptionHandler.php
- Handle ValidationException
- Handle NotFoundException
- Handle UnauthorizedException
- Handle DatabaseException
```

### 3.3 Middleware
- [ ] Create ValidationMiddleware
- [ ] Create RateLimitMiddleware
- [ ] Create LoggingMiddleware

---

## Phase 4: Pagination, Filtering, Sorting (Week 3)

### 4.1 Create Query Builder Trait
```php
// app/Traits/QueryBuilderTrait.php
- applyFilters($filters)
- applySorting($sort, $order)
- applyPagination($page, $perPage)
```

### 4.2 Standardize All List Endpoints
- [ ] Add ?page=1&per_page=20 to all list endpoints
- [ ] Add ?filter[status]=active&filter[priority]=high
- [ ] Add ?sort=created_at&order=desc
- [ ] Add ?search=keyword

---

## Phase 5: Security Hardening (Week 4)

### 5.1 Authentication Enhancements
- [ ] Implement token refresh endpoint
- [ ] Add token blacklist for logout
- [ ] Implement password reset flow
- [ ] Add 2FA support (optional)

### 5.2 Authorization
- [ ] Audit all endpoints for permission checks
- [ ] Add resource-level permissions
- [ ] Implement ownership checks

### 5.3 Security Features
- [ ] Add rate limiting (100 req/min per user)
- [ ] Implement request signing for critical operations
- [ ] Add IP whitelisting option
- [ ] Enable audit logging for all mutations

---

## Phase 6: Testing (Week 4)

### 6.1 Unit Tests
- [ ] Test all Services (80% coverage)
- [ ] Test all Repositories
- [ ] Test validation rules

### 6.2 Integration Tests
- [ ] Test all API endpoints
- [ ] Test authentication flow
- [ ] Test RBAC enforcement

### 6.3 Load Testing
- [ ] Test with 100 concurrent users
- [ ] Identify bottlenecks
- [ ] Optimize slow queries

---

## Phase 7: Performance Optimization (Week 5)

### 7.1 Caching
- [ ] Install Redis
- [ ] Cache user permissions
- [ ] Cache facility/system/equipment hierarchies
- [ ] Cache PM schedules
- [ ] Implement cache invalidation strategy

### 7.2 Database Optimization
- [ ] Add indexes on foreign keys
- [ ] Add composite indexes for common queries
- [ ] Optimize N+1 queries with eager loading
- [ ] Add database query logging

### 7.3 Response Optimization
- [ ] Enable GZIP compression
- [ ] Implement response caching headers
- [ ] Optimize JSON serialization

---

## Phase 8: Documentation & Deployment (Week 6)

### 8.1 API Documentation
- [ ] Complete OpenAPI spec
- [ ] Add Swagger UI endpoint (/api/docs)
- [ ] Add example requests/responses
- [ ] Document error codes

### 8.2 Deployment
- [ ] Set up CI/CD pipeline
- [ ] Configure production environment
- [ ] Set up monitoring (New Relic/DataDog)
- [ ] Configure log aggregation
- [ ] Set up automated backups

### 8.3 Developer Documentation
- [ ] Architecture guide
- [ ] Setup instructions
- [ ] Contribution guidelines
- [ ] Troubleshooting guide

---

## Quick Wins (Do First)

1. **Remove Views folder** - Instant cleanup
2. **Fix method signatures** - Fixes errors
3. **Add health check endpoint** - GET /api/health
4. **Standardize error responses** - Better DX
5. **Add API versioning header** - Future-proof

---

## Migration Checklist

### Before Deployment
- [ ] All UI code removed
- [ ] All tests passing
- [ ] API documentation complete
- [ ] Security audit passed
- [ ] Performance benchmarks met
- [ ] Backup strategy in place
- [ ] Rollback plan documented

### After Deployment
- [ ] Monitor error rates
- [ ] Monitor response times
- [ ] Monitor database performance
- [ ] Collect user feedback
- [ ] Plan next iteration
