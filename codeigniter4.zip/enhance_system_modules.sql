-- Enterprise-Grade Enhancement for system_modules table
-- Run this in phpMyAdmin to check and enhance the table

-- Step 1: Check if table exists and show structure
SELECT 'Current Table Structure:' as info;
DESCRIBE system_modules;

-- Step 2: Show current data
SELECT 'Current Module Data:' as info;
SELECT code, name, enabled, version FROM system_modules;

-- Step 3: Add missing columns if they don't exist (enterprise-grade)
ALTER TABLE system_modules 
ADD COLUMN IF NOT EXISTS description TEXT AFTER name,
ADD COLUMN IF NOT EXISTS icon VARCHAR(50) AFTER description,
ADD COLUMN IF NOT EXISTS route_prefix VARCHAR(100) AFTER icon,
ADD COLUMN IF NOT EXISTS display_order INT DEFAULT 0 AFTER route_prefix,
ADD COLUMN IF NOT EXISTS license_required BOOLEAN DEFAULT FALSE AFTER display_order,
ADD COLUMN IF NOT EXISTS min_php_version VARCHAR(20) DEFAULT '8.0' AFTER license_required,
ADD COLUMN IF NOT EXISTS status ENUM('active','inactive','maintenance','deprecated') DEFAULT 'active' AFTER enabled,
ADD INDEX idx_code (code),
ADD INDEX idx_enabled (enabled),
ADD INDEX idx_status (status);

-- Step 4: Insert/Update RWOP module with enterprise data
INSERT INTO system_modules (
    id, code, name, description, icon, route_prefix, display_order,
    enabled, status, version, dependencies, ghana_features,
    license_required, min_php_version, created_at, updated_at
) VALUES (
    UUID(),
    'rwop',
    'Repair Work Order Program',
    'Complete work order management with team assignments, shift handover, and Ghana compliance',
    'wrench',
    '/rwop',
    1,
    TRUE,
    'active',
    '2.1.0',
    '["ims","hrms","asset"]',
    '{"shift_handover":true,"union_notification":true,"power_outage_tracking":true,"forex_tracking":true,"team_leader_enforcement":true}',
    FALSE,
    '8.0',
    NOW(),
    NOW()
) ON DUPLICATE KEY UPDATE
    description = 'Complete work order management with team assignments, shift handover, and Ghana compliance',
    icon = 'wrench',
    route_prefix = '/rwop',
    display_order = 1,
    version = '2.1.0',
    dependencies = '["ims","hrms","asset"]',
    ghana_features = '{"shift_handover":true,"union_notification":true,"power_outage_tracking":true,"forex_tracking":true,"team_leader_enforcement":true}',
    updated_at = NOW();

-- Step 5: Verify final structure
SELECT 'Final Verification:' as info;
SELECT code, name, enabled, status, version, display_order FROM system_modules ORDER BY display_order;
