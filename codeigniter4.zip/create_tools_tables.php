<?php
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Create tools table
$sql = "CREATE TABLE IF NOT EXISTS `tools` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `tool_code` VARCHAR(50) NOT NULL,
    `tool_name` VARCHAR(255) NOT NULL,
    `category` VARCHAR(100) NULL,
    `description` TEXT NULL,
    `manufacturer` VARCHAR(255) NULL,
    `model_number` VARCHAR(100) NULL,
    `serial_number` VARCHAR(100) NULL,
    `quantity_available` INT(11) NOT NULL DEFAULT 0,
    `quantity_in_use` INT(11) NOT NULL DEFAULT 0,
    `location` VARCHAR(255) NULL,
    `condition_status` ENUM('excellent', 'good', 'fair', 'poor', 'needs_repair') DEFAULT 'good',
    `calibration_required` BOOLEAN DEFAULT FALSE,
    `last_calibration_date` DATE NULL,
    `next_calibration_date` DATE NULL,
    `purchase_date` DATE NULL,
    `purchase_cost` DECIMAL(10,2) NULL,
    `image_url` VARCHAR(500) NULL,
    `barcode` VARCHAR(100) NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    `notes` TEXT NULL,
    `created_by` INT(11) UNSIGNED NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `tool_code_unique` (`tool_code`),
    KEY `category` (`category`),
    KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->query($sql)) {
    echo "Tools table created successfully\n";
} else {
    echo "Error creating tools table: " . $db->error . "\n";
}

// Create tool_assignments table
$sql2 = "CREATE TABLE IF NOT EXISTS `tool_assignments` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `tool_id` INT(11) UNSIGNED NOT NULL,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `assigned_to_user_id` INT(11) UNSIGNED NULL,
    `quantity` INT(11) NOT NULL DEFAULT 1,
    `assigned_at` DATETIME NULL,
    `returned_at` DATETIME NULL,
    `status` ENUM('required', 'assigned', 'in_use', 'returned', 'damaged') DEFAULT 'required',
    `condition_on_return` ENUM('excellent', 'good', 'fair', 'poor', 'damaged') NULL,
    `notes` TEXT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `tool_id` (`tool_id`),
    KEY `work_order_id` (`work_order_id`),
    KEY `assigned_to_user_id` (`assigned_to_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($db->query($sql2)) {
    echo "Tool assignments table created successfully\n";
} else {
    echo "Error creating tool_assignments table: " . $db->error . "\n";
}

$db->close();
echo "Migration completed!\n";
