<?php
/**
 * COMPREHENSIVE CONTROLLER MIGRATION
 * Step 1: Move controllers to correct modules based on route analysis
 * Step 2: Update namespaces
 * Step 3: Generate route update script
 */

// Complete mapping based on route analysis
$migrations = [
    // RWOP Module (14 controllers)
    ['from' => 'WorkOrdersController.php', 'to' => 'RWOP/WorkOrderController.php', 'merge_with' => 'WorkOrderController.php'],
    ['from' => 'WorkOrderController.php', 'to' => 'RWOP/WorkOrderController.php', 'action' => 'skip'], // Already exists
    ['from' => 'WorkOrderCompletionController.php', 'to' => 'RWOP/CompletionController.php', 'merge_with' => 'CompletionController.php'],
    ['from' => 'MaintenanceRequestController.php', 'to' => 'RWOP/MaintenanceRequestController.php'],
    ['from' => 'MaintenanceOrderController.php', 'to' => 'RWOP/MaintenanceOrderController.php'],
    ['from' => 'AssignmentsController.php', 'to' => 'RWOP/AssignmentsController.php'],
    ['from' => 'WorkOrderTeamController.php', 'to' => 'RWOP/WorkOrderTeamController.php'],
    ['from' => 'WorkOrderTemplateController.php', 'to' => 'RWOP/WorkOrderTemplateController.php'],
    ['from' => 'RecurringWorkOrderController.php', 'to' => 'RWOP/RecurringWorkOrderController.php'],
    ['from' => 'WorkOrderMaterialController.php', 'to' => 'RWOP/WorkOrderMaterialController.php'],
    ['from' => 'WorkOrderMaterialsController.php', 'to' => 'RWOP/WorkOrderMaterialController.php', 'action' => 'merge'],
    ['from' => 'FailureCodeController.php', 'to' => 'RWOP/FailureCodeController.php'],
    ['from' => 'RCAController.php', 'to' => 'RWOP/RCAController.php'],
    ['from' => 'AssistanceRequestController.php', 'to' => 'RWOP/AssistanceRequestController.php'],
    ['from' => 'WorkOrderAssignmentController.php', 'to' => 'RWOP/WorkOrderAssignmentController.php'],
    ['from' => 'WorkOrderAttachmentsController.php', 'to' => 'RWOP/WorkOrderAttachmentsController.php'],
    ['from' => 'WorkOrderLogsController.php', 'to' => 'RWOP/WorkOrderLogsController.php'],
    ['from' => 'WorkOrderTasksController.php', 'to' => 'RWOP/WorkOrderTasksController.php'],
    
    // ASSET Module (12 controllers)
    ['from' => 'EamEquipmentController.php', 'to' => 'ASSET/EquipmentController.php', 'merge_with' => 'EquipmentController.php'],
    ['from' => 'MachineController.php', 'to' => 'ASSET/EquipmentController.php', 'action' => 'merge'],
    ['from' => 'EamFacilitiesController.php', 'to' => 'ASSET/FacilitiesController.php', 'merge_with' => 'FacilitiesController.php'],
    ['from' => 'FacilitiesController.php', 'to' => 'ASSET/FacilitiesController.php', 'action' => 'skip'],
    ['from' => 'EamAssembliesController.php', 'to' => 'ASSET/AssembliesController.php', 'merge_with' => 'AssembliesController.php'],
    ['from' => 'AssemblyController.php', 'to' => 'ASSET/AssembliesController.php', 'action' => 'merge'],
    ['from' => 'BillOfMaterialsController.php', 'to' => 'ASSET/BomController.php', 'merge_with' => 'BomController.php'],
    ['from' => 'MetersController.php', 'to' => 'ASSET/MetersController.php', 'merge_with' => 'MetersController.php'],
    ['from' => 'AssetHealthController.php', 'to' => 'ASSET/HealthController.php', 'merge_with' => 'HealthController.php'],
    ['from' => 'EamSystemsController.php', 'to' => 'ASSET/SystemsController.php'],
    ['from' => 'EamComponentsController.php', 'to' => 'ASSET/ComponentsController.php'],
    ['from' => 'BarcodeController.php', 'to' => 'ASSET/BarcodeController.php'],
    ['from' => 'ModelLayersController.php', 'to' => 'ASSET/ModelLayersController.php'],
    
    // IMS Module (8 controllers)
    ['from' => 'EamInventoryController.php', 'to' => 'IMS/InventoryController.php', 'merge_with' => 'InventoryController.php'],
    ['from' => 'InventoryController.php', 'to' => 'IMS/InventoryController.php', 'action' => 'skip'],
    ['from' => 'EamPartsController.php', 'to' => 'IMS/PartsController.php', 'merge_with' => 'PartsController.php'],
    ['from' => 'PartController.php', 'to' => 'IMS/PartsController.php', 'action' => 'merge'],
    ['from' => 'VendorsController.php', 'to' => 'IMS/VendorsController.php'],
    ['from' => 'MaterialRequestController.php', 'to' => 'IMS/MaterialRequestController.php'],
    ['from' => 'MaterialRequisitionController.php', 'to' => 'IMS/MaterialRequisitionController.php'],
    ['from' => 'StockTransactionsController.php', 'to' => 'IMS/StockTransactionsController.php'],
    ['from' => 'InventoryForecastController.php', 'to' => 'IMS/InventoryForecastController.php'],
    ['from' => 'SubPartsController.php', 'to' => 'IMS/SubPartsController.php'],
    ['from' => 'EquipmentPartsController.php', 'to' => 'IMS/EquipmentPartsController.php'],
    
    // MRMP Module (16 controllers)
    ['from' => 'PmController.php', 'to' => 'MRMP/PmController.php'],
    ['from' => 'EamPmController.php', 'to' => 'MRMP/PmController.php', 'action' => 'merge'],
    ['from' => 'PreventiveMaintenanceController.php', 'to' => 'MRMP/PmController.php', 'action' => 'merge'],
    ['from' => 'CalibrationController.php', 'to' => 'MRMP/CalibrationController.php'],
    ['from' => 'PredictiveController.php', 'to' => 'MRMP/PredictiveController.php'],
    ['from' => 'IoTDevicesController.php', 'to' => 'MRMP/IoTDevicesController.php'],
    ['from' => 'IoTDataController.php', 'to' => 'MRMP/IoTDataController.php'],
    ['from' => 'IoTRulesController.php', 'to' => 'MRMP/IoTRulesController.php'],
    ['from' => 'PmTasksController.php', 'to' => 'MRMP/PmTasksController.php'],
    ['from' => 'PmTypesController.php', 'to' => 'MRMP/PmTypesController.php'],
    ['from' => 'PmModesController.php', 'to' => 'MRMP/PmModesController.php'],
    ['from' => 'PmInspectionTypesController.php', 'to' => 'MRMP/PmInspectionTypesController.php'],
    ['from' => 'PmTriggerTypesController.php', 'to' => 'MRMP/PmTriggerTypesController.php'],
    ['from' => 'PmWorkOrderController.php', 'to' => 'MRMP/PmWorkOrderController.php'],
    ['from' => 'UsageBasedPmController.php', 'to' => 'MRMP/UsageBasedPmController.php'],
    ['from' => 'PartPmTaskController.php', 'to' => 'MRMP/PartPmTaskController.php'],
    ['from' => 'SLAController.php', 'to' => 'MRMP/SLAController.php'],
    
    // MPMP Module (11 controllers)
    ['from' => 'ProductionController.php', 'to' => 'MPMP/ProductionController.php'],
    ['from' => 'ProductionDataController.php', 'to' => 'MPMP/ProductionDataController.php'],
    ['from' => 'ProductionTrackingController.php', 'to' => 'MPMP/ProductionTrackingController.php'],
    ['from' => 'ProductionRunsController.php', 'to' => 'MPMP/ProductionRunsController.php'],
    ['from' => 'OEEController.php', 'to' => 'MPMP/OEEController.php'],
    ['from' => 'DowntimeController.php', 'to' => 'MPMP/DowntimeController.php'],
    ['from' => 'QualityController.php', 'to' => 'MPMP/QualityController.php'],
    ['from' => 'SurveysController.php', 'to' => 'MPMP/SurveysController.php'],
    ['from' => 'SingeingDesizingController.php', 'to' => 'MPMP/SingeingDesizingController.php'],
    ['from' => 'EnergyController.php', 'to' => 'MPMP/EnergyController.php'],
    
    // HRMS Module (12 controllers)
    ['from' => 'EamUsersController.php', 'to' => 'HRMS/UsersController.php', 'merge_with' => 'UsersController.php'],
    ['from' => 'UserController.php', 'to' => 'HRMS/UsersController.php', 'action' => 'merge'],
    ['from' => 'ShiftsController.php', 'to' => 'HRMS/ShiftsController.php'],
    ['from' => 'EmployeeShiftsController.php', 'to' => 'HRMS/EmployeeShiftsController.php'],
    ['from' => 'ShiftAssignmentController.php', 'to' => 'HRMS/ShiftAssignmentController.php'],
    ['from' => 'SkillsController.php', 'to' => 'HRMS/SkillsController.php'],
    ['from' => 'SkillCategoriesController.php', 'to' => 'HRMS/SkillCategoriesController.php'],
    ['from' => 'TradesController.php', 'to' => 'HRMS/TradesController.php'],
    ['from' => 'TrainingRecordsController.php', 'to' => 'HRMS/TrainingController.php', 'merge_with' => 'TrainingController.php'],
    ['from' => 'LaborLogController.php', 'to' => 'HRMS/LaborController.php', 'merge_with' => 'LaborController.php'],
    ['from' => 'OperatorGroupsController.php', 'to' => 'HRMS/OperatorGroupsController.php'],
    ['from' => 'TechnicianGroupController.php', 'to' => 'HRMS/TechnicianGroupController.php'],
    ['from' => 'EamRolesController.php', 'to' => 'HRMS/RolesController.php'],
    ['from' => 'UserPermissionsController.php', 'to' => 'HRMS/UserPermissionsController.php'],
    
    // TRAC Module (6 controllers)
    ['from' => 'ToolsController.php', 'to' => 'TRAC/ToolsController.php'],
    ['from' => 'LOTOController.php', 'to' => 'TRAC/LOTOController.php'],
    ['from' => 'LOTOLockController.php', 'to' => 'TRAC/LOTOLockController.php'],
    ['from' => 'PermitToWorkController.php', 'to' => 'TRAC/PermitController.php', 'merge_with' => 'PermitController.php'],
    ['from' => 'ResourceAvailabilityController.php', 'to' => 'TRAC/ResourceController.php', 'merge_with' => 'ResourceController.php'],
    ['from' => 'RiskAssessmentController.php', 'to' => 'TRAC/RiskAssessmentController.php'],
    
    // CORE Module (40+ controllers)
    ['from' => 'EamAuthController.php', 'to' => 'CORE/AuthController.php', 'merge_with' => 'AuthController.php'],
    ['from' => 'AuthController.php', 'to' => 'CORE/AuthController.php', 'action' => 'skip'],
    ['from' => 'PasswordResetController.php', 'to' => 'CORE/PasswordResetController.php'],
    ['from' => 'AnalyticsController.php', 'to' => 'CORE/AnalyticsController.php'],
    ['from' => 'MaintenanceAnalyticsController.php', 'to' => 'CORE/MaintenanceAnalyticsController.php'],
    ['from' => 'PmAnalyticsController.php', 'to' => 'CORE/PmAnalyticsController.php'],
    ['from' => 'CompletionAnalyticsController.php', 'to' => 'CORE/CompletionAnalyticsController.php'],
    ['from' => 'WorkOrderAnalyticsController.php', 'to' => 'CORE/WorkOrderAnalyticsController.php'],
    ['from' => 'DashboardController.php', 'to' => 'CORE/DashboardController.php'],
    ['from' => 'ReportsController.php', 'to' => 'CORE/ReportsController.php'],
    ['from' => 'WorkOrderReportsController.php', 'to' => 'CORE/WorkOrderReportsController.php'],
    ['from' => 'ProductionReportsController.php', 'to' => 'CORE/ProductionReportsController.php'],
    ['from' => 'StockReportsController.php', 'to' => 'CORE/StockReportsController.php'],
    ['from' => 'NotificationsController.php', 'to' => 'CORE/NotificationsController.php'],
    ['from' => 'NotificationController.php', 'to' => 'CORE/NotificationController.php'],
    ['from' => 'PmNotificationController.php', 'to' => 'CORE/PmNotificationController.php'],
    ['from' => 'SystemSettingsController.php', 'to' => 'CORE/SettingsController.php', 'merge_with' => 'SettingsController.php'],
    ['from' => 'CompanySettingsController.php', 'to' => 'CORE/CompanySettingsController.php'],
    ['from' => 'ModuleSettingsController.php', 'to' => 'CORE/ModuleController.php', 'merge_with' => 'ModuleController.php'],
    ['from' => 'DepartmentsController.php', 'to' => 'CORE/DepartmentsController.php'],
    ['from' => 'BaseApiController.php', 'to' => 'CORE/BaseApiController.php'],
    ['from' => 'AdvancedControllers.php', 'to' => 'CORE/AdvancedControllers.php'],
    ['from' => 'AIController.php', 'to' => 'CORE/AIController.php'],
    ['from' => 'APIManagementController.php', 'to' => 'CORE/APIManagementController.php'],
    ['from' => 'BulkOperationsController.php', 'to' => 'CORE/BulkOperationsController.php'],
    ['from' => 'CollaborationController.php', 'to' => 'CORE/CollaborationController.php'],
    ['from' => 'CommentController.php', 'to' => 'CORE/CommentController.php'],
    ['from' => 'AttachmentController.php', 'to' => 'CORE/AttachmentController.php'],
    ['from' => 'DocsController.php', 'to' => 'CORE/DocsController.php'],
    ['from' => 'DocumentsController.php', 'to' => 'CORE/DocumentsController.php'],
    ['from' => 'ERPIntegrationController.php', 'to' => 'CORE/ERPIntegrationController.php'],
    ['from' => 'ERPMappingController.php', 'to' => 'CORE/ERPMappingController.php'],
    ['from' => 'ERPScheduleController.php', 'to' => 'CORE/ERPScheduleController.php'],
    ['from' => 'ERPTransformationController.php', 'to' => 'CORE/ERPTransformationController.php'],
    ['from' => 'GhanaEnhancementsController.php', 'to' => 'CORE/GhanaEnhancementsController.php'],
    ['from' => 'HealthController.php', 'to' => 'CORE/SystemHealthController.php'],
    ['from' => 'SystemHealthController.php', 'to' => 'CORE/SystemHealthController.php', 'action' => 'skip'],
    ['from' => 'MetricsController.php', 'to' => 'CORE/MetricsController.php'],
    ['from' => 'MobileController.php', 'to' => 'CORE/MobileController.php'],
    ['from' => 'ProtectedController.php', 'to' => 'CORE/ProtectedController.php'],
    ['from' => 'SchedulerController.php', 'to' => 'CORE/SchedulerController.php'],
    ['from' => 'SearchController.php', 'to' => 'CORE/SearchController.php'],
    ['from' => 'CacheController.php', 'to' => 'CORE/CacheController.php'],
    ['from' => 'AuditLogsController.php', 'to' => 'CORE/AuditLogsController.php'],
];

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║  COMPREHENSIVE CONTROLLER MIGRATION                        ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

$moved = 0;
$merged = 0;
$skipped = 0;
$errors = [];

foreach ($migrations as $migration) {
    $from = 'app/Controllers/Api/V1/' . $migration['from'];
    $to = 'app/Controllers/Api/V1/Modules/' . $migration['to'];
    $action = $migration['action'] ?? 'move';
    
    if (!file_exists($from)) {
        $skipped++;
        continue;
    }
    
    if ($action === 'skip') {
        $skipped++;
        continue;
    }
    
    $content = file_get_contents($from);
    
    // Update namespace
    preg_match('/Modules\/(\w+)\//', $to, $matches);
    $module = $matches[1] ?? 'CORE';
    $content = preg_replace(
        '/namespace\s+App\\\\Controllers\\\\Api\\\\V1;/',
        "namespace App\\Controllers\\Api\\V1\\Modules\\$module;",
        $content
    );
    
    // Create directory if needed
    $dir = dirname($to);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    if ($action === 'merge' && file_exists($to)) {
        echo "⊕ Merge: " . basename($from) . " → " . basename($to) . "\n";
        unlink($from);
        $merged++;
    } else {
        if (file_put_contents($to, $content)) {
            unlink($from);
            echo "✓ Moved: " . basename($from) . " → $module/" . basename($to) . "\n";
            $moved++;
        } else {
            $errors[] = $from;
        }
    }
}

echo "\n╔════════════════════════════════════════════════════════════╗\n";
echo "║  MIGRATION SUMMARY                                         ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "  Moved: $moved\n";
echo "  Merged: $merged\n";
echo "  Skipped: $skipped\n";
echo "  Errors: " . count($errors) . "\n\n";

if (count($errors) === 0) {
    echo "✅ All controllers migrated successfully!\n";
    echo "📋 Next: Update routes to point to Modules/\n";
} else {
    echo "⚠️  Some files had errors:\n";
    foreach ($errors as $error) {
        echo "  - $error\n";
    }
}
