# Model Upload Guide

## Overview

This guide covers the complete process of uploading 3D models (GLB/GLTF) and 2D diagrams (SVG) to the EAM system for interactive visualization and PM task assignment.

## Supported File Formats

### 3D Models
- **GLB** (Binary GLTF) - Recommended for production
- **GLTF** (JSON GLTF) - Good for development/debugging
- **ZIP** - Archives containing GLTF + assets

### 2D Diagrams
- **SVG** - Scalable Vector Graphics

## File Requirements

### Size Limits
- **3D Models**: Maximum 100MB
- **2D Diagrams**: Maximum 10MB
- **ZIP Archives**: Maximum 100MB

### Quality Guidelines
- **3D Models**: 
  - Polygon count: < 100,000 triangles
  - Texture resolution: 1024x1024 or 2048x2048
  - Use PBR materials when possible
- **2D Diagrams**:
  - Vector-based (avoid raster images)
  - Clean, organized layer structure
  - Meaningful element IDs for auto-mapping

## Upload Process

### Step 1: Access Upload Interface
1. Navigate to `/models/upload`
2. Ensure you have appropriate permissions (Admin/Manager role)

### Step 2: Select Target Machine
1. Choose the machine from the available list
2. Each machine can have multiple model versions
3. Verify machine details before proceeding

### Step 3: Upload File
1. **Drag & Drop**: Drag file onto upload area
2. **File Browser**: Click "Choose File" to browse
3. **Validation**: System validates file type and size
4. **Progress**: Monitor upload progress bar

### Step 4: Processing (3D Models Only)
1. **Queue**: File enters processing queue
2. **Optimization**: Node.js script processes the model
   - Draco compression applied
   - Textures converted to KTX2 format
   - Thumbnail generated
   - Mesh names extracted
3. **Status**: Monitor processing status
4. **Completion**: Model ready for use

## Processing Pipeline Details

### 3D Model Processing
```
Upload → Validation → Storage → Processing Queue → Node.js Script
                                                        ↓
Thumbnail ← KTX2 Textures ← Draco Compression ← Mesh Analysis
    ↓
Database Update → Model Ready
```

### Processing Steps
1. **File Validation**
   - Format verification
   - Size check
   - Virus scan (if configured)

2. **Initial Storage**
   - File saved to `writable/models/{machineId}/{modelId}/`
   - Database record created
   - Status set to 'uploaded'

3. **Background Processing**
   - Node.js worker script triggered
   - Status updated to 'processing'
   - Processing logs generated

4. **Optimization**
   - **Draco Compression**: Reduces geometry size by 60-80%
   - **KTX2 Textures**: GPU-optimized texture format
   - **LOD Generation**: Multiple detail levels (future)

5. **Thumbnail Generation**
   - 200x200 preview image
   - Multiple angles (future enhancement)
   - Automatic lighting setup

6. **Mesh Analysis**
   - Extract mesh names
   - Analyze hierarchy
   - Generate metadata

7. **Completion**
   - Optimized files saved
   - Database updated with paths
   - Status set to 'processed'

## File Preparation Best Practices

### 3D Models

#### Modeling Guidelines
- **Clean Geometry**: Remove duplicate vertices, fix normals
- **Proper Naming**: Use descriptive mesh names (e.g., "Engine_Block", "Cylinder_Head")
- **Hierarchy**: Organize objects in logical parent-child relationships
- **Materials**: Use PBR materials with proper texture maps
- **Scale**: Use real-world units (meters recommended)

#### Optimization Tips
- **Polygon Reduction**: Use decimation for non-critical parts
- **Texture Atlasing**: Combine multiple textures into atlases
- **LOD Models**: Create multiple detail levels
- **Instancing**: Use instances for repeated components

#### Export Settings (Blender)
```
Format: glTF 2.0 (.glb)
Include: Selected Objects
Transform: +Y Up
Geometry: Apply Modifiers, UVs, Normals, Tangents
Materials: Export Materials
Compression: Draco (Quantization: Position 14, Normal 10, Texcoord 12)
```

### 2D Diagrams

#### SVG Guidelines
- **Vector Graphics**: Avoid embedded raster images
- **Clean Code**: Use semantic element names
- **Layers**: Organize content in logical groups
- **IDs**: Use meaningful IDs for auto-mapping
- **Viewbox**: Set appropriate viewBox for scaling

#### Element Naming Convention
```xml
<!-- Good: Descriptive IDs -->
<g id="hydraulic_system">
  <rect id="hydraulic_pump" />
  <circle id="pressure_gauge" />
</g>

<!-- Bad: Generic IDs -->
<g id="layer1">
  <rect id="rect123" />
  <circle id="circle456" />
</g>
```

## Troubleshooting

### Upload Issues

#### File Too Large
- **Problem**: File exceeds size limit
- **Solution**: 
  - Optimize model in 3D software
  - Reduce texture resolution
  - Use Draco compression before upload

#### Invalid File Format
- **Problem**: Unsupported file type
- **Solution**:
  - Convert to supported format
  - Check file extension matches content
  - Verify file is not corrupted

#### Upload Timeout
- **Problem**: Upload fails due to timeout
- **Solution**:
  - Check network connection
  - Try smaller file
  - Contact administrator for timeout settings

### Processing Issues

#### Processing Stuck
- **Problem**: Model stuck in 'processing' status
- **Solution**:
  - Check Node.js service status
  - Review processing logs
  - Restart processing service
  - Contact administrator

#### Processing Failed
- **Problem**: Status shows 'failed'
- **Solution**:
  - Check processing logs for errors
  - Verify model file integrity
  - Try re-uploading
  - Contact support with error details

#### Missing Thumbnail
- **Problem**: No thumbnail generated
- **Solution**:
  - Check if model has textures
  - Verify lighting setup
  - Manually regenerate thumbnail
  - Use default placeholder

### Model Display Issues

#### Model Not Loading
- **Problem**: Viewer shows loading indefinitely
- **Solution**:
  - Check browser console for errors
  - Verify file paths in database
  - Test with different browser
  - Clear browser cache

#### Incorrect Scale
- **Problem**: Model appears too large/small
- **Solution**:
  - Check model units in 3D software
  - Adjust scale in viewer settings
  - Re-export with correct scale
  - Update model metadata

#### Missing Textures
- **Problem**: Model appears without materials
- **Solution**:
  - Verify texture paths in GLTF
  - Check if textures were included in export
  - Re-export with embedded textures
  - Use GLB format instead of GLTF

## Advanced Features

### Batch Upload
- Upload multiple models simultaneously
- Queue management for processing
- Bulk operations for similar models

### Version Management
- Multiple versions per machine
- Version comparison tools
- Rollback capabilities
- Change tracking

### Collaboration
- Multi-user upload permissions
- Upload notifications
- Review and approval workflow
- Comment system

## API Integration

### Upload via API
```javascript
const formData = new FormData();
formData.append('machine_id', '123');
formData.append('model_file', file);

const response = await fetch('/api/v1/models/upload', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ' + token
  },
  body: formData
});
```

### Monitor Processing
```javascript
const status = await fetch(`/api/v1/processing-jobs/${jobId}`);
const data = await status.json();
console.log('Status:', data.status);
console.log('Logs:', data.logs);
```

## Security Considerations

### File Validation
- MIME type verification
- File signature checking
- Malware scanning
- Size limit enforcement

### Access Control
- Role-based upload permissions
- Machine-specific access
- Audit logging
- Rate limiting

### Storage Security
- Secure file storage location
- Access path restrictions
- Regular backup procedures
- Encryption at rest

## Performance Optimization

### Server Configuration
- PHP upload limits: `upload_max_filesize`, `post_max_size`
- Nginx/Apache timeout settings
- Disk space monitoring
- Processing queue management

### Client Optimization
- Progress indicators
- Chunked uploads for large files
- Resume capability
- Background processing notifications

## Maintenance

### Regular Tasks
- Clean up failed uploads
- Monitor disk space usage
- Update processing dependencies
- Review processing logs

### Monitoring
- Upload success rates
- Processing times
- Error frequency
- Storage utilization

### Backup
- Model files backup
- Database backup
- Processing scripts backup
- Configuration backup