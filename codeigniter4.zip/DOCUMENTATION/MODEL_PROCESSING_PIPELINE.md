# Model Processing Pipeline

## Overview

The Model Processing Pipeline is a Node.js-based system that automatically optimizes 3D models (GLB/GLTF) for web viewing, generates thumbnails, and extracts metadata for the EAM system.

## Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   File Upload   │    │   Queue System  │    │   Processing    │
│   (PHP/CI4)     │───►│   (Database)    │───►│   (Node.js)     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                                        │
                                                        ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   File Storage  │◄───│   Optimization  │◄───│   Validation    │
│   (Filesystem)  │    │   (gltf-pipeline)│    │   (Format Check)│
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## Processing Components

### 1. Queue Management
- **Job Creation**: PHP creates processing job record
- **Status Tracking**: Database tracks job progress
- **Error Handling**: Failed jobs logged and retried
- **Concurrency**: Multiple jobs processed simultaneously

### 2. File Validation
- **Format Verification**: GLB/GLTF structure validation
- **Size Limits**: File size constraints
- **Content Analysis**: Mesh and material inspection
- **Security Checks**: Malicious content detection

### 3. Optimization Engine
- **Draco Compression**: Geometry compression
- **Texture Optimization**: KTX2 conversion
- **Mesh Simplification**: LOD generation
- **Material Optimization**: Shader optimization

### 4. Metadata Extraction
- **Mesh Names**: Extract object hierarchy
- **Material Properties**: PBR material analysis
- **Bounding Boxes**: Spatial information
- **Animation Data**: Keyframe information

## Processing Steps

### Step 1: Job Initialization
```javascript
// Job created by PHP backend
const job = {
  id: 'uuid-job-id',
  model_id: 'uuid-model-id',
  status: 'pending',
  input_path: '/path/to/input.glb',
  output_dir: '/path/to/output/',
  options: {
    compression: true,
    thumbnail: true,
    lod: false
  }
};
```

### Step 2: File Validation
```javascript
async function validateModel(inputPath) {
  // Check file exists and is readable
  if (!fs.existsSync(inputPath)) {
    throw new Error('Input file not found');
  }
  
  // Validate GLB/GLTF structure
  const buffer = fs.readFileSync(inputPath);
  const gltf = await gltfPipeline.processGltf(buffer, { validate: true });
  
  // Check for required components
  if (!gltf.scenes || gltf.scenes.length === 0) {
    throw new Error('No scenes found in model');
  }
  
  return true;
}
```

### Step 3: Optimization Processing
```javascript
async function optimizeModel(inputPath, outputPath, options) {
  const gltfOptions = {
    // Draco compression
    dracoOptions: {
      compressionLevel: 7,
      quantizePositionBits: 11,
      quantizeNormalBits: 8,
      quantizeTexcoordBits: 10,
      quantizeColorBits: 8,
      quantizeGenericBits: 8,
      unifiedQuantization: false
    },
    
    // KTX2 texture compression
    ktx2Options: {
      uastc: true,
      qualityLevel: 128,
      normalMap: false
    },
    
    // General optimizations
    removeUnusedMaterials: true,
    removeUnusedTextures: true,
    removeUnusedVertexAttributes: true,
    mergeDuplicateVertices: true,
    
    // Keep original structure for mapping
    keepUnusedElements: false
  };
  
  const input = fs.readFileSync(inputPath);
  const result = await gltfPipeline.processGltf(input, gltfOptions);
  
  fs.writeFileSync(outputPath, result.glb);
  return result;
}
```

### Step 4: Thumbnail Generation
```javascript
async function generateThumbnail(modelPath, thumbnailPath) {
  // Option 1: Extract existing texture
  const gltf = await loadGLTF(modelPath);
  if (gltf.textures && gltf.textures.length > 0) {
    const texture = gltf.textures[0];
    await sharp(texture.source.uri)
      .resize(200, 200)
      .jpeg({ quality: 80 })
      .toFile(thumbnailPath);
    return;
  }
  
  // Option 2: Render 3D scene (headless)
  const scene = await renderScene(modelPath);
  const canvas = scene.canvas;
  const buffer = canvas.toBuffer('image/jpeg');
  
  await sharp(buffer)
    .resize(200, 200)
    .jpeg({ quality: 80 })
    .toFile(thumbnailPath);
}
```

### Step 5: Metadata Extraction
```javascript
async function extractMetadata(modelPath) {
  const gltf = await loadGLTF(modelPath);
  
  const metadata = {
    meshes: [],
    materials: [],
    textures: [],
    animations: [],
    boundingBox: null
  };
  
  // Extract mesh information
  if (gltf.meshes) {
    gltf.meshes.forEach((mesh, index) => {
      metadata.meshes.push({
        name: mesh.name || `Mesh_${index}`,
        primitiveCount: mesh.primitives.length,
        vertexCount: calculateVertexCount(mesh),
        materialIndex: mesh.primitives[0]?.material
      });
    });
  }
  
  // Extract material information
  if (gltf.materials) {
    gltf.materials.forEach((material, index) => {
      metadata.materials.push({
        name: material.name || `Material_${index}`,
        type: material.pbrMetallicRoughness ? 'PBR' : 'Basic',
        baseColor: material.pbrMetallicRoughness?.baseColorFactor,
        metallic: material.pbrMetallicRoughness?.metallicFactor,
        roughness: material.pbrMetallicRoughness?.roughnessFactor
      });
    });
  }
  
  // Calculate bounding box
  metadata.boundingBox = calculateBoundingBox(gltf);
  
  return metadata;
}
```

## Configuration

### Node.js Dependencies
```json
{
  "dependencies": {
    "gltf-pipeline": "^4.1.0",
    "sharp": "^0.33.0",
    "three": "^0.160.0",
    "canvas": "^2.11.2",
    "axios": "^1.6.0",
    "fs-extra": "^11.2.0"
  }
}
```

### Processing Options
```javascript
const processingConfig = {
  // Compression settings
  compression: {
    draco: {
      enabled: true,
      compressionLevel: 7,
      quantization: {
        position: 11,
        normal: 8,
        texcoord: 10,
        color: 8
      }
    },
    ktx2: {
      enabled: true,
      uastc: true,
      qualityLevel: 128
    }
  },
  
  // Thumbnail settings
  thumbnail: {
    enabled: true,
    size: 200,
    quality: 80,
    format: 'jpeg',
    background: '#f0f0f0'
  },
  
  // LOD settings (future)
  lod: {
    enabled: false,
    levels: [1.0, 0.5, 0.25, 0.1],
    algorithm: 'quadric'
  },
  
  // Timeout settings
  timeout: {
    processing: 300000, // 5 minutes
    thumbnail: 60000,   // 1 minute
    validation: 30000   // 30 seconds
  }
};
```

## Error Handling

### Common Errors
```javascript
const ErrorTypes = {
  VALIDATION_FAILED: 'Model validation failed',
  COMPRESSION_FAILED: 'Compression process failed',
  THUMBNAIL_FAILED: 'Thumbnail generation failed',
  TIMEOUT: 'Processing timeout exceeded',
  DISK_SPACE: 'Insufficient disk space',
  MEMORY_LIMIT: 'Memory limit exceeded',
  INVALID_FORMAT: 'Invalid file format',
  CORRUPTED_FILE: 'File appears to be corrupted'
};

async function handleProcessingError(error, jobId) {
  const errorInfo = {
    type: classifyError(error),
    message: error.message,
    stack: error.stack,
    timestamp: new Date().toISOString()
  };
  
  // Log error
  console.error(`Processing failed for job ${jobId}:`, errorInfo);
  
  // Update job status
  await updateJobStatus(jobId, 'failed', JSON.stringify(errorInfo));
  
  // Cleanup temporary files
  await cleanupTempFiles(jobId);
  
  // Notify administrators for critical errors
  if (isCriticalError(error)) {
    await notifyAdministrators(jobId, errorInfo);
  }
}
```

### Retry Logic
```javascript
async function processWithRetry(jobId, maxRetries = 3) {
  let attempt = 0;
  
  while (attempt < maxRetries) {
    try {
      await processModel(jobId);
      return; // Success
    } catch (error) {
      attempt++;
      
      if (attempt >= maxRetries) {
        throw error; // Final failure
      }
      
      // Wait before retry (exponential backoff)
      const delay = Math.pow(2, attempt) * 1000;
      await new Promise(resolve => setTimeout(resolve, delay));
      
      console.log(`Retry attempt ${attempt} for job ${jobId}`);
    }
  }
}
```

## Performance Optimization

### Memory Management
```javascript
// Monitor memory usage
function checkMemoryUsage() {
  const usage = process.memoryUsage();
  const maxMemory = 1024 * 1024 * 1024; // 1GB limit
  
  if (usage.heapUsed > maxMemory * 0.8) {
    console.warn('High memory usage detected:', usage);
    
    // Force garbage collection
    if (global.gc) {
      global.gc();
    }
    
    // Pause processing if memory is critical
    if (usage.heapUsed > maxMemory * 0.95) {
      throw new Error('Memory limit exceeded');
    }
  }
}

// Process models in chunks
async function processLargeModel(modelPath) {
  const chunks = await splitModelIntoChunks(modelPath);
  const results = [];
  
  for (const chunk of chunks) {
    checkMemoryUsage();
    const result = await processChunk(chunk);
    results.push(result);
    
    // Clean up chunk data
    chunk.dispose();
  }
  
  return mergeResults(results);
}
```

### Concurrent Processing
```javascript
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;

if (cluster.isMaster) {
  // Fork workers
  for (let i = 0; i < Math.min(numCPUs, 4); i++) {
    cluster.fork();
  }
  
  cluster.on('exit', (worker, code, signal) => {
    console.log(`Worker ${worker.process.pid} died`);
    cluster.fork(); // Restart worker
  });
} else {
  // Worker process
  startProcessingWorker();
}

async function startProcessingWorker() {
  while (true) {
    const job = await getNextJob();
    if (job) {
      await processJob(job);
    } else {
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }
}
```

## Monitoring and Logging

### Job Status Tracking
```javascript
const JobStatus = {
  PENDING: 'pending',
  RUNNING: 'running',
  SUCCESS: 'success',
  FAILED: 'failed',
  TIMEOUT: 'timeout'
};

async function updateJobStatus(jobId, status, logs = null) {
  const updateData = {
    status: status,
    updated_at: new Date().toISOString()
  };
  
  if (logs) {
    updateData.logs = logs;
  }
  
  // Update via API
  await axios.put(`${API_BASE_URL}/processing-jobs/${jobId}`, updateData);
}
```

### Performance Metrics
```javascript
const metrics = {
  totalJobs: 0,
  successfulJobs: 0,
  failedJobs: 0,
  averageProcessingTime: 0,
  compressionRatio: 0
};

function recordJobMetrics(jobId, startTime, originalSize, compressedSize) {
  const processingTime = Date.now() - startTime;
  const compressionRatio = compressedSize / originalSize;
  
  metrics.totalJobs++;
  metrics.averageProcessingTime = 
    (metrics.averageProcessingTime * (metrics.totalJobs - 1) + processingTime) / metrics.totalJobs;
  metrics.compressionRatio = 
    (metrics.compressionRatio * (metrics.totalJobs - 1) + compressionRatio) / metrics.totalJobs;
  
  console.log(`Job ${jobId} completed in ${processingTime}ms, compression: ${(compressionRatio * 100).toFixed(1)}%`);
}
```

## Deployment

### Service Setup (Windows)
```batch
@echo off
echo Installing Model Processing Service...

npm install -g pm2
pm2 start process-model.js --name "model-processor" --instances 2
pm2 startup
pm2 save

echo Service installed successfully
```

### Service Setup (Linux)
```bash
#!/bin/bash
# Install PM2 globally
npm install -g pm2

# Start processing service
pm2 start process-model.js --name "model-processor" --instances max

# Setup auto-start
pm2 startup
pm2 save

echo "Model processing service installed"
```

### Health Checks
```javascript
// Health check endpoint
app.get('/health', (req, res) => {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    activeJobs: getActiveJobCount(),
    queueSize: getQueueSize()
  };
  
  res.json(health);
});

// Periodic health monitoring
setInterval(async () => {
  try {
    await performHealthCheck();
  } catch (error) {
    console.error('Health check failed:', error);
    await notifyAdministrators('Health check failure', error);
  }
}, 60000); // Every minute
```

## Troubleshooting

### Common Issues

#### Processing Stuck
- Check Node.js service status
- Review memory usage
- Examine processing logs
- Restart processing service

#### High Memory Usage
- Reduce concurrent job limit
- Implement model chunking
- Add memory monitoring
- Increase system memory

#### Slow Processing
- Check CPU usage
- Optimize compression settings
- Implement job prioritization
- Scale processing workers

#### Failed Thumbnails
- Verify graphics libraries
- Check headless rendering setup
- Test with sample models
- Implement fallback thumbnails

### Debug Commands
```bash
# Check service status
pm2 status

# View logs
pm2 logs model-processor

# Monitor resources
pm2 monit

# Restart service
pm2 restart model-processor

# Check job queue
curl http://localhost:3000/health
```