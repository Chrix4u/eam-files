# 3D/2D Model Viewer System Overview

## Introduction

The 3D/2D Model Viewer System is a comprehensive solution for visualizing machine breakdowns in an interactive format, similar to "XZZ Xinzhizao Maintenance Inquiry System". It supports both 3D models (GLB/GLTF) and 2D diagrams (SVG) with interactive hotspots for PM task assignment.

## System Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Processing    │
│   (Next.js)     │◄──►│ (CodeIgniter)   │◄──►│   (Node.js)     │
│                 │    │                 │    │                 │
│ • Model Viewer  │    │ • API Routes    │    │ • GLB/GLTF      │
│ • Hotspot Editor│    │ • Services      │    │   Optimization  │
│ • PM Integration│    │ • Controllers   │    │ • Thumbnail     │
│ • Mapping UI    │    │ • Models        │    │   Generation    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────┐
                    │    Database     │
                    │    (MySQL)      │
                    │                 │
                    │ • machine_models│
                    │ • model_hotspots│
                    │ • model_layers  │
                    │ • part_geometry │
                    └─────────────────┘
```

## Key Features

### 1. Model Management
- **Upload Support**: GLB, GLTF, SVG, ZIP files
- **Automatic Processing**: 3D model optimization with Draco compression
- **Thumbnail Generation**: Automatic preview generation
- **Version Control**: Multiple model versions per machine

### 2. Interactive Visualization
- **3D Viewer**: Three.js-based 3D model rendering
- **2D Viewer**: SVG-based diagram viewing
- **Hotspot System**: Interactive clickable areas
- **Layer Management**: Show/hide different model layers

### 3. Mesh-to-Part Mapping
- **Auto-Mapping**: Intelligent mesh name to part matching
- **Manual Mapping**: Drag-and-drop interface
- **Confidence Scoring**: Mapping quality indicators
- **Bulk Operations**: Mass mapping capabilities

### 4. PM Integration
- **Direct Assignment**: Assign PM tasks from model hotspots
- **Template Selection**: Choose from available PM templates
- **Frequency Configuration**: Set maintenance intervals
- **Priority Management**: Task priority assignment

## API Endpoints

### Model Management
- `POST /api/v1/models/upload` - Upload model file
- `GET /api/v1/models/machine/{id}` - Get models by machine
- `GET /api/v1/models/{id}` - Get model details
- `DELETE /api/v1/models/{id}` - Delete model
- `GET /api/v1/models/{id}/parse` - Parse model for mesh names

### Hotspot Management
- `POST /api/v1/models/hotspots` - Create hotspot
- `GET /api/v1/models/{id}/hotspots` - Get model hotspots
- `PUT /api/v1/models/hotspots/{id}` - Update hotspot
- `DELETE /api/v1/models/hotspots/{id}` - Delete hotspot
- `POST /api/v1/models/hotspots/bulk` - Bulk create hotspots
- `POST /api/v1/models/hotspots/auto-generate` - Auto-generate hotspots

### Viewer Operations
- `GET /api/v1/models/{id}/viewer-data` - Get viewer data
- `GET /api/v1/models/{id}/file` - Download model file
- `PUT /api/v1/models/{id}/layers` - Update layer visibility
- `POST /api/v1/models/{id}/view-state` - Save view state

### PM Integration
- `POST /api/v1/models/pm/assign-task` - Assign PM task
- `GET /api/v1/models/pm/node-tasks/{type}/{id}` - Get node tasks
- `GET /api/v1/models/pm/templates` - Get available templates

## Usage Workflow

### 1. Model Upload
1. Navigate to `/models/upload`
2. Select target machine
3. Upload GLB/GLTF/SVG file
4. Wait for processing completion

### 2. Mesh Mapping
1. Open `/models/{id}/map`
2. Use auto-mapping or manual drag-and-drop
3. Review confidence scores
4. Adjust mappings as needed

### 3. Hotspot Creation
1. Open `/models/{id}/hotspots`
2. Enable edit mode
3. Click to create hotspots
4. Configure hotspot properties
5. Link to machine parts

### 4. PM Task Assignment
1. Open model viewer `/models/{id}`
2. Click on hotspot
3. Select "Assign PM Task"
4. Choose template and frequency
5. Save assignment

## Performance Considerations

### 3D Models
- **File Size**: Recommend < 50MB for GLB/GLTF
- **Optimization**: Automatic Draco compression reduces size by 60-80%
- **Loading**: Progressive loading with thumbnails
- **Caching**: Browser caching for optimized models

### 2D Models
- **File Size**: Recommend < 10MB for SVG
- **Optimization**: SVG minification
- **Rendering**: Hardware-accelerated SVG rendering