-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 2: ATTENDANCE & FEES
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- ATTENDANCE TABLE
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_student_date` (`student_id`, `timestamp`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_class_section_date` (`class_id`, `section_id`, `timestamp`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_year_term_att` (`year`(30), `term`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_status_att` (`status`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_checked_in` (`checked_in`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_checked_out` (`checked_out`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_mute_att` (`mute`);
ALTER TABLE `attendance` ADD INDEX IF NOT EXISTS `idx_routine` (`class_routine_id`);

-- FEEDING_FEE TABLE
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_student_fee` (`student_id`, `class_id`, `timestamp`);
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_class_section_fee` (`class_id`, `section_id`, `timestamp`);
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_year_term_fee` (`year`(30), `term`);
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_feeding_status` (`feeding_status`);
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_classes_status` (`classes_status`);
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_att_status` (`att_status`);
ALTER TABLE `feeding_fee` ADD INDEX IF NOT EXISTS `idx_mute_fee` (`mute`);

-- INVOICE TABLE
ALTER TABLE `invoice` ADD INDEX IF NOT EXISTS `idx_student_invoice` (`student_id`, `class_id`);
ALTER TABLE `invoice` ADD INDEX IF NOT EXISTS `idx_invoice_code` (`invoice_code`(50));
ALTER TABLE `invoice` ADD INDEX IF NOT EXISTS `idx_year_term_invoice` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `invoice` ADD INDEX IF NOT EXISTS `idx_status_invoice` (`status`(50));
ALTER TABLE `invoice` ADD INDEX IF NOT EXISTS `idx_creation_timestamp` (`creation_timestamp`);
ALTER TABLE `invoice` ADD INDEX IF NOT EXISTS `idx_mute_invoice` (`mute`);

-- PAYMENT TABLE
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_student_payment` (`student_id`, `class_id`);
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_invoice_payment` (`invoice_id`);
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_invoice_code_payment` (`invoice_code`(50));
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_receipt_code` (`receipt_code`(50));
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_year_term_payment` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_timestamp_payment` (`timestamp`(50));
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_day_timestamp` (`day_timestamp`(50));
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_expense_category` (`expense_category_id`);
ALTER TABLE `payment` ADD INDEX IF NOT EXISTS `idx_account` (`account_id`);

-- TRANSPORT_FARE TABLE
ALTER TABLE `transport_fare` ADD INDEX IF NOT EXISTS `idx_student_transport` (`student_id`, `class_id`, `section_id`);
ALTER TABLE `transport_fare` ADD INDEX IF NOT EXISTS `idx_year_term_transport` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `transport_fare` ADD INDEX IF NOT EXISTS `idx_transport_status` (`transport_status`);
ALTER TABLE `transport_fare` ADD INDEX IF NOT EXISTS `idx_att_status_transport` (`att_status`);
ALTER TABLE `transport_fare` ADD INDEX IF NOT EXISTS `idx_mute_transport` (`mute`);

-- MOBILE_MONEY_PAYMENT TABLE
ALTER TABLE `mobile_money_payment` ADD INDEX IF NOT EXISTS `idx_student_mobile` (`student_id`);
ALTER TABLE `mobile_money_payment` ADD INDEX IF NOT EXISTS `idx_invoice_mobile` (`invoice_id`);
ALTER TABLE `mobile_money_payment` ADD INDEX IF NOT EXISTS `idx_invoice_code_mobile` (`invoice_code`(50));
ALTER TABLE `mobile_money_payment` ADD INDEX IF NOT EXISTS `idx_year_term_mobile` (`year`(50), `term`(50), `sem`(50));
ALTER TABLE `mobile_money_payment` ADD INDEX IF NOT EXISTS `idx_timestamp_mobile` (`timestamp`(50));
ALTER TABLE `mobile_money_payment` ADD INDEX IF NOT EXISTS `idx_expense_cat_mobile` (`expense_category_id`);

COMMIT;
