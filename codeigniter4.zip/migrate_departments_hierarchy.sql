-- Hierarchical Departments Migration
-- Run this SQL script directly in MySQL

USE factory_manager;

-- Add parent_id column if not exists
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = 'factory_manager' AND TABLE_NAME = 'departments' AND COLUMN_NAME = 'parent_id');

SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE departments ADD COLUMN parent_id INT(11) UNSIGNED NULL AFTER id',
    'SELECT "parent_id already exists" AS message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add level column if not exists
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = 'factory_manager' AND TABLE_NAME = 'departments' AND COLUMN_NAME = 'level');

SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE departments ADD COLUMN level TINYINT(2) DEFAULT 1 COMMENT "1=Main Department, 2=Sub-Department" AFTER parent_id',
    'SELECT "level already exists" AS message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add supervisor_id column if not exists (check first)
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = 'factory_manager' AND TABLE_NAME = 'departments' AND COLUMN_NAME = 'supervisor_id');

SET @sql = IF(@col_exists = 0, 
    'ALTER TABLE departments ADD COLUMN supervisor_id INT(11) UNSIGNED NULL AFTER description',
    'SELECT "supervisor_id already exists" AS message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add indexes
CREATE INDEX IF NOT EXISTS idx_parent_id ON departments(parent_id);
CREATE INDEX IF NOT EXISTS idx_supervisor_id ON departments(supervisor_id);
CREATE INDEX IF NOT EXISTS idx_level ON departments(level);

-- Add foreign key constraint (check if exists first)
SET @fk_exists = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS 
    WHERE TABLE_SCHEMA = 'factory_manager' AND TABLE_NAME = 'departments' AND CONSTRAINT_NAME = 'fk_departments_parent');

SET @sql = IF(@fk_exists = 0,
    'ALTER TABLE departments ADD CONSTRAINT fk_departments_parent FOREIGN KEY (parent_id) REFERENCES departments(id) ON DELETE SET NULL',
    'SELECT "Foreign key already exists" AS message');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'Hierarchical departments migration completed successfully!' AS status;
