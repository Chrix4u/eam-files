<?php

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Adding performance indexes...\n\n";
    
    $indexes = [
        // Assets indexes
        "CREATE INDEX idx_assets_status ON assets_unified(status)",
        "CREATE INDEX idx_assets_type ON assets_unified(asset_type)",
        "CREATE INDEX idx_assets_criticality ON assets_unified(criticality)",
        "CREATE INDEX idx_assets_location ON assets_unified(location)",
        "CREATE INDEX idx_assets_parent ON assets_unified(parent_id)",
        
        // Work orders indexes
        "CREATE INDEX idx_wo_status ON work_orders(status)",
        "CREATE INDEX idx_wo_priority ON work_orders(priority)",
        "CREATE INDEX idx_wo_asset ON work_orders(asset_id)",
        "CREATE INDEX idx_wo_assigned ON work_orders(assigned_to)",
        "CREATE INDEX idx_wo_created ON work_orders(created_at)",
        
        // Users indexes
        "CREATE INDEX idx_users_role ON users(role)",
        "CREATE INDEX idx_users_email ON users(email)",
        
        // Machines indexes
        "CREATE INDEX idx_machines_status ON machines(status)",
        "CREATE INDEX idx_machines_location ON machines(plant_location)",
        
        // Composite indexes for common queries
        "CREATE INDEX idx_assets_type_status ON assets_unified(asset_type, status)",
        "CREATE INDEX idx_wo_asset_status ON work_orders(asset_id, status)",
    ];
    
    foreach ($indexes as $sql) {
        try {
            $pdo->exec($sql);
            echo "✓ " . substr($sql, 0, 60) . "...\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                echo "✗ Error: " . $e->getMessage() . "\n";
            } else {
                echo "⊙ Already exists\n";
            }
        }
    }
    
    echo "\n✅ Performance indexes added successfully!\n";
    
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
