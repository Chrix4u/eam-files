<?php

$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "╔══════════════════════════════════════════════════════════════╗\n";
echo "║     CHECKING EXISTING INTEGRATION STATUS                     ║\n";
echo "╚══════════════════════════════════════════════════════════════╝\n\n";

// 1. Check if part_inventory_links exists
echo "1. Checking part_inventory_links table...\n";
$result = $conn->query("SHOW TABLES LIKE 'part_inventory_links'");
if ($result->num_rows > 0) {
    echo "   ✅ Table EXISTS\n";
    $count = $conn->query("SELECT COUNT(*) as cnt FROM part_inventory_links")->fetch_assoc();
    echo "   📊 Records: {$count['cnt']}\n";
} else {
    echo "   ❌ Table DOES NOT EXIST\n";
}

// 2. Check pm_task_materials
echo "\n2. Checking pm_task_materials table...\n";
$result = $conn->query("SHOW TABLES LIKE 'pm_task_materials'");
if ($result->num_rows > 0) {
    echo "   ✅ Table EXISTS\n";
    $count = $conn->query("SELECT COUNT(*) as cnt FROM pm_task_materials")->fetch_assoc();
    echo "   📊 Records: {$count['cnt']}\n";
    
    // Check structure
    $result = $conn->query("DESCRIBE pm_task_materials");
    echo "   📋 Fields: ";
    $fields = [];
    while ($row = $result->fetch_assoc()) {
        $fields[] = $row['Field'];
    }
    echo implode(', ', $fields) . "\n";
} else {
    echo "   ❌ Table DOES NOT EXIST\n";
}

// 3. Check pm_required_spares
echo "\n3. Checking pm_required_spares table...\n";
$count = $conn->query("SELECT COUNT(*) as cnt FROM pm_required_spares")->fetch_assoc();
echo "   ✅ Table EXISTS\n";
echo "   📊 Records: {$count['cnt']}\n";

// 4. Check asset_spare_parts
echo "\n4. Checking asset_spare_parts table...\n";
$count = $conn->query("SELECT COUNT(*) as cnt FROM asset_spare_parts")->fetch_assoc();
echo "   ✅ Table EXISTS\n";
echo "   📊 Records: {$count['cnt']}\n";

// Check if it links to inventory_items
$result = $conn->query("DESCRIBE asset_spare_parts");
$hasInventoryLink = false;
while ($row = $result->fetch_assoc()) {
    if ($row['Field'] == 'inventory_item_id') {
        $hasInventoryLink = true;
        break;
    }
}
echo "   " . ($hasInventoryLink ? "✅" : "❌") . " Has inventory_item_id field\n";

// 5. Check parts table
echo "\n5. Checking parts table...\n";
$count = $conn->query("SELECT COUNT(*) as cnt FROM parts")->fetch_assoc();
echo "   ✅ Table EXISTS\n";
echo "   📊 Records: {$count['cnt']}\n";

// Check if has spare_availability field
$result = $conn->query("DESCRIBE parts");
$hasSpareField = false;
while ($row = $result->fetch_assoc()) {
    if ($row['Field'] == 'spare_availability') {
        $hasSpareField = true;
        break;
    }
}
echo "   " . ($hasSpareField ? "✅" : "❌") . " Has spare_availability field\n";

// 6. Check inventory_items
echo "\n6. Checking inventory_items table...\n";
$count = $conn->query("SELECT COUNT(*) as cnt FROM inventory_items")->fetch_assoc();
echo "   ✅ Table EXISTS\n";
echo "   📊 Records: {$count['cnt']}\n";

// 7. Check material_requests
echo "\n7. Checking material_requests table...\n";
$result = $conn->query("SHOW TABLES LIKE 'material_requests'");
if ($result->num_rows > 0) {
    echo "   ✅ Table EXISTS\n";
    $count = $conn->query("SELECT COUNT(*) as cnt FROM material_requests")->fetch_assoc();
    echo "   📊 Records: {$count['cnt']}\n";
} else {
    echo "   ❌ Table DOES NOT EXIST\n";
}

// Summary
echo "\n";
echo "╔══════════════════════════════════════════════════════════════╗\n";
echo "║                    INTEGRATION STATUS                        ║\n";
echo "╚══════════════════════════════════════════════════════════════╝\n\n";

echo "EXISTING TABLES:\n";
echo "✅ parts (component hierarchy)\n";
echo "✅ inventory_items (warehouse stock)\n";
echo "✅ asset_spare_parts (asset → spares)\n";
echo "✅ pm_required_spares (PM → spares)\n";

echo "\nNEW INTEGRATION TABLES NEEDED:\n";
if ($conn->query("SHOW TABLES LIKE 'part_inventory_links'")->num_rows == 0) {
    echo "❌ part_inventory_links (links parts to inventory)\n";
} else {
    echo "✅ part_inventory_links\n";
}

if ($conn->query("SHOW TABLES LIKE 'pm_task_materials'")->num_rows == 0) {
    echo "❌ pm_task_materials (PM task materials)\n";
} else {
    echo "✅ pm_task_materials\n";
}

if ($conn->query("SHOW TABLES LIKE 'material_requests'")->num_rows == 0) {
    echo "❌ material_requests (material requisition)\n";
} else {
    echo "✅ material_requests\n";
}

echo "\nCONCLUSION:\n";
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";

$hasPartInventoryLinks = $conn->query("SHOW TABLES LIKE 'part_inventory_links'")->num_rows > 0;
$hasPmTaskMaterials = $conn->query("SHOW TABLES LIKE 'pm_task_materials'")->num_rows > 0;

if ($hasPartInventoryLinks && $hasPmTaskMaterials) {
    echo "✅ INTEGRATION IS ACTIVE\n";
    echo "   Parts, Inventory, and PM are linked and working.\n";
} else {
    echo "⚠️  PARTIAL INTEGRATION\n";
    echo "   Tables exist but integration tables are missing.\n";
    echo "   Need to create: part_inventory_links, pm_task_materials\n";
}

$conn->close();
