<?php

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "=== FIXING DATABASE STRUCTURE ===\n\n";
    
    $queries = [
        "ALTER TABLE `work_orders` ADD COLUMN `wo_number` VARCHAR(50) NULL AFTER `id`",
        "ALTER TABLE `work_orders` ADD COLUMN `wo_type` VARCHAR(50) NULL AFTER `status`",
        "ALTER TABLE `work_orders` ADD COLUMN `team_leader_id` INT(11) UNSIGNED NULL AFTER `assigned_to`",
        "ALTER TABLE `work_orders` ADD COLUMN `assigned_supervisor_id` INT(11) UNSIGNED NULL AFTER `team_leader_id`",
        "ALTER TABLE `work_orders` ADD COLUMN `forwarded_by` INT(11) UNSIGNED NULL AFTER `assigned_supervisor_id`",
        "ALTER TABLE `work_orders` ADD COLUMN `forwarded_at` DATETIME NULL AFTER `forwarded_by`",
        "ALTER TABLE `work_orders` ADD COLUMN `assignment_type` ENUM('direct', 'via_supervisor') DEFAULT 'direct' AFTER `forwarded_at`",
        
        "CREATE TABLE IF NOT EXISTS `work_order_help_requests` (
            `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `work_order_id` INT(11) UNSIGNED NOT NULL,
            `requested_by` INT(11) UNSIGNED NOT NULL,
            `requested_technicians` JSON NOT NULL,
            `reason` TEXT NOT NULL,
            `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
            `approved_by` INT(11) UNSIGNED NULL,
            `approved_at` DATETIME NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `work_order_id` (`work_order_id`),
            KEY `status` (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
        
        "CREATE TABLE IF NOT EXISTS `work_order_completion_reports` (
            `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
            `work_order_id` INT(11) UNSIGNED NOT NULL,
            `submitted_by` INT(11) UNSIGNED NOT NULL,
            `work_performed` TEXT NOT NULL,
            `findings` TEXT NULL,
            `recommendations` TEXT NULL,
            `team_members_data` JSON NOT NULL,
            `materials_used` JSON NULL,
            `completion_status` ENUM('completed', 'partial', 'pending_parts') DEFAULT 'completed',
            `submitted_at` DATETIME NOT NULL,
            `created_at` DATETIME NOT NULL,
            PRIMARY KEY (`id`),
            KEY `work_order_id` (`work_order_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    ];
    
    foreach ($queries as $index => $query) {
        try {
            $pdo->exec($query);
            echo "✅ Query " . ($index + 1) . " executed successfully\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                echo "⚠️  Query " . ($index + 1) . " skipped (column already exists)\n";
            } elseif (strpos($e->getMessage(), 'already exists') !== false) {
                echo "⚠️  Query " . ($index + 1) . " skipped (table already exists)\n";
            } else {
                echo "❌ Query " . ($index + 1) . " failed: " . $e->getMessage() . "\n";
            }
        }
    }
    
    echo "\n✅ Database structure fix completed!\n";
    echo "Run validate_db_structure.php to verify.\n";
    
} catch (PDOException $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "\n";
    exit(1);
}
