USE factory_manager;

CREATE TABLE IF NOT EXISTS `tools` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tool_code` VARCHAR(50) UNIQUE,
  `tool_name` VARCHAR(255) NOT NULL,
  `category` VARCHAR(100) NULL,
  `description` TEXT NULL,
  `manufacturer` VARCHAR(255) NULL,
  `model_number` VARCHAR(100) NULL,
  `serial_number` VARCHAR(100) NULL,
  `quantity_available` INT(11) DEFAULT 0,
  `quantity_in_use` INT(11) DEFAULT 0,
  `location` VARCHAR(255) NULL,
  `condition_status` ENUM('excellent', 'good', 'fair', 'poor', 'needs_repair') DEFAULT 'good',
  `calibration_required` BOOLEAN DEFAULT false,
  `last_calibration_date` DATE NULL,
  `next_calibration_date` DATE NULL,
  `purchase_date` DATE NULL,
  `purchase_cost` DECIMAL(10,2) NULL,
  `image_url` VARCHAR(500) NULL,
  `barcode` VARCHAR(100) NULL,
  `is_active` BOOLEAN DEFAULT true,
  `notes` TEXT NULL,
  `created_by` INT(11) UNSIGNED NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tool_code` (`tool_code`),
  KEY `idx_category` (`category`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `tool_assignments` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tool_id` INT(11) UNSIGNED NOT NULL,
  `work_order_id` INT(11) UNSIGNED NULL,
  `assigned_to_user_id` INT(11) UNSIGNED NULL,
  `quantity` INT(11) DEFAULT 1,
  `assigned_at` DATETIME NOT NULL,
  `returned_at` DATETIME NULL,
  `status` ENUM('assigned', 'returned', 'lost', 'damaged') DEFAULT 'assigned',
  `condition_on_return` ENUM('excellent', 'good', 'fair', 'poor', 'damaged') NULL,
  `notes` TEXT NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tool_id` (`tool_id`),
  KEY `idx_work_order_id` (`work_order_id`),
  KEY `idx_assigned_to` (`assigned_to_user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_tool_assignments_tool` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert sample tools
INSERT INTO `tools` (`tool_code`, `tool_name`, `category`, `quantity_available`, `is_active`, `created_at`) VALUES
('TOOL-00001', 'Torque Wrench', 'Hand Tools', 5, 1, NOW()),
('TOOL-00002', 'Multimeter', 'Electrical', 3, 1, NOW()),
('TOOL-00003', 'Impact Driver', 'Power Tools', 4, 1, NOW()),
('TOOL-00004', 'Hydraulic Jack', 'Lifting Equipment', 2, 1, NOW()),
('TOOL-00005', 'Angle Grinder', 'Power Tools', 6, 1, NOW());
