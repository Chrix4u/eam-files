# Fix 404 Errors - Module Access

## Problem
Routes return 404 because:
1. `company_modules` table doesn't exist or is empty
2. Filters block access when modules not licensed/enabled

## Quick Fix

Run this SQL to enable all modules:

```sql
-- Run in phpMyAdmin or MySQL client
source c:/wamp64/www/factorymanager/database/seed_company_modules.sql
```

Or manually:

```sql
-- Create table
CREATE TABLE IF NOT EXISTS `company_modules` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `company_id` INT UNSIGNED NOT NULL,
  `module_code` VARCHAR(50) NOT NULL,
  `is_active` TINYINT(1) DEFAULT 0,
  `is_enabled` TINYINT(1) DEFAULT 0,
  `license_type` ENUM('trial', 'standard', 'premium', 'enterprise') DEFAULT 'standard',
  `license_expires_at` DATETIME NULL,
  `activated_at` DATETIME NULL,
  `activated_by` INT UNSIGNED NULL,
  `enabled_at` DATETIME NULL,
  `enabled_by` INT UNSIGNED NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `company_module_unique` (`company_id`, `module_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Enable all modules for company_id = 1
INSERT INTO `company_modules` 
(`company_id`, `module_code`, `is_active`, `is_enabled`, `license_type`, `activated_at`, `enabled_at`)
VALUES
(1, 'CORE', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'ASSET', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'RWOP', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'MRMP', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'MPMP', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'IMS', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'HRMS', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'TRAC', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'IOT', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'DIGITAL_TWIN', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'MOBILE', 1, 1, 'enterprise', NOW(), NOW()),
(1, 'REPORTS', 1, 1, 'enterprise', NOW(), NOW())
ON DUPLICATE KEY UPDATE
  `is_active` = 1,
  `is_enabled` = 1;
```

## Verify

Check if modules are enabled:
```sql
SELECT module_code, is_active, is_enabled 
FROM company_modules 
WHERE company_id = 1;
```

Should show all 12 modules with is_active=1 and is_enabled=1.

## Test Routes

After running SQL, test:
- http://localhost/factorymanager/public/index.php/api/v1/eam/digital-twin/metrics
- http://localhost/factorymanager/public/index.php/api/v1/eam/analytics/kpis

Both should return 200 OK (or 401 if not authenticated).

## Alternative: Disable Filters Temporarily

If you want to test without module licensing, comment out filters in route files:

```php
// Before
$routes->group('api/v1/eam', ['filter' => 'jwt|modulelicense|moduleaccess:REPORTS'], function($routes) {

// After (JWT only)
$routes->group('api/v1/eam', ['filter' => 'jwt'], function($routes) {
```

But this is NOT recommended for production.
