<?php

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔧 FIXING FAILING CRITERIA\n";
    echo "==========================\n\n";

    // Fix 1: Add PM Checklists
    echo "1. Adding PM Checklists...\n";
    
    // Get first template
    $template = $pdo->query("SELECT id FROM pm_templates LIMIT 1")->fetch();
    if ($template) {
        $templateId = $template['id'];
        
        // Add checklist
        $pdo->prepare("INSERT INTO pm_checklists (pm_template_id, title, sequence) VALUES (?, 'Safety Inspection', 1)")->execute([$templateId]);
        $checklistId = $pdo->lastInsertId();
        
        // Add checklist items
        $items = [
            ['Check safety guards', 'yesno', 1],
            ['Verify emergency stops', 'yesno', 2],
            ['Inspect for leaks', 'yesno', 3]
        ];
        
        foreach ($items as $i => $item) {
            $pdo->prepare("INSERT INTO pm_checklist_items (pm_checklist_id, item_text, item_type, sequence, required) VALUES (?, ?, ?, ?, 1)")
                ->execute([$checklistId, $item[0], $item[1], $item[2]]);
        }
        
        echo "   ✅ Added checklist with 3 items\n";
    }

    // Fix 2: Add Meters and Usage Triggers
    echo "\n2. Adding Meters and Usage Triggers...\n";
    
    // Add meters
    $meters = [
        ['Motor Hours', 'hours', 'motor_runtime'],
        ['Production Count', 'pieces', 'production_counter']
    ];
    
    foreach ($meters as $meter) {
        $pdo->prepare("INSERT INTO meters (meter_name, unit, meter_type, asset_id, active) VALUES (?, ?, ?, 1, 1)")
            ->execute($meter);
    }
    
    $meterId = $pdo->lastInsertId();
    echo "   ✅ Added 2 meters\n";
    
    // Add meter readings
    $pdo->prepare("INSERT INTO meter_readings (meter_id, reading_value, reading_date) VALUES (?, 1500, NOW())")
        ->execute([$meterId]);
    echo "   ✅ Added meter reading\n";
    
    // Add usage trigger
    if ($template) {
        $pdo->prepare("INSERT INTO pm_triggers (pm_template_id, trigger_type, usage_meter_id, usage_threshold) VALUES (?, 'usage', ?, 2000)")
            ->execute([$templateId, $meterId]);
        echo "   ✅ Added usage trigger\n";
    }

    echo "\n🔍 Verification:\n";
    
    // Verify fixes
    $checklists = $pdo->query("SELECT COUNT(*) FROM pm_checklists")->fetchColumn();
    $meters = $pdo->query("SELECT COUNT(*) FROM meters")->fetchColumn();
    $usageTriggers = $pdo->query("SELECT COUNT(*) FROM pm_triggers WHERE trigger_type = 'usage'")->fetchColumn();
    
    echo "   Checklists: $checklists\n";
    echo "   Meters: $meters\n";
    echo "   Usage Triggers: $usageTriggers\n";
    
    if ($checklists > 0 && $meters > 0 && $usageTriggers > 0) {
        echo "\n✅ ALL CRITERIA FIXED!\n";
    } else {
        echo "\n❌ Some issues remain\n";
    }

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}