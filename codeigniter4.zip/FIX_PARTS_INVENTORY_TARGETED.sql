-- ============================================================================
-- ENTERPRISE-GRADE PARTS & INVENTORY INTEGRATION FIX (TARGETED)
-- ============================================================================
-- Based on actual database audit
-- Date: 2026-01-27
-- Tables: 206 existing tables analyzed
-- ============================================================================

USE factory_manager;

-- ============================================================================
-- STEP 1: FIX COLLATION MISMATCH (parts vs inventory_items)
-- ============================================================================

ALTER TABLE parts 
MODIFY part_number VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci;

ALTER TABLE parts 
MODIFY part_code VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci;

-- ============================================================================
-- STEP 2: CREATE MISSING TABLE - part_inventory_links
-- ============================================================================

CREATE TABLE part_inventory_links (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    part_id INT NOT NULL COMMENT 'FK to parts.id',
    inventory_item_id INT UNSIGNED NOT NULL COMMENT 'FK to inventory_items.id',
    quantity_per_unit DECIMAL(10,3) DEFAULT 1.000,
    is_primary BOOLEAN DEFAULT TRUE,
    substitute_priority INT DEFAULT 0,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    
    UNIQUE KEY unique_part_inventory (part_id, inventory_item_id),
    INDEX idx_part_id (part_id),
    INDEX idx_inventory_item_id (inventory_item_id),
    INDEX idx_primary (is_primary)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- ============================================================================
-- STEP 3: ENHANCE EXISTING asset_spare_parts TABLE
-- ============================================================================

ALTER TABLE asset_spare_parts
ADD COLUMN IF NOT EXISTS part_id INT NULL COMMENT 'FK to parts.id' AFTER inventory_item_id,
ADD COLUMN IF NOT EXISTS criticality ENUM('critical','high','medium','low') DEFAULT 'medium' AFTER quantity_required,
ADD COLUMN IF NOT EXISTS replacement_frequency_days INT NULL,
ADD COLUMN IF NOT EXISTS last_replaced_date DATE NULL,
ADD COLUMN IF NOT EXISTS next_replacement_date DATE NULL,
ADD COLUMN IF NOT EXISTS notes TEXT,
ADD COLUMN IF NOT EXISTS updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add foreign key if not exists
ALTER TABLE asset_spare_parts
ADD CONSTRAINT fk_asp_part_id FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL;

ALTER TABLE asset_spare_parts
ADD CONSTRAINT fk_asp_inventory_id FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT;

ALTER TABLE asset_spare_parts
ADD CONSTRAINT fk_asp_asset_node FOREIGN KEY (asset_node_id) REFERENCES asset_nodes(id) ON DELETE CASCADE;

-- Add indexes
CREATE INDEX idx_asp_criticality ON asset_spare_parts(criticality);
CREATE INDEX idx_asp_next_replacement ON asset_spare_parts(next_replacement_date);

-- ============================================================================
-- STEP 4: ENHANCE EXISTING work_order_materials TABLE
-- ============================================================================

ALTER TABLE work_order_materials
ADD COLUMN IF NOT EXISTS part_id INT NULL COMMENT 'FK to parts.id' AFTER inventory_item_id,
ADD COLUMN IF NOT EXISTS unit_cost DECIMAL(10,2) DEFAULT 0 AFTER quantity_issued,
ADD COLUMN IF NOT EXISTS total_cost DECIMAL(10,2) GENERATED ALWAYS AS (quantity_issued * unit_cost) STORED,
ADD COLUMN IF NOT EXISTS notes TEXT,
ADD COLUMN IF NOT EXISTS updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

-- Add foreign key
ALTER TABLE work_order_materials
ADD CONSTRAINT fk_wom_part_id FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL;

-- ============================================================================
-- STEP 5: ENHANCE EXISTING inventory_items TABLE
-- ============================================================================

ALTER TABLE inventory_items
ADD COLUMN IF NOT EXISTS quantity_reserved DECIMAL(15,2) DEFAULT 0 COMMENT 'Reserved for work orders',
ADD COLUMN IF NOT EXISTS quantity_available DECIMAL(15,2) GENERATED ALWAYS AS (quantity_on_hand - quantity_reserved) STORED,
ADD COLUMN IF NOT EXISTS min_stock_level DECIMAL(15,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS max_stock_level DECIMAL(15,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS abc_classification ENUM('A','B','C') DEFAULT 'C',
ADD COLUMN IF NOT EXISTS last_issued_date DATETIME NULL,
ADD COLUMN IF NOT EXISTS last_received_date DATETIME NULL;

-- Add indexes
CREATE INDEX idx_inventory_available ON inventory_items(quantity_available);
CREATE INDEX idx_inventory_abc ON inventory_items(abc_classification);

-- ============================================================================
-- STEP 6: CREATE MISSING TABLE - pm_task_materials
-- ============================================================================

CREATE TABLE IF NOT EXISTS pm_task_materials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pm_task_id INT NOT NULL COMMENT 'FK to part_pm_tasks.id',
    part_id INT NULL COMMENT 'FK to parts.id',
    inventory_item_id INT UNSIGNED NOT NULL COMMENT 'FK to inventory_items.id',
    planned_quantity DECIMAL(10,3) NOT NULL DEFAULT 1.000,
    unit_of_measure VARCHAR(50) DEFAULT 'EA',
    is_critical BOOLEAN DEFAULT FALSE,
    substitute_allowed BOOLEAN DEFAULT TRUE,
    estimated_cost DECIMAL(10,2) NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    
    INDEX idx_pm_task (pm_task_id),
    INDEX idx_part (part_id),
    INDEX idx_inventory (inventory_item_id),
    INDEX idx_critical (is_critical)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- ============================================================================
-- STEP 7: CREATE MISSING TABLE - inventory_reservations
-- ============================================================================

CREATE TABLE IF NOT EXISTS inventory_reservations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NULL,
    pm_task_id INT NULL,
    reserved_quantity DECIMAL(10,3) NOT NULL,
    reserved_by INT UNSIGNED NOT NULL,
    reserved_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NULL,
    status ENUM('active','consumed','cancelled','expired') DEFAULT 'active',
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE CASCADE,
    
    INDEX idx_inventory (inventory_item_id),
    INDEX idx_work_order (work_order_id),
    INDEX idx_status (status),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- ============================================================================
-- STEP 8: ENHANCE asset_inventory_links TABLE
-- ============================================================================

ALTER TABLE asset_inventory_links
ADD COLUMN IF NOT EXISTS part_id INT NULL COMMENT 'FK to parts.id' AFTER inventory_item_id,
ADD COLUMN IF NOT EXISTS updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;

ALTER TABLE asset_inventory_links
ADD CONSTRAINT fk_ail_part_id FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL;

-- ============================================================================
-- STEP 9: CREATE ENTERPRISE VIEWS
-- ============================================================================

-- View 1: Parts with Inventory Status
CREATE OR REPLACE VIEW vw_parts_inventory_status AS
SELECT 
    p.id AS part_id,
    p.part_name,
    p.part_number,
    p.part_code,
    p.spare_availability,
    p.criticality AS part_criticality,
    pil.inventory_item_id,
    ii.item_code,
    ii.item_name,
    ii.quantity_on_hand,
    ii.quantity_reserved,
    ii.quantity_available,
    ii.reorder_point,
    ii.location,
    ii.unit_cost,
    CASE 
        WHEN ii.quantity_available IS NULL THEN 'NO_INVENTORY'
        WHEN ii.quantity_available <= 0 THEN 'OUT_OF_STOCK'
        WHEN ii.quantity_available <= ii.reorder_point THEN 'LOW_STOCK'
        ELSE 'IN_STOCK'
    END AS stock_status,
    pil.quantity_per_unit,
    pil.is_primary
FROM parts p
LEFT JOIN part_inventory_links pil ON p.id = pil.part_id AND pil.is_primary = TRUE
LEFT JOIN inventory_items ii ON pil.inventory_item_id = ii.id;

-- View 2: Asset Spare Parts Availability
CREATE OR REPLACE VIEW vw_asset_spare_parts_status AS
SELECT 
    asp.id,
    asp.asset_node_id,
    an.node_name AS asset_name,
    an.node_code AS asset_code,
    asp.inventory_item_id,
    ii.item_name,
    ii.item_code,
    asp.quantity_required,
    ii.quantity_available,
    CASE 
        WHEN ii.quantity_available >= asp.quantity_required THEN 'AVAILABLE'
        WHEN ii.quantity_available > 0 THEN 'PARTIAL'
        ELSE 'NOT_AVAILABLE'
    END AS availability_status,
    asp.criticality,
    asp.next_replacement_date,
    DATEDIFF(asp.next_replacement_date, CURDATE()) AS days_until_replacement
FROM asset_spare_parts asp
JOIN asset_nodes an ON asp.asset_node_id = an.id
JOIN inventory_items ii ON asp.inventory_item_id = ii.id;

-- View 3: PM Tasks with Material Availability
CREATE OR REPLACE VIEW vw_pm_materials_readiness AS
SELECT 
    ppt.id AS pm_task_id,
    ppt.part_id,
    p.part_name,
    ptm.inventory_item_id,
    ii.item_name,
    ptm.planned_quantity,
    ii.quantity_available,
    ptm.is_critical,
    CASE 
        WHEN ptm.inventory_item_id IS NULL THEN 'NO_MATERIALS'
        WHEN ii.quantity_available >= ptm.planned_quantity THEN 'READY'
        WHEN ii.quantity_available > 0 THEN 'PARTIAL'
        WHEN ptm.is_critical = TRUE THEN 'BLOCKED'
        ELSE 'NOT_READY'
    END AS material_status,
    ppt.next_due_date
FROM part_pm_tasks ppt
JOIN parts p ON ppt.part_id = p.id
LEFT JOIN pm_task_materials ptm ON ppt.id = ptm.pm_task_id
LEFT JOIN inventory_items ii ON ptm.inventory_item_id = ii.id
WHERE ppt.is_active = 1;

-- View 4: Work Order Materials Status
CREATE OR REPLACE VIEW vw_work_order_materials_status AS
SELECT 
    wom.id,
    wom.work_order_id,
    wo.work_order_number,
    wom.inventory_item_id,
    ii.item_name,
    ii.item_code,
    wom.quantity_required,
    wom.quantity_reserved,
    wom.quantity_issued,
    ii.quantity_available,
    wom.status,
    CASE 
        WHEN wom.status = 'issued' THEN 'ISSUED'
        WHEN ii.quantity_available >= wom.quantity_required THEN 'AVAILABLE'
        WHEN ii.quantity_available > 0 THEN 'PARTIAL'
        ELSE 'NOT_AVAILABLE'
    END AS availability_status
FROM work_order_materials wom
JOIN work_orders wo ON wom.work_order_id = wo.id
JOIN inventory_items ii ON wom.inventory_item_id = ii.id;

-- ============================================================================
-- STEP 10: POPULATE INITIAL DATA
-- ============================================================================

-- Link parts to inventory where part_number matches item_code
INSERT IGNORE INTO part_inventory_links (part_id, inventory_item_id, is_primary)
SELECT p.id, i.id, TRUE
FROM parts p
JOIN inventory_items i ON p.part_number = i.item_code
WHERE p.spare_availability = 'yes';

-- ============================================================================
-- STEP 11: CREATE STORED PROCEDURES
-- ============================================================================

DELIMITER //

-- Check PM Materials Availability
DROP PROCEDURE IF EXISTS sp_check_pm_materials_availability//
CREATE PROCEDURE sp_check_pm_materials_availability(
    IN p_pm_task_id INT,
    OUT p_is_ready BOOLEAN,
    OUT p_missing_items TEXT
)
BEGIN
    DECLARE v_missing_count INT DEFAULT 0;
    
    SELECT COUNT(*) INTO v_missing_count
    FROM pm_task_materials ptm
    JOIN inventory_items ii ON ptm.inventory_item_id = ii.id
    WHERE ptm.pm_task_id = p_pm_task_id
    AND ptm.is_critical = TRUE
    AND ii.quantity_available < ptm.planned_quantity;
    
    SET p_is_ready = (v_missing_count = 0);
    
    SELECT GROUP_CONCAT(
        CONCAT(ii.item_name, ' (Need: ', ptm.planned_quantity, ', Available: ', ii.quantity_available, ')')
        SEPARATOR '; '
    ) INTO p_missing_items
    FROM pm_task_materials ptm
    JOIN inventory_items ii ON ptm.inventory_item_id = ii.id
    WHERE ptm.pm_task_id = p_pm_task_id
    AND ii.quantity_available < ptm.planned_quantity;
END//

-- Reserve Materials for Work Order
DROP PROCEDURE IF EXISTS sp_reserve_materials_for_work_order//
CREATE PROCEDURE sp_reserve_materials_for_work_order(
    IN p_work_order_id INT,
    IN p_reserved_by INT,
    OUT p_success BOOLEAN,
    OUT p_message TEXT
)
BEGIN
    DECLARE v_error_count INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_success = FALSE;
        SET p_message = 'Error reserving materials';
    END;
    
    START TRANSACTION;
    
    -- Check availability
    SELECT COUNT(*) INTO v_error_count
    FROM work_order_materials wom
    JOIN inventory_items ii ON wom.inventory_item_id = ii.id
    WHERE wom.work_order_id = p_work_order_id
    AND wom.status = 'pending'
    AND ii.quantity_available < wom.quantity_required;
    
    IF v_error_count > 0 THEN
        SET p_success = FALSE;
        SET p_message = 'Insufficient inventory';
        ROLLBACK;
    ELSE
        -- Create reservations
        INSERT INTO inventory_reservations (
            inventory_item_id, work_order_id, reserved_quantity, 
            reserved_by, expires_at, status
        )
        SELECT 
            wom.inventory_item_id,
            wom.work_order_id,
            wom.quantity_required,
            p_reserved_by,
            DATE_ADD(NOW(), INTERVAL 7 DAY),
            'active'
        FROM work_order_materials wom
        WHERE wom.work_order_id = p_work_order_id
        AND wom.status = 'pending';
        
        -- Update inventory
        UPDATE inventory_items ii
        JOIN work_order_materials wom ON ii.id = wom.inventory_item_id
        SET ii.quantity_reserved = ii.quantity_reserved + wom.quantity_required
        WHERE wom.work_order_id = p_work_order_id
        AND wom.status = 'pending';
        
        -- Update status
        UPDATE work_order_materials
        SET status = 'reserved', quantity_reserved = quantity_required
        WHERE work_order_id = p_work_order_id
        AND status = 'pending';
        
        SET p_success = TRUE;
        SET p_message = 'Materials reserved successfully';
        COMMIT;
    END IF;
END//

DELIMITER ;

-- ============================================================================
-- STEP 12: ADD PERFORMANCE INDEXES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_parts_spare ON parts(spare_availability);
CREATE INDEX IF NOT EXISTS idx_parts_criticality ON parts(criticality);
CREATE INDEX IF NOT EXISTS idx_parts_status ON parts(status);

-- ============================================================================
-- VERIFICATION
-- ============================================================================

SELECT '✅ ENTERPRISE INTEGRATION COMPLETE' AS status;

SELECT 'part_inventory_links' AS table_name, COUNT(*) AS records FROM part_inventory_links
UNION ALL
SELECT 'asset_spare_parts', COUNT(*) FROM asset_spare_parts
UNION ALL
SELECT 'pm_task_materials', COUNT(*) FROM pm_task_materials
UNION ALL
SELECT 'inventory_reservations', COUNT(*) FROM inventory_reservations;

-- ============================================================================
-- END
-- ============================================================================
