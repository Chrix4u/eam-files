SHOW TABLES LIKE 'pm_triggers';
