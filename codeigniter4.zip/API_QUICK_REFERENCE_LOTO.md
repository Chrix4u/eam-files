# Quick API Reference - Work Order Completion, Permit to Work & LOTO

**Base URL**: `http://localhost/factorymanager/public/index.php/api/v1/eam`

---

## 🔧 Work Order Completion API

### Time Tracking

#### Start Time Log
```http
POST /maintenance/work-orders/{id}/time-logs/start
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "message": "Time tracking started",
  "data": {
    "id": 1,
    "work_order_id": 123,
    "technician_id": 5,
    "clock_in": "2025-01-28 08:00:00",
    "status": "active"
  }
}
```

#### Stop Time Log
```http
POST /maintenance/work-orders/{id}/time-logs/stop
Authorization: Bearer {token}
Content-Type: application/json

{
  "break_duration": 30,
  "activity_description": "Replaced motor bearings",
  "work_type": "repair"
}

Response:
{
  "status": "success",
  "message": "Time log completed",
  "data": {
    "actual_hours": 7.5
  }
}
```

#### Get Time Log Summary
```http
GET /maintenance/work-orders/{id}/time-logs/summary
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "data": {
    "total_hours": 15.5,
    "total_break_minutes": 60,
    "total_sessions": 3,
    "by_technician": [
      {
        "technician_id": 5,
        "total_hours": 7.5,
        "sessions": 1
      }
    ]
  }
}
```

### Materials Tracking

#### Add Material Used
```http
POST /maintenance/work-orders/{id}/materials-used
Authorization: Bearer {token}
Content-Type: application/json

{
  "part_id": 45,
  "quantity_used": 2,
  "quantity_returned": 0,
  "unit_cost": 150.00,
  "total_cost": 300.00,
  "notes": "Replaced both bearings"
}

Response:
{
  "status": "success",
  "message": "Material usage recorded",
  "data": {
    "id": 1
  }
}
```

### Completion Report

#### Save Report (Draft)
```http
POST /maintenance/work-orders/{id}/completion-report
Authorization: Bearer {token}
Content-Type: application/json

{
  "work_performed": "Replaced motor bearings and aligned shaft",
  "root_cause": "Bearing wear due to lack of lubrication",
  "corrective_actions": "Installed new bearings, added lubrication schedule",
  "observations": "Motor running smoothly after repair",
  "recommendations": "Implement weekly lubrication checks",
  "quality_check_passed": true,
  "quality_notes": "All parameters within specification"
}

Response:
{
  "status": "success",
  "message": "Completion report saved",
  "data": {
    "id": 1
  }
}
```

#### Submit Report
```http
POST /maintenance/work-orders/{id}/completion-report/submit
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "message": "Work order completed successfully"
}
```

---

## 🛡️ Permit to Work API

### Create Permit
```http
POST /permits-to-work
Authorization: Bearer {token}
Content-Type: application/json

{
  "permit_type": "hot_work",
  "location": "Production Area A - Welding Bay",
  "equipment_id": 15,
  "work_description": "Welding repairs on conveyor frame",
  "hazards_identified": "Fire risk, hot surfaces, fumes",
  "risk_level": "high",
  "control_measures": "Fire extinguisher on site, fire watch assigned, area cleared",
  "ppe_required": "Welding helmet, gloves, fire-resistant clothing",
  "emergency_procedures": "Evacuate area, call emergency response team",
  "valid_from": "2025-01-28 08:00:00",
  "valid_until": "2025-01-28 17:00:00",
  "authorized_workers": [5, 12, 18]
}

Response:
{
  "status": "success",
  "message": "Permit created successfully",
  "data": {
    "id": 1,
    "permit_number": "HO-20250128-0001"
  }
}
```

### Submit for Approval
```http
POST /permits-to-work/{id}/submit
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "message": "Permit submitted for approval"
}
```

### Approve Permit
```http
POST /permits-to-work/{id}/approve
Authorization: Bearer {token}
Content-Type: application/json

{
  "comments": "All safety measures verified and approved"
}

Response:
{
  "status": "success",
  "message": "Permit approved"
}
```

### Start Work
```http
POST /permits-to-work/{id}/start
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "message": "Work started"
}
```

### Extend Permit
```http
POST /permits-to-work/{id}/extend
Authorization: Bearer {token}
Content-Type: application/json

{
  "reason": "Additional welding required to complete repairs",
  "new_valid_until": "2025-01-28 20:00:00"
}

Response:
{
  "status": "success",
  "message": "Permit extended"
}
```

### Complete Work
```http
POST /permits-to-work/{id}/complete
Authorization: Bearer {token}
Content-Type: application/json

{
  "post_work_inspection": {
    "area_cleaned": true,
    "fire_watch_completed": true,
    "equipment_secured": true
  },
  "incidents_reported": null
}

Response:
{
  "status": "success",
  "message": "Permit closed successfully"
}
```

### Dashboard
```http
GET /permits-to-work/dashboard
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "data": {
    "active": 5,
    "pending_approval": 3,
    "expiring_today": 2,
    "by_type": [
      {
        "permit_type": "hot_work",
        "count": 3
      },
      {
        "permit_type": "confined_space",
        "count": 2
      }
    ]
  }
}
```

---

## 🔒 LOTO System API

### Create Procedure
```http
POST /loto-procedures
Authorization: Bearer {token}
Content-Type: application/json

{
  "equipment_id": 15,
  "procedure_name": "Conveyor Motor Lockout",
  "procedure_code": "LOTO-CONV-001",
  "energy_sources": [
    "480V electrical",
    "Pneumatic air supply",
    "Hydraulic pressure"
  ],
  "isolation_steps": "1. Turn off main breaker\n2. Close air valve\n3. Release hydraulic pressure",
  "verification_steps": "1. Test motor start button\n2. Check air pressure gauge\n3. Verify hydraulic pressure at zero",
  "restoration_steps": "1. Remove all locks\n2. Open air valve\n3. Turn on main breaker\n4. Test equipment operation"
}

Response:
{
  "status": "success",
  "message": "LOTO procedure created successfully",
  "data": {
    "id": 1
  }
}
```

### Apply LOTO
```http
POST /loto/apply
Authorization: Bearer {token}
Content-Type: application/json

{
  "equipment_id": 15,
  "procedure_id": 1,
  "work_order_id": 123,
  "lock_numbers": ["LOCK-001", "LOCK-002"],
  "tag_numbers": ["TAG-001", "TAG-002"]
}

Response:
{
  "status": "success",
  "message": "LOTO applied successfully",
  "data": {
    "id": 1
  }
}
```

### Verify Zero Energy
```http
POST /loto/{id}/verify
Authorization: Bearer {token}
Content-Type: application/json

{
  "verification_notes": "All energy sources verified at zero. Equipment tested and safe."
}

Response:
{
  "status": "success",
  "message": "LOTO verified successfully"
}
```

### Remove LOTO
```http
POST /loto/{id}/remove
Authorization: Bearer {token}
Content-Type: application/json

{
  "equipment_tested": true,
  "removal_notes": "All locks removed. Equipment tested and operational."
}

Response:
{
  "status": "success",
  "message": "LOTO removed successfully"
}
```

### Get Active Lockouts
```http
GET /loto/active
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "equipment_id": 15,
      "equipment_name": "Conveyor Motor #3",
      "procedure_name": "Conveyor Motor Lockout",
      "applied_by": "John Smith",
      "applied_at": "2025-01-28 08:00:00",
      "status": "verified",
      "lock_numbers": ["LOCK-001", "LOCK-002"]
    }
  ]
}
```

### Lock Inventory

#### List Locks
```http
GET /loto-locks?status=available
Authorization: Bearer {token}

Response:
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "lock_number": "LOCK-001",
      "lock_type": "Padlock",
      "assigned_to": null,
      "status": "available",
      "current_location": "Tool Crib A"
    }
  ]
}
```

#### Add Lock
```http
POST /loto-locks
Authorization: Bearer {token}
Content-Type: application/json

{
  "lock_number": "LOCK-050",
  "lock_type": "Padlock",
  "status": "available",
  "current_location": "Tool Crib A"
}

Response:
{
  "status": "success",
  "message": "Lock created successfully",
  "data": {
    "id": 50
  }
}
```

---

## 📋 Common Response Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request (validation error) |
| 401 | Unauthorized (invalid token) |
| 404 | Not Found |
| 500 | Server Error |

---

## 🔑 Authentication

All endpoints require JWT authentication:

```http
Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc...
```

Get token from login endpoint:
```http
POST /api/v1/eam/auth/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "admin123"
}
```

---

## 📊 Status Values

### Work Order Completion Report
- `draft` - Being edited
- `submitted` - Awaiting approval
- `approved` - Approved by supervisor
- `rejected` - Rejected, needs revision

### Permit to Work
- `draft` - Being created
- `pending_approval` - Awaiting approvals
- `approved` - All approvals received
- `active` - Work in progress
- `suspended` - Temporarily stopped
- `completed` - Work finished
- `cancelled` - Permit cancelled

### LOTO Application
- `applied` - Locks applied
- `verified` - Zero energy confirmed
- `active` - In use
- `removed` - Locks removed

### LOTO Lock
- `available` - Ready for use
- `in_use` - Currently assigned
- `damaged` - Needs repair
- `lost` - Missing

---

## 🎯 Workflow Examples

### Complete Work Order Flow
1. Start time log → `POST /time-logs/start`
2. Add materials → `POST /materials-used`
3. Stop time log → `POST /time-logs/stop`
4. Save report → `POST /completion-report`
5. Submit report → `POST /completion-report/submit`
6. Approve report → `POST /completion-report/approve`

### Permit to Work Flow
1. Create permit → `POST /permits-to-work`
2. Submit → `POST /{id}/submit`
3. Approve (supervisor) → `POST /{id}/approve`
4. Approve (safety) → `POST /{id}/approve`
5. Start work → `POST /{id}/start`
6. Complete → `POST /{id}/complete`

### LOTO Flow
1. Create procedure → `POST /loto-procedures`
2. Apply LOTO → `POST /loto/apply`
3. Verify → `POST /loto/{id}/verify`
4. Perform work
5. Remove → `POST /loto/{id}/remove`

---

## 🧪 Testing with cURL

### Start Time Log
```bash
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/maintenance/work-orders/123/time-logs/start \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json"
```

### Create Permit
```bash
curl -X POST http://localhost/factorymanager/public/index.php/api/v1/eam/permits-to-work \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "permit_type": "hot_work",
    "location": "Production Area A",
    "work_description": "Welding repairs",
    "hazards_identified": "Fire risk",
    "risk_level": "high",
    "control_measures": "Fire extinguisher on site",
    "ppe_required": "Welding helmet, gloves",
    "valid_from": "2025-01-28 08:00:00",
    "valid_until": "2025-01-28 17:00:00"
  }'
```

---

**For complete documentation, see**: `WORK_ORDER_COMPLETION_LOTO_IMPLEMENTATION.md`
