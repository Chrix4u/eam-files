@echo off
echo Fixing all user passwords...
C:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager < fix_all_users.sql
echo.
echo All users now have password: admin123
echo.
echo Users updated:
C:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager -e "SELECT username, email, role FROM users WHERE role IN ('admin','manager','supervisor','planner');"
pause
