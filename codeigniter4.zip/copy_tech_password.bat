@echo off
echo Comparing users...
C:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager < compare_users.sql
echo.
echo Copying technician1 password to other users...
C:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager -e "UPDATE users SET password = (SELECT password FROM (SELECT password FROM users WHERE username='technician1') AS temp) WHERE username IN ('admin','supervisor','planner');"
echo.
echo Done. All users now have same password as technician1
pause
