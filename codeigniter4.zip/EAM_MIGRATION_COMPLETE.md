# EAM Schema Migration - Status

## ✅ Partially Complete

### Successfully Created (2 tables)
1. **facilities** - Top-level locations ✅
2. **systems** - Systems within facilities ✅

### Conflicts with Existing Tables
The following EAM tables conflict with existing factory_manager tables:
- equipment (old table exists)
- assemblies (old table exists)
- parts (old table exists)
- work_orders (old table exists)

### Solution: Use EAM Prefix

All new EAM tables will use `eam_` prefix to avoid conflicts:
- eam_equipment
- eam_assemblies
- eam_components
- eam_parts
- eam_sub_parts
- eam_assets
- eam_meters
- eam_meter_readings
- eam_pm_rules
- eam_pm_schedules
- eam_work_orders
- eam_work_order_tasks
- eam_work_order_materials
- eam_inventory_items
- eam_stock_transactions
- eam_vendors
- eam_purchase_orders
- eam_permissions
- eam_user_roles
- eam_role_permissions
- eam_audit_logs

## Current Status

**Migrations Created:** 21 files
**Migrations Run:** 2 (facilities, systems)
**Remaining:** 19 migrations

## Next Steps

1. Rename all remaining migrations to use `eam_` prefix
2. Run `php spark migrate` to complete schema
3. Update model references to new table names

## Alternative: Fresh Database

For a clean EAM-only system:
```bash
# Drop all tables
php spark migrate:rollback --all

# Run all migrations fresh
php spark migrate
```

This will create the complete EAM schema without conflicts.

## Files Ready

All 21 migration files are created and ready in:
`app/Database/Migrations/2025-11-14-*`

Simply rename tables in migrations or use fresh database for clean EAM system.
