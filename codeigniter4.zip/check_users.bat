@echo off
cd c:\wamp64\bin\mysql\mysql8.2.0\bin
mysql.exe -u root -pmyjesus4mE factory_manager -e "SHOW TABLES LIKE 'users'; SHOW TABLES LIKE 'departments'; DESCRIBE users; DESCRIBE departments;"
