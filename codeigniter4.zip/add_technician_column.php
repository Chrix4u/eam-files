<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

echo "Adding assigned_technician_id column...\n";

$result = $mysqli->query("SHOW COLUMNS FROM maintenance_requests LIKE 'assigned_technician_id'");
if ($result->num_rows > 0) {
    echo "Column already exists!\n";
} else {
    $mysqli->query("ALTER TABLE maintenance_requests ADD COLUMN assigned_technician_id INT UNSIGNED NULL AFTER assigned_planner_id");
    echo "Column added successfully!\n";
}

$mysqli->close();
