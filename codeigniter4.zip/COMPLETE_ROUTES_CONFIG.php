<?php

/**
 * Enterprise Work Order Module - Complete Routes Configuration
 * Add to app/Config/RoutesEam.php inside the api/v1/eam group
 */

// ============================================================================
// WORK ORDER TEAM MANAGEMENT
// ============================================================================
$routes->group('work-orders/(:num)', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    // Team Management
    $routes->get('team', 'WorkOrderTeamController::getTeamMembers/$1');
    $routes->post('team', 'WorkOrderTeamController::addTeamMember/$1');
    $routes->delete('team/(:num)', 'WorkOrderTeamController::removeTeamMember/$1/$2');
    
    // Time Tracking
    $routes->post('time-log', 'WorkOrderTeamController::logTime/$1');
    $routes->get('time-logs/(:num)', 'WorkOrderTeamController::getTimeLogs/$1/$2');
    
    // Timeline
    $routes->get('timeline', 'WorkOrderAnalyticsController::timeline/$1');
});

// ============================================================================
// MATERIAL REQUEST MANAGEMENT
// ============================================================================
$routes->group('materials', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    $routes->post('request', 'MaterialRequestController::request');
    $routes->get('pending', 'MaterialRequestController::getPending');
    $routes->post('(:num)/approve', 'MaterialRequestController::approve/$1');
    $routes->post('(:num)/issue', 'MaterialRequestController::issue/$1');
    $routes->post('(:num)/usage', 'MaterialRequestController::recordUsage/$1');
});

// ============================================================================
// ASSISTANCE REQUEST WORKFLOW
// ============================================================================
$routes->group('assistance-requests', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    $routes->get('/', 'AssistanceRequestController::index');
    $routes->get('pending', 'AssistanceRequestController::getPending');
    $routes->post('/', 'AssistanceRequestController::create');
    $routes->post('(:num)/approve', 'AssistanceRequestController::approve/$1');
    $routes->post('(:num)/reject', 'AssistanceRequestController::reject/$1');
});

// ============================================================================
// TECHNICIAN GROUP MANAGEMENT
// ============================================================================
$routes->group('technician-groups', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    $routes->get('/', 'TechnicianGroupController::index');
    $routes->get('(:num)', 'TechnicianGroupController::show/$1');
    $routes->post('/', 'TechnicianGroupController::create');
    $routes->put('(:num)', 'TechnicianGroupController::update/$1');
    $routes->post('(:num)/members', 'TechnicianGroupController::addMember/$1');
    $routes->delete('(:num)/members/(:num)', 'TechnicianGroupController::removeMember/$1/$2');
});

// ============================================================================
// ANALYTICS & REPORTING
// ============================================================================
$routes->group('analytics', ['namespace' => 'App\\Controllers\\Api\\V1'], function($routes) {
    // Performance Metrics
    $routes->get('performance', 'WorkOrderAnalyticsController::performance');
    $routes->get('dashboard-kpis', 'WorkOrderAnalyticsController::dashboardKPIs');
    
    // Productivity Reports
    $routes->get('technician-productivity', 'WorkOrderAnalyticsController::technicianProductivity');
    
    // Material Reports
    $routes->get('material-consumption', 'WorkOrderAnalyticsController::materialConsumption');
    
    // Failure Analysis
    $routes->get('failure-analysis', 'WorkOrderAnalyticsController::failureAnalysis');
});

// ============================================================================
// ENHANCED WORK ORDER OPERATIONS (Using Service Layer)
// ============================================================================
$routes->post('work-orders/create-with-team', 'WorkOrdersController::createWithTeam');
$routes->post('work-orders/(:num)/complete-full', 'WorkOrdersController::completeFull/$1');
$routes->get('work-orders/(:num)/details', 'WorkOrdersController::getFullDetails/$1');
