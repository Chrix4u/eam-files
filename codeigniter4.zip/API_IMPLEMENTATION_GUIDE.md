# Factory Manager - REST API Implementation Guide

## ✅ COMPLETED STRUCTURE

### Folders Created
```
app/
├── Controllers/Api/V1/
│   ├── BaseApiController.php ✅
│   ├── AuthController.php ✅
│   ├── AssetsController.php ✅
│   └── WorkOrdersController.php ✅
├── Services/
│   ├── AuthService.php ✅
│   ├── AssetService.php ✅
│   └── WorkOrderService.php ✅
├── Repositories/
│   ├── UserRepository.php ✅
│   ├── AssetRepository.php ✅
│   └── WorkOrderRepository.php ✅
├── Filters/
│   ├── JWTAuthFilter.php ✅
│   └── CorsFilter.php ✅
├── Libraries/JWT/
│   └── JWTHandler.php ✅
├── Traits/
│   └── ApiResponseTrait.php ✅
└── Config/
    └── RoutesApi.php ✅
```

## 📋 REMAINING CONTROLLERS TO CREATE

### 1. AssetHierarchyController
```php
<?php
namespace App\Controllers\Api\V1;

class AssetHierarchyController extends BaseApiController
{
    public function getEquipment() { }
    public function getAssemblies($equipmentId) { }
    public function getParts($assemblyId) { }
    public function createAssembly($equipmentId) { }
    public function createPart($assemblyId) { }
}
```

### 2. PreventiveMaintenanceController
```php
<?php
namespace App\Controllers\Api\V1;

class PreventiveMaintenanceController extends BaseApiController
{
    public function index() { }
    public function show($id) { }
    public function create() { }
    public function update($id) { }
    public function delete($id) { }
    public function getTasks() { }
    public function generateWorkOrders() { }
}
```

### 3. InventoryController
```php
<?php
namespace App\Controllers\Api\V1;

class InventoryController extends BaseApiController
{
    public function index() { }
    public function show($id) { }
    public function create() { }
    public function update($id) { }
    public function updateStock($id) { }
    public function getLowStock() { }
}
```

### 4. ProductionController
```php
<?php
namespace App\Controllers\Api\V1;

class ProductionController extends BaseApiController
{
    public function index() { }
    public function create() { }
    public function getReports() { }
    public function getPerformance($equipmentId) { }
}
```

### 5. NotificationsController
```php
<?php
namespace App\Controllers\Api\V1;

class NotificationsController extends BaseApiController
{
    public function index() { }
    public function markAsRead($id) { }
    public function delete($id) { }
    public function getUnreadCount() { }
}
```

### 6. UsersController
```php
<?php
namespace App\Controllers\Api\V1;

class UsersController extends BaseApiController
{
    public function index() { }
    public function show($id) { }
    public function create() { }
    public function update($id) { }
    public function delete($id) { }
    public function getRoles() { }
    public function createRole() { }
}
```

## 🔧 INSTALLATION STEPS

### 1. Install JWT Library
```bash
composer require firebase/php-jwt
```

### 2. Update Filters Configuration
Edit `app/Config/Filters.php`:
```php
public $aliases = [
    // ... existing filters
    'jwtauth' => \App\Filters\JWTAuthFilter::class,
    'cors' => \App\Filters\CorsFilter::class,
];
```

### 3. Add JWT Secret to Environment
Edit `.env` file:
```env
JWT_SECRET_KEY=your-256-bit-secret-key-here-change-in-production
```

### 4. Include API Routes
Edit `app/Config/Routes.php` and add at the end:
```php
// Include API routes
require APPPATH . 'Config/RoutesApi.php';
```

### 5. Update Database Config
Ensure `app/Config/Database.php` uses environment variables:
```php
'hostname' => getenv('database.default.hostname') ?: 'localhost',
'username' => getenv('database.default.username') ?: 'root',
'password' => getenv('database.default.password') ?: '',
'database' => getenv('database.default.database') ?: 'factory_manager',
```

## 📡 API ENDPOINTS

### Authentication
```
POST   /api/v1/auth/login
POST   /api/v1/auth/register
POST   /api/v1/auth/refresh
GET    /api/v1/auth/me
POST   /api/v1/auth/logout
```

### Assets
```
GET    /api/v1/assets?page=1&per_page=20&search=pump&sort_by=id&sort_order=DESC
GET    /api/v1/assets/{id}
POST   /api/v1/assets
PUT    /api/v1/assets/{id}
DELETE /api/v1/assets/{id}
GET    /api/v1/assets/{id}/maintenance-history
```

### Asset Hierarchy
```
GET    /api/v1/equipment
GET    /api/v1/equipment/{id}/assemblies
GET    /api/v1/assemblies/{id}/parts
POST   /api/v1/equipment/{id}/assemblies
POST   /api/v1/assemblies/{id}/parts
```

### Preventive Maintenance
```
GET    /api/v1/pm/schedules
POST   /api/v1/pm/schedules
GET    /api/v1/pm/schedules/{id}
PUT    /api/v1/pm/schedules/{id}
DELETE /api/v1/pm/schedules/{id}
GET    /api/v1/pm/tasks
POST   /api/v1/pm/generate-work-orders
```

### Work Orders
```
GET    /api/v1/work-orders?status=pending&priority=high
POST   /api/v1/work-orders
GET    /api/v1/work-orders/{id}
PUT    /api/v1/work-orders/{id}
PATCH  /api/v1/work-orders/{id}/status
POST   /api/v1/work-orders/{id}/complete
```

### Inventory
```
GET    /api/v1/inventory/parts
GET    /api/v1/inventory/parts/{id}
POST   /api/v1/inventory/parts
PUT    /api/v1/inventory/parts/{id}
PATCH  /api/v1/inventory/parts/{id}/stock
GET    /api/v1/inventory/low-stock
```

### Production
```
GET    /api/v1/production/surveys
POST   /api/v1/production/surveys
GET    /api/v1/production/reports
GET    /api/v1/production/equipment/{id}/performance
```

### Notifications
```
GET    /api/v1/notifications
PATCH  /api/v1/notifications/{id}/read
DELETE /api/v1/notifications/{id}
GET    /api/v1/notifications/unread-count
```

### Users & Roles
```
GET    /api/v1/users
GET    /api/v1/users/{id}
POST   /api/v1/users
PUT    /api/v1/users/{id}
DELETE /api/v1/users/{id}
GET    /api/v1/roles
POST   /api/v1/roles
```

## 🔐 AUTHENTICATION FLOW

### 1. Login Request
```bash
curl -X POST http://localhost/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123"
  }'
```

### 2. Login Response
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "username": "admin",
      "email": "admin@example.com",
      "role": "admin"
    },
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "token_type": "Bearer"
  }
}
```

### 3. Authenticated Request
```bash
curl -X GET http://localhost/api/v1/assets \
  -H "Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGc..."
```

## 📊 RESPONSE FORMATS

### Success Response
```json
{
  "success": true,
  "message": "Operation successful",
  "data": { },
  "meta": { }
}
```

### Paginated Response
```json
{
  "success": true,
  "message": "Success",
  "data": [ ],
  "meta": {
    "pagination": {
      "current_page": 1,
      "per_page": 20,
      "total": 100,
      "total_pages": 5,
      "from": 1,
      "to": 20
    }
  }
}
```

### Error Response
```json
{
  "success": false,
  "message": "Error message",
  "errors": {
    "field": ["Validation error"]
  },
  "code": 400
}
```

### Validation Error Response
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": {
    "equipment_name": ["The equipment_name field is required."],
    "equipment_code": ["The equipment_code field must be unique."]
  },
  "code": 422
}
```

## 🧪 TESTING WITH POSTMAN

### 1. Create Environment
- Variable: `base_url` = `http://localhost/api/v1`
- Variable: `token` = (will be set after login)

### 2. Login Request
```
POST {{base_url}}/auth/login
Body: {
  "username": "admin",
  "password": "password"
}
```

### 3. Set Token in Tests Tab
```javascript
pm.test("Login successful", function () {
    var jsonData = pm.response.json();
    pm.environment.set("token", jsonData.data.access_token);
});
```

### 4. Use Token in Requests
```
GET {{base_url}}/assets
Headers:
  Authorization: Bearer {{token}}
```

## 🚀 NEXT STEPS

1. ✅ Install firebase/php-jwt: `composer require firebase/php-jwt`
2. ✅ Update Filters.php configuration
3. ✅ Create .env file with JWT_SECRET_KEY
4. ✅ Include RoutesApi.php in main Routes.php
5. ⏳ Create remaining controllers (AssetHierarchy, PM, Inventory, Production, Notifications, Users)
6. ⏳ Create corresponding services for each module
7. ⏳ Create corresponding repositories for each module
8. ⏳ Remove old view files from app/Views/
9. ⏳ Test all endpoints with Postman
10. ⏳ Write API documentation
11. ⏳ Add rate limiting
12. ⏳ Add API versioning strategy
13. ⏳ Implement token blacklist for logout
14. ⏳ Add comprehensive error handling
15. ⏳ Write unit tests for all endpoints

## 📝 MIGRATION CHECKLIST

### Phase 1: Core Infrastructure (COMPLETED ✅)
- [x] Create folder structure
- [x] Implement JWT authentication
- [x] Create base API controller
- [x] Implement API response trait
- [x] Create CORS filter
- [x] Set up API routes

### Phase 2: Core Modules (IN PROGRESS ⏳)
- [x] Auth module (login, register, refresh)
- [x] Assets module (CRUD + maintenance history)
- [x] Work Orders module (CRUD + status updates)
- [ ] Asset Hierarchy module
- [ ] Preventive Maintenance module
- [ ] Inventory module
- [ ] Production module
- [ ] Notifications module
- [ ] Users & Roles module

### Phase 3: Remove UI (PENDING ⏳)
- [ ] Archive app/Views/backend/
- [ ] Remove view-related routes
- [ ] Remove old controllers (non-API)
- [ ] Update documentation

### Phase 4: Testing & Documentation (PENDING ⏳)
- [ ] Write unit tests
- [ ] Create Postman collection
- [ ] Write API documentation
- [ ] Performance testing
- [ ] Security audit

## 🎯 ARCHITECTURE BENEFITS

### Controller → Service → Repository Pattern

**Controllers:**
- Handle HTTP requests/responses
- Validate input
- Return JSON responses
- Thin layer, no business logic

**Services:**
- Business logic layer
- Orchestrate multiple repositories
- Handle transactions
- Reusable across controllers

**Repositories:**
- Data access layer
- Database queries
- Model interactions
- Single responsibility

### Benefits:
✅ Separation of concerns
✅ Testable code
✅ Reusable components
✅ Easy to maintain
✅ Scalable architecture
✅ Clear dependencies

## 📚 ADDITIONAL RESOURCES

- CodeIgniter 4 Docs: https://codeigniter.com/user_guide/
- JWT.io: https://jwt.io/
- REST API Best Practices: https://restfulapi.net/
- Postman: https://www.postman.com/

---

**Status:** Core infrastructure complete. Ready for remaining module implementation.
**Estimated Time to Complete:** 2-3 weeks for all modules + testing
