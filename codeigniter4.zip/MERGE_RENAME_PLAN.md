# 🔧 Controller Merge & Rename - Complete Plan

**Strategy**: Merge → Delete → Rename File → Update Class Name → Update Routes

---

## 📋 Step-by-Step Process

### For Each Duplicate Pair:

1. **Compare**: Read both files, compare methods
2. **Merge**: Copy unique methods to Eam version
3. **Delete**: Remove non-Eam version
4. **Rename**: Remove "Eam" prefix from filename
5. **Update Class**: Change class name inside file
6. **Update Routes**: Ensure routes use correct name
7. **Test**: Verify endpoint works

---

## 🎯 Execution Order

### 1. Core/AuthController ✅ DONE
- ✅ Merged (identical)
- ✅ Deleted EamAuthController.php
- ✅ Kept AuthController.php with correct class name
- ✅ Routes already correct

### 2. Core/RolesController
**Current State**:
- RolesController.php (class: EamRolesController ❌)
- EamRolesController.php (class: EamRolesController)

**Actions**:
1. Compare methods (IDENTICAL confirmed)
2. Delete RolesController.php (wrong class name)
3. Rename EamRolesController.php → RolesController.php
4. Update class name: EamRolesController → RolesController
5. Routes already use RolesController ✅

### 3. ASSET/AssembliesController
**Actions**:
1. Compare AssembliesController.php vs EamAssembliesController.php
2. Merge unique methods into EamAssembliesController.php
3. Delete AssembliesController.php
4. Rename EamAssembliesController.php → AssembliesController.php
5. Update class: EamAssembliesController → AssembliesController
6. Update routes if needed

### 4. ASSET/EquipmentController
**Actions**:
1. Check if both exist
2. Compare methods
3. Merge into EamEquipmentController.php
4. Delete EquipmentController.php (if exists)
5. Rename EamEquipmentController.php → EquipmentController.php
6. Update class: EamEquipmentController → EquipmentController
7. Update routes if needed

### 5. ASSET/FacilitiesController ✅ ALREADY DONE
- Already using FacilitiesController with RBAC

### 6. HRMS/UsersController
**Actions**:
1. Check if UsersController.php exists
2. Compare with EamUsersController.php
3. Merge into EamUsersController.php
4. Delete UsersController.php (if exists)
5. Rename EamUsersController.php → UsersController.php
6. Update class: EamUsersController → UsersController
7. Update routes if needed

### 7. IMS/InventoryController ✅ ALREADY DONE
- Already using EamInventoryController with RBAC
- Routes updated

### 8. IMS/PartsController
**Actions**:
1. Compare PartsController.php vs EamPartsController.php
2. Merge into EamPartsController.php
3. Delete PartsController.php
4. Rename EamPartsController.php → PartsController.php
5. Update class: EamPartsController → PartsController
6. Update routes if needed

### 9. MRMP/PmController
**Actions**:
1. Compare PmController.php vs EamPmController.php
2. Merge into EamPmController.php
3. Delete PmController.php
4. Rename EamPmController.php → PmController.php
5. Update class: EamPmController → PmController
6. Update routes if needed

### 10. RWOP/WorkOrdersController
**Actions**:
1. Compare WorkOrdersController.php vs EamWorkOrdersController.php
2. Merge into EamWorkOrdersController.php
3. Delete WorkOrdersController.php
4. Rename EamWorkOrdersController.php → WorkOrdersController.php
5. Update class: EamWorkOrdersController → WorkOrdersController
6. Update routes if needed

---

## 🔍 Comparison Commands

```bash
# List methods in both files
findstr /n "public function" Controller.php
findstr /n "public function" EamController.php

# Compare files
fc Controller.php EamController.php
```

---

## ✏️ Rename Template

```bash
# Step 1: Delete old file
del Controller.php

# Step 2: Rename Eam file
ren EamController.php Controller.php

# Step 3: Update class name inside file (manual edit)
# Change: class EamController
# To: class Controller
```

---

## 📊 Progress Tracker

| Module | Controller | Compared | Merged | Deleted | Renamed | Class Updated | Routes Updated | Tested |
|--------|-----------|----------|--------|---------|---------|---------------|----------------|--------|
| Core | AuthController | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ⏳ |
| Core | RolesController | ✅ | ✅ | ⏳ | ⏳ | ⏳ | ✅ | ⏳ |
| ASSET | AssembliesController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| ASSET | EquipmentController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| ASSET | FacilitiesController | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| HRMS | UsersController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| IMS | InventoryController | ✅ | ✅ | ✅ | N/A | N/A | ✅ | ✅ |
| IMS | PartsController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| MRMP | PmController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |
| RWOP | WorkOrdersController | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ | ⏳ |

---

**Status**: 🟢 READY TO EXECUTE  
**Next**: Start with RolesController

