<?php
$host = 'localhost';
$dbname = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$db = new mysqli($host, $user, $pass, $dbname);

$tables = ['facilities', 'systems', 'assets', 'machines'];

foreach ($tables as $table) {
    echo "\n{$table} table structure:\n";
    echo str_repeat("=", 60) . "\n";
    $result = $db->query("DESCRIBE {$table}");
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . "\n";
    }
}

$db->close();
