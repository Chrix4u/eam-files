<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');
if (!$db) die('Connection failed: ' . mysqli_connect_error());

$result = mysqli_query($db, "DESCRIBE departments");
echo "Departments table structure:\n";
while ($row = mysqli_fetch_assoc($result)) {
    echo $row['Field'] . " | " . $row['Type'] . "\n";
}

mysqli_close($db);
