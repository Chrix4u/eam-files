<?php
$host = 'localhost';
$username = 'root';
$password = 'myjesus4mE';
$database = 'factory_manager_test';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create meters table
    $pdo->exec("CREATE TABLE IF NOT EXISTS meters (
        id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        asset_node_type VARCHAR(50) NOT NULL,
        asset_node_id INT(11) UNSIGNED NOT NULL,
        meter_type VARCHAR(50) NOT NULL,
        unit VARCHAR(20) NOT NULL,
        value DECIMAL(10,2) DEFAULT 0,
        last_read_at DATETIME NULL,
        created_by INT(11) UNSIGNED NULL,
        updated_by INT(11) UNSIGNED NULL,
        version INT(11) DEFAULT 1,
        created_at DATETIME NULL,
        updated_at DATETIME NULL,
        deleted_at DATETIME NULL,
        PRIMARY KEY (id)
    )");
    
    // Create meter_readings table
    $pdo->exec("CREATE TABLE IF NOT EXISTS meter_readings (
        id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        meter_id INT(11) UNSIGNED NOT NULL,
        value DECIMAL(10,2) NOT NULL,
        reading_at DATETIME NOT NULL,
        recorded_by INT(11) UNSIGNED NULL,
        created_at DATETIME NULL,
        PRIMARY KEY (id)
    )");
    
    // Create meter_update_queue table
    $pdo->exec("CREATE TABLE IF NOT EXISTS meter_update_queue (
        id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        meter_id INT(11) UNSIGNED NOT NULL,
        payload TEXT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        last_error TEXT NULL,
        attempts INT(11) DEFAULT 0,
        created_at DATETIME NULL,
        updated_at DATETIME NULL,
        PRIMARY KEY (id)
    )");
    
    echo "Meter tables created successfully\n";
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>