<?php

// Check what work order tables exist
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔍 Checking Work Order Tables\n";
    echo "=============================\n\n";
    
    // Check what tables exist with 'work' in the name
    $stmt = $pdo->query("SHOW TABLES LIKE '%work%'");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "Tables with 'work' in name:\n";
    foreach ($tables as $table) {
        echo "  - $table\n";
    }
    
    // Check for any order-related tables
    $stmt = $pdo->query("SHOW TABLES LIKE '%order%'");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "\nTables with 'order' in name:\n";
    foreach ($tables as $table) {
        echo "  - $table\n";
    }
    
    // Check all tables
    $stmt = $pdo->query("SHOW TABLES");
    $allTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "\nAll tables in database:\n";
    foreach ($allTables as $table) {
        echo "  - $table\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}