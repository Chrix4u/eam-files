<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}

echo "Creating work_order_materials table...\n";

$mysqli->query("CREATE TABLE IF NOT EXISTS work_order_materials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT UNSIGNED NOT NULL,
    date DATE NULL,
    time TIME NULL,
    gt_code VARCHAR(50) NULL,
    description TEXT NULL,
    specification TEXT NULL,
    quantity_issued DECIMAL(10,2) NULL,
    remarks TEXT NULL,
    receiver_signature VARCHAR(255) NULL,
    store_clerk_signature VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

echo "work_order_materials table created!\n";

$mysqli->close();
echo "\nMigration completed!\n";
