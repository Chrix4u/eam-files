<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_comparisons (
    comparison_id INT AUTO_INCREMENT PRIMARY KEY,
    comparison_name VARCHAR(255) NOT NULL,
    survey_ids JSON NOT NULL,
    comparison_type ENUM('side_by_side', 'trend', 'benchmark') NOT NULL,
    metrics JSON NOT NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_comparison_user (created_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$sql = "CREATE TABLE IF NOT EXISTS survey_bi_exports (
    export_id INT AUTO_INCREMENT PRIMARY KEY,
    export_name VARCHAR(255) NOT NULL,
    bi_system VARCHAR(100) NOT NULL,
    query_config JSON NOT NULL,
    schedule_frequency VARCHAR(50),
    last_export_at TIMESTAMP NULL,
    next_export_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_bi_active (is_active),
    INDEX idx_next_export (next_export_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

echo "✅ Comparison & BI tables created\n";
$db->close();
