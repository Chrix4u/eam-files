<?php

$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Creating RCA Module Tables...\n\n";

// 1. Failure Modes
echo "1. Creating failure_modes table...\n";
$conn->query("DROP TABLE IF EXISTS failure_modes");
$sql = "CREATE TABLE failure_modes (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    failure_code VARCHAR(50) UNIQUE,
    failure_name VARCHAR(255),
    description TEXT,
    category ENUM('Mechanical', 'Electrical', 'Hydraulic', 'Pneumatic', 'Control', 'Structural', 'Other'),
    severity ENUM('Critical', 'High', 'Medium', 'Low') DEFAULT 'Medium',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at DATETIME,
    updated_at DATETIME,
    INDEX(category)
)";
$conn->query($sql);
echo "   ✅ Created\n\n";

// 2. Failure Reports
echo "2. Creating failure_reports table...\n";
$conn->query("DROP TABLE IF EXISTS failure_reports");
$sql = "CREATE TABLE failure_reports (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    report_number VARCHAR(100) UNIQUE,
    asset_id INT(11) UNSIGNED,
    work_order_id INT(11) UNSIGNED,
    failure_mode_id INT(11) UNSIGNED,
    failure_date DATETIME,
    detection_method ENUM('Inspection', 'Monitoring', 'Operator Report', 'Breakdown', 'Other'),
    downtime_hours DECIMAL(10,2) DEFAULT 0,
    failure_description TEXT,
    immediate_action TEXT,
    cost_impact DECIMAL(15,2) DEFAULT 0,
    safety_impact ENUM('None', 'Minor', 'Moderate', 'Severe') DEFAULT 'None',
    reported_by INT(11) UNSIGNED,
    status ENUM('Open', 'Under Investigation', 'RCA Complete', 'CAPA In Progress', 'Closed') DEFAULT 'Open',
    created_at DATETIME,
    updated_at DATETIME,
    INDEX(asset_id),
    INDEX(failure_mode_id),
    INDEX(status)
)";
$conn->query($sql);
echo "   ✅ Created\n\n";

// 3. Root Cause Analysis
echo "3. Creating root_cause_analysis table...\n";
$conn->query("DROP TABLE IF EXISTS root_cause_analysis");
$sql = "CREATE TABLE root_cause_analysis (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    failure_report_id INT(11) UNSIGNED,
    analysis_method ENUM('5 Whys', 'Fishbone', 'Fault Tree', 'FMEA', 'Other'),
    root_cause_category ENUM('Human Error', 'Equipment', 'Process', 'Material', 'Environment', 'Design', 'Maintenance'),
    root_cause_description TEXT,
    contributing_factors TEXT,
    analysis_data JSON,
    analyzed_by INT(11) UNSIGNED,
    analysis_date DATETIME,
    verified_by INT(11) UNSIGNED,
    verification_date DATETIME,
    created_at DATETIME,
    updated_at DATETIME,
    INDEX(failure_report_id)
)";
$conn->query($sql);
echo "   ✅ Created\n\n";

// 4. Corrective Actions
echo "4. Creating corrective_actions table...\n";
$conn->query("DROP TABLE IF EXISTS corrective_actions");
$sql = "CREATE TABLE corrective_actions (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    failure_report_id INT(11) UNSIGNED,
    action_type ENUM('Corrective', 'Preventive') DEFAULT 'Corrective',
    action_description TEXT,
    action_category ENUM('Repair', 'Replace', 'Modify', 'Training', 'Procedure Change', 'Design Change', 'Other'),
    assigned_to INT(11) UNSIGNED,
    priority ENUM('Critical', 'High', 'Medium', 'Low') DEFAULT 'Medium',
    due_date DATE,
    completion_date DATE,
    status ENUM('Planned', 'In Progress', 'Completed', 'Verified', 'Cancelled') DEFAULT 'Planned',
    cost_estimate DECIMAL(15,2) DEFAULT 0,
    actual_cost DECIMAL(15,2),
    effectiveness_rating INT(1),
    notes TEXT,
    created_at DATETIME,
    updated_at DATETIME,
    INDEX(failure_report_id),
    INDEX(assigned_to),
    INDEX(status)
)";
$conn->query($sql);
echo "   ✅ Created\n\n";

// 5. Failure Attachments
echo "5. Creating failure_attachments table...\n";
$conn->query("DROP TABLE IF EXISTS failure_attachments");
$sql = "CREATE TABLE failure_attachments (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    failure_report_id INT(11) UNSIGNED,
    file_name VARCHAR(255),
    file_path VARCHAR(500),
    file_type VARCHAR(50),
    file_size INT(11),
    description VARCHAR(255),
    uploaded_by INT(11) UNSIGNED,
    created_at DATETIME,
    INDEX(failure_report_id)
)";
$conn->query($sql);
echo "   ✅ Created\n\n";

// 6. Statistics View
echo "6. Creating vw_failure_statistics view...\n";
$conn->query("DROP VIEW IF EXISTS vw_failure_statistics");
$sql = "CREATE VIEW vw_failure_statistics AS
SELECT 
    a.id as asset_id,
    a.asset_name,
    COUNT(fr.id) as total_failures,
    SUM(fr.downtime_hours) as total_downtime,
    SUM(fr.cost_impact) as total_cost,
    AVG(fr.downtime_hours) as avg_downtime,
    MAX(fr.failure_date) as last_failure_date
FROM assets_unified a
LEFT JOIN failure_reports fr ON a.id = fr.asset_id
GROUP BY a.id";
$conn->query($sql);
echo "   ✅ Created\n\n";

echo "✅ RCA Module tables created successfully!\n";

$conn->close();
