@echo off
echo Fixing SLA Definitions Table...
c:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager < fix_sla.sql
if %errorlevel% equ 0 (
    echo SUCCESS: SLA table fixed!
) else (
    echo ERROR: Failed to fix SLA table!
)
pause
