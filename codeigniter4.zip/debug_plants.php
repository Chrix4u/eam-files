<?php
// Simple DB check - Access via: http://localhost/factorymanager/debug_plants.php

$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h2>Admin User Plant Assignments</h2>";
    
    // Check admin user
    $stmt = $pdo->query("SELECT id, username FROM users WHERE username = 'admin'");
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        echo "<p style='color:red'>ERROR: Admin user not found!</p>";
        exit;
    }
    
    echo "<p>Admin User ID: {$admin['id']}</p>";
    
    // Check plant assignments
    $stmt = $pdo->prepare("
        SELECT up.*, p.plant_name 
        FROM user_plants up 
        JOIN plants p ON p.id = up.plant_id 
        WHERE up.user_id = ?
    ");
    $stmt->execute([$admin['id']]);
    $plants = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($plants)) {
        echo "<p style='color:red'><strong>PROBLEM FOUND: Admin not assigned to any plants!</strong></p>";
        echo "<p>Run this SQL to fix:</p>";
        echo "<pre>INSERT INTO user_plants (user_id, plant_id, is_primary) VALUES ({$admin['id']}, 1, 1);</pre>";
    } else {
        echo "<p style='color:green'>Admin is assigned to " . count($plants) . " plant(s):</p>";
        echo "<ul>";
        foreach ($plants as $p) {
            echo "<li>Plant ID: {$p['plant_id']}, Name: {$p['plant_name']}, Primary: " . ($p['is_primary'] ? 'Yes' : 'No') . "</li>";
        }
        echo "</ul>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color:red'>Database Error: " . $e->getMessage() . "</p>";
}
