<?php
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS skills (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category ENUM('mechanical','electrical','hydraulic','pneumatic','plc','welding','quality','safety','other') NOT NULL,
    description TEXT,
    required_for_role VARCHAR(50),
    is_active TINYINT(1) DEFAULT 1,
    created_at DATETIME
)";
$db->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS user_skills (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    skill_id INT UNSIGNED NOT NULL,
    proficiency_level TINYINT CHECK(proficiency_level BETWEEN 1 AND 5),
    certified TINYINT(1) DEFAULT 0,
    certification_date DATE,
    expiry_date DATE,
    last_assessed DATE,
    assessor_id INT UNSIGNED,
    notes TEXT,
    created_at DATETIME,
    updated_at DATETIME,
    UNIQUE KEY unique_user_skill (user_id, skill_id),
    INDEX idx_user (user_id),
    INDEX idx_skill (skill_id)
)";
$db->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS training_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    skill_id INT UNSIGNED,
    training_name VARCHAR(255) NOT NULL,
    training_date DATE NOT NULL,
    duration_hours DECIMAL(5,2),
    trainer VARCHAR(100),
    status ENUM('scheduled','completed','cancelled') DEFAULT 'scheduled',
    proficiency_level TINYINT,
    certified TINYINT(1) DEFAULT 0,
    cost DECIMAL(10,2),
    notes TEXT,
    created_at DATETIME,
    INDEX idx_user (user_id)
)";
$db->query($sql);

$skills = [
    ['Mechanical Troubleshooting', 'mechanical', 'Diagnose and repair mechanical issues'],
    ['Electrical Systems', 'electrical', 'Work with electrical circuits and components'],
    ['PLC Programming', 'plc', 'Program and troubleshoot PLCs'],
    ['Hydraulic Systems', 'hydraulic', 'Maintain hydraulic equipment'],
    ['Pneumatic Systems', 'pneumatic', 'Maintain pneumatic equipment'],
    ['Welding', 'welding', 'MIG/TIG welding skills'],
    ['Quality Inspection', 'quality', 'Perform quality checks'],
    ['Safety Procedures', 'safety', 'Follow safety protocols'],
];

$stmt = $db->prepare("INSERT IGNORE INTO skills (name, category, description, created_at) VALUES (?, ?, ?, NOW())");
foreach ($skills as $s) {
    $stmt->bind_param('sss', $s[0], $s[1], $s[2]);
    $stmt->execute();
}

echo "Skills Matrix tables created successfully!\n";
$db->close();
