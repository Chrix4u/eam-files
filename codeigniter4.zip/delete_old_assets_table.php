<?php
$conn = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

echo "=== DELETING OLD ASSETS TABLE ===\n\n";

// Drop the deprecated table
if ($conn->query("DROP TABLE IF EXISTS assets_deprecated")) {
    echo "✓ Deleted: assets_deprecated\n";
} else {
    echo "✗ Failed: " . $conn->error . "\n";
}

// Also drop old facilities and systems tables (already migrated)
if ($conn->query("DROP TABLE IF EXISTS facilities")) {
    echo "✓ Deleted: facilities (migrated to assets_unified)\n";
} else {
    echo "✗ Failed: " . $conn->error . "\n";
}

if ($conn->query("DROP TABLE IF EXISTS systems")) {
    echo "✓ Deleted: systems (migrated to assets_unified)\n";
} else {
    echo "✗ Failed: " . $conn->error . "\n";
}

echo "\n=== CLEANUP COMPLETE ===\n";
echo "Active tables:\n";
echo "  - assets_unified (156 records) - PRIMARY\n";
echo "  - machines (2 records) - Detailed machine data\n";
echo "  - asset_closure - Hierarchy relationships\n\n";

$conn->close();
?>
