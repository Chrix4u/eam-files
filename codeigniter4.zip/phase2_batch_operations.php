<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_batch_operations (
    batch_id INT AUTO_INCREMENT PRIMARY KEY,
    operation_type ENUM('approve', 'reject', 'export', 'update', 'delete') NOT NULL,
    survey_ids JSON NOT NULL,
    parameters JSON,
    initiated_by INT NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed') DEFAULT 'pending',
    total_count INT NOT NULL,
    processed_count INT DEFAULT 0,
    success_count INT DEFAULT 0,
    failed_count INT DEFAULT 0,
    error_log JSON,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_batch_status (status),
    INDEX idx_batch_user (initiated_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

echo "✅ Batch Operations table created\n";
$db->close();
