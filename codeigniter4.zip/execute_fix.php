<?php
$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die('Connection failed: ' . $db->connect_error);
}

echo "=== EXECUTING ENTERPRISE FIX ===" . PHP_EOL . PHP_EOL;

// Step 1: Fix collation
echo "Step 1: Fixing collation..." . PHP_EOL;
$db->query("ALTER TABLE parts MODIFY part_number VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci");
$db->query("ALTER TABLE parts MODIFY part_code VARCHAR(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci");
echo "✓ Collation fixed" . PHP_EOL . PHP_EOL;

// Step 2: Create part_inventory_links
echo "Step 2: Creating part_inventory_links table..." . PHP_EOL;
$sql = "CREATE TABLE IF NOT EXISTS part_inventory_links (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    part_id INT NOT NULL,
    inventory_item_id INT UNSIGNED NOT NULL,
    quantity_per_unit DECIMAL(10,3) DEFAULT 1.000,
    is_primary BOOLEAN DEFAULT TRUE,
    substitute_priority INT DEFAULT 0,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE CASCADE,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    UNIQUE KEY unique_part_inventory (part_id, inventory_item_id),
    INDEX idx_part_id (part_id),
    INDEX idx_inventory_item_id (inventory_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci";
$db->query($sql);
echo "✓ Table created" . PHP_EOL . PHP_EOL;

// Step 3: Enhance asset_spare_parts
echo "Step 3: Enhancing asset_spare_parts..." . PHP_EOL;
$columns = ['part_id', 'criticality', 'notes', 'updated_at'];
foreach($columns as $col) {
    $result = $db->query("SHOW COLUMNS FROM asset_spare_parts LIKE '$col'");
    if($result->num_rows == 0) {
        if($col == 'part_id') $db->query("ALTER TABLE asset_spare_parts ADD COLUMN part_id INT NULL AFTER inventory_item_id");
        if($col == 'criticality') $db->query("ALTER TABLE asset_spare_parts ADD COLUMN criticality ENUM('critical','high','medium','low') DEFAULT 'medium' AFTER quantity_required");
        if($col == 'notes') $db->query("ALTER TABLE asset_spare_parts ADD COLUMN notes TEXT");
        if($col == 'updated_at') $db->query("ALTER TABLE asset_spare_parts ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
    }
}
echo "✓ Columns added" . PHP_EOL . PHP_EOL;

// Step 4: Enhance work_order_materials
echo "Step 4: Enhancing work_order_materials..." . PHP_EOL;
$columns = ['part_id', 'unit_cost', 'notes'];
foreach($columns as $col) {
    $result = $db->query("SHOW COLUMNS FROM work_order_materials LIKE '$col'");
    if($result->num_rows == 0) {
        if($col == 'part_id') $db->query("ALTER TABLE work_order_materials ADD COLUMN part_id INT NULL AFTER inventory_item_id");
        if($col == 'unit_cost') $db->query("ALTER TABLE work_order_materials ADD COLUMN unit_cost DECIMAL(10,2) DEFAULT 0 AFTER quantity_issued");
        if($col == 'notes') $db->query("ALTER TABLE work_order_materials ADD COLUMN notes TEXT");
    }
}
echo "✓ Columns added" . PHP_EOL . PHP_EOL;

// Step 5: Enhance inventory_items
echo "Step 5: Enhancing inventory_items..." . PHP_EOL;
$columns = ['quantity_reserved', 'min_stock_level', 'max_stock_level', 'abc_classification'];
foreach($columns as $col) {
    $result = $db->query("SHOW COLUMNS FROM inventory_items LIKE '$col'");
    if($result->num_rows == 0) {
        if($col == 'quantity_reserved') $db->query("ALTER TABLE inventory_items ADD COLUMN quantity_reserved DECIMAL(15,2) DEFAULT 0");
        if($col == 'min_stock_level') $db->query("ALTER TABLE inventory_items ADD COLUMN min_stock_level DECIMAL(15,2) DEFAULT 0");
        if($col == 'max_stock_level') $db->query("ALTER TABLE inventory_items ADD COLUMN max_stock_level DECIMAL(15,2) DEFAULT 0");
        if($col == 'abc_classification') $db->query("ALTER TABLE inventory_items ADD COLUMN abc_classification ENUM('A','B','C') DEFAULT 'C'");
    }
}
echo "✓ Columns added" . PHP_EOL . PHP_EOL;

// Step 6: Create pm_task_materials
echo "Step 6: Creating pm_task_materials..." . PHP_EOL;
$sql = "CREATE TABLE IF NOT EXISTS pm_task_materials (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    pm_task_id INT NOT NULL,
    part_id INT NULL,
    inventory_item_id INT UNSIGNED NOT NULL,
    planned_quantity DECIMAL(10,3) NOT NULL DEFAULT 1.000,
    is_critical BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (part_id) REFERENCES parts(id) ON DELETE SET NULL,
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE RESTRICT,
    INDEX idx_pm_task (pm_task_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci";
$db->query($sql);
echo "✓ Table created" . PHP_EOL . PHP_EOL;

// Step 7: Create inventory_reservations
echo "Step 7: Creating inventory_reservations..." . PHP_EOL;
$sql = "CREATE TABLE IF NOT EXISTS inventory_reservations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    inventory_item_id INT UNSIGNED NOT NULL,
    work_order_id INT UNSIGNED NULL,
    reserved_quantity DECIMAL(10,3) NOT NULL,
    reserved_by INT UNSIGNED NOT NULL,
    reserved_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active','consumed','cancelled') DEFAULT 'active',
    FOREIGN KEY (inventory_item_id) REFERENCES inventory_items(id) ON DELETE CASCADE,
    INDEX idx_inventory (inventory_item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci";
$db->query($sql);
echo "✓ Table created" . PHP_EOL . PHP_EOL;

// Step 8: Populate links
echo "Step 8: Populating part_inventory_links..." . PHP_EOL;
$sql = "INSERT IGNORE INTO part_inventory_links (part_id, inventory_item_id, is_primary)
SELECT p.id, i.id, TRUE
FROM parts p
JOIN inventory_items i ON p.part_number = i.item_code
WHERE p.spare_availability = 'yes'";
$result = $db->query($sql);
echo "✓ Linked " . $db->affected_rows . " parts to inventory" . PHP_EOL . PHP_EOL;

// Step 9: Create views
echo "Step 9: Creating views..." . PHP_EOL;
$db->query("DROP VIEW IF EXISTS vw_parts_inventory_status");
$sql = "CREATE VIEW vw_parts_inventory_status AS
SELECT 
    p.id AS part_id, p.part_name, p.part_number,
    pil.inventory_item_id, ii.item_name, ii.quantity_on_hand,
    ii.quantity_reserved, ii.location,
    CASE 
        WHEN ii.id IS NULL THEN 'NO_INVENTORY'
        WHEN ii.quantity_on_hand - IFNULL(ii.quantity_reserved,0) <= 0 THEN 'OUT_OF_STOCK'
        WHEN ii.quantity_on_hand - IFNULL(ii.quantity_reserved,0) <= ii.reorder_point THEN 'LOW_STOCK'
        ELSE 'IN_STOCK'
    END AS stock_status
FROM parts p
LEFT JOIN part_inventory_links pil ON p.id = pil.part_id AND pil.is_primary = TRUE
LEFT JOIN inventory_items ii ON pil.inventory_item_id = ii.id";
$db->query($sql);
echo "✓ Views created" . PHP_EOL . PHP_EOL;

// Verification
echo "=== VERIFICATION ===" . PHP_EOL;
$result = $db->query("SELECT COUNT(*) as cnt FROM part_inventory_links");
$row = $result->fetch_assoc();
echo "part_inventory_links: " . $row['cnt'] . " records" . PHP_EOL;

$result = $db->query("SELECT COUNT(*) as cnt FROM pm_task_materials");
$row = $result->fetch_assoc();
echo "pm_task_materials: " . $row['cnt'] . " records" . PHP_EOL;

$result = $db->query("SELECT COUNT(*) as cnt FROM inventory_reservations");
$row = $result->fetch_assoc();
echo "inventory_reservations: " . $row['cnt'] . " records" . PHP_EOL;

echo PHP_EOL . "✅ ENTERPRISE INTEGRATION COMPLETE!" . PHP_EOL;

$db->close();
