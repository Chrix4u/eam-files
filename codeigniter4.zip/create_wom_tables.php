<?php

$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Work Order Materials table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS work_order_materials (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            work_order_id INT UNSIGNED NOT NULL,
            inventory_item_id INT UNSIGNED NOT NULL,
            quantity_required DECIMAL(10,2) NOT NULL,
            quantity_reserved DECIMAL(10,2) DEFAULT 0,
            quantity_issued DECIMAL(10,2) DEFAULT 0,
            unit_cost DECIMAL(12,2) DEFAULT 0,
            status ENUM('required', 'reserved', 'issued', 'returned') DEFAULT 'required',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE,
            INDEX idx_wo_materials (work_order_id),
            INDEX idx_inventory_item (inventory_item_id)
        )
    ");

    // Work Order Logs table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS work_order_logs (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            work_order_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED,
            action VARCHAR(50) NOT NULL,
            old_status VARCHAR(50),
            new_status VARCHAR(50),
            notes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE,
            INDEX idx_wo_logs (work_order_id),
            INDEX idx_action (action)
        )
    ");

    // Work Order Attachments table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS work_order_attachments (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            work_order_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED,
            filename VARCHAR(255) NOT NULL,
            original_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(500) NOT NULL,
            file_size INT UNSIGNED,
            mime_type VARCHAR(100),
            thumbnail_path VARCHAR(500),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE,
            INDEX idx_wo_attachments (work_order_id)
        )
    ");

    // Inventory Items table (if not exists)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS inventory_items (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            part_code VARCHAR(50) NOT NULL UNIQUE,
            part_name VARCHAR(255) NOT NULL,
            description TEXT,
            unit_of_measure VARCHAR(20) DEFAULT 'EA',
            unit_cost DECIMAL(12,2) DEFAULT 0,
            quantity_on_hand DECIMAL(10,2) DEFAULT 0,
            quantity_reserved DECIMAL(10,2) DEFAULT 0,
            reorder_point DECIMAL(10,2) DEFAULT 0,
            location VARCHAR(100),
            status ENUM('active', 'inactive', 'discontinued') DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");

    // Add constraints to work_orders table
    $pdo->exec("
        ALTER TABLE work_orders 
        ADD COLUMN IF NOT EXISTS version INT DEFAULT 1,
        ADD COLUMN IF NOT EXISTS sla_breached_at DATETIME NULL,
        ADD COLUMN IF NOT EXISTS total_cost DECIMAL(12,2) DEFAULT 0
    ");

    // Add unique constraint for asset breakdown prevention
    $pdo->exec("
        ALTER TABLE work_orders 
        ADD CONSTRAINT uk_asset_breakdown 
        UNIQUE (asset_id, type, status) 
    ");

    echo "✅ Work Order Management tables created successfully!\n";

} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'Duplicate key name') !== false) {
        echo "⚠️  Some constraints already exist, continuing...\n";
    } else {
        echo "❌ Error: " . $e->getMessage() . "\n";
    }
}