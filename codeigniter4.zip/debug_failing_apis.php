<?php
// Debug failing API endpoints
$baseUrl = "http://localhost/factorymanager/public/api/v1/eam/assets";

$endpoints = [
    '/3d-model/1',
    '/relationship/1',
    '/relationship/graph/1',
];

foreach ($endpoints as $path) {
    echo "Testing: $path\n";
    echo str_repeat("=", 60) . "\n";
    
    $ch = curl_init($baseUrl . $path);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP Code: $httpCode\n";
    echo "Response:\n";
    echo $response . "\n\n";
}
