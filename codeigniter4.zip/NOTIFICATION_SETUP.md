# Notification System Setup

## Database Migration

```bash
php spark migrate
```

## Configuration

### Email (SMTP)
Edit `app/Config/Email.php`:
```php
public string $SMTPHost = 'smtp.gmail.com';
public string $SMTPUser = 'your-email@gmail.com';
public string $SMTPPass = 'your-app-password';
public int $SMTPPort = 587;
```

### SMS (Twilio - Optional)
Add to `.env`:
```
TWILIO_SID=your_account_sid
TWILIO_TOKEN=your_auth_token
TWILIO_FROM=+1234567890
```

Install Twilio SDK:
```bash
composer require twilio/sdk
```

## Start Worker

```bash
# Start notification worker (processes queue)
php spark eam:worker

# Run in background (Windows)
start /B php spark eam:worker

# Run in background (Linux)
nohup php spark eam:worker > worker.log 2>&1 &
```

## Cron Job for Escalations

Add to crontab (runs every hour):
```bash
0 * * * * cd /path/to/factorymanager && php spark eam:escalations
```

Windows Task Scheduler:
```
Program: C:\wamp64\bin\php\php8.x.x\php.exe
Arguments: spark eam:escalations
Start in: C:\wamp64\www\factorymanager
Trigger: Hourly
```

## Usage Examples

### Send Notification
```php
$notificationService = new \App\Services\NotificationService();

// PM due notification
$notificationService->send(
    userId: 5,
    type: 'pm_due',
    data: [
        'schedule_id' => 123,
        'asset_name' => 'Pump A-101',
        'due_date' => '2024-01-20',
    ],
    channels: ['in_app', 'email']
);

// Work order assigned
$notificationService->send(
    userId: 3,
    type: 'wo_assigned',
    data: [
        'wo_number' => 'WO-2024-0001',
        'priority' => 'high',
    ]
);
```

### Escalation Rules

**24 hours overdue:**
- Notify department supervisor
- Channels: in-app + email

**72 hours overdue:**
- Notify manager
- Channels: in-app + email + SMS

## API Endpoints

Add to `app/Config/RoutesEam.php`:

```php
// Notifications
$routes->get('notifications', 'NotificationController::index');
$routes->put('notifications/(:num)/read', 'NotificationController::markAsRead/$1');
$routes->delete('notifications/(:num)', 'NotificationController::delete/$1');
```

## Notification Types

- `pm_due` - PM schedule due soon
- `pm_overdue` - PM schedule overdue
- `wo_assigned` - Work order assigned
- `wo_overdue` - Work order overdue
- `asset_critical` - Asset in critical condition
- `inventory_low` - Inventory below threshold

## Testing

```bash
# Test email configuration
php spark eam:test-email user@example.com

# Test SMS (if configured)
php spark eam:test-sms +1234567890

# Manually trigger escalation check
php spark eam:escalations
```

## Monitoring

Check job status:
```sql
SELECT status, COUNT(*) as count 
FROM notification_jobs 
GROUP BY status;

-- Failed jobs
SELECT * FROM notification_jobs 
WHERE status = 'failed' 
ORDER BY created_at DESC;
```

## Email Templates

Templates are in `NotificationWorker::getEmailTemplate()`. Customize as needed:
- pm_due
- pm_overdue
- wo_assigned
- wo_overdue
