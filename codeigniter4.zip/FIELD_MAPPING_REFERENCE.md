# Field Mapping Reference

## Database Schema vs Frontend Naming

### Core Entities
- **Machine** = **Equipment** (in database context)
- **Assembly** = **Component** (in database context)

### Database Field Names (Source of Truth)
```
machines table:
- id (PK)
- asset_tag
- name

assemblies table:
- id (PK)
- equipment_id (FK -> machines.id)
- assembly_code
- assembly_name

parts table:
- id (PK)
- component_id (FK -> assemblies.id)
- part_number
- part_name
```

### Frontend Field Aliases (for UX)
```
Machine:
- machine_name (alias for name)
- asset_code (alias for asset_tag)

Assembly:
- machine_id (alias for equipment_id)

Part:
- assembly_id (alias for component_id)
```

### API Parameter Mapping
```
GET /assemblies?equipment_id=1  (database field)
GET /assemblies?machine_id=1    (frontend compatibility)

GET /parts?component_id=1       (database field)
GET /parts?assembly_id=1        (frontend compatibility)
```

### Form Field Mapping
```
AssemblyForm:
- equipment_id -> assemblies.equipment_id

PartForm:
- component_id -> parts.component_id
```

## Consistency Rules
1. **Database operations** use actual field names (equipment_id, component_id)
2. **Frontend display** can use aliases (machine_id, assembly_id) for UX
3. **API controllers** accept both for backward compatibility
4. **Models** use actual database field names only