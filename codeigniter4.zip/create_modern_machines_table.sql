-- Modern Professional EAM Machines Table
CREATE TABLE IF NOT EXISTS machines (
    id INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    
    -- Basic Information
    machine_code VARCHAR(50) NOT NULL UNIQUE,
    machine_name VARCHAR(255) NOT NULL,
    machine_category VARCHAR(100) NOT NULL,
    asset_class ENUM('rotating', 'static', 'electrical', 'instrumentation', 'civil') NULL,
    model VARCHAR(100) NULL,
    manufacturer VARCHAR(100) NULL,
    vendor_id INT(11) UNSIGNED NULL,
    supplier_part_number VARCHAR(100) NULL,
    serial_number VARCHAR(100) NULL,
    
    -- Location & Organization
    plant_location VARCHAR(255) NOT NULL,
    functional_location VARCHAR(100) NULL,
    department VARCHAR(100) NOT NULL,
    cost_center VARCHAR(50) NULL,
    production_line VARCHAR(100) NULL,
    
    -- Description & Notes
    description TEXT NULL,
    installation_notes TEXT NULL,
    modification_history TEXT NULL,
    special_instructions TEXT NULL,
    operation_type ENUM('continuous', 'batch', 'manual', 'automated') DEFAULT 'continuous',
    
    -- Dates & Lifecycle
    purchase_date DATE NULL,
    installation_date DATE NULL,
    commissioning_date DATE NULL,
    warranty_expiry DATE NULL,
    warranty_type ENUM('manufacturer', 'extended', 'service_contract', 'none') DEFAULT 'none',
    service_contract_number VARCHAR(100) NULL,
    service_contract_expiry DATE NULL,
    decommissioning_date DATE NULL,
    disposal_date DATE NULL,
    replacement_planned_date DATE NULL,
    
    -- Media & Documentation
    machine_photo VARCHAR(255) NULL,
    technical_manual_path VARCHAR(255) NULL,
    parts_catalog_path VARCHAR(255) NULL,
    drawing_number VARCHAR(100) NULL,
    qr_code VARCHAR(255) NULL,
    barcode VARCHAR(255) NULL,
    
    -- Status & Criticality
    status ENUM('active', 'inactive', 'out_of_service') DEFAULT 'active',
    criticality ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    safety_class ENUM('class_1', 'class_2', 'class_3', 'non_classified') NULL,
    hazardous_area_classification VARCHAR(50) NULL,
    
    -- Technical Specifications
    rated_power VARCHAR(50) NULL,
    voltage VARCHAR(50) NULL,
    capacity VARCHAR(100) NULL,
    cycle_time VARCHAR(50) NULL,
    speed_throughput VARCHAR(100) NULL,
    operating_weight VARCHAR(50) NULL,
    dimensions VARCHAR(100) NULL,
    operating_temperature_range VARCHAR(50) NULL,
    operating_pressure VARCHAR(50) NULL,
    environmental_conditions TEXT NULL,
    
    -- Financial Data
    acquisition_cost DECIMAL(15,2) NULL,
    current_value DECIMAL(15,2) NULL,
    depreciation_method ENUM('straight_line', 'declining_balance', 'units_of_production') NULL,
    useful_life_years INT(11) NULL,
    salvage_value DECIMAL(15,2) NULL,
    replacement_cost_estimate DECIMAL(15,2) NULL,
    
    -- Reliability & Performance
    mtbf_hours DECIMAL(10,2) NULL,
    mttr_hours DECIMAL(10,2) NULL,
    design_life_years INT(11) NULL,
    oee_target DECIMAL(5,2) NULL,
    
    -- Safety & Compliance
    permit_required ENUM('yes', 'no') DEFAULT 'no',
    lockout_tagout_required ENUM('yes', 'no') DEFAULT 'no',
    ppe_requirements TEXT NULL,
    regulatory_compliance TEXT NULL,
    
    -- Maintenance Configuration
    maintenance_strategy ENUM('time-based', 'usage-based', 'condition-based') DEFAULT 'time-based',
    warranty_alerts ENUM('yes', 'no') DEFAULT 'no',
    default_technician_group VARCHAR(100) NULL,
    pm_frequency INT(11) NULL,
    usage_unit ENUM('hours', 'cycles', 'meters', 'quantity_produced') DEFAULT 'hours',
    maintenance_plan_id INT(11) UNSIGNED NULL,
    lubrication_schedule VARCHAR(100) NULL,
    calibration_required ENUM('yes', 'no') DEFAULT 'no',
    calibration_frequency_days INT(11) NULL,
    last_calibration_date DATE NULL,
    next_calibration_date DATE NULL,
    
    -- Operational Data
    redundancy_available ENUM('yes', 'no') DEFAULT 'no',
    backup_equipment_id INT(11) UNSIGNED NULL,
    downtime_impact ENUM('production_stop', 'reduced_capacity', 'quality_impact', 'minimal') NULL,
    
    -- Timestamps
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    
    PRIMARY KEY (id),
    KEY idx_machine_code (machine_code),
    KEY idx_status (status),
    KEY idx_criticality (criticality),
    KEY idx_department (department),
    KEY idx_plant_location (plant_location)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
