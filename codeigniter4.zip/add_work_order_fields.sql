-- Add new fields to work_orders table
ALTER TABLE work_orders 
ADD COLUMN is_breakdown BOOLEAN DEFAULT FALSE AFTER type,
ADD COLUMN technical_description TEXT NULL AFTER description,
ADD COLUMN trade_activity ENUM('mechanical', 'electrical', 'civil', 'facility', 'workshop', 'other') DEFAULT 'mechanical' AFTER type,
ADD COLUMN delivery_date_required DATE NULL AFTER scheduled_date,
ADD COLUMN repair_started_date DATETIME NULL AFTER completed_date,
ADD COLUMN repair_ended_date DATETIME NULL AFTER repair_started_date,
ADD COLUMN technician_report TEXT NULL AFTER notes,
ADD COLUMN failure_description TEXT NULL AFTER technician_report,
ADD COLUMN cause_description TEXT NULL AFTER failure_description,
ADD COLUMN action_description TEXT NULL AFTER cause_description,
ADD COLUMN general_remarks TEXT NULL AFTER action_description,
ADD COLUMN operator_signature VARCHAR(255) NULL AFTER general_remarks,
ADD COLUMN line_manager_signature VARCHAR(255) NULL AFTER operator_signature,
ADD COLUMN supervisor_signature VARCHAR(255) NULL AFTER line_manager_signature,
ADD COLUMN downtime_hours DECIMAL(10,2) NULL AFTER estimated_hours;

-- Create materials request table
CREATE TABLE IF NOT EXISTS work_order_materials (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    gt_code VARCHAR(100) NULL,
    description TEXT NOT NULL,
    quantity_issued DECIMAL(10,2) NOT NULL,
    remarks TEXT NULL,
    receiver_signature VARCHAR(255) NULL,
    store_clerk_signature VARCHAR(255) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
