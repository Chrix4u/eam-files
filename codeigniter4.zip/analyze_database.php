<?php

/**
 * Database Structure Analyzer
 * Analyzes current database tables and generates migration files based on actual structure
 */

require_once 'vendor/autoload.php';

class DatabaseAnalyzer
{
    private $db;
    private $outputDir;
    
    public function __construct()
    {
        // Load database configuration
        $config = include 'app/Config/Database.php';
        $dbConfig = $config['default'];
        
        $this->db = new PDO(
            "mysql:host={$dbConfig['hostname']};dbname={$dbConfig['database']};charset=utf8mb4",
            $dbConfig['username'],
            $dbConfig['password'],
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        
        $this->outputDir = 'database_analysis';
        if (!is_dir($this->outputDir)) {
            mkdir($this->outputDir, 0755, true);
        }
    }
    
    public function analyzeDatabase()
    {
        echo "🔍 Analyzing database structure...\n\n";
        
        $tables = $this->getAllTables();
        $analysis = [];
        
        foreach ($tables as $table) {
            echo "📊 Analyzing table: {$table}\n";
            $analysis[$table] = $this->analyzeTable($table);
        }
        
        $this->generateAnalysisReport($analysis);
        $this->generateMigrationFiles($analysis);
        $this->generateTableDocumentation($analysis);
        
        echo "\n✅ Analysis complete! Check the '{$this->outputDir}' directory for results.\n";
    }
    
    private function getAllTables()
    {
        $stmt = $this->db->query("SHOW TABLES");
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    
    private function analyzeTable($tableName)
    {
        $analysis = [
            'name' => $tableName,
            'columns' => $this->getTableColumns($tableName),
            'indexes' => $this->getTableIndexes($tableName),
            'foreign_keys' => $this->getTableForeignKeys($tableName),
            'row_count' => $this->getTableRowCount($tableName),
            'engine' => $this->getTableEngine($tableName),
            'collation' => $this->getTableCollation($tableName)
        ];
        
        return $analysis;
    }
    
    private function getTableColumns($tableName)
    {
        $stmt = $this->db->prepare("DESCRIBE `{$tableName}`");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function getTableIndexes($tableName)
    {
        $stmt = $this->db->prepare("SHOW INDEX FROM `{$tableName}`");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function getTableForeignKeys($tableName)
    {
        $sql = "
            SELECT 
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME,
                UPDATE_RULE,
                DELETE_RULE
            FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = ? 
            AND REFERENCED_TABLE_NAME IS NOT NULL
        ";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$tableName]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    private function getTableRowCount($tableName)
    {
        try {
            $stmt = $this->db->prepare("SELECT COUNT(*) FROM `{$tableName}`");
            $stmt->execute();
            return $stmt->fetchColumn();
        } catch (Exception $e) {
            return 0;
        }
    }
    
    private function getTableEngine($tableName)
    {
        $sql = "
            SELECT ENGINE 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = ?
        ";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$tableName]);
        return $stmt->fetchColumn();
    }
    
    private function getTableCollation($tableName)
    {
        $sql = "
            SELECT TABLE_COLLATION 
            FROM INFORMATION_SCHEMA.TABLES 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = ?
        ";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$tableName]);
        return $stmt->fetchColumn();
    }
    
    private function generateAnalysisReport($analysis)
    {
        $report = "# Database Structure Analysis Report\n\n";
        $report .= "**Generated:** " . date('Y-m-d H:i:s') . "\n";
        $report .= "**Total Tables:** " . count($analysis) . "\n\n";
        
        // Summary statistics
        $totalColumns = 0;
        $totalRows = 0;
        $tablesByEngine = [];
        
        foreach ($analysis as $table) {
            $totalColumns += count($table['columns']);
            $totalRows += $table['row_count'];
            $engine = $table['engine'] ?? 'Unknown';
            $tablesByEngine[$engine] = ($tablesByEngine[$engine] ?? 0) + 1;
        }
        
        $report .= "## Summary Statistics\n\n";
        $report .= "- **Total Columns:** {$totalColumns}\n";
        $report .= "- **Total Rows:** " . number_format($totalRows) . "\n";
        $report .= "- **Engines Used:** " . implode(', ', array_keys($tablesByEngine)) . "\n\n";
        
        // Table list with details
        $report .= "## Tables Overview\n\n";
        $report .= "| Table | Columns | Rows | Engine | Has FK |\n";
        $report .= "|-------|---------|------|--------|--------|\n";
        
        foreach ($analysis as $table) {
            $hasFk = !empty($table['foreign_keys']) ? '✅' : '❌';
            $report .= "| {$table['name']} | " . count($table['columns']) . " | " . 
                      number_format($table['row_count']) . " | {$table['engine']} | {$hasFk} |\n";
        }
        
        // Maintenance-related tables
        $report .= "\n## Maintenance System Tables\n\n";
        $maintenanceTables = array_filter($analysis, function($table) {
            return strpos($table['name'], 'maintenance') !== false || 
                   strpos($table['name'], 'work_order') !== false ||
                   strpos($table['name'], 'asset') !== false ||
                   strpos($table['name'], 'equipment') !== false;
        });
        
        foreach ($maintenanceTables as $table) {
            $report .= "### {$table['name']}\n\n";
            $report .= "**Columns:** " . count($table['columns']) . " | ";
            $report .= "**Rows:** " . number_format($table['row_count']) . " | ";
            $report .= "**Foreign Keys:** " . count($table['foreign_keys']) . "\n\n";
            
            if (!empty($table['columns'])) {
                $report .= "| Column | Type | Null | Key | Default |\n";
                $report .= "|--------|------|------|-----|----------|\n";
                
                foreach ($table['columns'] as $column) {
                    $report .= "| {$column['Field']} | {$column['Type']} | {$column['Null']} | {$column['Key']} | {$column['Default']} |\n";
                }
                $report .= "\n";
            }
        }
        
        file_put_contents("{$this->outputDir}/database_analysis_report.md", $report);
        echo "📄 Generated analysis report\n";
    }
    
    private function generateMigrationFiles($analysis)
    {
        $migrationDir = "{$this->outputDir}/migrations";
        if (!is_dir($migrationDir)) {
            mkdir($migrationDir, 0755, true);
        }
        
        $timestamp = date('Y-m-d-His');
        $counter = 1;
        
        foreach ($analysis as $table) {
            $migrationFile = $this->generateMigrationFile($table, $timestamp, $counter);
            file_put_contents("{$migrationDir}/{$migrationFile['filename']}", $migrationFile['content']);
            $counter++;
        }
        
        echo "📁 Generated " . count($analysis) . " migration files\n";
    }
    
    private function generateMigrationFile($table, $timestamp, $counter)
    {
        $className = 'Create' . $this->toPascalCase($table['name']) . 'Table';
        $filename = "{$timestamp}-" . str_pad($counter, 6, '0', STR_PAD_LEFT) . "_{$className}.php";
        
        $content = "<?php\n\n";
        $content .= "namespace App\\Database\\Migrations;\n\n";
        $content .= "use CodeIgniter\\Database\\Migration;\n\n";
        $content .= "/**\n";
        $content .= " * Migration for {$table['name']} table\n";
        $content .= " * Generated from existing database structure\n";
        $content .= " * Rows: " . number_format($table['row_count']) . "\n";
        $content .= " */\n";
        $content .= "class {$className} extends Migration\n";
        $content .= "{\n";
        $content .= "    public function up()\n";
        $content .= "    {\n";
        $content .= "        \$this->forge->addField([\n";
        
        foreach ($table['columns'] as $column) {
            $content .= $this->generateColumnDefinition($column);
        }
        
        $content .= "        ]);\n\n";
        
        // Add primary key
        $primaryKey = $this->findPrimaryKey($table['indexes']);
        if ($primaryKey) {
            $content .= "        \$this->forge->addKey('{$primaryKey}', true);\n";
        }
        
        // Add other indexes
        $indexes = $this->getUniqueIndexes($table['indexes']);
        foreach ($indexes as $index) {
            if ($index['type'] === 'unique') {
                $content .= "        \$this->forge->addUniqueKey('{$index['column']}');\n";
            } else {
                $content .= "        \$this->forge->addKey('{$index['column']}');\n";
            }
        }
        
        // Add foreign keys
        foreach ($table['foreign_keys'] as $fk) {
            $content .= "        \$this->forge->addForeignKey('{$fk['COLUMN_NAME']}', '{$fk['REFERENCED_TABLE_NAME']}', '{$fk['REFERENCED_COLUMN_NAME']}', '{$fk['UPDATE_RULE']}', '{$fk['DELETE_RULE']}');\n";
        }
        
        $content .= "\n        \$this->forge->createTable('{$table['name']}');\n";
        $content .= "    }\n\n";
        $content .= "    public function down()\n";
        $content .= "    {\n";
        $content .= "        \$this->forge->dropTable('{$table['name']}', true);\n";
        $content .= "    }\n";
        $content .= "}\n";
        
        return ['filename' => $filename, 'content' => $content];
    }
    
    private function generateColumnDefinition($column)
    {
        $definition = "            '{$column['Field']}' => [";
        
        // Parse type
        $type = $this->parseColumnType($column['Type']);
        $definition .= "'type' => '{$type['type']}'";
        
        if (!empty($type['constraint'])) {
            $definition .= ", 'constraint' => {$type['constraint']}";
        }
        
        if ($column['Null'] === 'YES') {
            $definition .= ", 'null' => true";
        }
        
        if ($column['Default'] !== null && $column['Default'] !== '') {
            if (is_numeric($column['Default'])) {
                $definition .= ", 'default' => {$column['Default']}";
            } else {
                $definition .= ", 'default' => '{$column['Default']}'";
            }
        }
        
        if ($column['Extra'] === 'auto_increment') {
            $definition .= ", 'auto_increment' => true";
        }
        
        if (strpos($column['Type'], 'unsigned') !== false) {
            $definition .= ", 'unsigned' => true";
        }
        
        $definition .= "],\n";
        
        return $definition;
    }
    
    private function parseColumnType($type)
    {
        $result = ['type' => '', 'constraint' => ''];
        
        if (preg_match('/^(\w+)(?:\(([^)]+)\))?/', $type, $matches)) {
            $baseType = strtoupper($matches[1]);
            $constraint = $matches[2] ?? '';
            
            switch ($baseType) {
                case 'TINYINT':
                case 'SMALLINT':
                case 'MEDIUMINT':
                case 'INT':
                case 'BIGINT':
                    $result['type'] = 'INT';
                    $result['constraint'] = $constraint ?: '11';
                    break;
                case 'VARCHAR':
                    $result['type'] = 'VARCHAR';
                    $result['constraint'] = $constraint ?: '255';
                    break;
                case 'CHAR':
                    $result['type'] = 'CHAR';
                    $result['constraint'] = $constraint ?: '1';
                    break;
                case 'TEXT':
                case 'MEDIUMTEXT':
                case 'LONGTEXT':
                    $result['type'] = 'TEXT';
                    break;
                case 'DECIMAL':
                case 'NUMERIC':
                    $result['type'] = 'DECIMAL';
                    $result['constraint'] = "'{$constraint}'";
                    break;
                case 'FLOAT':
                case 'DOUBLE':
                    $result['type'] = 'FLOAT';
                    break;
                case 'DATE':
                    $result['type'] = 'DATE';
                    break;
                case 'DATETIME':
                case 'TIMESTAMP':
                    $result['type'] = 'DATETIME';
                    break;
                case 'TIME':
                    $result['type'] = 'TIME';
                    break;
                case 'BOOLEAN':
                case 'BOOL':
                    $result['type'] = 'BOOLEAN';
                    break;
                case 'ENUM':
                    $result['type'] = 'ENUM';
                    $result['constraint'] = "[{$constraint}]";
                    break;
                default:
                    $result['type'] = $baseType;
                    if ($constraint) {
                        $result['constraint'] = "'{$constraint}'";
                    }
            }
        }
        
        return $result;
    }
    
    private function findPrimaryKey($indexes)
    {
        foreach ($indexes as $index) {
            if ($index['Key_name'] === 'PRIMARY') {
                return $index['Column_name'];
            }
        }
        return null;
    }
    
    private function getUniqueIndexes($indexes)
    {
        $result = [];
        $processed = [];
        
        foreach ($indexes as $index) {
            if ($index['Key_name'] === 'PRIMARY') continue;
            if (in_array($index['Key_name'], $processed)) continue;
            
            $result[] = [
                'name' => $index['Key_name'],
                'column' => $index['Column_name'],
                'type' => $index['Non_unique'] == 0 ? 'unique' : 'index'
            ];
            
            $processed[] = $index['Key_name'];
        }
        
        return $result;
    }
    
    private function generateTableDocumentation($analysis)
    {
        $doc = "# Database Table Documentation\n\n";
        $doc .= "**Generated:** " . date('Y-m-d H:i:s') . "\n\n";
        
        foreach ($analysis as $table) {
            $doc .= "## {$table['name']}\n\n";
            $doc .= "**Engine:** {$table['engine']} | ";
            $doc .= "**Collation:** {$table['collation']} | ";
            $doc .= "**Rows:** " . number_format($table['row_count']) . "\n\n";
            
            if (!empty($table['columns'])) {
                $doc .= "### Columns\n\n";
                $doc .= "| Column | Type | Null | Key | Default | Extra |\n";
                $doc .= "|--------|------|------|-----|---------|-------|\n";
                
                foreach ($table['columns'] as $column) {
                    $doc .= "| `{$column['Field']}` | {$column['Type']} | {$column['Null']} | {$column['Key']} | {$column['Default']} | {$column['Extra']} |\n";
                }
                $doc .= "\n";
            }
            
            if (!empty($table['foreign_keys'])) {
                $doc .= "### Foreign Keys\n\n";
                $doc .= "| Column | References | On Update | On Delete |\n";
                $doc .= "|--------|------------|-----------|----------|\n";
                
                foreach ($table['foreign_keys'] as $fk) {
                    $doc .= "| `{$fk['COLUMN_NAME']}` | `{$fk['REFERENCED_TABLE_NAME']}.{$fk['REFERENCED_COLUMN_NAME']}` | {$fk['UPDATE_RULE']} | {$fk['DELETE_RULE']} |\n";
                }
                $doc .= "\n";
            }
            
            $doc .= "---\n\n";
        }
        
        file_put_contents("{$this->outputDir}/table_documentation.md", $doc);
        echo "📚 Generated table documentation\n";
    }
    
    private function toPascalCase($string)
    {
        return str_replace(' ', '', ucwords(str_replace('_', ' ', $string)));
    }
}

// Run the analyzer
try {
    $analyzer = new DatabaseAnalyzer();
    $analyzer->analyzeDatabase();
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "Make sure your database configuration is correct in app/Config/Database.php\n";
}