<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS vendors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category ENUM('maintenance', 'parts', 'services', 'contractor') NOT NULL,
    contact_person VARCHAR(255) NULL,
    email VARCHAR(255) NULL,
    phone VARCHAR(50) NULL,
    address TEXT NULL,
    rating DECIMAL(3,2) DEFAULT 0,
    performance_score DECIMAL(5,2) DEFAULT 0,
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

if ($db->query($sql)) {
    echo "✓ Table 'vendors' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql2 = "CREATE TABLE IF NOT EXISTS vendor_contracts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendor_id INT NOT NULL,
    contract_number VARCHAR(100) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    contract_type ENUM('service', 'supply', 'maintenance', 'project') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    value DECIMAL(12,2) NOT NULL,
    status ENUM('draft', 'active', 'expired', 'terminated') DEFAULT 'draft',
    sla_response_time INT NULL,
    sla_resolution_time INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
)";

if ($db->query($sql2)) {
    echo "✓ Table 'vendor_contracts' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql3 = "CREATE TABLE IF NOT EXISTS vendor_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vendor_id INT NOT NULL,
    work_order_id INT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    on_time BOOLEAN DEFAULT TRUE,
    quality_score INT NULL CHECK (quality_score BETWEEN 1 AND 100),
    comments TEXT NULL,
    evaluated_by INT NOT NULL,
    evaluation_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
)";

if ($db->query($sql3)) {
    echo "✓ Table 'vendor_performance' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$tableCheck = $db->query("SHOW COLUMNS FROM vendors LIKE 'vendor_name'");
if ($tableCheck->num_rows > 0) {
    $vendors = [
        ['VND-001', 'ABC Maintenance Co.', 'John Smith', 'john@abc.com', '555-0101'],
        ['VND-002', 'Parts Unlimited', 'Jane Doe', 'jane@parts.com', '555-0102'],
        ['VND-003', 'Tech Services Inc.', 'Bob Johnson', 'bob@tech.com', '555-0103'],
        ['VND-004', 'General Contractors', 'Alice Brown', 'alice@gc.com', '555-0104']
    ];

    foreach ($vendors as $v) {
        $stmt = $db->prepare("INSERT INTO vendors (vendor_code, vendor_name, contact_person, email, phone, status) VALUES (?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("sssss", $v[0], $v[1], $v[2], $v[3], $v[4]);
        $stmt->execute();
    }

    echo "✓ Inserted 4 sample vendors\n";
} else {
    echo "Note: Using existing vendors table structure\n";
}

$contracts = [
    [1, 'CNT-2024-001', 'Annual Maintenance Contract', 'maintenance', '2024-01-01', '2024-12-31', 50000, 'active', 4, 24],
    [2, 'CNT-2024-002', 'Parts Supply Agreement', 'supply', '2024-01-01', '2024-12-31', 75000, 'active', null, null],
    [3, 'CNT-2024-003', 'Technical Support Services', 'service', '2024-01-01', '2024-06-30', 30000, 'active', 2, 8]
];

foreach ($contracts as $c) {
    $stmt = $db->prepare("INSERT INTO vendor_contracts (vendor_id, contract_number, title, contract_type, start_date, end_date, value, status, sla_response_time, sla_resolution_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssdsii", $c[0], $c[1], $c[2], $c[3], $c[4], $c[5], $c[6], $c[7], $c[8], $c[9]);
    $stmt->execute();
}

echo "✓ Inserted 3 sample contracts\n";

$db->close();
?>
