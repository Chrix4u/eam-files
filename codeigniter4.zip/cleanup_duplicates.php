<?php
/**
 * PHASE 2: CLEANUP DUPLICATE CONTROLLERS
 * Removes old flat-structure files after modular consolidation
 * SAFE: Only removes files that have been consolidated into Modules/
 */

$filesToDelete = [
    // RWOP duplicates
    'app/Controllers/Api/V1/WorkOrdersController.php',
    'app/Controllers/Api/V1/WorkOrderController.php',
    'app/Controllers/Api/V1/EamWorkOrdersController.php',
    'app/Controllers/Api/V1/WorkOrderCompletionController.php',
    'app/Controllers/Api/V1/MaintenanceRequestController.php',
    'app/Controllers/Api/V1/MaintenanceRequestController.php.new',
    'app/Controllers/Api/V1/AssistanceRequestController.php',
    'app/Controllers/Api/V1/WorkOrderAssignmentController.php',
    'app/Controllers/Api/V1/WorkOrderLogsController.php',
    'app/Controllers/Api/V1/WorkOrderTasksController.php',
    'app/Controllers/Api/V1/WorkOrderTeamController.php',
    'app/Controllers/Api/V1/WorkOrderAttachmentsController.php',
    'app/Controllers/Api/V1/WorkOrderMaterialController.php',
    'app/Controllers/Api/V1/WorkOrderMaterialsController.php',
    'app/Controllers/Api/V1/RecurringWorkOrderController.php',
    'app/Controllers/Api/V1/WorkOrderTemplateController.php',
    
    // MRMP duplicates
    'app/Controllers/Api/V1/PmController.php',
    'app/Controllers/Api/V1/EamPmController.php',
    'app/Controllers/Api/V1/PreventiveMaintenanceController.php',
    'app/Controllers/Api/V1/CalibrationController.php',
    'app/Controllers/Api/V1/PredictiveController.php',
    'app/Controllers/Api/V1/PmWorkOrderController.php',
    'app/Controllers/Api/V1/PmTasksController.php',
    'app/Controllers/Api/V1/PmTypesController.php',
    'app/Controllers/Api/V1/PmModesController.php',
    'app/Controllers/Api/V1/PmInspectionTypesController.php',
    'app/Controllers/Api/V1/PmTriggerTypesController.php',
    'app/Controllers/Api/V1/UsageBasedPmController.php',
    'app/Controllers/Api/V1/PartPmTaskController.php',
    'app/Controllers/Api/V1/IoTDevicesController.php',
    'app/Controllers/Api/V1/IoTDataController.php',
    'app/Controllers/Api/V1/IoTRulesController.php',
    
    // MPMP duplicates
    'app/Controllers/Api/V1/ProductionController.php',
    'app/Controllers/Api/V1/OEEController.php',
    'app/Controllers/Api/V1/DowntimeController.php',
    'app/Controllers/Api/V1/ProductionDataController.php',
    'app/Controllers/Api/V1/ProductionTrackingController.php',
    'app/Controllers/Api/V1/ProductionRunsController.php',
    'app/Controllers/Api/V1/SurveysController.php',
    'app/Controllers/Api/V1/QualityController.php',
    
    // IMS duplicates
    'app/Controllers/Api/V1/EamInventoryController.php',
    'app/Controllers/Api/V1/InventoryController.php',
    'app/Controllers/Api/V1/EamPartsController.php',
    'app/Controllers/Api/V1/PartController.php',
    'app/Controllers/Api/V1/StockTransactionsController.php',
    'app/Controllers/Api/V1/InventoryForecastController.php',
    'app/Controllers/Api/V1/MaterialRequestController.php',
    'app/Controllers/Api/V1/MaterialRequisitionController.php',
    'app/Controllers/Api/V1/SubPartsController.php',
    'app/Controllers/Api/V1/EquipmentPartsController.php',
    'app/Controllers/Api/V1/VendorsController.php',
    
    // HRMS duplicates
    'app/Controllers/Api/V1/EamUsersController.php',
    'app/Controllers/Api/V1/UserController.php',
    'app/Controllers/Api/V1/ShiftsController.php',
    'app/Controllers/Api/V1/EmployeeShiftsController.php',
    'app/Controllers/Api/V1/ShiftAssignmentController.php',
    'app/Controllers/Api/V1/SkillsController.php',
    'app/Controllers/Api/V1/SkillCategoriesController.php',
    'app/Controllers/Api/V1/TradesController.php',
    'app/Controllers/Api/V1/TrainingRecordsController.php',
    'app/Controllers/Api/V1/LaborLogController.php',
    
    // TRAC duplicates
    'app/Controllers/Api/V1/ToolsController.php',
    'app/Controllers/Api/V1/LOTOController.php',
    'app/Controllers/Api/V1/LOTOLockController.php',
    'app/Controllers/Api/V1/PermitToWorkController.php',
    'app/Controllers/Api/V1/ResourceAvailabilityController.php',
    
    // ASSET duplicates
    'app/Controllers/Api/V1/EamEquipmentController.php',
    'app/Controllers/Api/V1/MachineController.php',
    'app/Controllers/Api/V1/EamFacilitiesController.php',
    'app/Controllers/Api/V1/FacilitiesController.php',
    'app/Controllers/Api/V1/EamAssembliesController.php',
    'app/Controllers/Api/V1/AssemblyController.php',
    'app/Controllers/Api/V1/BillOfMaterialsController.php',
    'app/Controllers/Api/V1/MetersController.php',
    'app/Controllers/Api/V1/AssetHealthController.php',
    
    // CORE duplicates
    'app/Controllers/Api/V1/EamAuthController.php',
    'app/Controllers/Api/V1/AuthController.php',
    'app/Controllers/Api/V1/PasswordResetController.php',
    'app/Controllers/Api/V1/AnalyticsController.php',
    'app/Controllers/Api/V1/DashboardController.php',
    'app/Controllers/Api/V1/ReportsController.php',
    'app/Controllers/Api/V1/WorkOrderAnalyticsController.php',
    'app/Controllers/Api/V1/MaintenanceAnalyticsController.php',
    'app/Controllers/Api/V1/PmAnalyticsController.php',
    'app/Controllers/Api/V1/CompletionAnalyticsController.php',
    'app/Controllers/Api/V1/WorkOrderReportsController.php',
    'app/Controllers/Api/V1/ProductionReportsController.php',
    'app/Controllers/Api/V1/StockReportsController.php',
    'app/Controllers/Api/V1/NotificationController.php',
    'app/Controllers/Api/V1/NotificationsController.php',
    'app/Controllers/Api/V1/PmNotificationController.php',
    'app/Controllers/Api/V1/SystemSettingsController.php',
    'app/Controllers/Api/V1/CompanySettingsController.php',
    'app/Controllers/Api/V1/ModuleSettingsController.php',
    'app/Controllers/Api/V1/DepartmentsController.php',
    'app/Controllers/Api/V1/EamRolesController.php',
    'app/Controllers/Api/V1/UserPermissionsController.php',
];

$foldersToDelete = [
    'app/Controllers/Api/V1/RWOP',
    'app/Controllers/Api/V1/Shift',
    'app/Controllers/Api/V1/WorkExecution',
];

echo "╔════════════════════════════════════════════════════════════╗\n";
echo "║  PHASE 2: CLEANUP DUPLICATE CONTROLLERS                   ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n\n";

$deleted = 0;
$notFound = 0;
$errors = 0;

echo "🗑️  Deleting duplicate files...\n\n";

foreach ($filesToDelete as $file) {
    if (file_exists($file)) {
        if (unlink($file)) {
            $deleted++;
            echo "  ✓ Deleted: " . basename($file) . "\n";
        } else {
            $errors++;
            echo "  ✗ Failed: " . basename($file) . "\n";
        }
    } else {
        $notFound++;
    }
}

echo "\n📁 Deleting empty folders...\n\n";

foreach ($foldersToDelete as $folder) {
    if (is_dir($folder)) {
        // Check if empty
        $files = scandir($folder);
        $files = array_diff($files, ['.', '..']);
        
        if (count($files) === 0) {
            if (rmdir($folder)) {
                echo "  ✓ Removed: $folder\n";
            } else {
                echo "  ✗ Failed: $folder\n";
            }
        } else {
            echo "  ⊘ Skipped: $folder (not empty)\n";
        }
    }
}

echo "\n╔════════════════════════════════════════════════════════════╗\n";
echo "║  CLEANUP SUMMARY                                           ║\n";
echo "╚════════════════════════════════════════════════════════════╝\n";
echo "  Files deleted: $deleted\n";
echo "  Not found: $notFound\n";
echo "  Errors: $errors\n\n";

if ($errors === 0) {
    echo "✅ Cleanup complete! Modular architecture is now clean.\n";
    echo "📋 Next: Clear cache and test routes\n";
} else {
    echo "⚠️  Some files could not be deleted. Check permissions.\n";
}
