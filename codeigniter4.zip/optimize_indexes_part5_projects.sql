-- ============================================================================
-- COMPREHENSIVE INDEX OPTIMIZATION - PART 5: PROJECTS & ASSETS
-- ============================================================================
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;

-- PROJECT TABLE
ALTER TABLE `project` ADD INDEX IF NOT EXISTS `idx_status_project` (`pro_status`);
ALTER TABLE `project` ADD INDEX IF NOT EXISTS `idx_dates_project` (`pro_start_date`, `pro_end_date`);

-- PRO_TASK TABLE
ALTER TABLE `pro_task` ADD INDEX IF NOT EXISTS `idx_project_task` (`pro_id`);
ALTER TABLE `pro_task` ADD INDEX IF NOT EXISTS `idx_status_task` (`status`);
ALTER TABLE `pro_task` ADD INDEX IF NOT EXISTS `idx_task_type` (`task_type`);
ALTER TABLE `pro_task` ADD INDEX IF NOT EXISTS `idx_approve_status` (`approve_status`);
ALTER TABLE `pro_task` ADD INDEX IF NOT EXISTS `idx_dates_task` (`start_date`, `end_date`);

-- ASSIGN_TASK TABLE
ALTER TABLE `assign_task` ADD INDEX IF NOT EXISTS `idx_task_project_assign` (`task_id`, `project_id`);
ALTER TABLE `assign_task` ADD INDEX IF NOT EXISTS `idx_assign_user` (`assign_user`);
ALTER TABLE `assign_task` ADD INDEX IF NOT EXISTS `idx_user_type` (`user_type`);

-- PROJECT_FILE TABLE
ALTER TABLE `project_file` ADD INDEX IF NOT EXISTS `idx_project_file` (`pro_id`);
ALTER TABLE `project_file` ADD INDEX IF NOT EXISTS `idx_assigned_to_file` (`assigned_to`);

-- PRO_NOTES TABLE
ALTER TABLE `pro_notes` ADD INDEX IF NOT EXISTS `idx_project_notes` (`pro_id`);
ALTER TABLE `pro_notes` ADD INDEX IF NOT EXISTS `idx_assign_to_notes` (`assign_to`);

-- PRO_EXPENSES TABLE
ALTER TABLE `pro_expenses` ADD INDEX IF NOT EXISTS `idx_project_expenses` (`pro_id`);
ALTER TABLE `pro_expenses` ADD INDEX IF NOT EXISTS `idx_assign_to_expenses` (`assign_to`);
ALTER TABLE `pro_expenses` ADD INDEX IF NOT EXISTS `idx_date_expenses` (`date`);

-- PRO_TASK_ASSETS TABLE
ALTER TABLE `pro_task_assets` ADD INDEX IF NOT EXISTS `idx_task_assets` (`pro_task_id`);
ALTER TABLE `pro_task_assets` ADD INDEX IF NOT EXISTS `idx_assign_id_assets` (`assign_id`);

-- FIELD_VISIT TABLE
ALTER TABLE `field_visit` ADD INDEX IF NOT EXISTS `idx_project_visit` (`project_id`);
ALTER TABLE `field_visit` ADD INDEX IF NOT EXISTS `idx_emp_visit` (`emp_id`);
ALTER TABLE `field_visit` ADD INDEX IF NOT EXISTS `idx_status_visit` (`status`);
ALTER TABLE `field_visit` ADD INDEX IF NOT EXISTS `idx_dates_visit` (`start_date`, `approx_end_date`);

-- ASSETS TABLE
ALTER TABLE `assets` ADD INDEX IF NOT EXISTS `idx_category_asset` (`catid`);
ALTER TABLE `assets` ADD INDEX IF NOT EXISTS `idx_ass_code` (`ass_code`);
ALTER TABLE `assets` ADD INDEX IF NOT EXISTS `idx_purchasing_date` (`purchasing_date`);

-- ASSETS_CATEGORY TABLE
ALTER TABLE `assets_category` ADD INDEX IF NOT EXISTS `idx_cat_status` (`cat_status`);

-- EMP_ASSETS TABLE
ALTER TABLE `emp_assets` ADD INDEX IF NOT EXISTS `idx_emp_assets_assign` (`emp_id`, `assets_id`);
ALTER TABLE `emp_assets` ADD INDEX IF NOT EXISTS `idx_given_date` (`given_date`);
ALTER TABLE `emp_assets` ADD INDEX IF NOT EXISTS `idx_return_date` (`return_date`);

-- LOGISTIC_ASSET TABLE
ALTER TABLE `logistic_asset` ADD INDEX IF NOT EXISTS `idx_entry_date` (`entry_date`);

-- LOGISTIC_ASSIGN TABLE
ALTER TABLE `logistic_assign` ADD INDEX IF NOT EXISTS `idx_asset_logistic` (`asset_id`);
ALTER TABLE `logistic_assign` ADD INDEX IF NOT EXISTS `idx_assign_project_task` (`assign_id`, `project_id`, `task_id`);
ALTER TABLE `logistic_assign` ADD INDEX IF NOT EXISTS `idx_dates_logistic` (`start_date`, `end_date`);

-- EMP_TRAINING TABLE
ALTER TABLE `emp_training` ADD INDEX IF NOT EXISTS `idx_training_emp` (`trainig_id`, `emp_id`);

COMMIT;
