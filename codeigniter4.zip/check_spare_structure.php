<?php

$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "TABLE STRUCTURES:\n";
echo "=================\n\n";

// Check asset_spare_parts
echo "1. asset_spare_parts\n";
echo "--------------------\n";
$result = $conn->query("DESCRIBE asset_spare_parts");
while ($row = $result->fetch_assoc()) {
    echo sprintf("%-25s %-20s %s\n", $row['Field'], $row['Type'], $row['Key']);
}

echo "\n\n2. pm_required_spares\n";
echo "--------------------\n";
$result = $conn->query("DESCRIBE pm_required_spares");
while ($row = $result->fetch_assoc()) {
    echo sprintf("%-25s %-20s %s\n", $row['Field'], $row['Type'], $row['Key']);
}

echo "\n\n3. inventory_items (for comparison)\n";
echo "-----------------------------------\n";
$result = $conn->query("DESCRIBE inventory_items");
while ($row = $result->fetch_assoc()) {
    echo sprintf("%-25s %-20s %s\n", $row['Field'], $row['Type'], $row['Key']);
}

$conn->close();
