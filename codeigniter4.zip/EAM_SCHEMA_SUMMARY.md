# Enterprise Asset Management (EAM) Database Schema

## ✅ Complete Schema Generated

### Tables Created: 21 Migrations

#### Asset Hierarchy (7 tables)
1. **facilities** - Top-level locations
2. **systems** - Systems within facilities
3. **equipment** - Equipment within systems
4. **assemblies** - Assemblies within equipment
5. **components** - Components within assemblies
6. **parts** - Parts within components
7. **sub_parts** - Sub-parts within parts

#### Unified Asset View (1 table)
8. **assets** - Unified view of all asset types with hierarchy

#### Metering (2 tables)
9. **meters** - Asset meters (hours, cycles, etc.)
10. **meter_readings** - Historical meter readings

#### Preventive Maintenance (2 tables)
11. **pm_rules** - PM trigger rules (time/meter-based)
12. **pm_schedules** - Generated PM schedules

#### Work Management (3 tables)
13. **work_orders** - Work order master
14. **work_order_tasks** - Task breakdown
15. **work_order_materials** - Materials used

#### Inventory (2 tables)
16. **inventory_items** - Stock items
17. **stock_transactions** - Stock movements

#### Procurement (2 tables)
18. **vendors** - Supplier information
19. **purchase_orders** - Purchase orders

#### Security & Audit (2 tables)
20. **permissions, user_roles, role_permissions** - RBAC system
21. **audit_logs** - Complete audit trail

---

## 🔑 Key Features

### Cascade Rules
- **CASCADE DELETE**: Child records deleted when parent deleted
  - facilities → systems → equipment → assemblies → components → parts
  - assets → meters → meter_readings
  - work_orders → work_order_tasks, work_order_materials
  
- **SET NULL**: Reference cleared when parent deleted
  - pm_rules.meter_id → meters

### Indexes
- Primary keys on all tables
- Foreign key indexes for joins
- Composite indexes for common queries:
  - `(asset_id, status)` on work_orders
  - `(status, priority)` on work_orders
  - `(asset_id, due_date)` on pm_schedules
  - `(inventory_item_id, transaction_date)` on stock_transactions

### Data Types
- **ENUM** for status fields (controlled values)
- **DECIMAL(10,2)** for currency
- **DECIMAL(15,2)** for quantities
- **JSON** for audit log values
- **DATETIME** for timestamps
- **TEXT** for descriptions

---

## 📊 Entity Relationships

```
facilities (1) ──→ (N) systems
systems (1) ──→ (N) equipment
equipment (1) ──→ (N) assemblies
assemblies (1) ──→ (N) components
components (1) ──→ (N) parts
parts (1) ──→ (N) sub_parts

assets (1) ──→ (N) meters
meters (1) ──→ (N) meter_readings

assets (1) ──→ (N) pm_rules
pm_rules (1) ──→ (N) pm_schedules

assets (1) ──→ (N) work_orders
work_orders (1) ──→ (N) work_order_tasks
work_orders (1) ──→ (N) work_order_materials

inventory_items (1) ──→ (N) stock_transactions
inventory_items (1) ──→ (N) work_order_materials

vendors (1) ──→ (N) purchase_orders
vendors (1) ──→ (N) inventory_items

users (N) ──→ (N) roles (via user_roles)
roles (N) ──→ (N) permissions (via role_permissions)
```

---

## 🚀 Usage Examples

### Run Migrations
```bash
php spark migrate
```

### Rollback
```bash
php spark migrate:rollback
```

### Check Status
```bash
php spark migrate:status
```

---

## 📝 Sample Queries

### Get Asset Hierarchy
```sql
SELECT 
    f.facility_name,
    s.system_name,
    e.equipment_name,
    a.assembly_name
FROM facilities f
JOIN systems s ON s.facility_id = f.id
JOIN equipment e ON e.system_id = s.id
JOIN assemblies a ON a.equipment_id = e.id
WHERE f.id = 1;
```

### Get Due PM Work Orders
```sql
SELECT 
    wo.wo_number,
    a.asset_name,
    wo.scheduled_start,
    wo.priority
FROM work_orders wo
JOIN assets a ON a.id = wo.asset_id
WHERE wo.status = 'pending'
AND wo.scheduled_start <= CURDATE()
ORDER BY wo.priority DESC, wo.scheduled_start ASC;
```

### Get Low Stock Items
```sql
SELECT 
    item_code,
    item_name,
    quantity_on_hand,
    reorder_point
FROM inventory_items
WHERE quantity_on_hand <= reorder_point
AND status = 'active';
```

### Audit Trail
```sql
SELECT 
    al.action,
    al.table_name,
    al.record_id,
    u.username,
    al.created_at
FROM audit_logs al
LEFT JOIN users u ON u.id = al.user_id
WHERE al.table_name = 'work_orders'
AND al.record_id = 123
ORDER BY al.created_at DESC;
```

---

## 🎯 Model Templates

### Entity Example
```php
namespace App\Entities;
use CodeIgniter\Entity\Entity;

class Asset extends Entity
{
    protected $dates = ['created_at', 'updated_at'];
    protected $casts = ['id' => 'integer'];
    
    public function isActive(): bool
    {
        return $this->attributes['status'] === 'active';
    }
}
```

### Model Example
```php
namespace App\Models;
use CodeIgniter\Model;

class EamAssetModel extends Model
{
    protected $table = 'assets';
    protected $returnType = 'App\Entities\Asset';
    protected $allowedFields = ['asset_code', 'asset_name', ...];
    protected $useTimestamps = true;
    
    public function getAssetHierarchy(int $id): array
    {
        return $this->select('assets.*, parent.asset_name')
            ->join('assets parent', 'parent.id = assets.parent_asset_id', 'left')
            ->find($id);
    }
}
```

---

## 📦 Files Generated

### Migrations (21 files)
- 2025-11-14-000001_CreateEamFacilities.php
- 2025-11-14-000002_CreateEamSystems.php
- 2025-11-14-000003_CreateEamEquipment.php
- 2025-11-14-000004_CreateEamAssemblies.php
- 2025-11-14-000005_CreateEamComponents.php
- 2025-11-14-000006_CreateEamParts.php
- 2025-11-14-000007_CreateEamSubParts.php
- 2025-11-14-000008_CreateEamAssets.php
- 2025-11-14-000009_CreateEamMeters.php
- 2025-11-14-000010_CreateEamMeterReadings.php
- 2025-11-14-000011_CreateEamPmRules.php
- 2025-11-14-000012_CreateEamPmSchedules.php
- 2025-11-14-000013_CreateEamWorkOrders.php
- 2025-11-14-000014_CreateEamWorkOrderTasks.php
- 2025-11-14-000015_CreateEamInventoryItems.php
- 2025-11-14-000016_CreateEamWorkOrderMaterials.php
- 2025-11-14-000017_CreateEamStockTransactions.php
- 2025-11-14-000018_CreateEamVendors.php
- 2025-11-14-000019_CreateEamPurchaseOrders.php
- 2025-11-14-000020_CreateEamRbac.php
- 2025-11-14-000021_CreateEamAuditLogs.php

### Entities (1 file)
- app/Entities/Asset.php

### Models (2 files)
- app/Models/EamAssetModel.php
- app/Models/EamWorkOrderModel.php

---

## ✅ Schema Complete

Total: **24 files** created for complete EAM system database structure.

Ready for: `php spark migrate`
