<?php
echo "==============================================\n";
echo "FINAL SYSTEM VERIFICATION\n";
echo "==============================================\n\n";

$checks = [
    'Database Tables' => [
        'facilities', 'departments', 'work_order_assignments', 'documents',
        'production_schedules', 'shifts', 'shift_handovers', 'quality_inspections',
        'energy_consumption', 'employee_roster', 'inventory_forecasts'
    ],
    'Models' => [
        'FacilitiesModel.php', 'DepartmentsModel.php', 'WorkOrderAssignmentsModel.php',
        'DocumentsModel.php', 'ProductionSchedulesModel.php', 'ShiftsModel.php',
        'ShiftHandoversModel.php', 'QualityInspectionsModel.php', 'EnergyConsumptionModel.php',
        'EmployeeRosterModel.php', 'InventoryForecastsModel.php'
    ],
    'Controllers' => [
        'EamFacilitiesController.php', 'DepartmentsController.php', 'AssignmentsController.php',
        'DocumentsController.php', 'SchedulerController.php', 'ShiftsController.php',
        'ShiftHandoverController.php', 'QualityController.php', 'EnergyController.php',
        'EmployeeShiftsController.php', 'InventoryForecastController.php'
    ]
];

$conn = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
$passed = 0;
$total = 0;

// Check Database Tables
echo "1. DATABASE TABLES\n";
echo str_repeat("-", 50) . "\n";
foreach ($checks['Database Tables'] as $table) {
    $total++;
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        echo "✅ $table\n";
        $passed++;
    } else {
        echo "❌ $table\n";
    }
}

// Check Models
echo "\n2. MODELS (with allowedFields)\n";
echo str_repeat("-", 50) . "\n";
$modelPath = 'C:/wamp64/www/factorymanager/app/Models/';
foreach ($checks['Models'] as $model) {
    $total++;
    $file = $modelPath . $model;
    if (file_exists($file)) {
        $content = file_get_contents($file);
        if (strpos($content, 'protected $allowedFields') !== false) {
            echo "✅ $model (has allowedFields)\n";
            $passed++;
        } else {
            echo "⚠️  $model (missing allowedFields)\n";
        }
    } else {
        echo "❌ $model (not found)\n";
    }
}

// Check Controllers
echo "\n3. CONTROLLERS (with validation)\n";
echo str_repeat("-", 50) . "\n";
$controllerPath = 'C:/wamp64/www/factorymanager/app/Controllers/Api/V1/';
foreach ($checks['Controllers'] as $controller) {
    $total++;
    $file = $controllerPath . $controller;
    if (file_exists($file)) {
        $content = file_get_contents($file);
        $hasModel = strpos($content, 'protected $model') !== false || strpos($content, 'new \\App\\Models\\') !== false;
        $hasValidation = strpos($content, 'validationRules') !== false || strpos($content, 'validate') !== false;
        
        if ($hasModel && $hasValidation) {
            echo "✅ $controller (model + validation)\n";
            $passed++;
        } else if ($hasModel) {
            echo "⚠️  $controller (has model, needs validation)\n";
        } else {
            echo "⚠️  $controller (needs model + validation)\n";
        }
    } else {
        echo "❌ $controller (not found)\n";
    }
}

// Summary
echo "\n" . str_repeat("=", 50) . "\n";
echo "FINAL SCORE\n";
echo str_repeat("=", 50) . "\n";
echo "Passed: $passed / $total\n";
$percentage = round(($passed / $total) * 100, 1);
echo "Success Rate: $percentage%\n";

if ($percentage >= 95) {
    echo "Status: ✅ EXCELLENT - PRODUCTION READY\n";
} else if ($percentage >= 80) {
    echo "Status: ✅ GOOD - Minor fixes needed\n";
} else {
    echo "Status: ⚠️  NEEDS WORK\n";
}

echo str_repeat("=", 50) . "\n";

$conn->close();
?>
