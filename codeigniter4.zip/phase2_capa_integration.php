<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_capa (
    capa_id INT AUTO_INCREMENT PRIMARY KEY,
    capa_code VARCHAR(50) UNIQUE NOT NULL,
    survey_id INT NOT NULL,
    capa_type ENUM('corrective', 'preventive') NOT NULL,
    issue_description TEXT NOT NULL,
    root_cause TEXT,
    action_plan TEXT NOT NULL,
    responsible_user_id INT NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('open', 'in_progress', 'completed', 'verified', 'closed') DEFAULT 'open',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    cost_estimate DECIMAL(12,2),
    actual_cost DECIMAL(12,2),
    effectiveness_check TEXT,
    completed_at TIMESTAMP NULL,
    verified_by INT NULL,
    verified_at TIMESTAMP NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_survey_capa (survey_id),
    INDEX idx_status_capa (status),
    INDEX idx_due_date (due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

$db->query("ALTER TABLE production_surveys ADD COLUMN capa_required BOOLEAN DEFAULT FALSE, ADD COLUMN capa_count INT DEFAULT 0");

echo "✅ CAPA Integration table created\n";
$db->close();
