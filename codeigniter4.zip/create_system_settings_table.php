<?php
require 'vendor/autoload.php';

$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "CREATE TABLE IF NOT EXISTS system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if (mysqli_query($db, $sql)) {
    echo "Table system_settings created successfully\n";
    
    // Insert default settings
    $defaults = [
        ['system_name', 'EAM System', 'general'],
        ['timezone', 'UTC', 'general'],
        ['date_format', 'YYYY-MM-DD', 'general'],
        ['time_format', '24h', 'general'],
        ['language', 'en', 'general'],
        ['currency', 'USD', 'regional'],
        ['currency_symbol', '$', 'regional'],
        ['decimal_separator', '.', 'regional'],
        ['thousand_separator', ',', 'regional'],
        ['length_unit', 'meters', 'units'],
        ['weight_unit', 'kg', 'units'],
        ['temperature_unit', 'celsius', 'units'],
        ['pressure_unit', 'bar', 'units'],
        ['volume_unit', 'liters', 'units'],
        ['production_unit', 'units', 'production'],
        ['shift_duration', '8', 'production'],
        ['working_days', 'monday,tuesday,wednesday,thursday,friday', 'production'],
        ['pm_lead_time', '7', 'maintenance'],
        ['wo_auto_number', 'true', 'maintenance'],
        ['wo_prefix', 'WO', 'maintenance'],
        ['wo_default_priority', 'medium', 'maintenance'],
        ['email_notifications', 'true', 'notifications'],
        ['sms_notifications', 'false', 'notifications'],
        ['push_notifications', 'true', 'notifications'],
        ['alert_threshold', '80', 'notifications'],
        ['session_timeout', '30', 'security'],
        ['password_expiry', '90', 'security'],
        ['max_login_attempts', '5', 'security'],
        ['two_factor_auth', 'false', 'security'],
        ['auto_backup', 'true', 'backup'],
        ['backup_frequency', 'daily', 'backup'],
        ['backup_retention', '30', 'backup']
    ];
    
    foreach ($defaults as $setting) {
        mysqli_query($db, "INSERT IGNORE INTO system_settings (setting_key, setting_value, category) VALUES ('{$setting[0]}', '{$setting[1]}', '{$setting[2]}')");
    }
    
    echo "Default settings inserted\n";
} else {
    echo "Error: " . mysqli_error($db);
}

mysqli_close($db);
