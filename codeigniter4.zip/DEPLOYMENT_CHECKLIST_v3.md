# ✅ ENTERPRISE MAINTENANCE v3.0 - DEPLOYMENT CHECKLIST

## 🎯 PRE-DEPLOYMENT

### Environment Check
- [ ] PHP 8.2+ installed
- [ ] MySQL 8.0+ running
- [ ] CodeIgniter 4 configured
- [ ] Composer dependencies updated
- [ ] Database backup created

### File Verification
- [ ] ENTERPRISE_MAINTENANCE_UPGRADE.sql exists
- [ ] 10 model files in app/Models/
- [ ] EnterpriseMaintenanceController.php in app/Controllers/Api/V1/
- [ ] Routes.php updated with enterprise routes

---

## 🗄️ DATABASE DEPLOYMENT

### Step 1: Backup Current Database
```bash
cd c:\wamp64\www\factorymanager
mysqldump -u root -p factorymanager > backup_before_v3_upgrade.sql
```
- [ ] Backup completed
- [ ] Backup file verified (check file size > 0)

### Step 2: Run Migration
```bash
mysql -u root -p factorymanager < ENTERPRISE_MAINTENANCE_UPGRADE.sql
```
- [ ] Migration executed without errors
- [ ] Success message displayed

### Step 3: Verify Tables
```sql
USE factorymanager;

-- Check all tables created
SHOW TABLES LIKE 'work_order_%';
SHOW TABLES LIKE 'shutdown_%';
SHOW TABLES LIKE 'predictive_%';
SHOW TABLES LIKE 'pm_meter_%';
SHOW TABLES LIKE 'sla_%';
```
Expected: 11 tables
- [ ] work_order_team_members
- [ ] work_order_assistance_requests
- [ ] work_order_job_plans
- [ ] work_order_resource_reservations
- [ ] work_order_status_history
- [ ] work_order_sla_tracking
- [ ] sla_definitions
- [ ] shutdown_events
- [ ] shutdown_work_orders
- [ ] predictive_maintenance_inspections
- [ ] pm_meter_triggers

### Step 4: Verify Data
```sql
-- Check SLA definitions
SELECT COUNT(*) FROM sla_definitions;
-- Expected: 8

SELECT * FROM sla_definitions;
-- Should show 8 pre-configured SLAs
```
- [ ] 8 SLA definitions present
- [ ] All SLA fields populated correctly

---

## 🔧 BACKEND DEPLOYMENT

### Step 1: Verify Models
```bash
cd c:\wamp64\www\factorymanager\app\Models
dir WorkOrder*.php
dir Shutdown*.php
dir Predictive*.php
dir PmMeter*.php
```
- [ ] WorkOrderTeamMemberModel.php
- [ ] WorkOrderAssistanceRequestModel.php
- [ ] WorkOrderJobPlanModel.php
- [ ] WorkOrderResourceReservationModel.php
- [ ] WorkOrderStatusHistoryModel.php
- [ ] WorkOrderSlaTrackingModel.php
- [ ] PredictiveMaintenanceInspectionModel.php
- [ ] ShutdownEventModel.php
- [ ] ShutdownWorkOrderModel.php
- [ ] PmMeterTriggerModel.php

### Step 2: Verify Controller
```bash
cd c:\wamp64\www\factorymanager\app\Controllers\Api\V1
dir EnterpriseMaintenanceController.php
```
- [ ] EnterpriseMaintenanceController.php exists
- [ ] File size > 10KB

### Step 3: Verify Routes
```bash
cd c:\wamp64\www\factorymanager\app\Config
type Routes.php | findstr "enterprise"
```
- [ ] /api/v1/eam/enterprise route group exists
- [ ] 25+ endpoints registered

### Step 4: Clear Cache
```bash
cd c:\wamp64\www\factorymanager
php spark cache:clear
```
- [ ] Cache cleared successfully

---

## 🧪 API TESTING

### Start Server
```bash
cd c:\wamp64\www\factorymanager
php spark serve
```
- [ ] Server started on port 8080

### Test Endpoints

#### 1. SLA Tracking
```bash
curl http://localhost:8080/api/v1/eam/enterprise/sla-tracking/breached
```
Expected: `{"status":"success","data":[]}`
- [ ] Returns valid JSON
- [ ] No errors

#### 2. Team Management
```bash
curl -X POST http://localhost:8080/api/v1/eam/enterprise/team/assign ^
  -H "Content-Type: application/json" ^
  -d "{\"work_order_id\":1,\"technician_id\":1,\"role\":\"team_lead\",\"assigned_by\":1}"
```
Expected: `{"status":"success","id":1}` or validation error
- [ ] Endpoint responds
- [ ] Returns valid JSON

#### 3. Assistance Requests
```bash
curl http://localhost:8080/api/v1/eam/enterprise/assistance-requests
```
Expected: `{"status":"success","data":[]}`
- [ ] Returns valid JSON
- [ ] No errors

#### 4. Job Planning
```bash
curl http://localhost:8080/api/v1/eam/enterprise/job-plan/work-order/1
```
Expected: `{"status":"success","data":null}` or data
- [ ] Endpoint responds
- [ ] Returns valid JSON

#### 5. Inspections
```bash
curl http://localhost:8080/api/v1/eam/enterprise/inspections
```
Expected: `{"status":"success","data":[]}`
- [ ] Returns valid JSON
- [ ] No errors

#### 6. Shutdown Events
```bash
curl http://localhost:8080/api/v1/eam/enterprise/shutdown-events
```
Expected: `{"status":"success","data":[]}`
- [ ] Returns valid JSON
- [ ] No errors

---

## 🔐 SECURITY CHECK

### Database Security
- [ ] Database user has appropriate permissions
- [ ] No root access in production
- [ ] Connection uses SSL (if production)

### API Security
- [ ] JWT authentication enabled
- [ ] CORS configured correctly
- [ ] Rate limiting configured
- [ ] Input validation working

### File Permissions
```bash
# Check file permissions (Linux/Mac)
ls -la app/Models/WorkOrder*.php
ls -la app/Controllers/Api/V1/EnterpriseMaintenanceController.php
```
- [ ] Files readable by web server
- [ ] Files not writable by web server

---

## 📊 INTEGRATION TESTING

### Test Workflow 1: Team Assignment
```sql
-- 1. Create test work order (if needed)
INSERT INTO maintenance_orders (title, status, priority) 
VALUES ('Test WO', 'open', 'medium');

-- 2. Get work order ID
SELECT id FROM maintenance_orders WHERE title = 'Test WO';

-- 3. Assign team via API (use curl from above)

-- 4. Verify in database
SELECT * FROM work_order_team_members WHERE work_order_id = [ID];
```
- [ ] Team member inserted
- [ ] All fields populated correctly

### Test Workflow 2: SLA Tracking
```bash
# Initialize SLA via API
curl -X POST http://localhost:8080/api/v1/eam/enterprise/sla-tracking/initialize ^
  -H "Content-Type: application/json" ^
  -d "{\"work_order_id\":1,\"priority\":\"urgent\",\"order_type\":\"corrective\"}"
```
```sql
-- Verify in database
SELECT * FROM work_order_sla_tracking WHERE work_order_id = 1;
```
- [ ] SLA tracking record created
- [ ] Target times calculated correctly
- [ ] SLA definition linked

### Test Workflow 3: Assistance Request
```bash
# Create assistance request
curl -X POST http://localhost:8080/api/v1/eam/enterprise/assistance-requests ^
  -H "Content-Type: application/json" ^
  -d "{\"work_order_id\":1,\"requested_by\":1,\"reason\":\"Test\",\"urgency\":\"medium\"}"
```
```sql
-- Verify in database
SELECT * FROM work_order_assistance_requests WHERE work_order_id = 1;
```
- [ ] Request created
- [ ] Status is 'pending'
- [ ] Timestamps set correctly

---

## 📈 PERFORMANCE CHECK

### Database Performance
```sql
-- Check indexes
SHOW INDEX FROM work_order_team_members;
SHOW INDEX FROM work_order_sla_tracking;
SHOW INDEX FROM predictive_maintenance_inspections;
```
- [ ] All indexes created
- [ ] No missing indexes

### Query Performance
```sql
-- Test query speed
EXPLAIN SELECT * FROM work_order_team_members WHERE work_order_id = 1;
EXPLAIN SELECT * FROM work_order_sla_tracking WHERE response_breached = 1;
```
- [ ] Queries use indexes
- [ ] No full table scans

### API Response Time
```bash
# Test response time
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:8080/api/v1/eam/enterprise/sla-tracking/breached
```
- [ ] Response time < 200ms
- [ ] No timeout errors

---

## 📝 DOCUMENTATION CHECK

### Files Present
- [ ] ENTERPRISE_MAINTENANCE_UPGRADE.sql
- [ ] IMPLEMENTATION_GUIDE_v3.md
- [ ] QUICK_REFERENCE_v3.md
- [ ] ENTERPRISE_UPGRADE_COMPLETE.md
- [ ] THIS FILE (DEPLOYMENT_CHECKLIST.md)

### Documentation Accuracy
- [ ] API endpoints match implementation
- [ ] Examples work as documented
- [ ] SQL queries return expected results

---

## 👥 USER ACCEPTANCE TESTING

### Test Users
- [ ] Create test technician user
- [ ] Create test supervisor user
- [ ] Create test planner user

### Test Scenarios

#### Scenario 1: Planner Creates Work Order with Team
- [ ] Planner logs in
- [ ] Creates work order
- [ ] Creates job plan
- [ ] Assigns team lead
- [ ] Assigns assistants
- [ ] Verifies team appears in work order

#### Scenario 2: Technician Requests Assistance
- [ ] Technician logs in
- [ ] Views assigned work order
- [ ] Submits assistance request
- [ ] Supervisor receives notification
- [ ] Supervisor approves request
- [ ] Additional technician added to team

#### Scenario 3: SLA Monitoring
- [ ] Create urgent work order
- [ ] SLA tracking initialized
- [ ] View SLA status
- [ ] Simulate breach
- [ ] Verify escalation

---

## 🚀 PRODUCTION DEPLOYMENT

### Pre-Production
- [ ] All tests passed
- [ ] UAT completed
- [ ] Documentation reviewed
- [ ] Rollback plan prepared

### Production Deployment
- [ ] Maintenance window scheduled
- [ ] Users notified
- [ ] Database backup created
- [ ] Run migration script
- [ ] Verify tables created
- [ ] Clear production cache
- [ ] Test critical endpoints
- [ ] Monitor error logs

### Post-Deployment
- [ ] Verify all endpoints working
- [ ] Check database connections
- [ ] Monitor performance
- [ ] Review error logs
- [ ] Collect user feedback

---

## 🔍 MONITORING SETUP

### Database Monitoring
```sql
-- Create monitoring view
CREATE OR REPLACE VIEW v_enterprise_health AS
SELECT 
    'Team Members' as metric,
    COUNT(*) as count
FROM work_order_team_members
UNION ALL
SELECT 
    'Assistance Requests',
    COUNT(*)
FROM work_order_assistance_requests
UNION ALL
SELECT 
    'SLA Tracking',
    COUNT(*)
FROM work_order_sla_tracking
UNION ALL
SELECT 
    'Inspections',
    COUNT(*)
FROM predictive_maintenance_inspections;
```
- [ ] Monitoring view created
- [ ] Query returns data

### Application Monitoring
- [ ] Error logging enabled
- [ ] Performance monitoring configured
- [ ] Alert thresholds set

---

## ✅ FINAL SIGN-OFF

### Technical Lead
- [ ] All tests passed
- [ ] Code reviewed
- [ ] Documentation complete
- [ ] Signed off by: _________________ Date: _______

### Project Manager
- [ ] UAT completed
- [ ] Stakeholders informed
- [ ] Training scheduled
- [ ] Signed off by: _________________ Date: _______

### System Administrator
- [ ] Production deployed
- [ ] Monitoring active
- [ ] Backup verified
- [ ] Signed off by: _________________ Date: _______

---

## 🎉 DEPLOYMENT COMPLETE

**System Status**: ✅ PRODUCTION READY  
**Version**: 3.0.0  
**Grade**: A++ Enterprise  
**Deployment Date**: _________________

**Congratulations! Your enterprise maintenance module is now live!** 🚀

---

## 📞 POST-DEPLOYMENT SUPPORT

### Issue Tracking
- Monitor error logs: `app/Logs/`
- Check database logs
- Review user feedback

### Performance Monitoring
- API response times
- Database query performance
- User activity metrics

### Continuous Improvement
- Collect user feedback
- Identify optimization opportunities
- Plan next iteration

---

**For support, refer to IMPLEMENTATION_GUIDE_v3.md**
