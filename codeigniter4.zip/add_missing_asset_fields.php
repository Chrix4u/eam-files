<?php
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "🔧 ADDING MISSING ASSET FIELDS\n\n";
    
    // Add missing fields to machines table
    $machineFields = [
        "ADD COLUMN `machine_photo` VARCHAR(500) AFTER `oem_docs`",
        "ADD COLUMN `location` VARCHAR(255) AFTER `machine_photo`"
    ];
    
    foreach ($machineFields as $field) {
        try {
            $pdo->exec("ALTER TABLE machines $field");
            echo "✅ Added field to machines: $field\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                echo "⚠️ Field already exists in machines: $field\n";
            } else {
                echo "❌ Error adding field to machines: " . $e->getMessage() . "\n";
            }
        }
    }
    
    // Add missing fields to assemblies table
    $assemblyFields = [
        "ADD COLUMN `assembly_image` VARCHAR(500) AFTER `status`"
    ];
    
    foreach ($assemblyFields as $field) {
        try {
            $pdo->exec("ALTER TABLE assemblies $field");
            echo "✅ Added field to assemblies: $field\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                echo "⚠️ Field already exists in assemblies: $field\n";
            } else {
                echo "❌ Error adding field to assemblies: " . $e->getMessage() . "\n";
            }
        }
    }
    
    // Add missing fields to parts table
    $partFields = [
        "ADD COLUMN `part_image` VARCHAR(500) AFTER `status`",
        "ADD COLUMN `part_code` VARCHAR(50) AFTER `part_number`"
    ];
    
    foreach ($partFields as $field) {
        try {
            $pdo->exec("ALTER TABLE parts $field");
            echo "✅ Added field to parts: $field\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
                echo "⚠️ Field already exists in parts: $field\n";
            } else {
                echo "❌ Error adding field to parts: " . $e->getMessage() . "\n";
            }
        }
    }
    
    echo "\n✅ Database field updates completed!\n";
    
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    exit(1);
}