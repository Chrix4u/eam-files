# Module Access Flow Implementation

## Overview
Two-step module access control:
1. **ModuleLicenseFilter** - System/Vendor admin activates license (`is_active=1`)
2. **ModuleAccessFilter** - Company admin enables module (`is_enabled=1`)

## Database Schema

```sql
company_modules:
  - is_active (TINYINT)   → License activated by system/vendor admin
  - is_enabled (TINYINT)  → Module enabled by company admin
```

## Access Flow

```
User Request
    ↓
JWT Authentication (jwt filter)
    ↓
License Check (modulelicense filter)
    → Checks: is_active = 1
    → Error: "Module not licensed. Contact system administrator."
    ↓
Enablement Check (moduleaccess:MODULE filter)
    → Checks: is_enabled = 1
    → Error: "Module not enabled. Contact your company administrator."
    ↓
Access Granted
```

## Standard Route Pattern

```php
$routes->group('api/v1/eam', ['filter' => 'jwt|modulelicense|moduleaccess:MODULE'], function($routes) {
    // Module routes
});
```

## Filter Details

### ModuleLicenseFilter (Step 1)
- **Purpose**: Check if system/vendor admin activated license
- **Checks**: `is_active = 1` in `company_modules`
- **Auto-detects**: Module from URI using `moduleRouteMap`
- **Error**: 403 "Module not licensed"

### ModuleAccessFilter (Step 2)
- **Purpose**: Check if company admin enabled module
- **Checks**: `is_enabled = 1` in `company_modules`
- **Requires**: Module code as argument (e.g., `moduleaccess:IMS`)
- **Error**: 403 "Module not enabled"

## Module Codes
- CORE (always active/enabled)
- ASSET, RWOP, MRMP, IMS, MPMP, HRMS, TRAC
- IOT, DIGITAL_TWIN, MOBILE, REPORTS

## Admin Workflows

### System/Vendor Admin (Activate License)
```sql
UPDATE company_modules 
SET is_active = 1, 
    activated_at = NOW(), 
    activated_by = :admin_id
WHERE company_id = :company_id 
  AND module_code = :module;
```

### Company Admin (Enable Module)
```sql
UPDATE company_modules 
SET is_enabled = 1, 
    enabled_at = NOW(), 
    enabled_by = :admin_id
WHERE company_id = :company_id 
  AND module_code = :module
  AND is_active = 1; -- Must be licensed first
```

## Error Messages

| Filter | Condition | Message |
|--------|-----------|---------|
| modulelicense | `is_active = 0` | Module not licensed. Contact system administrator. |
| modulelicense | License expired | Module license expired. Contact system administrator. |
| moduleaccess | `is_enabled = 0` | Module not enabled. Contact your company administrator. |

## Implementation Status

✅ ModuleLicenseFilter - Updated to check `is_active`
✅ ModuleAccessFilter - Updated to check `is_enabled`
✅ Database schema - `company_modules` table
✅ IMS_NEW.php - Standard filter pattern applied
⏳ All other module routes - Need standardization
