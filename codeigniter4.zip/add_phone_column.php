<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');
if (!$db) die('Connection failed: ' . mysqli_connect_error());

// Add residential_address column
$sql = "ALTER TABLE users ADD COLUMN residential_address VARCHAR(255) AFTER phone";
if (mysqli_query($db, $sql)) {
    echo "✅ Added residential_address column to users table\n";
} else {
    echo "❌ Error: " . mysqli_error($db) . "\n";
}

mysqli_close($db);
