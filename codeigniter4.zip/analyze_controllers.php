<?php
// Script to identify controllers that need RBAC updates
$controllers = [
    // ASSET module
    'C:\wamp64\www\factorymanager\app\Controllers\Api\V1\Modules\ASSET\AssetsUnifiedController.php',

    // IMS module
    'C:\wamp64\www\factorymanager\app\Controllers\Api\V1\Modules\IMS\EamInventoryController.php',
    'C:\wamp64\www\factorymanager\app\Controllers\Api\V1\Modules\IMS\PartsController.php',
    'C:\wamp64\www\factorymanager\app\Controllers\Api\V1\Modules\IMS\VendorsController.php',

    // RWOP module
    'C:\wamp64\www\factorymanager\app\Controllers\Api\V1\Modules\RWOP\WorkOrderController.php',

    // HRMS module
    'C:\wamp64\www\factorymanager\app\Controllers\Api\V1\Modules\HRMS\UsersController.php',
];

echo "=== CONTROLLER RBAC ANALYSIS ===\n\n";

foreach ($controllers as $controllerPath) {
    $filename = basename($controllerPath);
    echo "Controller: $filename\n";

    if (!file_exists($controllerPath)) {
        echo "  ❌ File not found\n\n";
        continue;
    }

    $content = file_get_contents($controllerPath);

    // Check if extends BaseApiController
    $extendsBaseApi = strpos($content, 'extends BaseApiController') !== false;
    echo "  • Extends BaseApiController: " . ($extendsBaseApi ? '✅' : '❌') . "\n";

    // Check for permission checks
    $hasPermissionCheck = strpos($content, 'checkPermission(') !== false ||
                          strpos($content, 'requirePermission(') !== false;
    echo "  • Has permission checks: " . ($hasPermissionCheck ? '✅' : '❌') . "\n";

    // Check for plant scoping
    $hasPlantScope = strpos($content, 'getPlantIds()') !== false ||
                     strpos($content, 'applyPlantFilter(') !== false ||
                     strpos($content, 'plant_id') !== false;
    echo "  • Has plant scoping: " . ($hasPlantScope ? '✅' : '❌') . "\n";

    // Determine status
    if ($extendsBaseApi && $hasPermissionCheck && $hasPlantScope) {
        echo "  📊 Status: ✅ COMPLETE\n";
    } elseif ($extendsBaseApi && $hasPermissionCheck) {
        echo "  📊 Status: ⚠️  NEEDS PLANT SCOPING\n";
    } elseif ($extendsBaseApi) {
        echo "  📊 Status: 🔄 NEEDS PERMISSION CHECKS\n";
    } else {
        echo "  📊 Status: 🚨 NEEDS FULL UPDATE\n";
    }

    echo "\n";
}

echo "=== SUMMARY ===\n";
echo "Controllers needing updates will be marked with 🚨 or 🔄\n";
echo "Priority: RWOP (Work Orders), IMS (Inventory), HRMS (Users)\n";
?>
