CREATE TABLE IF NOT EXISTS company_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    address TEXT,
    phone VARCHAR(50),
    email VARCHAR(100),
    website VARCHAR(255),
    logo VARCHAR(255),
    created_at DATETIME,
    updated_at DATETIME
);

INSERT INTO company_settings (company_name, created_at) VALUES ('GTP', NOW());
