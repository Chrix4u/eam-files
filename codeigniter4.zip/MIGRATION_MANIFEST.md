# EAM Database Migration Manifest

## Existing Migrations (Already Created)

### Core Tables
- ✅ `2025-11-14-100000_CreateUsersTable.php` - Users with role_id, dept_id, status
- ✅ `2025-11-14-000020_CreateEamRbac.php` - Roles, permissions, role_permissions, user_permissions

### Asset Hierarchy
- ✅ `2025-11-14-000001_CreateEamFacilities.php` - Facilities
- ✅ `2025-11-14-000002_CreateEamSystems.php` - Systems (facility_id FK)
- ✅ `2025-11-14-000003_CreateEamEquipment.php` - Equipment (system_id FK, parent_equipment_id)
- ✅ `2025-11-14-000004_CreateEamAssemblies.php` - Assemblies (equipment_id FK)
- ✅ `2025-11-14-000005_CreateEamComponents.php` - Components (assembly_id FK)
- ✅ `2025-11-14-000006_CreateEamParts.php` - Parts (component_id FK, sku, uom, lead_time, min_stock)
- ✅ `2025-11-14-000007_CreateEamSubParts.php` - Sub-parts (part_id FK)

### Meters & Readings
- ✅ `2025-11-14-000009_CreateEamMeters.php` - Meters (asset_id, meter_type, value, last_reading_at)
- ✅ `2025-11-14-000010_CreateEamMeterReadings.php` - Meter readings (meter_id FK, reading, recorded_by, recorded_at)

### PM System
- ✅ `2025-11-14-000011_CreateEamPmRules.php` - PM rules (asset_type, asset_id, interval_days, interval_usage, threshold, priority, active)
- ✅ `2025-11-14-000012_CreateEamPmSchedules.php` - PM schedules (pm_rule_id FK, next_due_date, next_due_usage, status)
- ✅ `2025-11-14-200000_AddPmScheduleFields.php` - Additional PM schedule fields
- ✅ `2025-11-14-200001_AddPmRuleFields.php` - Additional PM rule fields

### Work Orders
- ✅ `2025-11-14-000013_CreateEamWorkOrders.php` - Work orders (pm_schedule_id FK, title, description, created_by, assigned_to, planned_start/end, actual_start/end, status, priority)
- ✅ `2025-11-14-000014_CreateEamWorkOrderTasks.php` - Work order tasks (work_order_id FK, description, checklist JSON, expected_hours, actual_hours, status)
- ✅ `2025-11-14-000016_CreateEamWorkOrderMaterials.php` - Work order materials (work_order_id FK, part_id FK, qty_required, qty_issued)

### Inventory
- ✅ `2025-11-14-000015_CreateEamInventoryItems.php` - Inventory items (part_id FK, sku, location_id, qty_on_hand, qty_reserved)
- ✅ `2025-11-14-000017_CreateEamStockTransactions.php` - Stock transactions (inventory_item_id FK, type IN/OUT/RESERVE/RELEASE, qty, ref_type, ref_id, created_by, created_at)

### Additional
- ✅ `2025-11-14-000018_CreateEamVendors.php` - Vendors
- ✅ `2025-11-14-000019_CreateEamPurchaseOrders.php` - Purchase orders
- ✅ `2025-11-14-000021_CreateEamAuditLogs.php` - Audit logs

---

## New Migrations (Just Created)

### Missing Tables
- ✅ `2024-01-01-000002_CreateDepartmentsTable.php` - Departments (id, name, manager_user_id)
- ✅ `2024-01-01-000100_CreateBillOfMaterialsTable.php` - Bill of materials (bom_id, parent_part_id FK, child_part_id FK, qty)
- ✅ `2024-01-01-000101_CreateProductionRunsTable.php` - Production runs (id, batch_no, product_id, asset_id FK, start_time, end_time, produced_qty)
- ✅ `2024-01-01-000102_CreateProductionSurveysTable.php` - Production surveys (id, run_id FK, inspector_id, notes, created_at)
- ✅ `2024-01-01-000103_CreateShiftsTable.php` - Shifts (id, name, dept_id FK, start_time, end_time, created_by)
- ✅ `2024-01-01-000104_CreateEmployeeShiftsTable.php` - Employee shifts (id, user_id FK, shift_id FK, start_date, end_date, assigned_by)

---

## Table Descriptions

### Users & Access Control
| Table | Description | Key Columns |
|-------|-------------|-------------|
| users | System users | id, name, email, password_hash, role_id, dept_id, status |
| roles | User roles | id, name, description |
| permissions | System permissions | id, name, resource, action |
| role_permissions | Role-permission mapping | role_id, permission_id |
| user_permissions | User-specific permissions | user_id, permission_id |
| departments | Organizational departments | id, name, manager_user_id |

### Asset Hierarchy (7 levels)
| Table | Description | Parent FK |
|-------|-------------|-----------|
| eam_facilities | Top-level facilities | - |
| eam_systems | Systems within facilities | facility_id |
| eam_equipment | Equipment/machines | system_id, parent_equipment_id |
| eam_assemblies | Equipment assemblies | equipment_id |
| eam_components | Assembly components | assembly_id |
| eam_parts | Spare parts | component_id |
| eam_sub_parts | Part sub-components | part_id |
| bill_of_materials | Part relationships | parent_part_id, child_part_id |

### Meters & Monitoring
| Table | Description | Key Columns |
|-------|-------------|-------------|
| eam_meters | Asset meters | id, asset_id, meter_type (hours/cycles/meters), value, last_reading_at |
| eam_meter_readings | Meter reading history | id, meter_id, reading, recorded_by, recorded_at |

### Preventive Maintenance
| Table | Description | Key Columns |
|-------|-------------|-------------|
| eam_pm_rules | PM task definitions | id, asset_type, asset_id, interval_days, interval_usage, usage_meter_id, threshold, priority, active |
| eam_pm_schedules | PM schedule instances | id, pm_rule_id, next_due_date, next_due_usage, status |

### Work Orders
| Table | Description | Key Columns |
|-------|-------------|-------------|
| eam_work_orders | Work orders | id, pm_schedule_id, title, description, created_by, assigned_to, planned_start/end, actual_start/end, status, priority |
| eam_work_order_tasks | WO task checklist | id, work_order_id, description, checklist (JSON), expected_hours, actual_hours, status |
| eam_work_order_materials | WO parts usage | id, work_order_id, part_id, qty_required, qty_issued |

### Inventory
| Table | Description | Key Columns |
|-------|-------------|-------------|
| eam_inventory_items | Stock items | id, part_id, sku, location_id, qty_on_hand, qty_reserved |
| eam_stock_transactions | Stock movements | id, inventory_item_id, type (IN/OUT/RESERVE/RELEASE), qty, ref_type, ref_id, created_by, created_at |

### Production
| Table | Description | Key Columns |
|-------|-------------|-------------|
| production_runs | Production batches | id, batch_no, product_id, asset_id, start_time, end_time, produced_qty |
| production_surveys | Quality inspections | id, run_id, inspector_id, notes, created_at |

### Workforce
| Table | Description | Key Columns |
|-------|-------------|-------------|
| shifts | Work shifts | id, name, dept_id, start_time, end_time, created_by |
| employee_shifts | Employee shift assignments | id, user_id, shift_id, start_date, end_date, assigned_by |

---

## Foreign Key Cascade Rules

### CASCADE DELETE
- eam_systems → eam_facilities
- eam_equipment → eam_systems
- eam_assemblies → eam_equipment
- eam_components → eam_assemblies
- eam_parts → eam_components
- eam_sub_parts → eam_parts
- bill_of_materials → eam_parts (both parent and child)
- eam_meter_readings → eam_meters
- eam_pm_schedules → eam_pm_rules
- eam_work_order_tasks → eam_work_orders
- eam_work_order_materials → eam_work_orders
- eam_stock_transactions → eam_inventory_items
- production_surveys → production_runs
- employee_shifts → users, shifts

### SET NULL
- departments.manager_user_id → users
- eam_equipment.parent_equipment_id → eam_equipment
- eam_work_orders.pm_schedule_id → eam_pm_schedules

---

## Indexes

### Primary Keys
All tables have auto-increment `id` or `bom_id` primary key

### Unique Indexes
- users.email
- roles.name
- eam_facilities.facility_code
- eam_systems.system_code
- eam_equipment.equipment_code
- production_runs.batch_no

### Foreign Key Indexes
Auto-created on all FK columns for performance

### Search Indexes
- eam_equipment (status, manufacturer, model)
- eam_work_orders (status, priority, assigned_to)
- eam_inventory_items (sku, location_id)
- eam_stock_transactions (type, created_at)

---

## Running Migrations

```bash
# Run all migrations
php spark migrate

# Run specific namespace
php spark migrate -n App\\Database\\Migrations\\EAM

# Rollback
php spark migrate:rollback

# Refresh (rollback all + migrate)
php spark migrate:refresh

# Check status
php spark migrate:status
```

---

## Running Seeds

```bash
# Run all seeders
php spark db:seed EamSeeder

# Or via migration
php spark migrate --all
```

---

## Sample SQL (Direct Insert)

```sql
-- Roles
INSERT INTO roles (name, description) VALUES
('admin', 'System Administrator'),
('manager', 'Facility Manager'),
('supervisor', 'Maintenance Supervisor'),
('planner', 'Maintenance Planner'),
('technician', 'Maintenance Technician');

-- Departments
INSERT INTO departments (name, manager_user_id) VALUES
('Maintenance', NULL),
('Production', NULL),
('Quality', NULL),
('Engineering', NULL),
('Warehouse', NULL);

-- Facilities
INSERT INTO eam_facilities (facility_code, facility_name, location, status) VALUES
('FAC-001', 'Main Plant', 'Building A', 'active'),
('FAC-002', 'Assembly Line', 'Building B', 'active'),
('FAC-003', 'Warehouse', 'Building C', 'active'),
('FAC-004', 'Quality Lab', 'Building D', 'active'),
('FAC-005', 'Maintenance Shop', 'Building E', 'active');

-- Systems
INSERT INTO eam_systems (facility_id, system_code, system_name, description) VALUES
(1, 'SYS-001', 'HVAC System', 'Heating and cooling'),
(1, 'SYS-002', 'Electrical System', 'Power distribution'),
(2, 'SYS-003', 'Conveyor System', 'Material handling'),
(2, 'SYS-004', 'Robotic System', 'Automated assembly'),
(3, 'SYS-005', 'Storage System', 'Racking and shelving');

-- Equipment
INSERT INTO eam_equipment (system_id, equipment_code, equipment_name, manufacturer, model, status) VALUES
(1, 'EQ-001', 'Chiller Unit 1', 'Carrier', 'CH-500', 'operational'),
(2, 'EQ-002', 'Transformer 1', 'ABB', 'TF-1000', 'operational'),
(3, 'EQ-003', 'Conveyor Belt 1', 'Siemens', 'CB-200', 'operational'),
(4, 'EQ-004', 'Robot Arm 1', 'Fanuc', 'R-2000', 'operational'),
(5, 'EQ-005', 'Forklift 1', 'Toyota', 'FL-3000', 'operational');
```

---

## ✅ Status

**Total Tables**: 25+
**Existing**: 21 tables
**New**: 6 tables
**Seed Data**: 5 rows per core table

All migrations ready to run!
