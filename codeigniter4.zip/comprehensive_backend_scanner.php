<?php
/**
 * Comprehensive Backend Code Scanner
 * Scans Controllers, Models, Services, Repositories for table and column usage
 */

$baseDir = __DIR__;
$results = [
    'tables_used' => [],
    'columns_used' => [],
    'company_id_references' => [],
    'plant_id_references' => [],
    'files_scanned' => 0
];

// Directories to scan
$scanDirs = [
    'app/Controllers',
    'app/Models',
    'app/Services',
    'app/Repositories'
];

function scanFile($filePath, &$results) {
    $content = file_get_contents($filePath);
    $results['files_scanned']++;
    
    // Find table() calls
    if (preg_match_all('/->table\([\'"]([a-z_]+)[\'"]\)/', $content, $matches)) {
        foreach ($matches[1] as $table) {
            if (!isset($results['tables_used'][$table])) {
                $results['tables_used'][$table] = [];
            }
            $results['tables_used'][$table][] = basename($filePath);
        }
    }
    
    // Find from() calls
    if (preg_match_all('/->from\([\'"]([a-z_]+)[\'"]\)/', $content, $matches)) {
        foreach ($matches[1] as $table) {
            if (!isset($results['tables_used'][$table])) {
                $results['tables_used'][$table] = [];
            }
            $results['tables_used'][$table][] = basename($filePath);
        }
    }
    
    // Find company_id references
    if (preg_match_all('/(company_id|companyId|company-id)/i', $content, $matches)) {
        $count = count($matches[0]);
        $results['company_id_references'][basename($filePath)] = $count;
    }
    
    // Find plant_id references
    if (preg_match_all('/(plant_id|plantId|plant-id)/i', $content, $matches)) {
        $count = count($matches[0]);
        $results['plant_id_references'][basename($filePath)] = $count;
    }
    
    // Find column references in where/select clauses
    if (preg_match_all('/->where\([\'"]([a-z_]+)[\'"]/', $content, $matches)) {
        foreach ($matches[1] as $column) {
            if (!isset($results['columns_used'][$column])) {
                $results['columns_used'][$column] = 0;
            }
            $results['columns_used'][$column]++;
        }
    }
    
    if (preg_match_all('/->select\([\'"]([a-z_,\s]+)[\'"]/', $content, $matches)) {
        foreach ($matches[1] as $selectStr) {
            $columns = array_map('trim', explode(',', $selectStr));
            foreach ($columns as $column) {
                if (!isset($results['columns_used'][$column])) {
                    $results['columns_used'][$column] = 0;
                }
                $results['columns_used'][$column]++;
            }
        }
    }
}

function scanDirectory($dir, &$results) {
    if (!is_dir($dir)) {
        return;
    }
    
    $files = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir),
        RecursiveIteratorIterator::SELF_FIRST
    );
    
    foreach ($files as $file) {
        if ($file->isFile() && $file->getExtension() === 'php') {
            scanFile($file->getPathname(), $results);
        }
    }
}

echo "=== COMPREHENSIVE BACKEND CODE SCANNER ===\n\n";
echo "Scanning directories...\n";

foreach ($scanDirs as $dir) {
    $fullPath = $baseDir . '/' . $dir;
    echo "Scanning: $fullPath\n";
    scanDirectory($fullPath, $results);
}

echo "\n=== SCAN RESULTS ===\n";
echo "Files scanned: {$results['files_scanned']}\n";
echo "Unique tables found: " . count($results['tables_used']) . "\n";
echo "Unique columns found: " . count($results['columns_used']) . "\n\n";

// Tables used in code
echo "=== TABLES USED IN CODE ===\n";
ksort($results['tables_used']);
foreach ($results['tables_used'] as $table => $files) {
    $uniqueFiles = array_unique($files);
    echo "$table (" . count($uniqueFiles) . " files)\n";
}

echo "\n=== FILES WITH COMPANY_ID REFERENCES ===\n";
arsort($results['company_id_references']);
foreach ($results['company_id_references'] as $file => $count) {
    echo "$file: $count occurrences\n";
}

echo "\n=== FILES WITH PLANT_ID REFERENCES ===\n";
arsort($results['plant_id_references']);
foreach ($results['plant_id_references'] as $file => $count) {
    echo "$file: $count occurrences\n";
}

echo "\n=== TOP 20 MOST USED COLUMNS ===\n";
arsort($results['columns_used']);
$top20 = array_slice($results['columns_used'], 0, 20, true);
foreach ($top20 as $column => $count) {
    echo "$column: $count times\n";
}

// Save detailed results
file_put_contents('backend_code_analysis.json', json_encode($results, JSON_PRETTY_PRINT));
echo "\n\nDetailed results saved to backend_code_analysis.json\n";

// Now compare with database tables
echo "\n=== LOADING DATABASE AUDIT ===\n";
if (file_exists('database_audit.json')) {
    $dbAudit = json_decode(file_get_contents('database_audit.json'), true);
    $dbTables = array_keys($dbAudit);
    $codeTables = array_keys($results['tables_used']);
    
    $unusedTables = array_diff($dbTables, $codeTables);
    $missingTables = array_diff($codeTables, $dbTables);
    
    echo "\n=== UNUSED TABLES (In DB but not in code) ===\n";
    echo "Count: " . count($unusedTables) . "\n";
    foreach ($unusedTables as $table) {
        echo "  - $table\n";
    }
    
    echo "\n=== MISSING TABLES (In code but not in DB) ===\n";
    echo "Count: " . count($missingTables) . "\n";
    foreach ($missingTables as $table) {
        echo "  - $table\n";
    }
    
    // Check for company_id in database
    echo "\n=== TABLES WITH COMPANY_ID IN DATABASE ===\n";
    foreach ($dbAudit as $table => $data) {
        foreach ($data['columns'] as $col) {
            if (stripos($col['Field'], 'company') !== false) {
                echo "$table -> {$col['Field']}\n";
            }
        }
    }
    
    // Save comparison
    $comparison = [
        'unused_tables' => array_values($unusedTables),
        'missing_tables' => array_values($missingTables),
        'tables_in_both' => array_values(array_intersect($dbTables, $codeTables))
    ];
    file_put_contents('table_comparison.json', json_encode($comparison, JSON_PRETTY_PRINT));
    echo "\nComparison saved to table_comparison.json\n";
}

echo "\n=== SCAN COMPLETE ===\n";
