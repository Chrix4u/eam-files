<?php
// Database Schema Discovery Script
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get all tables
    $stmt = $pdo->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "=== ALL TABLES ===\n";
    foreach ($tables as $table) {
        echo "$table\n";
    }
    
    echo "\n=== HIERARCHY-RELATED TABLES ===\n";
    $hierarchyKeywords = ['facility', 'plant', 'site', 'location', 'machine', 'asset', 'area', 'line', 'department'];
    
    foreach ($tables as $table) {
        foreach ($hierarchyKeywords as $keyword) {
            if (stripos($table, $keyword) !== false) {
                echo "\n--- $table ---\n";
                $stmt = $pdo->query("DESCRIBE $table");
                $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
                foreach ($columns as $col) {
                    echo "  {$col['Field']} ({$col['Type']}) {$col['Null']} {$col['Key']}\n";
                }
                break;
            }
        }
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
