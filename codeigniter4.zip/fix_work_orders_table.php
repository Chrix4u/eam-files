<?php

// Add updated_at column to work_orders table if missing
$host = 'localhost';
$database = 'factory_manager';
$username = 'root';
$password = 'myjesus4mE';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "🔧 Checking work_orders table for updated_at column...\n";
    
    $stmt = $pdo->query("SHOW COLUMNS FROM work_orders LIKE 'updated_at'");
    if ($stmt->rowCount() == 0) {
        echo "❌ updated_at column missing, adding it...\n";
        $pdo->exec("ALTER TABLE work_orders ADD COLUMN updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
        echo "✅ updated_at column added\n";
    } else {
        echo "✅ updated_at column already exists\n";
    }
    
} catch (PDOException $e) {
    echo "❌ Database Error: " . $e->getMessage() . "\n";
}