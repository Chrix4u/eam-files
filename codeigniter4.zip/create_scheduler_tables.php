<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS work_order_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT NOT NULL,
    technician_id INT NOT NULL,
    scheduled_start DATETIME NOT NULL,
    scheduled_end DATETIME NOT NULL,
    estimated_hours DECIMAL(5,2) NOT NULL,
    actual_hours DECIMAL(5,2) NULL,
    status ENUM('scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_technician (technician_id),
    INDEX idx_work_order (work_order_id),
    INDEX idx_scheduled_start (scheduled_start)
)";

if ($db->query($sql)) {
    echo "✓ Table 'work_order_schedules' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$sql2 = "CREATE TABLE IF NOT EXISTS resource_availability (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    date DATE NOT NULL,
    available_hours DECIMAL(5,2) DEFAULT 8.0,
    scheduled_hours DECIMAL(5,2) DEFAULT 0,
    is_available BOOLEAN DEFAULT TRUE,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user_date (user_id, date)
)";

if ($db->query($sql2)) {
    echo "✓ Table 'resource_availability' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$db->close();
?>
