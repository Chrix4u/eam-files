<?php
// Simple debug script to test CodeIgniter
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "CodeIgniter Debug Test\n";
echo "======================\n\n";

// Check if CodeIgniter can be loaded
try {
    require_once 'vendor/autoload.php';
    echo "✅ Composer autoload successful\n";
    
    // Try to load CodeIgniter
    $pathsPath = realpath(FCPATH . '../app/Config/Paths.php');
    if ($pathsPath) {
        require $pathsPath;
        echo "✅ Paths config loaded\n";
    } else {
        echo "❌ Paths config not found\n";
    }
    
    // Check database connection
    if (class_exists('Config\\Database')) {
        $db = \Config\Database::connect();
        if ($db->connID) {
            echo "✅ Database connected\n";
        } else {
            echo "❌ Database connection failed\n";
        }
    } else {
        echo "❌ Database config class not found\n";
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
    echo "File: " . $e->getFile() . ":" . $e->getLine() . "\n";
}

echo "\n📁 Directory structure:\n";
echo "- Current dir: " . getcwd() . "\n";
echo "- App dir exists: " . (is_dir('app') ? 'Yes' : 'No') . "\n";
echo "- Vendor dir exists: " . (is_dir('vendor') ? 'Yes' : 'No') . "\n";
echo "- Public dir exists: " . (is_dir('public') ? 'Yes' : 'No') . "\n";

// Check .env file
if (file_exists('.env')) {
    echo "✅ .env file exists\n";
} else {
    echo "❌ .env file missing\n";
}
?>