@echo off
C:\wamp64\bin\mysql\mysql8.2.13\bin\mysql.exe -u root -pmyjesus4mE factory_manager < database\seeds\AddMeterFieldsToPmTasks.sql
echo Meter fields added successfully!
pause
