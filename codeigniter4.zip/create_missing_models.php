<?php
// Create all missing models with proper structure

$modelsToCreate = [
    'Facilities' => [
        'table' => 'facilities',
        'primaryKey' => 'id',
        'allowedFields' => ['facility_code', 'facility_name', 'facility_type', 'address_line1', 'city', 'country_code', 'status']
    ],
    'Departments' => [
        'table' => 'departments',
        'primaryKey' => 'id',
        'allowedFields' => ['department_code', 'department_name', 'facility_id', 'status']
    ],
    'WorkOrderAssignments' => [
        'table' => 'work_order_assignments',
        'primaryKey' => 'id',
        'allowedFields' => ['work_order_id', 'assigned_to_user_id', 'assigned_date', 'estimated_hours', 'actual_hours', 'assignment_status']
    ],
    'Documents' => [
        'table' => 'documents',
        'primaryKey' => 'id',
        'allowedFields' => ['document_number', 'title', 'category', 'version', 'status', 'file_name', 'file_path', 'file_size', 'file_type', 'asset_id', 'uploaded_by', 'approved_by', 'language_code', 'keywords']
    ],
    'ProductionSchedules' => [
        'table' => 'production_schedules',
        'primaryKey' => 'id',
        'allowedFields' => ['schedule_code', 'schedule_name', 'planned_start_date', 'planned_end_date', 'status']
    ],
    'Shifts' => [
        'table' => 'shifts',
        'primaryKey' => 'id',
        'allowedFields' => ['shift_code', 'name', 'dept_id', 'start_time', 'end_time', 'facility_id', 'is_active', 'created_by']
    ],
    'ShiftHandovers' => [
        'table' => 'shift_handovers',
        'primaryKey' => 'id',
        'allowedFields' => ['handover_number', 'survey_id', 'handover_notes', 'issues_reported', 'pending_tasks', 'machine_condition', 'special_instructions', 'next_shift_actions', 'acknowledged_by', 'status']
    ],
    'QualityInspections' => [
        'table' => 'quality_inspections',
        'primaryKey' => 'id',
        'allowedFields' => ['inspection_number', 'inspection_type', 'inspection_date', 'result', 'status']
    ],
    'EnergyConsumption' => [
        'table' => 'energy_consumption',
        'primaryKey' => 'id',
        'allowedFields' => ['facility_id', 'asset_id', 'consumption_kwh', 'cost', 'rate_per_kwh', 'peak_demand_kw', 'power_factor', 'timestamp', 'currency_code', 'co2_emissions_kg']
    ],
    'EmployeeRoster' => [
        'table' => 'employee_roster',
        'primaryKey' => 'id',
        'allowedFields' => ['employee_id', 'shift_id', 'roster_date', 'status']
    ],
    'InventoryForecasts' => [
        'table' => 'inventory_forecasts',
        'primaryKey' => 'id',
        'allowedFields' => ['item_code', 'forecast_date', 'forecasted_demand']
    ]
];

$modelsPath = 'C:/wamp64/www/factorymanager/app/Models/';
$created = 0;

foreach ($modelsToCreate as $modelName => $config) {
    $fileName = $modelName . 'Model.php';
    $filePath = $modelsPath . $fileName;
    
    $allowedFieldsStr = "'" . implode("', '", $config['allowedFields']) . "'";
    
    $modelContent = "<?php

namespace App\Models;

use CodeIgniter\Model;

class {$modelName}Model extends Model
{
    protected \$table = '{$config['table']}';
    protected \$primaryKey = '{$config['primaryKey']}';
    protected \$useAutoIncrement = true;
    protected \$returnType = 'array';
    protected \$useSoftDeletes = false;
    protected \$protectFields = true;
    protected \$allowedFields = [{$allowedFieldsStr}];

    // Dates
    protected \$useTimestamps = true;
    protected \$dateFormat = 'datetime';
    protected \$createdField = 'created_at';
    protected \$updatedField = 'updated_at';
    protected \$deletedField = 'deleted_at';

    // Validation
    protected \$validationRules = [];
    protected \$validationMessages = [];
    protected \$skipValidation = false;
    protected \$cleanValidationRules = true;

    // Callbacks
    protected \$allowCallbacks = true;
    protected \$beforeInsert = [];
    protected \$afterInsert = [];
    protected \$beforeUpdate = [];
    protected \$afterUpdate = [];
    protected \$beforeFind = [];
    protected \$afterFind = [];
    protected \$beforeDelete = [];
    protected \$afterDelete = [];
}
";
    
    if (file_put_contents($filePath, $modelContent)) {
        echo "✅ Created: $fileName\n";
        $created++;
    } else {
        echo "❌ Failed: $fileName\n";
    }
}

echo "\n========================================\n";
echo "MODELS CREATED: $created/" . count($modelsToCreate) . "\n";
echo "========================================\n";
?>
