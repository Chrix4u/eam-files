<?php
$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$tables = ['documents', 'shifts', 'shift_handovers', 'energy_consumption', 'roles', 'permissions', 'role_permissions', 'company_settings', 'system_settings'];

foreach ($tables as $table) {
    echo "\n========================================\n";
    echo "TABLE: $table\n";
    echo "========================================\n";
    
    $result = $conn->query("DESCRIBE $table");
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            echo sprintf("%-30s %-20s %-10s %-10s\n", 
                $row['Field'], 
                $row['Type'], 
                $row['Null'], 
                $row['Key']
            );
        }
    } else {
        echo "Table does not exist or error: " . $conn->error . "\n";
    }
}

$conn->close();
?>
