-- Fix Missing Columns and Tables for Multi-Technician Work Order Module

USE factory_manager;

-- Add missing columns to work_orders table
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `wo_number` VARCHAR(50) NULL AFTER `id`;
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `wo_type` VARCHAR(50) NULL AFTER `status`;
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `team_leader_id` INT(11) UNSIGNED NULL AFTER `assigned_to`;
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `assigned_supervisor_id` INT(11) UNSIGNED NULL AFTER `team_leader_id`;
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `forwarded_by` INT(11) UNSIGNED NULL AFTER `assigned_supervisor_id`;
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `forwarded_at` DATETIME NULL AFTER `forwarded_by`;
ALTER TABLE `work_orders` ADD COLUMN IF NOT EXISTS `assignment_type` ENUM('direct', 'via_supervisor') DEFAULT 'direct' AFTER `forwarded_at`;

-- Create work_order_help_requests table
CREATE TABLE IF NOT EXISTS `work_order_help_requests` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `requested_by` INT(11) UNSIGNED NOT NULL,
    `requested_technicians` JSON NOT NULL,
    `reason` TEXT NOT NULL,
    `status` ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    `approved_by` INT(11) UNSIGNED NULL,
    `approved_at` DATETIME NULL,
    `created_at` DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_id` (`work_order_id`),
    KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create work_order_completion_reports table
CREATE TABLE IF NOT EXISTS `work_order_completion_reports` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_order_id` INT(11) UNSIGNED NOT NULL,
    `submitted_by` INT(11) UNSIGNED NOT NULL,
    `work_performed` TEXT NOT NULL,
    `findings` TEXT NULL,
    `recommendations` TEXT NULL,
    `team_members_data` JSON NOT NULL,
    `materials_used` JSON NULL,
    `completion_status` ENUM('completed', 'partial', 'pending_parts') DEFAULT 'completed',
    `submitted_at` DATETIME NOT NULL,
    `created_at` DATETIME NOT NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_id` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verify the changes
SELECT 'Database structure updated successfully!' as Status;
