<?php
require 'vendor/autoload.php';

$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die('Connection failed: ' . mysqli_connect_error());
}

$tables = [
    "CREATE TABLE IF NOT EXISTS `equipment_assignments` (
      `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      `equipment_id` INT(11) UNSIGNED NOT NULL,
      `user_id` INT(11) UNSIGNED NULL,
      `group_id` INT(11) UNSIGNED NULL,
      `assigned_by` INT(11) UNSIGNED NOT NULL,
      `start_date` DATETIME NOT NULL,
      `end_date` DATETIME NULL,
      `status` ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
      `created_at` DATETIME NULL,
      `updated_at` DATETIME NULL,
      INDEX `equipment_id` (`equipment_id`),
      INDEX `user_id` (`user_id`),
      INDEX `status` (`status`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "CREATE TABLE IF NOT EXISTS `production_surveys` (
      `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      `equipment_id` INT(11) UNSIGNED NOT NULL,
      `operator_id` INT(11) UNSIGNED NOT NULL,
      `shift_id` INT(11) UNSIGNED NULL,
      `production_count` INT(11) NOT NULL DEFAULT 0,
      `runtime_hours` DECIMAL(10,2) NOT NULL DEFAULT 0,
      `downtime_hours` DECIMAL(10,2) NOT NULL DEFAULT 0,
      `notes` TEXT NULL,
      `survey_date` DATE NOT NULL,
      `created_at` DATETIME NULL,
      INDEX `equipment_id` (`equipment_id`),
      INDEX `operator_id` (`operator_id`),
      INDEX `survey_date` (`survey_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "CREATE TABLE IF NOT EXISTS `meters` (
      `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      `equipment_id` INT(11) UNSIGNED NOT NULL,
      `meter_type` ENUM('hours', 'cycles', 'units') NOT NULL,
      `current_reading` DECIMAL(15,2) NOT NULL DEFAULT 0,
      `last_reset_date` DATETIME NULL,
      `created_at` DATETIME NULL,
      `updated_at` DATETIME NULL,
      INDEX `equipment_id` (`equipment_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
    
    "CREATE TABLE IF NOT EXISTS `meter_readings` (
      `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      `meter_id` INT(11) UNSIGNED NOT NULL,
      `survey_id` INT(11) UNSIGNED NULL,
      `reading_value` DECIMAL(15,2) NOT NULL,
      `reading_date` DATETIME NOT NULL,
      `recorded_by` INT(11) UNSIGNED NOT NULL,
      `created_at` DATETIME NULL,
      INDEX `meter_id` (`meter_id`),
      INDEX `survey_id` (`survey_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
];

foreach ($tables as $sql) {
    if (mysqli_query($db, $sql)) {
        echo "Table created successfully\n";
    } else {
        echo "Error: " . mysqli_error($db) . "\n";
    }
}

mysqli_close($db);
