<?php

$host = 'localhost';
$user = 'root';
$pass = 'myjesus4mE';
$db = 'factory_manager';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Checking for tables with 'spare' in the name:\n";
echo "================================================\n\n";

$result = $conn->query("SHOW TABLES");
$tables = [];
$spareRelated = [];

while ($row = $result->fetch_array()) {
    $table = $row[0];
    $tables[] = $table;
    if (stripos($table, 'spare') !== false) {
        $spareRelated[] = $table;
    }
}

if (empty($spareRelated)) {
    echo "❌ No tables found with 'spare' in the name\n\n";
} else {
    echo "✅ Found tables:\n";
    foreach ($spareRelated as $table) {
        echo "   - {$table}\n";
    }
    echo "\n";
}

echo "All tables in database ({$db}):\n";
echo "================================================\n";
foreach ($tables as $table) {
    echo "- {$table}\n";
}

$conn->close();
