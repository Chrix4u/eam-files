# Database Index Optimization Scripts

## Overview
Comprehensive index optimization for the school management system database. These scripts add indexes to improve query performance, especially for exam marks, attendance, fees, and employee management.

## Files Created

### Individual Part Scripts (Recommended for large databases)
1. **optimize_indexes_part1_academic.sql** - Core academic tables (mark, aggregation, enroll, exam, student, teacher)
2. **optimize_indexes_part2_fees.sql** - Attendance and fee management tables
3. **optimize_indexes_part3_exams_library.sql** - Online exams, portfolio, library
4. **optimize_indexes_part4_hr.sql** - Employee and HR management
5. **optimize_indexes_part5_projects.sql** - Project management and assets
6. **optimize_indexes_part6_messaging.sql** - Messaging and notifications
7. **optimize_indexes_part7_finance.sql** - Accounts and finance
8. **optimize_indexes_part8_misc.sql** - Miscellaneous tables

### Master Script (All-in-one)
- **optimize_indexes_master.sql** - Contains all indexes in one file

## How to Run

### Option 1: Run Individual Parts (Recommended)
Run each part separately during low-traffic periods:

```bash
mysql -u username -p database_name < optimize_indexes_part1_academic.sql
mysql -u username -p database_name < optimize_indexes_part2_fees.sql
mysql -u username -p database_name < optimize_indexes_part3_exams_library.sql
# ... continue with remaining parts
```

### Option 2: Run Master Script
Run all indexes at once:

```bash
mysql -u username -p database_name < optimize_indexes_master.sql
```

### Option 3: Using phpMyAdmin
1. Open phpMyAdmin
2. Select your database
3. Go to SQL tab
4. Copy and paste script content
5. Click "Go"

## Safety Features

- **IF NOT EXISTS** - All indexes use this clause to prevent errors if index already exists
- **No data modification** - Only adds indexes, doesn't change data
- **Rollback safe** - Uses transactions where possible
- **Re-runnable** - Safe to run multiple times

## Performance Impact

### During Index Creation
- CPU usage will increase
- Disk I/O will increase
- Table locks may occur (brief)
- Estimated time: 5-30 minutes depending on data size

### After Index Creation
- Faster SELECT queries (50-90% improvement)
- Slightly slower INSERT/UPDATE (5-10% overhead)
- Increased disk space usage (10-20% of table size)

## Key Optimizations

### Exam Marks Queries
- `mark` table: 6 indexes for student/exam/subject lookups
- `aggregation` table: 6 indexes for report card generation
- `enroll` table: 7 indexes for enrollment filtering

### Common Query Patterns Optimized
```sql
-- Student marks by exam
SELECT * FROM mark WHERE student_id = ? AND exam_id = ? AND class_id = ?;

-- Class aggregation
SELECT * FROM aggregation WHERE class_id = ? AND section_id = ? AND exam_id = ?;

-- Enrollment by year/term
SELECT * FROM enroll WHERE year = ? AND term = ? AND class_id = ?;

-- Attendance tracking
SELECT * FROM attendance WHERE student_id = ? AND timestamp BETWEEN ? AND ?;

-- Fee payments
SELECT * FROM payment WHERE student_id = ? AND year = ? AND term = ?;
```

## Verification

After running scripts, verify indexes were created:

```sql
-- Check mark table indexes
SHOW INDEX FROM mark;

-- Check aggregation table indexes
SHOW INDEX FROM aggregation;

-- Check enroll table indexes
SHOW INDEX FROM enroll;
```

## Performance Testing

Test query performance before and after:

```sql
-- Use EXPLAIN to see query execution plan
EXPLAIN SELECT * FROM mark 
WHERE student_id = 1 AND exam_id = 1 AND class_id = 1;

-- Check if index is being used (look for "Using index" in Extra column)
```

## Monitoring

After applying indexes, monitor:
- Query execution time (should decrease)
- Database size (will increase slightly)
- CPU usage during peak hours
- Slow query log

## Rollback

If you need to remove indexes:

```sql
-- Example: Remove specific index
ALTER TABLE mark DROP INDEX idx_student_exam;

-- Check existing indexes before removing
SHOW INDEX FROM mark;
```

## Best Practices

1. **Backup first** - Always backup database before making changes
2. **Low-traffic periods** - Run during off-peak hours
3. **Monitor** - Watch server resources during execution
4. **Test queries** - Verify performance improvements
5. **Document** - Keep record of which scripts were run

## Troubleshooting

### Error: "Duplicate key name"
- Index already exists, safe to ignore
- Script uses IF NOT EXISTS to prevent this

### Error: "Lock wait timeout"
- Database is busy, try again during low-traffic period
- Increase lock_wait_timeout temporarily

### Slow execution
- Normal for large tables
- Don't interrupt the process
- Monitor with: `SHOW PROCESSLIST;`

## Tables Optimized

Total: 50+ tables
- Academic: 15 tables
- Attendance & Fees: 6 tables
- Exams & Library: 10 tables
- HR & Employees: 20 tables
- Projects & Assets: 12 tables
- Messaging: 10 tables
- Finance: 6 tables
- Miscellaneous: 15 tables

## Index Count

- Total indexes added: 150+
- Composite indexes: 80+
- Single column indexes: 70+

## Support

For issues or questions:
1. Check MySQL error log
2. Verify table structure matches schema
3. Ensure sufficient disk space
4. Check MySQL version compatibility (5.6+)

## Notes

- Indexes are automatically maintained by MySQL
- No manual maintenance required
- Rebuild indexes if table is heavily modified: `OPTIMIZE TABLE table_name;`
- Monitor index usage: `SELECT * FROM sys.schema_unused_indexes;`
