<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("DESCRIBE work_orders");

echo "work_orders table columns:\n";
echo str_repeat("=", 80) . "\n";

$columns = [];
while ($row = $result->fetch_assoc()) {
    $columns[] = $row['Field'];
    printf("%-30s %-15s %-10s %-10s\n", 
        $row['Field'], 
        $row['Type'], 
        $row['Null'], 
        $row['Key']
    );
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "Total columns: " . count($columns) . "\n\n";

echo "PHP array format:\n";
echo "[\n";
foreach ($columns as $col) {
    echo "    '$col',\n";
}
echo "];\n";

$conn->close();
