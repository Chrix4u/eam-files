# EAM REST API Documentation

Base URL: `http://localhost/factorymanager/api/v1/eam`

## Authentication

### Login
```
POST /auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "password123"
}

Response:
{
  "status": "success",
  "data": {
    "user": {"id": 1, "username": "admin", "email": "admin@example.com"},
    "tokens": {
      "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
      "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
    }
  }
}
```

### Logout
```
POST /auth/logout
Authorization: Bearer {access_token}
```

### Refresh Token
```
POST /auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJ0eXAiOiJKV1QiLCJhbGc..."
}
```

## Asset Hierarchy

### Facilities
```
GET    /facilities              - List all facilities (paginated)
GET    /facilities/{id}         - Get facility details
POST   /facilities              - Create facility
PUT    /facilities/{id}         - Update facility
DELETE /facilities/{id}         - Delete facility

Query params: ?page=1&limit=20&search=keyword
```

### Systems
```
GET    /systems                 - List all systems
GET    /systems/{id}            - Get system details
POST   /systems                 - Create system
PUT    /systems/{id}            - Update system
DELETE /systems/{id}            - Delete system
```

### Equipment
```
GET    /equipment               - List all equipment
GET    /equipment/{id}          - Get equipment details
POST   /equipment               - Create equipment
PUT    /equipment/{id}          - Update equipment
DELETE /equipment/{id}          - Delete equipment
```

### Assemblies
```
GET    /assemblies              - List all assemblies
GET    /assemblies/{id}         - Get assembly details
POST   /assemblies              - Create assembly
PUT    /assemblies/{id}         - Update assembly
DELETE /assemblies/{id}         - Delete assembly
```

### Components
```
GET    /components              - List all components
GET    /components/{id}         - Get component details
POST   /components              - Create component
PUT    /components/{id}         - Update component
DELETE /components/{id}         - Delete component
```

### Parts
```
GET    /parts                   - List all parts
GET    /parts/{id}              - Get part details
POST   /parts                   - Create part
PUT    /parts/{id}              - Update part
DELETE /parts/{id}              - Delete part
```

## Preventive Maintenance

### PM Rules
```
GET  /pm-rules                  - List all PM rules
POST /pm-rules                  - Create PM rule

Body:
{
  "asset_id": 1,
  "rule_name": "Monthly Inspection",
  "frequency_type": "time",
  "frequency_value": 30,
  "description": "Monthly equipment inspection"
}

PUT /pm-rules/{id}              - Update PM rule
```

### PM Schedules
```
POST /pm-schedules/generate     - Generate schedules from rule

Body:
{
  "rule_id": 1,
  "start_date": "2025-01-01",
  "end_date": "2025-12-31"
}

GET /pm-schedules/{asset_id}    - Get schedules for asset
```

## Work Orders

### Work Order Management
```
GET  /work-orders               - List all work orders
GET  /work-orders/{id}          - Get work order details
POST /work-orders               - Create work order

Body:
{
  "asset_id": 1,
  "title": "Repair motor",
  "description": "Motor making unusual noise",
  "priority": "high",
  "work_type": "corrective"
}

PUT    /work-orders/{id}        - Update work order
DELETE /work-orders/{id}        - Delete work order
```

### Work Order Actions
```
POST /work-orders/{id}/assign   - Assign technician

Body:
{
  "technician_id": 5
}

POST /work-orders/{id}/complete - Complete work order

Body:
{
  "notes": "Replaced bearings, tested motor"
}
```

## Inventory Management

### Inventory Items
```
GET    /inventory               - List all inventory items
GET    /inventory/{id}          - Get item details
POST   /inventory               - Create item
PUT    /inventory/{id}          - Update item
DELETE /inventory/{id}          - Delete item
```

### Stock Transactions
```
POST /inventory/stock-in         - Add stock

Body:
{
  "item_id": 1,
  "quantity": 50,
  "reference": "PO-12345"
}

POST /inventory/stock-out        - Remove stock

Body:
{
  "item_id": 1,
  "quantity": 10,
  "reference": "WO-789"
}

POST /inventory/reserve          - Reserve for work order

Body:
{
  "item_id": 1,
  "work_order_id": 10,
  "quantity": 5
}
```

## User & Role Management

### Users
```
GET    /users                   - List all users
GET    /users/{id}              - Get user details
POST   /users                   - Create user

Body:
{
  "username": "john.doe",
  "email": "john@example.com",
  "password": "SecurePass123",
  "full_name": "John Doe"
}

PUT    /users/{id}              - Update user
DELETE /users/{id}              - Delete user

POST /users/{id}/assign-role    - Assign role to user

Body:
{
  "role_id": 2
}
```

### Roles
```
GET    /roles                   - List all roles
GET    /roles/{id}              - Get role details
POST   /roles                   - Create role
PUT    /roles/{id}              - Update role
DELETE /roles/{id}              - Delete role

POST /roles/{id}/assign-permissions - Assign permissions

Body:
{
  "permission_ids": [1, 2, 3, 5, 8]
}
```

## Response Format

### Success Response
```json
{
  "status": "success",
  "data": {...},
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150
  }
}
```

### Error Response
```json
{
  "status": "error",
  "message": "Resource not found"
}
```

## Authentication Header
All protected endpoints require JWT token:
```
Authorization: Bearer {access_token}
```

## Status Codes
- 200: Success
- 201: Created
- 400: Bad Request
- 401: Unauthorized
- 404: Not Found
- 500: Server Error
