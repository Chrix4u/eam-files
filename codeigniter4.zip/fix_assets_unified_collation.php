<?php
$host = 'localhost';
$dbname = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$db = new mysqli($host, $user, $pass, $dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

echo "Fixing assets_unified table collation to utf8mb4_unicode_520_ci...\n\n";

// Drop indexes
echo "Dropping indexes...\n";
$indexes = ['asset_code', 'idx_asset_type_status', 'idx_criticality_health', 'idx_parent_type', 'idx_created_at', 'idx_type_status', 'idx_criticality'];
foreach ($indexes as $idx) {
    try {
        $db->query("ALTER TABLE assets_unified DROP INDEX {$idx}");
        echo "  ✅ Dropped {$idx}\n";
    } catch (Exception $e) {
        echo "  ⚠️  {$idx} not found\n";
    }
}

// Convert table
echo "\nConverting table collation...\n";
$db->query("ALTER TABLE assets_unified CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci");
echo "✅ Table collation updated\n";

// Recreate indexes
echo "\nRecreating indexes...\n";
$db->query("ALTER TABLE assets_unified ADD UNIQUE KEY asset_code (asset_code)");
$db->query("CREATE INDEX idx_asset_type_status ON assets_unified(asset_type, status)");
$db->query("CREATE INDEX idx_criticality ON assets_unified(criticality)");
echo "✅ Indexes recreated\n";

echo "\n✅ Collation fixed to utf8mb4_unicode_520_ci\n";

$db->close();
