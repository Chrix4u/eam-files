-- PM Work Orders Tables Schema

CREATE TABLE IF NOT EXISTS `pm_work_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_pm_task_id` int(11) NOT NULL,
  `part_id` int(11) NOT NULL,
  `work_order_number` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `priority` enum('low','medium','high','critical') DEFAULT 'medium',
  `status` enum('pending','assigned','in_progress','completed','cancelled') DEFAULT 'pending',
  `scheduled_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `estimated_duration` time DEFAULT NULL,
  `actual_duration` time DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `work_order_number` (`work_order_number`),
  KEY `part_pm_task_id` (`part_pm_task_id`),
  KEY `part_id` (`part_id`),
  KEY `status` (`status`),
  KEY `due_date` (`due_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pm_checklist_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_work_order_id` int(11) NOT NULL,
  `item_description` varchar(255) NOT NULL,
  `item_order` int(11) DEFAULT 1,
  `is_completed` tinyint(1) DEFAULT 0,
  `completed_at` datetime DEFAULT NULL,
  `completed_by` int(11) DEFAULT NULL,
  `notes` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pm_work_order_id` (`pm_work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pm_execution_parameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pm_work_order_id` int(11) NOT NULL,
  `parameter_name` varchar(100) NOT NULL,
  `parameter_value` varchar(255) DEFAULT NULL,
  `parameter_unit` varchar(50) DEFAULT NULL,
  `expected_value` varchar(255) DEFAULT NULL,
  `status` enum('normal','warning','critical') DEFAULT 'normal',
  `notes` text,
  `recorded_by` int(11) DEFAULT NULL,
  `recorded_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `pm_work_order_id` (`pm_work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `pm_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_type` enum('due_soon','overdue','assigned','completed') NOT NULL,
  `part_pm_task_id` int(11) DEFAULT NULL,
  `pm_work_order_id` int(11) DEFAULT NULL,
  `recipient_role` varchar(50) DEFAULT NULL,
  `recipient_user_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `recipient_user_id` (`recipient_user_id`),
  KEY `is_read` (`is_read`),
  KEY `pm_work_order_id` (`pm_work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
