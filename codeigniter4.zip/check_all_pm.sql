DESCRIBE pm_types;
DESCRIBE pm_modes;
DESCRIBE pm_inspection_types;
DESCRIBE pm_tasks;
DESCRIBE part_pm_tasks;
