# Grade-A EAM System - Implementation Plan

**Phase**: System Upgrade to Grade-A  
**Timeline**: 12 Weeks  
**Priority**: HIGH

---

## 🎯 IMMEDIATE ACTIONS

### Action 1: Database Schema Upgrade (Week 1-2)

**Files to Create**:
1. `app/Database/Migrations/2025-01-20-000001_CreateGradeAAssetHierarchy.php`
2. `app/Database/Migrations/2025-01-20-000002_CreateAsset3DModels.php`
3. `app/Database/Migrations/2025-01-20-000003_CreateAssetRelationships.php`
4. `app/Database/Migrations/2025-01-20-000004_CreateAssetClosureTable.php`

### Action 2: File Cleanup (Week 1)

**Controllers to REMOVE**:
```
app/Controllers/Machine.php          → Use Api/V1/EamEquipmentController
app/Controllers/Assembly.php         → Use Api/V1/EamAssembliesController
app/Controllers/Parts.php            → Use Api/V1/EamPartsController
app/Controllers/PMDebug.php          → Development only
app/Controllers/PMDiagnostic.php     → Development only
app/Controllers/PMCheck.php          → Development only
app/Controllers/PMReset.php          → Development only
```

**Models to CONSOLIDATE**:
```
app/Models/MachineModel.php          → Merge into EamAssetModel
app/Models/AssemblyModel.php         → Merge into EamAssetModel
app/Models/PartModel.php             → Merge into EamAssetModel
app/Models/PartsModel.php            → Duplicate, remove
```

### Action 3: New Services (Week 2-3)

**Create**:
1. `app/Services/Asset/HierarchyService.php` - Asset tree operations
2. `app/Services/Asset/Model3DService.php` - 3D model management
3. `app/Services/Asset/VisualizationService.php` - Graph generation
4. `app/Services/Asset/RelationshipGraphService.php` - Relationship mapping

### Action 4: New API Controllers (Week 3-4)

**Create**:
1. `app/Controllers/Api/V1/Asset/HierarchyController.php`
2. `app/Controllers/Api/V1/Asset/Model3DController.php`
3. `app/Controllers/Api/V1/Asset/VisualizationController.php`
4. `app/Controllers/Api/V1/Asset/RelationshipController.php`

### Action 5: Frontend Components (Week 5-8)

**Create in Next.js**:
1. `src/components/asset/AssetHierarchyTree.tsx`
2. `src/components/asset/Asset3DViewer.tsx`
3. `src/components/asset/AssetHealthMatrix.tsx`
4. `src/components/asset/PMGanttChart.tsx`
5. `src/components/asset/AssetRelationshipGraph.tsx`

---

## 📊 DETAILED BREAKDOWN

### 1. Asset Hierarchy Features

**Current**: Simple parent-child relationship  
**Grade-A**: Multi-level hierarchy with closure table

**Benefits**:
- Query all descendants in O(1)
- Fast ancestor lookups
- Efficient tree operations
- Support unlimited depth

**API Endpoints to Add**:
```
GET    /api/v1/asset/hierarchy/tree/{id}           - Get full tree
GET    /api/v1/asset/hierarchy/ancestors/{id}      - Get all ancestors
GET    /api/v1/asset/hierarchy/descendants/{id}    - Get all descendants
GET    /api/v1/asset/hierarchy/siblings/{id}       - Get siblings
POST   /api/v1/asset/hierarchy/move                - Move node
POST   /api/v1/asset/hierarchy/reorder             - Reorder children
GET    /api/v1/asset/hierarchy/path/{id}           - Get breadcrumb path
GET    /api/v1/asset/hierarchy/search              - Search tree
```

### 2. 3D Model Integration

**Features**:
- Upload GLB/GLTF models
- Define clickable hotspots
- Link hotspots to child assets
- Rotate, zoom, pan
- Exploded view
- Measurement tools

**API Endpoints to Add**:
```
POST   /api/v1/asset/3d-model/upload               - Upload 3D model
GET    /api/v1/asset/3d-model/{assetId}            - Get model
PUT    /api/v1/asset/3d-model/{id}                 - Update model
DELETE /api/v1/asset/3d-model/{id}                 - Delete model
POST   /api/v1/asset/3d-model/{id}/hotspot        - Add hotspot
GET    /api/v1/asset/3d-model/{id}/hotspots       - Get hotspots
PUT    /api/v1/asset/3d-model/hotspot/{id}        - Update hotspot
DELETE /api/v1/asset/3d-model/hotspot/{id}        - Delete hotspot
```

### 3. Visualization & Diagrams

**Diagrams to Implement**:

**a) Asset Hierarchy Tree**
- Interactive D3.js tree
- Collapsible nodes
- Status colors
- Search highlight
- Export to PNG/SVG

**b) Asset Health Matrix**
- Scatter plot (Criticality vs Health)
- Color-coded dots
- Clickable for details
- Filter by type/status
- Real-time updates

**c) PM Schedule Gantt**
- Timeline view
- Drag to reschedule
- Resource conflicts
- Critical path
- Export to PDF

**d) Asset Relationship Graph**
- Force-directed network
- Node clustering
- Relationship types
- Path finding
- Zoom & pan

**API Endpoints to Add**:
```
GET    /api/v1/asset/visualization/tree            - Tree data
GET    /api/v1/asset/visualization/health-matrix   - Health matrix data
GET    /api/v1/asset/visualization/relationships   - Relationship graph
GET    /api/v1/asset/visualization/pm-gantt        - PM schedule data
POST   /api/v1/asset/visualization/export          - Export diagram
```

### 4. Asset Relationships

**Relationship Types**:
- Parent-Child (hierarchy)
- Depends-On (operational dependency)
- Supplies-To (material flow)
- Backup-For (redundancy)
- Similar-To (same type)
- Replaces (lifecycle)
- Connects-To (physical connection)

**API Endpoints to Add**:
```
POST   /api/v1/asset/relationship                  - Create relationship
GET    /api/v1/asset/relationship/{assetId}        - Get relationships
DELETE /api/v1/asset/relationship/{id}             - Delete relationship
GET    /api/v1/asset/relationship/graph/{assetId}  - Get relationship graph
GET    /api/v1/asset/relationship/path             - Find path between assets
```

---

## 🗂️ FILE ORGANIZATION

### Current Issues
- 80+ controllers (many duplicates)
- 90+ models (inconsistent naming)
- Mixed API versions
- Legacy files

### Grade-A Structure

```
app/
├── Controllers/
│   ├── Api/
│   │   └── V1/
│   │       ├── Asset/
│   │       │   ├── HierarchyController.php          ⭐ NEW
│   │       │   ├── Model3DController.php            ⭐ NEW
│   │       │   ├── VisualizationController.php      ⭐ NEW
│   │       │   ├── RelationshipController.php       ⭐ NEW
│   │       │   ├── AssetController.php              (consolidated)
│   │       │   └── BOMController.php
│   │       ├── PM/
│   │       │   ├── TemplateController.php
│   │       │   ├── ScheduleController.php
│   │       │   └── WorkOrderController.php
│   │       ├── WorkOrder/
│   │       │   ├── WorkOrderController.php
│   │       │   ├── MaterialController.php
│   │       │   └── AttachmentController.php
│   │       ├── Analytics/
│   │       │   ├── KPIController.php
│   │       │   └── ReportController.php
│   │       └── DashboardController.php
│   └── [Remove legacy controllers]
│
├── Services/
│   ├── Asset/
│   │   ├── HierarchyService.php                     ⭐ NEW
│   │   ├── Model3DService.php                       ⭐ NEW
│   │   ├── VisualizationService.php                 ⭐ NEW
│   │   ├── RelationshipGraphService.php             ⭐ NEW
│   │   ├── AssetService.php
│   │   └── BOMService.php
│   ├── PM/
│   │   ├── PMSchedulerService.php
│   │   └── PMTemplateService.php
│   └── Analytics/
│       ├── AssetHealthService.php                   ⭐ NEW
│       └── KPIService.php
│
├── Models/
│   ├── AssetHierarchyModel.php                      (unified)
│   ├── Asset3DModelModel.php                        ⭐ NEW
│   ├── AssetRelationshipModel.php                   ⭐ NEW
│   ├── AssetClosureModel.php                        ⭐ NEW
│   ├── WorkOrderModel.php
│   ├── PMTemplateModel.php
│   └── [Remove duplicates]
│
└── Database/
    └── Migrations/
        ├── 2025-01-20-000001_CreateGradeAAssetHierarchy.php    ⭐ NEW
        ├── 2025-01-20-000002_CreateAsset3DModels.php           ⭐ NEW
        ├── 2025-01-20-000003_CreateAssetRelationships.php      ⭐ NEW
        └── 2025-01-20-000004_CreateAssetClosureTable.php       ⭐ NEW
```

---

## 📦 TECHNOLOGY STACK UPGRADES

### Frontend (Next.js)
```json
{
  "dependencies": {
    "@react-three/fiber": "^8.15.0",      // 3D rendering
    "@react-three/drei": "^9.88.0",       // 3D helpers
    "three": "^0.158.0",                  // 3D engine
    "d3": "^7.8.5",                       // Visualizations
    "react-flow-renderer": "^10.3.17",    // Diagrams
    "framer-motion": "^10.16.0",          // Animations
    "recharts": "^2.10.0",                // Charts
    "react-dnd": "^16.0.1",               // Drag & drop
    "react-virtualized": "^9.22.5"        // Large lists
  }
}
```

### Backend (CodeIgniter 4)
```json
{
  "require": {
    "intervention/image": "^2.7",         // Image processing
    "phpoffice/phpspreadsheet": "^1.29",  // Excel export
    "mpdf/mpdf": "^8.2",                  // PDF generation
    "predis/predis": "^2.2"               // Redis caching
  }
}
```

---

## 🎯 IMPLEMENTATION PRIORITY

### Phase 1: Foundation (Week 1-2) - CRITICAL
✅ Database schema upgrade  
✅ File cleanup  
✅ Create base services  
✅ Migration scripts  

### Phase 2: 3D Integration (Week 3-4) - HIGH
✅ 3D model upload  
✅ Hotspot system  
✅ 3D viewer component  
✅ API endpoints  

### Phase 3: Hierarchy (Week 5-6) - HIGH
✅ Interactive tree  
✅ Drag-drop  
✅ Search & filter  
✅ Closure table queries  

### Phase 4: Visualization (Week 7-8) - MEDIUM
✅ Health matrix  
✅ Gantt chart  
✅ Relationship graph  
✅ Export features  

### Phase 5: Polish (Week 9-10) - MEDIUM
✅ Performance optimization  
✅ UI/UX improvements  
✅ Documentation  
✅ Testing  

### Phase 6: Deployment (Week 11-12) - LOW
✅ Production setup  
✅ User training  
✅ Go-live support  

---

## 💡 QUICK WINS (Can implement immediately)

### 1. Asset Status Colors (1 hour)
Add color coding to asset lists:
- 🟢 Green: Healthy/Active
- 🟡 Yellow: Warning/Maintenance
- 🔴 Red: Critical/Down
- ⚪ Gray: Idle/Retired

### 2. Breadcrumb Navigation (2 hours)
Show asset path: Facility > Building > Line > Machine > Assembly

### 3. Quick Stats Cards (3 hours)
Add dashboard cards:
- Total Assets by Type
- Assets by Status
- Critical Assets
- PM Compliance %

### 4. Asset Search (4 hours)
Global search with:
- Fuzzy matching
- Type filtering
- Status filtering
- Recent searches

### 5. Export to Excel (4 hours)
Export asset lists with:
- Hierarchy structure
- All properties
- Custom columns
- Formatted output

---

## 📈 EXPECTED OUTCOMES

### Performance
- Asset queries: 500ms → 50ms (10x faster)
- Tree loading: 2s → 200ms (10x faster)
- Search: 1s → 100ms (10x faster)

### User Experience
- Navigation clicks: 5 → 1 (5x reduction)
- Data entry time: 10min → 2min (5x faster)
- Error rate: 10% → 1% (10x reduction)

### Business Value
- Asset visibility: 60% → 100%
- PM compliance: 75% → 95%
- Downtime: -20%
- Maintenance costs: -15%

---

## 🚀 READY TO START?

**Recommended Starting Point**: Database Schema Upgrade

**Reason**: Everything else depends on proper database structure

**Next Steps**:
1. Review and approve migration scripts
2. Backup current database
3. Run migrations in test environment
4. Migrate existing data
5. Test thoroughly
6. Deploy to production

**Shall I create the migration files now?**

Options:
A) Yes, create all migration files
B) Start with Asset Hierarchy migration only
C) Show me sample data first
D) Let me review the plan more

**Your choice?**
