-- Compare working technician1 with non-working admin
SELECT id, username, email, password, role, status, LENGTH(password) as pwd_length 
FROM users 
WHERE username IN ('technician1', 'admin', 'supervisor', 'planner')
ORDER BY username;
