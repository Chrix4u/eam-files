<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');
if (!$db) die('Connection failed: ' . mysqli_connect_error());

// Get recent users
$result = mysqli_query($db, "SELECT id, username, email, role, status, created_at FROM users ORDER BY created_at DESC LIMIT 5");

echo "Recent users:\n\n";
while ($row = mysqli_fetch_assoc($result)) {
    echo "ID: " . $row['id'] . "\n";
    echo "Username: " . $row['username'] . "\n";
    echo "Email: " . $row['email'] . "\n";
    echo "Role: " . $row['role'] . "\n";
    echo "Status: " . $row['status'] . "\n";
    echo "Created: " . $row['created_at'] . "\n";
    echo "---\n";
}

mysqli_close($db);
