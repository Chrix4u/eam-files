<?php
require 'vendor/autoload.php';

$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Adding comprehensive employee fields...\n";

$fields = [
    "ALTER TABLE users ADD COLUMN title VARCHAR(20) NULL COMMENT 'Mr, Mrs, Dr, Eng'",
    "ALTER TABLE users ADD COLUMN first_name VARCHAR(100) NULL",
    "ALTER TABLE users ADD COLUMN middle_name VARCHAR(100) NULL",
    "ALTER TABLE users ADD COLUMN last_name VARCHAR(100) NULL",
    "ALTER TABLE users ADD COLUMN date_of_birth DATE NULL",
    "ALTER TABLE users ADD COLUMN gender ENUM('male','female','other') NULL",
    "ALTER TABLE users ADD COLUMN marital_status ENUM('single','married','divorced','widowed') NULL",
    "ALTER TABLE users ADD COLUMN nationality VARCHAR(100) NULL",
    "ALTER TABLE users ADD COLUMN national_id VARCHAR(50) NULL COMMENT 'Ghana Card, Passport'",
    "ALTER TABLE users ADD COLUMN ssnit_number VARCHAR(50) NULL",
    "ALTER TABLE users ADD COLUMN tin_number VARCHAR(50) NULL",
    "ALTER TABLE users ADD COLUMN staff_id VARCHAR(50) NULL UNIQUE",
    "ALTER TABLE users ADD COLUMN employment_type ENUM('permanent','contract','temporary','casual','intern') NULL",
    "ALTER TABLE users ADD COLUMN employment_status ENUM('active','on_leave','suspended','terminated','retired') DEFAULT 'active'",
    "ALTER TABLE users ADD COLUMN contract_start_date DATE NULL",
    "ALTER TABLE users ADD COLUMN contract_end_date DATE NULL",
    "ALTER TABLE users ADD COLUMN probation_end_date DATE NULL",
    "ALTER TABLE users ADD COLUMN confirmation_date DATE NULL",
    "ALTER TABLE users ADD COLUMN grade_level VARCHAR(50) NULL",
    "ALTER TABLE users ADD COLUMN step VARCHAR(50) NULL",
    "ALTER TABLE users ADD COLUMN bank_name VARCHAR(100) NULL",
    "ALTER TABLE users ADD COLUMN bank_branch VARCHAR(100) NULL",
    "ALTER TABLE users ADD COLUMN account_number VARCHAR(50) NULL",
    "ALTER TABLE users ADD COLUMN account_name VARCHAR(255) NULL",
    "ALTER TABLE users ADD COLUMN basic_salary DECIMAL(12,2) NULL",
    "ALTER TABLE users ADD COLUMN emergency_contact_1_name VARCHAR(255) NULL",
    "ALTER TABLE users ADD COLUMN emergency_contact_1_phone VARCHAR(20) NULL",
    "ALTER TABLE users ADD COLUMN emergency_contact_2_name VARCHAR(255) NULL",
    "ALTER TABLE users ADD COLUMN emergency_contact_2_phone VARCHAR(20) NULL",
    "ALTER TABLE users ADD COLUMN blood_group VARCHAR(10) NULL",
    "ALTER TABLE users ADD COLUMN annual_leave_days INT DEFAULT 0",
    "ALTER TABLE users ADD COLUMN leave_days_remaining INT DEFAULT 0"
];

foreach ($fields as $sql) {
    // Check if column exists first
    $columnName = explode(' ', trim(str_replace(['ALTER TABLE users ADD COLUMN ', 'ALTER TABLE users ADD COLUMN'], '', $sql)))[0];
    $checkSql = "SHOW COLUMNS FROM users LIKE '$columnName'";
    $result = mysqli_query($db, $checkSql);
    
    if (mysqli_num_rows($result) == 0) {
        if (mysqli_query($db, $sql)) {
            echo ".";
        } else {
            echo "E";
        }
    } else {
        echo "S"; // Skipped
    }
}

echo "\n✅ Enterprise HR fields added successfully!\n";

mysqli_close($db);
