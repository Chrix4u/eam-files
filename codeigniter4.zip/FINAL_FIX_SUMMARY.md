# ✅ DASHBOARD FIX - COMPLETE

## Root Cause Found

The API base URL was missing `/public/` in the path:

### Before (Wrong):
```
http://localhost/factorymanager/api/v1/eam
```

### After (Correct):
```
http://localhost/factorymanager/public/api/v1/eam
```

## Files Fixed

1. ✅ `.env.local` - Updated API URL
2. ✅ `src/lib/api.ts` - Updated default API URL
3. ✅ 6 Backend Controllers - Updated to use `assets_unified` table

## What You Need to Do

### Step 1: Restart Next.js Dev Server
```bash
# Stop the current server (Ctrl+C)
# Then restart:
npm run dev
```

**IMPORTANT:** Environment variable changes require server restart!

### Step 2: Hard Refresh Browser
Press `Ctrl + Shift + R` to clear cache

### Step 3: Verify Dashboard
Navigate to: `http://localhost:3000/admin`

**Expected Result:**
- Total Assets: **156** ✅
- Active Work Orders: 7
- All KPIs populated

## About Deleting Old `assets` Table

### ⚠️ DO NOT DELETE YET

The old `assets` table may have foreign key references from other tables like:
- `work_orders.asset_id`
- `pm_schedules.asset_id`
- `iot_devices.asset_id`
- `equipment_assignments.asset_id`

### Safe Migration Strategy

1. **Keep both tables for now** (assets + assets_unified)
2. **Update foreign keys gradually** to point to assets_unified
3. **Test thoroughly** - ensure all features work
4. **Backup database** before deletion
5. **Delete old table** only after 100% confidence

### Migration Script Needed

Create a script to:
```sql
-- 1. Update work_orders to reference assets_unified
ALTER TABLE work_orders 
  DROP FOREIGN KEY fk_work_orders_asset,
  ADD CONSTRAINT fk_work_orders_asset_unified 
  FOREIGN KEY (asset_id) REFERENCES assets_unified(id);

-- 2. Repeat for all tables with asset_id foreign keys
-- 3. Then drop old assets table
DROP TABLE assets;
```

### Recommendation

**Keep the old `assets` table for 2-4 weeks** as a safety backup. Once you're confident everything works with `assets_unified`, then delete it.

## Current Status

### ✅ Working
- Backend API returning 156 assets
- All controllers using assets_unified
- Routes configured correctly
- API base URL fixed

### 🔄 Pending
- Frontend server restart (user action required)
- Browser cache clear (user action required)

### 📊 Database Tables

**Active:**
- `assets_unified` - 156 records (PRIMARY)
- `asset_closure` - Hierarchy relationships
- `machines` - Detailed machine data (80 columns)

**Deprecated (Keep for now):**
- `assets` - Old table (150 records)
- `facilities` - Migrated to assets_unified
- `systems` - Migrated to assets_unified

## Verification Commands

### Test API Directly
```bash
curl "http://localhost/factorymanager/public/api/v1/eam/analytics/kpis"
```

Expected: `"totalAssets": 156`

### Check Frontend API Call
Open browser DevTools (F12) → Network tab → Look for `analytics/kpis` request

## Summary

**Problem:** Dashboard showing 0 assets  
**Cause 1:** Controllers using old `assets` table → **FIXED**  
**Cause 2:** API URL missing `/public/` → **FIXED**  
**Solution:** Restart Next.js server + hard refresh browser  
**Result:** Dashboard will show 156 assets ✅
