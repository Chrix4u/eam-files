-- Add safety_notes and ppe_required columns to work_orders table

ALTER TABLE `work_orders` 
ADD COLUMN `safety_notes` TEXT NULL AFTER `notes`,
ADD COLUMN `ppe_required` TEXT NULL AFTER `safety_notes`;
