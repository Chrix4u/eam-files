<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_query($db, 'SET FOREIGN_KEY_CHECKS = 0');

$result = mysqli_query($db, "SHOW TABLES");
while ($row = mysqli_fetch_array($result)) {
    $table = $row[0];
    echo "Dropping table: $table\n";
    mysqli_query($db, "DROP TABLE IF EXISTS `$table`");
}

mysqli_query($db, 'SET FOREIGN_KEY_CHECKS = 1');

echo "\nAll tables dropped successfully!\n";

mysqli_close($db);
