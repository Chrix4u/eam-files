@echo off
cd c:\wamp64\www\factorymanager
c:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE -e "SHOW DATABASES LIKE 'factory%%';"
pause
