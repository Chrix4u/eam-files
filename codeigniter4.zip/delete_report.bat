@echo off
C:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager -e "DELETE FROM work_order_completion_reports WHERE work_order_id = 9; SELECT wo.id, wo.work_order_number, wo.status, wocr.completion_status FROM work_orders wo LEFT JOIN work_order_completion_reports wocr ON wocr.work_order_id = wo.id WHERE wo.id = 9;"
