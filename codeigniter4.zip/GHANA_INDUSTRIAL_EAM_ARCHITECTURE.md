# Ghana Industrial EAM System Architecture
**Target Industries**: GTP Ghana, Unilever Ghana, Guinness Ghana, Tema Heavy Industries  
**Version**: 3.0.0-GH  
**Status**: Production-Grade for Ghanaian Manufacturing

---

## 1. GHANAIAN OPERATIONAL REALITIES (BASELINE ASSUMPTIONS)

### 1.1 Power & Connectivity
- **Unreliable Power**: ECG outages 2-4 times/week
- **Load Shedding**: Scheduled "dumsor" periods
- **Backup Systems**: Generators, UPS mandatory
- **Network**: Intermittent 3G/4G, fiber when available

**System Requirements**:
- Offline-first architecture
- Local data caching (IndexedDB)
- Auto-sync when online
- Generator runtime tracking
- Power outage logging

### 1.2 Shift Operations
- **3-Shift System**: Morning (6am-2pm), Afternoon (2pm-10pm), Night (10pm-6am)
- **Shift Handover**: Mandatory 15-30min overlap
- **Union Rules**: Strict break times, overtime approval
- **Shift Allowances**: Night shift differential pay

**System Requirements**:
- Shift-based user sessions
- Handover checklists
- Shift performance reports
- Union-compliant time tracking
- Shift allowance calculation

### 1.3 Audit Requirements
- **Internal Audits**: Monthly departmental audits
- **External Audits**: ISO 9001, ISO 14001, OHSAS 18001
- **Financial Audits**: Annual statutory audits
- **Regulatory**: EPA, FDA, Ghana Standards Authority

**System Requirements**:
- Immutable audit trails
- Digital signatures
- Document version control
- Audit report generation
- Compliance dashboards

### 1.4 Labor Environment
- **Unionized Workforce**: ICU, TUC affiliations
- **Collective Bargaining**: Annual negotiations
- **Grievance Procedures**: Formal complaint systems
- **Training Requirements**: Mandatory safety training

**System Requirements**:
- Union membership tracking
- Training compliance
- Grievance workflow
- Overtime approval chains
- Performance documentation

---

## 2. MODULE ARCHITECTURE (GHANA-SPECIFIC)

### 2.1 RWOP - Repair Work Order Program

#### Ghana-Specific Features
```
- Emergency Breakdown Priority (Production stoppage)
- Shift-based work assignment
- Union technician rotation
- Spare parts local sourcing tracking
- Forex impact on imported parts
- Vendor performance (local vs imported)
- Downtime cost calculation (GHS)
```

#### Workflow
```
Operator Report → Supervisor Approval → Planner Assignment → 
Union Shop Steward Notification → Technician Assignment → 
Parts Request → Store Issue → Work Execution → 
Shift Handover (if needed) → Completion → 
Supervisor Verification → Production Sign-off → Close
```

#### Data Model Extensions
```sql
CREATE TABLE rwop_work_orders (
    id VARCHAR(36) PRIMARY KEY,
    shift_id VARCHAR(36) NOT NULL,
    union_notification_sent BOOLEAN DEFAULT FALSE,
    production_loss_ghs DECIMAL(15,2),
    power_outage_related BOOLEAN DEFAULT FALSE,
    local_parts_used BOOLEAN DEFAULT FALSE,
    forex_impact_ghs DECIMAL(15,2),
    INDEX idx_shift (shift_id)
);
```

### 2.2 MRMP - Machine Reliability Maintenance Program

#### Ghana-Specific Features
```
- Humidity/temperature impact tracking (coastal vs inland)
- Rainy season maintenance schedules
- Generator maintenance integration
- Voltage fluctuation damage tracking
- Local calibration lab certification
- Spare parts lead time (local vs imported)
```

#### PM Schedule Adjustments
```
- Rainy Season (Apr-Jul, Sep-Nov): Increased frequency
- Dry Season (Dec-Mar): Standard frequency
- Harmattan (Dec-Feb): Dust protection focus
- Generator PM: Weekly during dumsor periods
```

#### Data Model Extensions
```sql
CREATE TABLE mrmp_pm_schedules (
    id VARCHAR(36) PRIMARY KEY,
    season_adjusted BOOLEAN DEFAULT TRUE,
    weather_condition ENUM('normal','rainy','harmattan','hot'),
    voltage_fluctuation_check BOOLEAN DEFAULT TRUE,
    generator_runtime_hours DECIMAL(10,2)
);
```

### 2.3 MPMP - Manufacturing Production Management

#### Ghana-Specific Features
```
- Shift production targets
- Power outage downtime tracking
- Raw material local content %
- Forex impact on production cost
- Union break time compliance
- Shift changeover efficiency
- Generator fuel consumption
```

#### OEE Calculation (Ghana Context)
```
Availability = (Planned Production Time - Downtime - Power Outages) / Planned Production Time
Performance = (Actual Output / Target Output) × (Standard Time / Actual Time)
Quality = (Good Units / Total Units)

Ghana OEE = Availability × Performance × Quality × Power Reliability Factor
```

#### Data Model Extensions
```sql
CREATE TABLE mpmp_production_orders (
    id VARCHAR(36) PRIMARY KEY,
    shift_id VARCHAR(36) NOT NULL,
    power_outage_minutes INT DEFAULT 0,
    generator_used BOOLEAN DEFAULT FALSE,
    local_content_percentage DECIMAL(5,2),
    forex_cost_ghs DECIMAL(15,2),
    union_break_compliance BOOLEAN DEFAULT TRUE
);

CREATE TABLE mpmp_power_outages (
    id VARCHAR(36) PRIMARY KEY,
    production_order_id VARCHAR(36),
    outage_start DATETIME NOT NULL,
    outage_end DATETIME,
    generator_switchover_seconds INT,
    production_loss_ghs DECIMAL(15,2)
);
```

### 2.4 IMS - Inventory Management System

#### Ghana-Specific Features
```
- Local vs Imported parts classification
- Forex rate tracking
- Lead time by source (local/imported)
- Customs clearance tracking
- Local supplier performance
- Minimum stock for dumsor periods
- Generator fuel inventory
```

#### Reorder Logic (Ghana Context)
```
Reorder Point = (Lead Time × Daily Usage) + Safety Stock + Dumsor Buffer

Safety Stock = Max Daily Usage × Max Lead Time × Forex Risk Factor
Dumsor Buffer = Critical parts × 2 weeks supply
```

#### Data Model Extensions
```sql
CREATE TABLE ims_parts (
    id VARCHAR(36) PRIMARY KEY,
    source_type ENUM('local','imported','both') NOT NULL,
    forex_sensitive BOOLEAN DEFAULT FALSE,
    customs_clearance_days INT,
    local_supplier_id VARCHAR(36),
    import_supplier_id VARCHAR(36),
    dumsor_critical BOOLEAN DEFAULT FALSE,
    last_forex_rate DECIMAL(10,4)
);

CREATE TABLE ims_forex_rates (
    id VARCHAR(36) PRIMARY KEY,
    currency_code VARCHAR(3) NOT NULL,
    rate_to_ghs DECIMAL(10,4) NOT NULL,
    effective_date DATE NOT NULL,
    INDEX idx_date (effective_date)
);
```

### 2.5 HRMS - Human Resources Management

#### Ghana-Specific Features
```
- Union membership tracking
- SSNIT contribution calculation
- Tier 2 & 3 pension tracking
- Shift allowance calculation
- Night shift differential (30-50%)
- Overtime approval (union rules)
- Training compliance (EPA, FDA, GSA)
- Medical insurance (NHIS integration)
```

#### Payroll Integration
```
Basic Salary + Shift Allowance + Night Differential + 
Overtime + Production Bonus - SSNIT (13.5%) - 
Tier 2 (5%) - Income Tax (Progressive) = Net Pay
```

#### Data Model Extensions
```sql
CREATE TABLE hrms_employees (
    id VARCHAR(36) PRIMARY KEY,
    union_member BOOLEAN DEFAULT FALSE,
    union_id VARCHAR(50),
    ssnit_number VARCHAR(20) NOT NULL,
    nhis_number VARCHAR(20),
    tier2_provider VARCHAR(100),
    shift_preference ENUM('morning','afternoon','night','rotating'),
    night_shift_rate DECIMAL(5,2) DEFAULT 1.5
);

CREATE TABLE hrms_shift_attendance (
    id VARCHAR(36) PRIMARY KEY,
    employee_id VARCHAR(36) NOT NULL,
    shift_id VARCHAR(36) NOT NULL,
    clock_in DATETIME NOT NULL,
    clock_out DATETIME,
    break_minutes INT DEFAULT 60,
    overtime_approved BOOLEAN DEFAULT FALSE,
    union_steward_id VARCHAR(36),
    INDEX idx_employee_shift (employee_id, shift_id)
);
```

### 2.6 TRAC - Tool & Rotating Asset Control

#### Ghana-Specific Features
```
- Tool custody tracking (union accountability)
- Calibration certificate tracking (GSA)
- Tool loss investigation workflow
- Rotating equipment (pumps, motors, gearboxes)
- Vibration analysis scheduling
- Bearing temperature monitoring
- Local vs imported tool sourcing
```

#### Data Model
```sql
CREATE TABLE trac_tools (
    id VARCHAR(36) PRIMARY KEY,
    tool_code VARCHAR(50) UNIQUE NOT NULL,
    custody_holder_id VARCHAR(36),
    union_signed_out BOOLEAN DEFAULT FALSE,
    calibration_cert_number VARCHAR(50),
    gsa_certified BOOLEAN DEFAULT FALSE,
    source_type ENUM('local','imported'),
    last_calibration_date DATE,
    next_calibration_date DATE
);

CREATE TABLE trac_rotating_assets (
    id VARCHAR(36) PRIMARY KEY,
    asset_code VARCHAR(50) UNIQUE NOT NULL,
    vibration_analysis_due DATE,
    bearing_temp_threshold DECIMAL(5,2),
    last_overhaul_date DATE,
    overhaul_interval_hours INT
);
```

---

## 3. OFFLINE-FIRST ARCHITECTURE

### 3.1 Frontend Strategy
```typescript
// Service Worker for offline capability
// Cache API responses
// IndexedDB for local storage
// Background sync when online

interface OfflineQueue {
  id: string;
  endpoint: string;
  method: string;
  data: any;
  timestamp: number;
  retryCount: number;
}
```

### 3.2 Sync Strategy
```
1. User performs action offline
2. Store in IndexedDB queue
3. Show optimistic UI update
4. When online, sync queue
5. Resolve conflicts (last-write-wins)
6. Update UI with server response
```

---

## 4. SHIFT MANAGEMENT SYSTEM

### 4.1 Shift Configuration
```sql
CREATE TABLE shifts (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_minutes INT DEFAULT 60,
    shift_allowance_ghs DECIMAL(10,2),
    is_night_shift BOOLEAN DEFAULT FALSE,
    night_differential DECIMAL(5,2) DEFAULT 1.5
);

CREATE TABLE shift_handovers (
    id VARCHAR(36) PRIMARY KEY,
    from_shift_id VARCHAR(36) NOT NULL,
    to_shift_id VARCHAR(36) NOT NULL,
    handover_date DATE NOT NULL,
    outgoing_supervisor_id VARCHAR(36),
    incoming_supervisor_id VARCHAR(36),
    production_status TEXT,
    pending_work_orders JSON,
    equipment_status JSON,
    safety_incidents JSON,
    signed_off BOOLEAN DEFAULT FALSE
);
```

---

## 5. AUDIT & COMPLIANCE

### 5.1 Audit Trail Requirements
```sql
CREATE TABLE audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    module_code VARCHAR(50) NOT NULL,
    entity_type VARCHAR(100) NOT NULL,
    entity_id VARCHAR(36) NOT NULL,
    action VARCHAR(50) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    user_name VARCHAR(100) NOT NULL,
    user_staff_id VARCHAR(50) NOT NULL,
    shift_id VARCHAR(36),
    before_data JSON,
    after_data JSON,
    ip_address VARCHAR(45),
    device_info TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_reversible BOOLEAN DEFAULT FALSE,
    reversed_by VARCHAR(36),
    reversed_at TIMESTAMP,
    INDEX idx_module (module_code),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_user (user_id),
    INDEX idx_shift (shift_id),
    INDEX idx_created (created_at)
);
```

### 5.2 Digital Signatures
```sql
CREATE TABLE digital_signatures (
    id VARCHAR(36) PRIMARY KEY,
    document_type VARCHAR(100) NOT NULL,
    document_id VARCHAR(36) NOT NULL,
    signer_id VARCHAR(36) NOT NULL,
    signer_name VARCHAR(100) NOT NULL,
    signature_hash VARCHAR(255) NOT NULL,
    signed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ip_address VARCHAR(45),
    INDEX idx_document (document_type, document_id)
);
```

---

## 6. COST TRACKING (GHS)

### 6.1 Cost Centers
```sql
CREATE TABLE cost_centers (
    id VARCHAR(36) PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    department_id VARCHAR(36),
    budget_ghs DECIMAL(15,2),
    actual_ghs DECIMAL(15,2) DEFAULT 0
);

CREATE TABLE cost_transactions (
    id VARCHAR(36) PRIMARY KEY,
    cost_center_id VARCHAR(36) NOT NULL,
    module_code VARCHAR(50) NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    amount_ghs DECIMAL(15,2) NOT NULL,
    forex_amount DECIMAL(15,2),
    forex_currency VARCHAR(3),
    forex_rate DECIMAL(10,4),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 7. REPORTING REQUIREMENTS

### 7.1 Management Reports
```
Daily:
- Shift production summary
- Downtime analysis (including power outages)
- Work order completion rate
- Material consumption

Weekly:
- OEE by shift
- Maintenance backlog
- Inventory turnover
- Cost center variance

Monthly:
- PM compliance rate
- Training compliance
- Union grievances
- Audit findings
- Forex impact analysis
```

---

## 8. IMPLEMENTATION PRIORITIES

### Phase 1: Foundation (Week 1-2)
- Offline-first architecture
- Shift management
- Audit logging
- Power outage tracking

### Phase 2: Core Modules (Week 3-6)
- RWOP with shift handover
- IMS with forex tracking
- HRMS with union features
- MPMP with OEE

### Phase 3: Advanced (Week 7-8)
- MRMP with season adjustments
- TRAC module
- Cost tracking
- Management dashboards

### Phase 4: Compliance (Week 9-10)
- Audit reports
- Digital signatures
- Regulatory compliance
- Training system

---

**This architecture is designed for real Ghanaian industrial operations, not theoretical scenarios.**
