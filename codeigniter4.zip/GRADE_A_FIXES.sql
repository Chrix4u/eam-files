-- =====================================================
-- GRADE A+ MAINTENANCE REQUEST SYSTEM - DATABASE FIXES
-- =====================================================
-- Database: factory_manager
-- Execute this script to fix all issues and add Grade A features

USE factory_manager;

-- 1. Ensure all workflow columns exist
ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS workflow_status ENUM('pending','supervisor_review','approved','rejected','assigned_to_planner','work_order_created','completed') DEFAULT 'pending' AFTER status;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS supervisor_id INT UNSIGNED NULL AFTER workflow_status;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS reviewed_by INT UNSIGNED NULL AFTER supervisor_id;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS reviewed_at DATETIME NULL AFTER reviewed_by;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS review_notes TEXT NULL AFTER reviewed_at;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS assigned_planner_id INT UNSIGNED NULL AFTER review_notes;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS planner_type ENUM('engineering','production') NULL AFTER assigned_planner_id;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS work_order_id INT UNSIGNED NULL AFTER planner_type;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS rejection_reason TEXT NULL AFTER work_order_id;

ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS department_id INT UNSIGNED NULL AFTER rejection_reason;

-- 2. Add SLA tracking columns
ALTER TABLE maintenance_requests 
ADD COLUMN IF NOT EXISTS sla_due_date DATETIME NULL AFTER department_id,
ADD COLUMN IF NOT EXISTS sla_status ENUM('on_time','at_risk','overdue') DEFAULT 'on_time' AFTER sla_due_date,
ADD COLUMN IF NOT EXISTS response_time INT NULL COMMENT 'Response time in minutes' AFTER sla_status,
ADD COLUMN IF NOT EXISTS resolution_time INT NULL COMMENT 'Resolution time in minutes' AFTER response_time;

-- 3. Add indexes for performance
ALTER TABLE maintenance_requests 
ADD INDEX IF NOT EXISTS idx_workflow_status (workflow_status),
ADD INDEX IF NOT EXISTS idx_supervisor (supervisor_id),
ADD INDEX IF NOT EXISTS idx_planner (assigned_planner_id),
ADD INDEX IF NOT EXISTS idx_department (department_id),
ADD INDEX IF NOT EXISTS idx_sla_status (sla_status),
ADD INDEX IF NOT EXISTS idx_created_at (created_at);

-- 4. Create workflow history table
CREATE TABLE IF NOT EXISTS maintenance_request_workflow (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    from_status VARCHAR(50),
    to_status VARCHAR(50) NOT NULL,
    action_by INT UNSIGNED NOT NULL,
    action_type ENUM('created','reviewed','approved','rejected','assigned','converted','completed','commented') NOT NULL,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_action_by (action_by),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (request_id) REFERENCES maintenance_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Create notifications table
CREATE TABLE IF NOT EXISTS maintenance_notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    request_id INT UNSIGNED NULL,
    work_order_id INT UNSIGNED NULL,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    read_at DATETIME NULL,
    INDEX idx_user_read (user_id, is_read),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (request_id) REFERENCES maintenance_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Create attachments table
CREATE TABLE IF NOT EXISTS maintenance_attachments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_type VARCHAR(100),
    file_size INT UNSIGNED,
    uploaded_by INT UNSIGNED NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    FOREIGN KEY (request_id) REFERENCES maintenance_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Create comments table
CREATE TABLE IF NOT EXISTS maintenance_comments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    request_id INT UNSIGNED NOT NULL,
    user_id INT UNSIGNED NOT NULL,
    comment TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_request (request_id),
    INDEX idx_created_at (created_at),
    FOREIGN KEY (request_id) REFERENCES maintenance_requests(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Create SLA configuration table
CREATE TABLE IF NOT EXISTS maintenance_sla_config (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    priority ENUM('low','medium','high','urgent') NOT NULL UNIQUE,
    response_time_hours INT NOT NULL COMMENT 'Response time in hours',
    resolution_time_hours INT NOT NULL COMMENT 'Resolution time in hours',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. Insert default SLA configurations
INSERT INTO maintenance_sla_config (priority, response_time_hours, resolution_time_hours) VALUES
('urgent', 1, 4),
('high', 4, 24),
('medium', 8, 72),
('low', 24, 168)
ON DUPLICATE KEY UPDATE 
    response_time_hours = VALUES(response_time_hours),
    resolution_time_hours = VALUES(resolution_time_hours);

-- 10. Create analytics view for reporting
CREATE OR REPLACE VIEW v_maintenance_request_analytics AS
SELECT 
    mr.id,
    mr.request_number,
    mr.title,
    mr.priority,
    mr.status,
    mr.workflow_status,
    mr.sla_status,
    mr.response_time,
    mr.resolution_time,
    mr.created_at,
    mr.updated_at,
    mr.requested_date,
    mr.completed_date,
    m.machine_name,
    m.machine_code,
    a.assembly_name,
    p.part_name,
    u1.username as requested_by_name,
    u1.email as requested_by_email,
    u2.username as assigned_to_name,
    u3.username as supervisor_name,
    u4.username as planner_name,
    d.name as department_name,
    TIMESTAMPDIFF(MINUTE, mr.created_at, COALESCE(mr.reviewed_at, NOW())) as time_to_review,
    TIMESTAMPDIFF(MINUTE, mr.created_at, COALESCE(mr.completed_date, NOW())) as time_to_complete,
    CASE 
        WHEN mr.sla_due_date IS NULL THEN NULL
        WHEN NOW() > mr.sla_due_date AND mr.status != 'completed' THEN 'overdue'
        WHEN TIMESTAMPDIFF(HOUR, NOW(), mr.sla_due_date) <= 4 THEN 'at_risk'
        ELSE 'on_time'
    END as calculated_sla_status
FROM maintenance_requests mr
LEFT JOIN machines m ON m.id = mr.machine_id
LEFT JOIN assemblies a ON a.id = mr.assembly_id
LEFT JOIN parts p ON p.id = mr.part_id
LEFT JOIN users u1 ON u1.id = mr.requested_by
LEFT JOIN users u2 ON u2.id = mr.assigned_to
LEFT JOIN users u3 ON u3.id = mr.supervisor_id
LEFT JOIN users u4 ON u4.id = mr.assigned_planner_id
LEFT JOIN departments d ON d.id = mr.department_id;

-- 11. Create stored procedure to calculate SLA
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS sp_calculate_sla(IN p_request_id INT)
BEGIN
    DECLARE v_priority VARCHAR(20);
    DECLARE v_response_hours INT;
    DECLARE v_resolution_hours INT;
    DECLARE v_created_at DATETIME;
    
    -- Get request details
    SELECT priority, created_at INTO v_priority, v_created_at
    FROM maintenance_requests
    WHERE id = p_request_id;
    
    -- Get SLA config
    SELECT response_time_hours, resolution_time_hours 
    INTO v_response_hours, v_resolution_hours
    FROM maintenance_sla_config
    WHERE priority = v_priority;
    
    -- Update SLA due date
    UPDATE maintenance_requests
    SET sla_due_date = DATE_ADD(v_created_at, INTERVAL v_resolution_hours HOUR)
    WHERE id = p_request_id;
END //
DELIMITER ;

-- 12. Create trigger to auto-calculate SLA on insert
DELIMITER //
CREATE TRIGGER IF NOT EXISTS trg_maintenance_request_sla_insert
AFTER INSERT ON maintenance_requests
FOR EACH ROW
BEGIN
    CALL sp_calculate_sla(NEW.id);
END //
DELIMITER ;

-- 13. Update existing requests with SLA
UPDATE maintenance_requests mr
JOIN maintenance_sla_config sla ON sla.priority = mr.priority
SET mr.sla_due_date = DATE_ADD(mr.created_at, INTERVAL sla.resolution_time_hours HOUR)
WHERE mr.sla_due_date IS NULL;

-- 14. Create indexes for work_orders table if not exists
CREATE TABLE IF NOT EXISTS work_orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_number VARCHAR(50) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
    status ENUM('open','in_progress','on_hold','completed','cancelled') DEFAULT 'open',
    work_type ENUM('corrective','preventive','predictive','inspection') DEFAULT 'corrective',
    machine_id INT UNSIGNED NULL,
    assembly_id INT UNSIGNED NULL,
    part_id INT UNSIGNED NULL,
    location VARCHAR(255),
    assigned_to INT UNSIGNED NULL,
    scheduled_date DATETIME NULL,
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    estimated_hours DECIMAL(10,2),
    actual_hours DECIMAL(10,2),
    created_by INT UNSIGNED NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_assigned_to (assigned_to),
    INDEX idx_scheduled_date (scheduled_date),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Check maintenance_requests structure
SELECT 'Maintenance Requests Columns:' as Info;
SHOW COLUMNS FROM maintenance_requests;

-- Check workflow history
SELECT 'Workflow History Count:' as Info, COUNT(*) as count FROM maintenance_request_workflow;

-- Check notifications
SELECT 'Notifications Count:' as Info, COUNT(*) as count FROM maintenance_notifications;

-- Check SLA config
SELECT 'SLA Configuration:' as Info;
SELECT * FROM maintenance_sla_config;

-- Check recent requests with SLA
SELECT 'Recent Requests with SLA:' as Info;
SELECT id, request_number, priority, status, sla_status, sla_due_date, created_at
FROM maintenance_requests
ORDER BY created_at DESC
LIMIT 5;

SELECT '✅ Grade A+ Database Setup Complete!' as Status;
