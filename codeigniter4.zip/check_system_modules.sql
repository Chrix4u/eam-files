-- Check system_modules table structure and data

-- Table structure
DESCRIBE system_modules;

-- Current data
SELECT 
    code,
    name,
    enabled,
    version,
    dependencies,
    ghana_features,
    created_at
FROM system_modules
ORDER BY code;

-- Count modules
SELECT COUNT(*) as total_modules FROM system_modules;

-- Check enabled modules
SELECT code, name FROM system_modules WHERE enabled = TRUE;
