ALTER TABLE maintenance_requests 
ADD COLUMN assembly_id INT(11) UNSIGNED NULL AFTER machine_id,
ADD COLUMN part_id INT(11) UNSIGNED NULL AFTER assembly_id;