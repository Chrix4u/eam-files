<?php
$conn = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

echo "=== CREATING BACKWARD COMPATIBILITY VIEW ===\n\n";

// Create a view named 'assets' that maps to assets_unified
$view_sql = "
CREATE OR REPLACE VIEW assets AS
SELECT 
    id,
    asset_code,
    asset_name,
    asset_type,
    parent_id,
    hierarchy_level,
    hierarchy_path,
    manufacturer,
    model_number,
    serial_number,
    installation_date,
    status,
    criticality,
    health_score,
    location_id,
    department_id,
    mtbf_hours,
    mttr_hours,
    oee_percent,
    acquisition_cost,
    model_3d_id,
    tags,
    custom_fields,
    created_at,
    updated_at,
    created_by
FROM assets_unified
";

if ($conn->query($view_sql)) {
    echo "✓ Created VIEW 'assets' -> assets_unified\n";
    echo "  All queries to 'assets' table will now use assets_unified\n\n";
} else {
    echo "✗ Failed to create view: " . $conn->error . "\n\n";
}

// Test the view
$test = $conn->query("SELECT COUNT(*) as cnt FROM assets")->fetch_assoc()['cnt'];
echo "✓ View test: $test records accessible via 'assets' view\n\n";

echo "=== COMPLETE ===\n";
echo "The 'assets' table is now a VIEW pointing to assets_unified.\n";
echo "All existing code will continue to work without changes.\n\n";

$conn->close();
?>
