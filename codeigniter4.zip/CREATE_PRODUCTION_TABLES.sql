-- Production Data Tables Creation Script
-- Run this in phpMyAdmin or MySQL command line

USE factorymanager;

-- Drop old table if exists and create new production_targets
DROP TABLE IF EXISTS `production_targets`;

-- Table 1: Production Targets
CREATE TABLE IF NOT EXISTS `production_targets` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_center` VARCHAR(100) NOT NULL,
    `code` VARCHAR(50) NOT NULL,
    `machine_id` INT(11) UNSIGNED NOT NULL,
    `target_date` DATE NOT NULL,
    `units_per_day` INT(11) DEFAULT NULL,
    `hours_per_unit_shift` DECIMAL(10,2) DEFAULT NULL,
    `target_per_machine` INT(11) DEFAULT NULL,
    `total_time_available_mins` INT(11) NOT NULL,
    `utilization_standard_percent` DECIMAL(5,2) DEFAULT 85.00,
    `speed_standard_yds_per_min` DECIMAL(10,2) DEFAULT 50.00,
    `created_by` INT(11) UNSIGNED DEFAULT NULL,
    `created_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `machine_id` (`machine_id`),
    KEY `target_date` (`target_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table 2: Operator Production Data
CREATE TABLE IF NOT EXISTS `operator_production_data` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `target_id` INT(11) UNSIGNED NOT NULL,
    `operator_id` INT(11) UNSIGNED NOT NULL,
    `shift` ENUM('Morning','Afternoon','Night') NOT NULL,
    `entry_date` DATE NOT NULL,
    
    -- Stoppages (Columns H-N)
    `break_mins` INT(11) DEFAULT 0,
    `repair_maint_mins` INT(11) DEFAULT 0,
    `input_delivery_mins` INT(11) DEFAULT 0,
    `change_over_mins` INT(11) DEFAULT 0,
    `startup_mins` INT(11) DEFAULT 0,
    `cleaning_mins` INT(11) DEFAULT 0,
    `others_mins` INT(11) DEFAULT 0,
    `preventive_maint_mins` INT(11) DEFAULT 0,
    
    -- Auto-calculated (Column O)
    `total_downtime_mins` INT(11) DEFAULT 0,
    
    -- Production
    `production_yards` DECIMAL(10,2) DEFAULT 0.00,
    
    -- Auto-calculated metrics
    `productive_time_mins` INT(11) DEFAULT 0,
    `utilization_actual` DECIMAL(5,2) DEFAULT 0.00,
    `speed_actual` DECIMAL(10,2) DEFAULT 0.00,
    `productivity` DECIMAL(5,2) DEFAULT 0.00,
    `efficiency` DECIMAL(5,2) DEFAULT 0.00,
    
    `created_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    `deleted_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `target_id` (`target_id`),
    KEY `operator_id` (`operator_id`),
    KEY `entry_date` (`entry_date`),
    KEY `shift` (`shift`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table 3: Production Data Summary (for reports)
CREATE TABLE IF NOT EXISTS `production_data_summary` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `work_center` VARCHAR(100) NOT NULL,
    `code` VARCHAR(50) NOT NULL,
    `report_date` DATE NOT NULL,
    
    -- Aggregated data
    `total_time_available_mins` INT(11) NOT NULL,
    `total_downtime_mins` INT(11) NOT NULL,
    `productive_time_mins` INT(11) NOT NULL,
    
    -- Production by shift
    `production_morning` DECIMAL(10,2) DEFAULT 0.00,
    `production_afternoon` DECIMAL(10,2) DEFAULT 0.00,
    `production_night` DECIMAL(10,2) DEFAULT 0.00,
    `total_production_yards` DECIMAL(10,2) DEFAULT 0.00,
    `target_yards` DECIMAL(10,2) DEFAULT 0.00,
    
    -- Metrics
    `utilization_actual` DECIMAL(5,2) DEFAULT 0.00,
    `utilization_standard` DECIMAL(5,2) DEFAULT 0.00,
    `speed_actual` DECIMAL(10,2) DEFAULT 0.00,
    `speed_standard` DECIMAL(10,2) DEFAULT 0.00,
    `productivity` DECIMAL(5,2) DEFAULT 0.00,
    `efficiency` DECIMAL(5,2) DEFAULT 0.00,
    
    `created_at` DATETIME DEFAULT NULL,
    `updated_at` DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`),
    KEY `report_date` (`report_date`),
    KEY `work_center_code` (`work_center`, `code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Verify tables created
SELECT 'Tables created successfully!' AS Status;
SHOW TABLES LIKE 'production_%';
