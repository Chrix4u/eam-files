@echo off
echo ========================================
echo Running Database Migrations
echo ========================================
cd c:\wamp64\bin\mysql\mysql9.5.0\bin
mysql.exe -u root -pmyjesus4mE factory_manager < c:\wamp64\www\factorymanager\RUN_ALL_MIGRATIONS.sql
echo.
echo ========================================
echo Migrations Completed!
echo ========================================
echo.
echo Tables created:
echo - technician_time_logs
echo - work_order_materials_used
echo - work_order_completion_reports
echo - work_order_signatures
echo - work_order_attachments
echo - permits_to_work
echo - permit_approvals
echo - permit_extensions
echo - loto_procedures
echo - loto_applications
echo - loto_locks
echo.
pause
