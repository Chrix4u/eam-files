<?php
require 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$sql = "CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NOT NULL,
    old_values JSON NULL,
    new_values JSON NULL,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created (created_at)
)";

if ($db->query($sql)) {
    echo "✓ Table 'audit_logs' created\n";
} else {
    echo "Error: " . $db->error . "\n";
}

$result = $db->query("SHOW COLUMNS FROM audit_logs LIKE 'entity_type'");
if ($result->num_rows > 0) {
    $samples = [
        [1, 'create', 'work_order', 1, null, '{"title":"PM Check","priority":"high"}'],
        [1, 'update', 'asset', 5, '{"status":"active"}', '{"status":"maintenance"}'],
        [2, 'delete', 'inventory', 3, '{"quantity":50}', null],
        [1, 'create', 'iot_device', 1, null, '{"device_id":"SENSOR-001","type":"vibration"}'],
        [3, 'update', 'work_order', 1, '{"status":"open"}', '{"status":"completed"}']
    ];

    foreach ($samples as $s) {
        $stmt = $db->prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?, ?, ?, ?, ?, ?, '127.0.0.1')");
        $stmt->bind_param("ississ", $s[0], $s[1], $s[2], $s[3], $s[4], $s[5]);
        $stmt->execute();
    }

    echo "✓ Inserted 5 sample audit logs\n";
} else {
    echo "⚠ Skipping sample data - table structure issue\n";
}

$db->close();
?>
