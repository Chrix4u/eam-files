@echo off
echo Checking admin user...
C:\wamp64\bin\mysql\mysql8.2.0\bin\mysql.exe -u root -pmyjesus4mE factory_manager -e "SELECT id, username, email, full_name, role, status FROM users WHERE role='admin' OR username='admin' OR email='admin@factory.com' LIMIT 5;"
pause
