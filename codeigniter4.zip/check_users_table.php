<?php
$mysqli = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

echo "=== Users Table Structure ===\n";
$result = $mysqli->query("DESCRIBE users");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo "• {$row['Field']} ({$row['Type']}) - " . (!empty($row['Null']) && $row['Null'] === 'YES' ? 'nullable' : 'NOT NULL') . "\n";
    }
}

echo "\n=== Sample Users ===\n";
$users = $mysqli->query("SELECT * FROM users LIMIT 5");
if ($users) {
    while ($row = $users->fetch_assoc()) {
        echo json_encode($row) . "\n";
    }
}

$mysqli->close();
?>
