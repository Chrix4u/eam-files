-- Add support for partial issuance and extended conditions
-- Run this SQL in your MySQL database

-- Add issue_notes column to work_order_tool_request_items
ALTER TABLE `work_order_tool_request_items`
ADD COLUMN `issue_notes` TEXT NULL AFTER `condition_on_issue`,
COMMENT 'Reason for partial issuance or non-issuance';

-- Add issue_notes column to tool_issue_logs
ALTER TABLE `tool_issue_logs`
ADD COLUMN `issue_notes` TEXT NULL AFTER `condition_on_issue`,
COMMENT 'Notes about tool condition or partial issuance';

-- Add PARTIAL_ISSUED status to work_order_tool_requests if not exists
-- This allows tracking requests where not all tools were fully issued
-- Status flow: PENDING → APPROVED → ISSUED/PARTIAL_ISSUED → RETURN_PENDING → COMPLETED

-- Update existing enum if needed (check your current enum values first)
-- ALTER TABLE `work_order_tool_requests` 
-- MODIFY COLUMN `request_status` ENUM('PENDING','APPROVED','REJECTED','CANCELLED','ISSUED','PARTIAL_ISSUED','RETURN_PENDING','COMPLETED') 
-- DEFAULT 'PENDING';

-- Note: The above ALTER for enum is commented out because it depends on your current schema
-- If you need to add PARTIAL_ISSUED status, uncomment and adjust based on your existing enum values
