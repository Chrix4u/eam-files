<?php

/**
 * Enterprise-Grade API Routes for Advanced EAM Modules
 * Add these routes to app/Config/Routes.php under the API v1 group
 */

// RCA Analysis Routes
$routes->group('rca', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    // 5 Whys
    $routes->get('5whys', 'RCAController::get5Whys');
    $routes->get('5whys/(:num)', 'RCAController::get5WhysById/$1');
    $routes->post('5whys', 'RCAController::create5Whys');
    $routes->put('5whys/(:num)', 'RCAController::update5Whys/$1');
    $routes->delete('5whys/(:num)', 'RCAController::delete5Whys/$1');
    
    // Fishbone
    $routes->get('fishbone', 'RCAController::getFishbone');
    $routes->get('fishbone/(:num)', 'RCAController::getFishboneById/$1');
    $routes->post('fishbone', 'RCAController::createFishbone');
    $routes->put('fishbone/(:num)', 'RCAController::updateFishbone/$1');
    $routes->delete('fishbone/(:num)', 'RCAController::deleteFishbone/$1');
    
    // Statistics
    $routes->get('statistics', 'RCAController::getStatistics');
});

// Failure Modes (FMEA) Routes
$routes->group('failure-modes', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    $routes->get('/', 'FailureModeController::index');
    $routes->post('/', 'FailureModeController::create');
    $routes->put('(:num)', 'FailureModeController::update/$1');
    $routes->delete('(:num)', 'FailureModeController::delete/$1');
});

// RCM Routes
$routes->group('rcm', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    $routes->get('/', 'RCMController::index');
    $routes->post('/', 'RCMController::create');
    $routes->put('(:num)', 'RCMController::update/$1');
    $routes->get('strategies', 'RCMController::getStrategies');
});

// Parts Optimization Routes
$routes->group('parts-optimization', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    $routes->get('/', 'PartsOptimizationController::index');
    $routes->post('run-analysis', 'PartsOptimizationController::runAnalysis');
    $routes->get('abc-analysis', 'PartsOptimizationController::getABCAnalysis');
});

// KPI Dashboard Routes
$routes->group('kpi', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    $routes->get('summary', 'KPIController::getSummary');
    $routes->get('trends', 'KPIController::getTrends');
    $routes->get('cost-breakdown', 'KPIController::getCostBreakdown');
});

// Work Order Backlog Routes (extends existing work-orders)
$routes->group('work-orders', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    $routes->get('backlog', 'WorkOrderController::getBacklog');
    $routes->get('backlog/aging', 'WorkOrderController::getBacklogAging');
    $routes->post('(:num)/schedule', 'WorkOrderController::schedule/$1');
});

// Mobile Work Orders Routes
$routes->group('mobile', ['namespace' => 'App\Controllers\API\V1'], function($routes) {
    $routes->get('work-orders/assigned/(:num)', 'MobileWorkOrderController::getAssigned/$1');
    $routes->post('work-orders/(:num)/start', 'MobileWorkOrderController::start/$1');
    $routes->post('work-orders/(:num)/complete', 'MobileWorkOrderController::complete/$1');
    $routes->post('work-orders/(:num)/photos', 'MobileWorkOrderController::uploadPhoto/$1');
    $routes->post('work-orders/(:num)/time-log', 'MobileWorkOrderController::logTime/$1');
});
