# 🔧 BACKEND CODE REFACTORING PLAN

**Status**: Ready to Execute  
**Target**: Remove all company_id references, implement plant_id scoping

---

## 📊 Analysis Results

### Company References Found
- **Controllers**: 24 references
- **Models**: 9 references
- **Total**: 33+ references

### Primary Files to Refactor
1. `CompanyModuleController.php` - DELETE (obsolete)
2. `ModuleLicenseController.php` - DELETE (obsolete)
3. `CompanySettingsController.php` - DELETE (obsolete)
4. Other controllers with company_id filters

---

## 🎯 Refactoring Strategy

### Phase 1: Delete Obsolete Controllers (IMMEDIATE)
```
✓ CompanyModuleController.php
✓ ModuleLicenseController.php  
✓ CompanySettingsController.php
✓ SystemModuleController.php
```

### Phase 2: Create New Module Controller (NEW)
```
✓ GlobalModuleController.php (uses modules table)
```

### Phase 3: Update Existing Controllers
```
□ Remove company_id filters
□ Add plant_id filters
□ Update validation rules
```

### Phase 4: Update Models
```
□ Remove company_id from $allowedFields
□ Add plant_id to $allowedFields
□ Add plant scoping methods
```

---

## 🚀 Execution Plan

### Step 1: Delete Obsolete Files
- [x] Identify obsolete controllers
- [ ] Delete CompanyModuleController.php
- [ ] Delete ModuleLicenseController.php
- [ ] Delete CompanySettingsController.php
- [ ] Delete SystemModuleController.php
- [ ] Delete ModuleController.php (if exists)

### Step 2: Create GlobalModuleController
- [ ] Create new controller using modules table
- [ ] Implement CRUD operations
- [ ] Add activation/deactivation with locks
- [ ] Add audit logging

### Step 3: Update Routes
- [ ] Remove old module routes
- [ ] Add new global module routes
- [ ] Update API documentation

### Step 4: Update Models
- [ ] Scan all models for company_id
- [ ] Replace with plant_id
- [ ] Add plant scoping methods

### Step 5: Testing
- [ ] Test module activation
- [ ] Test plant scoping
- [ ] Test API endpoints
- [ ] Verify no company_id errors

---

## 📁 Files to Modify

### DELETE (5 files)
```
app/Controllers/Api/V1/Modules/Core/
├── CompanyModuleController.php
├── ModuleLicenseController.php
├── CompanySettingsController.php
├── SystemModuleController.php
└── ModuleController.php (if exists)
```

### CREATE (1 file)
```
app/Controllers/Api/V1/Modules/Core/
└── GlobalModuleController.php (NEW)
```

### UPDATE (Multiple files)
```
app/Models/
├── Various models with company_id
└── Add plant_id scoping

app/Controllers/
└── Various controllers with company_id filters
```

---

## 🔍 Search Patterns

### Find company_id references
```bash
findstr /S /I "company_id" app\Controllers\*.php
findstr /S /I "company_id" app\Models\*.php
```

### Find company table references
```bash
findstr /S /I "companies" app\Controllers\*.php
findstr /S /I "company_modules" app\Controllers\*.php
```

---

## ✅ Success Criteria

- [ ] Zero company_id references in code
- [ ] All controllers use plant_id
- [ ] All models use plant_id
- [ ] GlobalModuleController working
- [ ] Module activation/deactivation working
- [ ] Audit logs working
- [ ] All tests passing
- [ ] API documentation updated

---

## 🎯 Next Action

**START**: Delete obsolete controllers and create GlobalModuleController
