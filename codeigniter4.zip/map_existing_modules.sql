-- Module Mapping: Existing → New Structure
-- Step 1: Add missing columns (MySQL 5.7 compatible)

ALTER TABLE system_modules
ADD COLUMN code VARCHAR(50) AFTER id,
ADD COLUMN version VARCHAR(20) DEFAULT '1.0.0' AFTER description,
ADD COLUMN dependencies JSON AFTER version,
ADD COLUMN ghana_features JSON AFTER dependencies,
ADD COLUMN route_prefix VARCHAR(100) AFTER ghana_features,
ADD COLUMN icon VARCHAR(50) AFTER route_prefix,
ADD COLUMN display_order INT DEFAULT 0 AFTER icon;

ALTER TABLE system_modules ADD INDEX idx_code (code);

-- Step 2: Update existing modules with new structure
UPDATE system_modules SET code = 'work_orders', route_prefix = '/rwop' WHERE module_name = 'work_orders';
UPDATE system_modules SET code = 'maintenance_requests', route_prefix = '/rwop' WHERE module_name = 'maintenance_requests';
UPDATE system_modules SET code = 'mrmp', route_prefix = '/mrmp' WHERE module_name = 'preventive_maintenance';
UPDATE system_modules SET code = 'asset', route_prefix = '/asset' WHERE module_name = 'asset_management';
UPDATE system_modules SET code = 'ims', route_prefix = '/ims' WHERE module_name = 'inventory';
UPDATE system_modules SET code = 'core', route_prefix = '/analytics' WHERE module_name = 'analytics';
UPDATE system_modules SET code = 'mrmp_iot', route_prefix = '/mrmp' WHERE module_name = 'iot_monitoring';
UPDATE system_modules SET code = 'mrmp_predictive', route_prefix = '/mrmp' WHERE module_name = 'predictive_maintenance';
UPDATE system_modules SET code = 'core_mobile', route_prefix = '/mobile' WHERE module_name = 'mobile_app';
UPDATE system_modules SET code = 'mpmp', route_prefix = '/mpmp' WHERE module_name = 'production_tracking';

-- Step 3: Add Ghana features to existing modules
UPDATE system_modules SET 
    version = '2.1.0',
    dependencies = '["ims","asset"]',
    ghana_features = '{"shift_handover":true,"union_notification":true,"team_leader_enforcement":true}'
WHERE module_name = 'work_orders';

UPDATE system_modules SET
    version = '1.0.0',
    dependencies = '["asset","ims"]',
    ghana_features = '{"season_adjustment":true,"generator_pm":true,"voltage_monitoring":true,"iot_integration":true,"predictive_analytics":true}'
WHERE module_name IN ('preventive_maintenance', 'iot_monitoring', 'predictive_maintenance');

UPDATE system_modules SET
    version = '1.0.0',
    dependencies = '["asset"]',
    ghana_features = '{"shift_production":true,"power_outage_downtime":true,"union_break_compliance":true}'
WHERE module_name = 'production_tracking';

UPDATE system_modules SET
    version = '1.0.0',
    dependencies = '[]',
    ghana_features = '{"forex_tracking":true,"local_vs_imported":true,"customs_tracking":true,"dumsor_buffer":true}'
WHERE module_name = 'inventory';

-- Insert missing HRMS and TRAC modules
INSERT INTO system_modules (module_name, display_name, description, is_enabled, subscription_tier, code, version, dependencies, ghana_features, route_prefix, display_order)
VALUES 
('hrms', 'Human Resources Management', 'Employee, shift, and training management with Ghana labor compliance', 1, 'professional', 'hrms', '1.0.0', '[]', '{"union_tracking":true,"ssnit_calculation":true,"shift_allowance":true,"night_differential":true}', '/hrms', 5),
('trac', 'Tool & Rotating Asset Control', 'Tool management, LOTO, and permit-to-work system', 1, 'professional', 'trac', '1.0.0', '["asset"]', '{"union_custody":true,"gsa_certification":true}', '/trac', 6)
ON DUPLICATE KEY UPDATE updated_at = NOW();

-- Verify mapping
SELECT 
    module_name as old_name,
    code as new_code,
    display_name,
    route_prefix,
    is_enabled,
    subscription_tier
FROM system_modules
ORDER BY display_order, module_name;
