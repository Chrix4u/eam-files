-- Create Material Requests Table
CREATE TABLE IF NOT EXISTS `material_requests` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `request_number` VARCHAR(50) UNIQUE NOT NULL,
    `work_order_id` INT(11) UNSIGNED NULL,
    `requested_by` INT(11) UNSIGNED NOT NULL,
    `department_id` INT(11) UNSIGNED NULL,
    `request_date` DATETIME NOT NULL,
    `required_date` DATETIME NULL,
    `priority` ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    `status` ENUM('pending', 'approved', 'rejected', 'issued', 'completed', 'cancelled') DEFAULT 'pending',
    `justification` TEXT NULL,
    `reviewed_by` INT(11) UNSIGNED NULL,
    `reviewed_at` DATETIME NULL,
    `review_notes` TEXT NULL,
    `issued_by` INT(11) UNSIGNED NULL,
    `issued_at` DATETIME NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `work_order_status` (`work_order_id`, `status`),
    KEY `requested_by` (`requested_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create Material Request Items Table
CREATE TABLE IF NOT EXISTS `material_request_items` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `material_request_id` INT(11) UNSIGNED NOT NULL,
    `inventory_item_id` INT(11) UNSIGNED NULL,
    `item_code` VARCHAR(100) NOT NULL,
    `item_name` VARCHAR(255) NOT NULL,
    `quantity_requested` DECIMAL(10,2) NOT NULL,
    `quantity_approved` DECIMAL(10,2) NULL,
    `quantity_issued` DECIMAL(10,2) NULL,
    `unit` VARCHAR(50) NOT NULL,
    `unit_cost` DECIMAL(10,2) NULL,
    `total_cost` DECIMAL(10,2) NULL,
    `notes` TEXT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `material_request_id` (`material_request_id`),
    KEY `inventory_item_id` (`inventory_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create Material Issues Table
CREATE TABLE IF NOT EXISTS `material_issues` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `issue_number` VARCHAR(50) UNIQUE NOT NULL,
    `material_request_id` INT(11) UNSIGNED NOT NULL,
    `work_order_id` INT(11) UNSIGNED NULL,
    `issued_by` INT(11) UNSIGNED NOT NULL,
    `issued_to` INT(11) UNSIGNED NOT NULL,
    `issue_date` DATETIME NOT NULL,
    `total_cost` DECIMAL(10,2) NULL,
    `notes` TEXT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `material_request_id` (`material_request_id`),
    KEY `work_order_id` (`work_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Create Inventory Transactions Table
CREATE TABLE IF NOT EXISTS `inventory_transactions` (
    `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
    `transaction_number` VARCHAR(50) UNIQUE NOT NULL,
    `inventory_item_id` INT(11) UNSIGNED NOT NULL,
    `transaction_type` ENUM('receipt', 'issue', 'adjustment', 'transfer', 'return') DEFAULT 'issue',
    `quantity` DECIMAL(10,2) NOT NULL,
    `unit_cost` DECIMAL(10,2) NULL,
    `total_cost` DECIMAL(10,2) NULL,
    `reference_type` VARCHAR(50) NULL,
    `reference_id` INT(11) UNSIGNED NULL,
    `from_location_id` INT(11) UNSIGNED NULL,
    `to_location_id` INT(11) UNSIGNED NULL,
    `performed_by` INT(11) UNSIGNED NOT NULL,
    `transaction_date` DATETIME NOT NULL,
    `notes` TEXT NULL,
    `created_at` DATETIME NULL,
    `updated_at` DATETIME NULL,
    PRIMARY KEY (`id`),
    KEY `inventory_item_id` (`inventory_item_id`),
    KEY `transaction_type_date` (`transaction_type`, `transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
