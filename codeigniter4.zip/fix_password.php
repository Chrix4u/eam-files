<?php
$db = mysqli_connect('localhost', 'root', 'myjesus4mE', 'factory_manager');
if (!$db) die('Connection failed: ' . mysqli_connect_error());

$username = 'Chrix4u';
$newPassword = 'myjesus4me';

// Hash the password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

echo "New password hash: " . $hashedPassword . "\n\n";

// Update the password
$stmt = mysqli_prepare($db, "UPDATE users SET password = ? WHERE username = ?");
mysqli_stmt_bind_param($stmt, "ss", $hashedPassword, $username);

if (mysqli_stmt_execute($stmt)) {
    echo "✅ Password updated successfully\n\n";
    
    // Verify it works
    $result = mysqli_query($db, "SELECT password FROM users WHERE username = '$username'");
    $row = mysqli_fetch_assoc($result);
    
    if (password_verify($newPassword, $row['password'])) {
        echo "✅ Password verification: SUCCESS\n";
        echo "You can now login with:\n";
        echo "Username: $username\n";
        echo "Password: $newPassword\n";
    } else {
        echo "❌ Verification failed\n";
    }
} else {
    echo "❌ Error: " . mysqli_error($db) . "\n";
}

mysqli_close($db);
