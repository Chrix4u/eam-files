USE factory_manager;
DESCRIBE work_orders;
DESCRIBE maintenance_requests;
