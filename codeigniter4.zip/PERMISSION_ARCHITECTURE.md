# PERMISSION-BASED ARCHITECTURE RESTRUCTURE
## Enterprise EAM System - Scalable RBAC Implementation

---

## EXECUTIVE SUMMARY

**Current Problem:**
- Hardcoded role-based directories (admin/, technician/, operator/)
- Duplicate pages for each role
- Not scalable - adding new roles requires creating new directories
- Difficult to maintain and update

**Solution:**
- Single unified frontend with permission-based access control
- Dynamic UI rendering based on user permissions
- Centralized permission management
- Role-agnostic pages with permission checks

---

## ARCHITECTURE OVERVIEW

### 1. DATABASE LAYER
```
permissions (module, action, name, description)
roles (name, description, is_system_role)
role_permissions (role_id, permission_id)
user_roles (user_id, role_id)
```

### 2. MIDDLEWARE LAYER
```
PermissionMiddleware → Check user permissions before controller
ViewPermissionHelper → Check permissions in views
API Permission Guard → Protect API endpoints
```

### 3. CONTROLLER LAYER
```
BaseController with permission checking
Permission-aware controllers
Dynamic route protection
```

### 4. VIEW LAYER
```
Single unified views
Permission-based UI rendering
Dynamic menu generation
Feature toggling based on permissions
```

---

## PERMISSION STRUCTURE

### Module-Action Pattern
Format: `module.action`

Examples:
- `work_orders.view`
- `work_orders.create`
- `work_orders.update`
- `work_orders.delete`
- `work_orders.assign`
- `work_orders.approve`
- `work_orders.close`

### Permission Hierarchy
```
Module Level:
├── work_orders
│   ├── view (read)
│   ├── create (write)
│   ├── update (write)
│   ├── delete (write)
│   ├── assign (special)
│   ├── approve (workflow)
│   └── close (workflow)
├── assets
│   ├── view
│   ├── create
│   ├── update
│   └── delete
└── inventory
    ├── view
    ├── create
    ├── update
    ├── issue
    └── receive
```

---

## IMPLEMENTATION PHASES

### PHASE 1: Core Infrastructure (Week 1)
- [x] Database migrations for RBAC tables
- [ ] Permission service layer
- [ ] Permission middleware
- [ ] Permission helper functions
- [ ] Base controller with permission checks

### PHASE 2: Backend Restructure (Week 2)
- [ ] Unified controller structure
- [ ] Remove role-specific controllers
- [ ] Implement permission checks in all controllers
- [ ] API endpoint protection
- [ ] Audit logging for permission checks

### PHASE 3: Frontend Restructure (Week 3)
- [ ] Single unified view directory
- [ ] Permission-based UI components
- [ ] Dynamic menu generation
- [ ] Feature toggling in views
- [ ] Remove role-specific view directories

### PHASE 4: Permission Management UI (Week 4)
- [ ] Role management interface
- [ ] Permission assignment interface
- [ ] User role assignment
- [ ] Permission testing tools
- [ ] Audit trail viewer

---

## FILE STRUCTURE (NEW)

```
app/
├── Controllers/
│   ├── BaseController.php (with permission checks)
│   ├── WorkOrders/
│   │   └── WorkOrderController.php (unified)
│   ├── Assets/
│   │   └── AssetController.php (unified)
│   ├── Inventory/
│   │   └── InventoryController.php (unified)
│   └── Admin/
│       ├── RoleController.php
│       └── PermissionController.php
│
├── Services/
│   ├── Permission/
│   │   ├── PermissionService.php
│   │   ├── RoleService.php
│   │   └── PermissionCacheService.php
│   └── Auth/
│       └── AuthorizationService.php
│
├── Filters/
│   ├── PermissionFilter.php (main filter)
│   └── ApiPermissionFilter.php
│
├── Helpers/
│   ├── permission_helper.php
│   └── ui_permission_helper.php
│
├── Views/
│   ├── layouts/
│   │   ├── main.php (unified layout)
│   │   └── components/
│   │       ├── sidebar.php (dynamic menu)
│   │       └── permission_gate.php
│   ├── work_orders/
│   │   ├── index.php (unified)
│   │   ├── create.php (unified)
│   │   └── view.php (unified)
│   ├── assets/
│   │   └── ... (unified)
│   └── admin/
│       ├── roles/
│       │   ├── index.php
│       │   ├── create.php
│       │   └── permissions.php
│       └── permissions/
│           └── index.php
│
└── Config/
    └── Permissions.php (permission definitions)
```

---

## MIGRATION STRATEGY

### Step 1: Parallel Implementation
- Keep existing role-based structure
- Build new permission-based structure alongside
- Test thoroughly before switching

### Step 2: Gradual Migration
- Migrate one module at a time
- Start with non-critical modules
- Work Orders → Assets → Inventory → PM

### Step 3: Cutover
- Switch routing to new controllers
- Deprecate old role-based directories
- Monitor for issues

### Step 4: Cleanup
- Remove old role-based code
- Update documentation
- Train users

---

## PERMISSION DEFINITIONS

### Core Modules

#### Work Orders
- `work_orders.view` - View work orders
- `work_orders.create` - Create new work orders
- `work_orders.update` - Edit work orders
- `work_orders.delete` - Delete work orders
- `work_orders.assign` - Assign technicians
- `work_orders.approve` - Approve work orders
- `work_orders.close` - Close completed work orders
- `work_orders.reopen` - Reopen closed work orders

#### Assets
- `assets.view` - View assets
- `assets.create` - Create assets
- `assets.update` - Edit assets
- `assets.delete` - Delete assets
- `assets.transfer` - Transfer assets
- `assets.dispose` - Dispose assets

#### Inventory
- `inventory.view` - View inventory
- `inventory.create` - Add inventory items
- `inventory.update` - Edit inventory
- `inventory.delete` - Remove inventory
- `inventory.issue` - Issue materials
- `inventory.receive` - Receive materials
- `inventory.adjust` - Adjust stock levels
- `inventory.transfer` - Transfer between locations

#### Preventive Maintenance
- `pm.view` - View PM schedules
- `pm.create` - Create PM schedules
- `pm.update` - Edit PM schedules
- `pm.delete` - Delete PM schedules
- `pm.execute` - Execute PM tasks
- `pm.approve` - Approve PM plans

#### Reports
- `reports.view` - View reports
- `reports.export` - Export reports
- `reports.schedule` - Schedule reports
- `reports.custom` - Create custom reports

#### Users & Roles
- `users.view` - View users
- `users.create` - Create users
- `users.update` - Edit users
- `users.delete` - Delete users
- `roles.view` - View roles
- `roles.create` - Create roles
- `roles.update` - Edit roles
- `roles.delete` - Delete roles
- `permissions.assign` - Assign permissions

---

## ROLE TEMPLATES

### 1. System Administrator
**Permissions:** ALL (*)
**Description:** Full system access

### 2. Maintenance Manager
**Permissions:**
- work_orders.* (all)
- assets.* (all)
- pm.* (all)
- inventory.view, inventory.issue
- reports.* (all)
- users.view

### 3. Maintenance Supervisor
**Permissions:**
- work_orders.view, create, update, assign, approve
- assets.view, update
- pm.view, execute, approve
- inventory.view, issue
- reports.view, export

### 4. Maintenance Technician
**Permissions:**
- work_orders.view, update
- assets.view
- pm.view, execute
- inventory.view
- reports.view

### 5. Maintenance Planner
**Permissions:**
- work_orders.view, create, update
- assets.view
- pm.view, create, update
- inventory.view
- reports.view, export

### 6. Store Keeper
**Permissions:**
- inventory.* (all)
- work_orders.view
- assets.view
- reports.view

### 7. Operator
**Permissions:**
- work_orders.view, create
- assets.view
- production.create, view
- reports.view

---

## IMPLEMENTATION CHECKLIST

### Database
- [ ] Run permission migrations
- [ ] Seed default permissions
- [ ] Seed default roles
- [ ] Assign roles to existing users

### Backend
- [ ] Create PermissionService
- [ ] Create RoleService
- [ ] Update BaseController
- [ ] Create PermissionFilter
- [ ] Add permission checks to all controllers
- [ ] Update API authentication

### Frontend
- [ ] Create unified layouts
- [ ] Create permission helper functions
- [ ] Update all views with permission checks
- [ ] Create dynamic menu system
- [ ] Add permission-based UI components

### Admin Interface
- [ ] Role management CRUD
- [ ] Permission assignment interface
- [ ] User role assignment
- [ ] Permission testing tool
- [ ] Audit log viewer

### Testing
- [ ] Unit tests for PermissionService
- [ ] Integration tests for permission checks
- [ ] UI tests for permission-based rendering
- [ ] Load testing with permission checks
- [ ] Security audit

### Documentation
- [ ] Permission reference guide
- [ ] Role creation guide
- [ ] Migration guide for existing users
- [ ] API documentation update
- [ ] User training materials

---

## BENEFITS

### Scalability
- Add new roles without code changes
- Modify permissions without deployment
- Fine-grained access control

### Maintainability
- Single codebase for all users
- Centralized permission logic
- Easier to update and test

### Security
- Consistent permission enforcement
- Audit trail for all actions
- Principle of least privilege

### Flexibility
- Custom roles per organization
- Dynamic permission assignment
- Easy to adapt to changing requirements

---

## NEXT STEPS

1. Review and approve architecture
2. Set up development environment
3. Begin Phase 1 implementation
4. Create test cases
5. Start migration planning

---

**Document Version:** 1.0
**Date:** 2026-03-11
**Author:** CTO/Chief Software Architect
**Status:** READY FOR IMPLEMENTATION
