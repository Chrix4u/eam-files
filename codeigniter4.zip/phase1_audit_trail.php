<?php
require_once 'vendor/autoload.php';

$db = new mysqli('localhost', 'root', 'myjesus4mE', 'factory_manager');
if ($db->connect_error) die("Connection failed: " . $db->connect_error);

$sql = "CREATE TABLE IF NOT EXISTS survey_audit_trail (
    audit_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT NOT NULL,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    field_name VARCHAR(100),
    old_value TEXT,
    new_value TEXT,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    session_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_survey_audit (survey_id),
    INDEX idx_user_audit (user_id),
    INDEX idx_action_audit (action),
    INDEX idx_created_audit (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$db->query($sql) or die("Error: " . $db->error);

echo "✅ Audit Trail table created\n";
$db->close();
