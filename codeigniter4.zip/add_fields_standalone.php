<?php

$host = 'localhost';
$db = 'factorymanager';
$user = 'root';
$pass = '';

$mysqli = new mysqli($host, $user, $pass, $db);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Add fields one by one
$fields = [
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS is_breakdown BOOLEAN DEFAULT FALSE",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS technical_description TEXT NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS trade_activity ENUM('mechanical', 'electrical', 'civil', 'facility', 'workshop', 'other') DEFAULT 'mechanical'",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS delivery_date_required DATE NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS repair_started_date DATETIME NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS repair_ended_date DATETIME NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS technician_report TEXT NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS failure_description TEXT NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS cause_description TEXT NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS action_description TEXT NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS general_remarks TEXT NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS operator_signature VARCHAR(255) NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS line_manager_signature VARCHAR(255) NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS supervisor_signature VARCHAR(255) NULL",
    "ALTER TABLE work_orders ADD COLUMN IF NOT EXISTS downtime_hours DECIMAL(10,2) NULL"
];

foreach ($fields as $sql) {
    if ($mysqli->query($sql)) {
        echo "✓ Field added\n";
    } else {
        echo "Note: " . $mysqli->error . "\n";
    }
}

// Create materials table
$sql = "CREATE TABLE IF NOT EXISTS work_order_materials (
    id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    work_order_id INT(11) UNSIGNED NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    gt_code VARCHAR(100) NULL,
    description TEXT NOT NULL,
    quantity_issued DECIMAL(10,2) NOT NULL,
    remarks TEXT NULL,
    receiver_signature VARCHAR(255) NULL,
    store_clerk_signature VARCHAR(255) NULL,
    created_at DATETIME NULL,
    updated_at DATETIME NULL,
    FOREIGN KEY (work_order_id) REFERENCES work_orders(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($mysqli->query($sql)) {
    echo "✓ Materials table created\n";
} else {
    echo "Note: " . $mysqli->error . "\n";
}

$mysqli->close();
echo "\nDone!\n";
