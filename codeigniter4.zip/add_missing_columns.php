<?php
$host = 'localhost';
$db = 'factory_manager';
$user = 'root';
$pass = 'myjesus4mE';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Adding missing columns to work_orders table...\n\n";

// Add notes column
$sql1 = "ALTER TABLE work_orders ADD COLUMN notes TEXT NULL AFTER general_remarks";
if ($conn->query($sql1) === TRUE) {
    echo "✓ Added 'notes' column\n";
} else {
    if (strpos($conn->error, 'Duplicate column') !== false) {
        echo "- 'notes' column already exists\n";
    } else {
        echo "✗ Error adding 'notes': " . $conn->error . "\n";
    }
}

// Add location column
$sql2 = "ALTER TABLE work_orders ADD COLUMN location VARCHAR(255) NULL AFTER machine_id";
if ($conn->query($sql2) === TRUE) {
    echo "✓ Added 'location' column\n";
} else {
    if (strpos($conn->error, 'Duplicate column') !== false) {
        echo "- 'location' column already exists\n";
    } else {
        echo "✗ Error adding 'location': " . $conn->error . "\n";
    }
}

echo "\nDone!\n";

$conn->close();
