# EAM System Architecture - File Reorganization Blueprint

## 🏗️ TARGET MODULAR STRUCTURE

```
app/
├── Controllers/Api/V1/
│   ├── Modules/
│   │   ├── RWOP/
│   │   │   ├── WorkOrderController.php
│   │   │   ├── MaintenanceRequestController.php
│   │   │   ├── CompletionController.php
│   │   │   ├── TeamController.php
│   │   │   └── AssistanceRequestController.php
│   │   ├── MRMP/
│   │   │   ├── PmController.php
│   │   │   ├── CalibrationController.php
│   │   │   ├── IoTController.php
│   │   │   └── PredictiveController.php
│   │   ├── MPMP/
│   │   │   ├── ProductionController.php
│   │   │   ├── OEEController.php
│   │   │   ├── DowntimeController.php
│   │   │   └── SurveyController.php
│   │   ├── IMS/
│   │   │   ├── InventoryController.php
│   │   │   ├── PartsController.php
│   │   │   ├── MaterialRequestController.php
│   │   │   └── VendorsController.php
│   │   ├── HRMS/
│   │   │   ├── UsersController.php
│   │   │   ├── ShiftsController.php
│   │   │   ├── TrainingController.php
│   │   │   └── SkillsController.php
│   │   ├── TRAC/
│   │   │   ├── ToolsController.php
│   │   │   ├── LOTOController.php
│   │   │   └── PermitsController.php
│   │   ├── ASSET/
│   │   │   ├── EquipmentController.php
│   │   │   ├── FacilitiesController.php
│   │   │   ├── AssembliesController.php
│   │   │   └── BOMController.php
│   │   └── CORE/
│   │       ├── AuthController.php
│   │       ├── AnalyticsController.php
│   │       ├── ReportsController.php
│   │       └── AuditController.php
│   └── [Legacy controllers remain for backward compatibility]
│
├── Services/
│   ├── RWOP/
│   │   ├── WorkOrderService.php ✅
│   │   ├── MaintenanceRequestService.php
│   │   ├── CompletionService.php
│   │   └── ShiftHandoverService.php ✅
│   ├── MRMP/
│   │   ├── PMService.php
│   │   ├── CalibrationService.php
│   │   └── PredictiveService.php
│   ├── MPMP/
│   │   ├── ProductionService.php
│   │   ├── OEEService.php ✅
│   │   └── DowntimeService.php
│   ├── IMS/
│   │   ├── InventoryService.php
│   │   └── StockMovementService.php
│   ├── HRMS/
│   │   ├── EmployeeService.php
│   │   └── ShiftService.php
│   ├── TRAC/
│   │   └── ToolService.php
│   ├── ASSET/
│   │   ├── AssetService.php ✅
│   │   └── BOMService.php ✅
│   └── CORE/
│       ├── AuthService.php
│       ├── AuditService.php ✅
│       └── ModuleService.php ✅
│
├── Models/
│   ├── RWOP/
│   │   ├── WorkOrderModel.php
│   │   ├── MaintenanceRequestModel.php
│   │   ├── WorkOrderTeamMemberModel.php
│   │   └── AssistanceRequestModel.php
│   ├── MRMP/
│   │   ├── PmScheduleModel.php
│   │   ├── CalibrationModel.php
│   │   └── IoTDeviceModel.php
│   ├── MPMP/
│   │   ├── ProductionRunModel.php
│   │   ├── OeeModel.php
│   │   └── DowntimeEventModel.php
│   ├── IMS/
│   │   ├── InventoryItemModel.php
│   │   ├── PartModel.php
│   │   └── MaterialRequestModel.php
│   ├── HRMS/
│   │   ├── UserModel.php
│   │   ├── ShiftModel.php
│   │   └── TrainingRecordModel.php
│   ├── TRAC/
│   │   ├── ToolModel.php
│   │   └── LOTOModel.php
│   ├── ASSET/
│   │   ├── MachineModel.php
│   │   ├── FacilitiesModel.php
│   │   └── BOMModel.php
│   └── CORE/
│       ├── AuditLogModel.php
│       └── NotificationModel.php
│
└── Repositories/
    ├── RWOP/
    │   └── WorkOrderRepository.php
    ├── MRMP/
    │   └── PMRepository.php
    ├── MPMP/
    │   └── ProductionRepository.php
    ├── IMS/
    │   └── InventoryRepository.php
    ├── HRMS/
    │   └── EmployeeRepository.php
    ├── TRAC/
    │   └── ToolRepository.php
    ├── ASSET/
    │   └── AssetRepository.php
    └── CORE/
        └── AuditRepository.php
```

## 📋 FILE MAPPING

### RWOP Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| WorkOrdersController.php | Modules/RWOP/WorkOrderController.php | Move |
| WorkOrderCompletionController.php | Modules/RWOP/CompletionController.php | Move |
| MaintenanceRequestController.php | Modules/RWOP/MaintenanceRequestController.php | Move |
| WorkOrderTeamController.php | Modules/RWOP/TeamController.php | Move |
| AssistanceRequestController.php | Modules/RWOP/AssistanceRequestController.php | Move |
| Services/RWOP/WorkOrderService.php | ✅ Already in place | - |
| Services/RWOP/ShiftHandoverService.php | ✅ Already in place | - |

### MRMP Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| PmController.php | Modules/MRMP/PmController.php | Move |
| CalibrationController.php | Modules/MRMP/CalibrationController.php | Move |
| IoTDevicesController.php | Modules/MRMP/IoTController.php | Move |
| PredictiveController.php | Modules/MRMP/PredictiveController.php | Move |

### MPMP Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| ProductionController.php | Modules/MPMP/ProductionController.php | Move |
| OEEController.php | Modules/MPMP/OEEController.php | Move |
| DowntimeController.php | Modules/MPMP/DowntimeController.php | Move |
| ProductionSurvey/* | Modules/MPMP/SurveyController.php | Move |

### IMS Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| EamInventoryController.php | Modules/IMS/InventoryController.php | Move |
| EamPartsController.php | Modules/IMS/PartsController.php | Move |
| MaterialRequestController.php | Modules/IMS/MaterialRequestController.php | Move |
| VendorsController.php | Modules/IMS/VendorsController.php | Move |

### HRMS Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| EamUsersController.php | Modules/HRMS/UsersController.php | Move |
| ShiftsController.php | Modules/HRMS/ShiftsController.php | Move |
| TrainingRecordsController.php | Modules/HRMS/TrainingController.php | Move |
| SkillsController.php | Modules/HRMS/SkillsController.php | Move |

### TRAC Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| ToolsController.php | Modules/TRAC/ToolsController.php | Move |
| LOTOController.php | Modules/TRAC/LOTOController.php | Move |
| PermitToWorkController.php | Modules/TRAC/PermitsController.php | Move |

### ASSET Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| EamEquipmentController.php | Modules/ASSET/EquipmentController.php | Move |
| EamFacilitiesController.php | Modules/ASSET/FacilitiesController.php | Move |
| EamAssembliesController.php | Modules/ASSET/AssembliesController.php | Move |
| BillOfMaterialsController.php | Modules/ASSET/BOMController.php | Move |

### CORE Module
| Current Location | New Location | Status |
|------------------|--------------|--------|
| EamAuthController.php | Modules/CORE/AuthController.php | Move |
| AnalyticsController.php | Modules/CORE/AnalyticsController.php | Move |
| ReportsController.php | Modules/CORE/ReportsController.php | Move |
| AuditLogsController.php | Modules/CORE/AuditController.php | Move |

## 🔄 MIGRATION STRATEGY

### Phase 1: Create Directory Structure ✅
```bash
mkdir -p app/Controllers/Api/V1/Modules/{RWOP,MRMP,MPMP,IMS,HRMS,TRAC,ASSET,CORE}
mkdir -p app/Services/{MRMP,MPMP,IMS,HRMS,TRAC}
mkdir -p app/Models/{RWOP,MRMP,MPMP,IMS,HRMS,TRAC,ASSET,CORE}
mkdir -p app/Repositories/{RWOP,MRMP,MPMP,IMS,HRMS,TRAC,ASSET,CORE}
```

### Phase 2: Copy Controllers (Non-Destructive)
- Copy files to new locations
- Update namespaces
- Keep originals as forwarders

### Phase 3: Update Routes
- Point routes to new controller locations
- Maintain backward compatibility

### Phase 4: Organize Models
- Move models to module folders
- Update namespaces

### Phase 5: Testing
- Test all endpoints
- Verify backward compatibility
- Check module access control

### Phase 6: Cleanup (Optional)
- Remove old controllers after verification
- Archive legacy code

## ✅ BENEFITS

1. **Clear Module Boundaries** - Each module is self-contained
2. **Easy Navigation** - Find files by module quickly
3. **Scalability** - Add new modules easily
4. **Maintainability** - Changes isolated to modules
5. **Team Collaboration** - Teams can own modules
6. **Testing** - Test modules independently
7. **Documentation** - Module structure is self-documenting

## 🎯 NEXT STEPS

1. Execute directory creation
2. Copy RWOP controllers first (pilot)
3. Update RWOP routes
4. Test RWOP module
5. Repeat for other 7 modules
6. Final verification

**Estimated Time**: 2-3 hours for complete reorganization
